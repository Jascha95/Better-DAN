import os

from flask import Flask, render_template, request, g, jsonify
import psycopg


app = Flask(__name__)
app.config.from_pyfile('.env')
def get_db():
    if not hasattr(g, 'db'):
        g.db = psycopg.connect(
            host=app.config["DB_HOST"],
            dbname=app.config["DB_NAME"],
            user=app.config["DB_USER"],
            password=app.config["DB_PASSWORD"],
            port=app.config["DB_PORT"]
        )
    return g.db


@app.route('/get_data', methods=['GET'])
def get_data():
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT message FROM messages')
    data = cursor.fetchall()
    cursor.close()
    return jsonify(data)

@app.route('/')
def message_board():
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute('SELECT * FROM messages ORDER BY created_on DESC LIMIT 3')
        prev_posts = cur.fetchall()
    except Exception as e:
        print(e)
        cur.close()
        return 'Error while fetching from database'
    cur.close()

    return render_template('board.html', posts=prev_posts)


@app.route('/editor')
def message_editor():
    return render_template('editor.html')


@app.post('/post-message')
def post_message():
    if request.form["submit"]:
        #displayname = request.form["displayname"]
        message = request.form["message"]
        db = get_db()
        cur = db.cursor()
        try:
            cur.execute("INSERT INTO messages (message, created_on) VALUES (%s,NOW())",
                        (message,))
            db.commit()
            cur.close()
            return app.redirect("/")
        except Exception as e:
            print(e)
            cur.close()
            return "Error while querying the database"

def close_db(error):
    if hasattr(g, 'db'):
        g.db.close()

if __name__ == '__main__':
    app.run(debug=True)