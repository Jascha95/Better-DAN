

// An array containing various emojis for the user to choose from.
const emojis = [
  "😀",
  "😃",
  "😄",
  "😁",
  "😆",
  "😅",
  "🤣",
  "😂",
  "🙂",
  "🙃",
  "🫠",
  "😉",
  "😊",
  "😇",
  "🥰",
  "😍",
  "🤩",
  "😘",
  "😗",
  "😚",
  "😙",
  "🥲",
  "😋",
  "😛",
  "😜",
  "🤪",
  "😝",
  "🤑",
  "🤗",
  "🤭",
  "🫢",
  "🫣",
  "🤫",
  "🤔",
  "🫡",
  "🤐",
  "🤨",
  "😐",
  "😑",
  "😶",
  "🫥",
  "😶",
  "😏",
  "😒",
  "🙄",
  "😬",
  "😮",
  "🤥",
  "😌",
  "😔",
  "😪",
  "🤤",
  "😴",
  "😷",
  "🤒",
  "🤕",
  "🤢",
  "🤮",
  "🤧",
  "🥵",
  "🥶",
  "🥴",
  "😵",
  "😵",
  "🤯",
  "🤠",
  "🥳",
  "🥸",
  "😎",
  "🤓",
  "🧐",
  "😕",
  "🫤",
  "😟",
  "🙁",
  "☹️ ",
  "😮",
  "😯",
  "😲",
  "😳",
  "🥺",
  "🥹",
  "😦",
  "😧",
  "😨",
  "😰",
  "😥",
  "😢",
  "😭",
  "😱",
  "😖",
  "😣",
  "😞",
  "😓",
  "😩",
  "😫",
  "🥱",
  "😤",
  "😡",
  "😠",
  "🤬",
  "😈",
  "👿",
];

// Get a reference to the HTML elements we will interact with.
const emojiContainer = document.querySelector(".emoji-container"); // Container to display emoji buttons
const messageElement = document.getElementById("message"); // Text input field for the message

// Function to insert the selected emoji into the message input field.
function insertEmoji(emoji) {
  messageElement.value += emoji;
}

// Function to load and display emoji buttons in the emoji container.
function loadEmojis() {
  for (let i = 0; i < emojis.length; i++) {
    let btn = document.createElement("button");

    // Add a click event listener to each emoji button to insert the emoji into the message input field.
    btn.addEventListener("click", function () {
      insertEmoji(emojis[i]);
    });

    // Set the button's text to the emoji and add a "btn" class for styling.
    btn.innerText = emojis[i];
    btn.classList.add("btn");

    // Append the button to the emoji container.
    emojiContainer.appendChild(btn);
  }
}

// Toggle the visibility of the emoji container when the "show emojis" button is clicked.
document.querySelector("#show-emojis").addEventListener("click", (e) => {
  e.preventDefault();
  if (emojiContainer.style.display === "block") {
    emojiContainer.style.display = "none";
  } else {
    emojiContainer.style.display = "block";
  }
});

// (Commented out) A button to send the message - functionality not implemented in this code.
// const sendButton = document.querySelector("#send-message");
// sendButton.addEventListener("click", () => {
//   // Simulate a posting action.
//   sendButton.disabled = true;
//   sendButton.innerText = "posting...";

//   window.setTimeout(() => {
//     messageElement.value = "";
//     sendButton.innerText = "post!";
//     sendButton.disabled = false;
//   }, 1000);
// });

// Load and display the emoji buttons when the page loads.
loadEmojis();
