const randomButton = document.getElementById('randomButton');
const dataDisplay = document.getElementById('dataDisplay');
const closeDisplayButton = document.getElementById('close_dispay');
let fetchedData = null;

// Add a click event listener to the button
randomButton.addEventListener('click', function() {
  if (fetchedData) {
    // Check if data has been fetched
    const randomIndex = Math.floor(Math.random() * fetchedData.length);
    const randomDataPoint = fetchedData[randomIndex];
    console.log(randomDataPoint)
    dataDisplay.textContent = JSON.stringify(randomDataPoint);
  } else {
    // Handle the case where data hasn't been fetched yet
    dataDisplay.textContent = 'Data has not been fetched yet.';
  }
});
closeDisplayButton.addEventListener('click', function() {
    dataDisplay.textContent = ''; // Clear the content of dataDisplay
  });

// fetch the data, you turned into a jason format with the get_data function in the app file
fetch('/get_data')
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.json();
  })
  .then(data => {
    fetchedData = data;
  })
  .catch(error => {
    // Handle errors
    console.error('Error:', error);
  });
