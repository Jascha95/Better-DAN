const emojis = [
    "😀", "😃", "😄", "😁", "😆", "😅", "🤣", "😂", "🙂", "🙃", "🫠", "😉", "😊", "😇", "🥰", "😍", "🤩", "😘", "😗", "😚",
    "😙", "🥲", "😋", "😛", "😜", "🤪", "😝", "🤑", "🤗", "🤭", "🫢", "🫣", "🤫", "🤔", "🫡", "🤐", "🤨", "😐", "😑", "😶",
    "🫥", "😶", "😏", "😒", "🙄", "😬", "😮", "🤥", "😌", "😔", "😪", "🤤", "😴", "😷", "🤒", "🤕", "🤢", "🤮", "🤧", "🥵",
    "🥶", "🥴", "😵", "😵", "🤯", "🤠", "🥳", "🥸", "😎", "🤓", "🧐", "😕", "🫤", "😟", "🙁", "☹️", "😮", "😯", "😲", "😳",
    "🥺", "🥹", "😦", "😧", "😨", "😰", "😥", "😢", "😭", "😱", "😖", "😣", "😞", "😓", "😩", "😫", "🥱", "😤", "😡", "😠",
    "🤬", "😈", "👿"
];

        // Get references to the button and emoji display div
        const emojiButton = document.getElementById('emoji-button');
        const emojiDisplay = document.getElementById('emoji-display');

        // Add a click event listener to the button
        emojiButton.addEventListener('click', function () {
            // Generate a random index to select a random emoji
            const randomIndex = Math.floor(Math.random() * emojis.length);

            // Get the emoji at the random index and display it
            const randomEmoji = emojis[randomIndex];
            emojiDisplay.textContent = randomEmoji;
        });