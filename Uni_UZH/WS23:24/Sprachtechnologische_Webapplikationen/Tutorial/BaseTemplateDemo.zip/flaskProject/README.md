# Example Flask App

## Overview

A simple Flask application that demonstrates how to extend base templates.


## Getting Started

1. Create a virtual environment and activate it
```
python -m venv env
source env/bin/activate
```

2. Install the required Python packages
```
pip install -r requirements.txt
```

3. Run the Flask application
```
python app.py
```

4. Access the Flask application at http://localhost:5000