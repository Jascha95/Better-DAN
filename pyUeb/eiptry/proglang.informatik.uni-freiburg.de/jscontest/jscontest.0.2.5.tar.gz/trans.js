/* 
Copyright 2010 Phillip Heidegger. All rights reserved.
   
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY PHILLIP HEIDEGGER ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL PHILLIP HEIDEGGER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation
are those of the authors and should not be interpreted as representing
official policies, either expressed or implied, of Phillip Heidegger.
*/

/** version 0.1.2 */

var TRANS = 
  (function () {

    // PRIVATE VARS

    var undoLog = new Array();

    // array 
    //    ( { proto:   object the method is assigned by the browser 
    //        undo:    undo factory method for the method m
    //        doApply: used instead of m.apply(object,params) if spezified
    //        method:  the method itself
    //      } )
    var undoFactory = [];
    
    function collectMethodsPlain(methods) {
      // if the object contains the method itself,
      // we are at the correct prototype, which we should
      // store in our global undoFactory. This will allow
      // us later to use instanceof togehter with the 
      // object and the prototype to check if we need to
      // register an undo entry in the undoLog.

      // === verwenden um functionen zu vergleichen
      for (mname in methods) {
        if (this.hasOwnProperty(mname) && this[mname] && 
            typeof this[mname] === 'function') {
          var undoObj = { proto: this, 
                          undo: methods[mname], 
                          method: this[mname],
          };
          undoFactory.push(undoObj);
        };
      };
    };
    
    function collectMethodsDeep(methods) {
      collectMethodsPlain.apply(this,[methods]);
      // the property is part of an parent object, so we will
      // secure it in a recursive call
      
      // if (e.__proto__ != e.constructor.prototype) {
      // This will hopefully never happen. If it does,
      // this means the not standard property __proto__ 
      // behaves not equal to the constructor.prototype
      // This can happen, if the programmer changes the
      // prototype property of functions after use them
      // as constructors. :(((
      // In this case, there is no way to detect for sure
      // the prototype of the object, so maybe we should
      // then raise an error here??
      // } else {
      if ((this.__proto__) && (this.__proto__ != this)) {
        collectMethodsDeep.apply(this.__proto__,[methods]);
      }
      // }
    };

    function getUndoFactoryForMethod(m) {
      if (undoFactory) {
        for (var i = 0; i < undoFactory.length; ++i) {
          if (undoFactory[i].method === m) {
            return undoFactory[i].undo;
          }
        }
      }
      return false;
    }

    function getUndoFactoryForObject(obj,mname) {
      return getUndoFactoryForMethod(obj[mname]);
    };

    function initLibrary() {
      // PRIVATE variables 
      // ELEMENTS
      var elements = { 
        ul: { 
          appendChild: function(node) { 
            function undo() {
              if (oldParent) {
                oldParent.insertBefore(node,oldnS);
              } else {
                parent.removeChild(node);
              }
            }
            var parent = this;
            var oldParent = node.parent;
            var oldnS = node.nextSibling;
            return undo;
          },
          removeChild: function(node) {
            function undo() {
              if (parent) {
                parent.insertBefore(node,next);          
              }
            }
            var parent = this;
            var next = node.nextSibling;
            return undo; 
          },
          insertBefore: function(node,next) {
            function undo() {
              if (oldParent) {
                oldParent.insertBefore(node,oldnS);
              } else {
                parent.removeChild(node);
              }
            }
            var parent = this;
            var oldParent = node.parent;
            var oldnS = node.nextSibling;
            return undo;
          },
        },
      };

      for (p in elements) {
        var sampleObject = document.createElement(p);
        collectMethodsDeep.apply(sampleObject,[elements[p]]);
      };  
      
      
      undoLog = new Array();
    }

    function revert() {
      for (var i = undoLog.length - 1; i > -1; --i) {
        undoLog[i]();
      };
      undoLog = new Array();
    };
    
    function doPropAssignment(object,prop,righthandside,operator_lambda) {
      function createUndoProp(object,prop,value) {
        return (function () { object[prop] = value });
      };
      var old_value = object[prop];
      var new_value = righthandside;
      if (operator_lambda) {
        new_value = operator_lambda(old_value,righthandside);
      }
      undoLog.push(createUndoProp(object,prop,old_value));
      object[prop] = new_value;
      return undefined;
    };

    function doMCall(method,object,params) {

      // if method is equal to the call method,
      // remove one indirection
      if (method === Function.call) {
        var nparams = [];
        for (var i = 1; i < params.length; ++i) {
          nparams.push(params[i]);
        };
        return doMCall(object,params[0],nparams);
      }

      // if method is the apply method, remove one
      // indirection
      if (method === Function.apply) {
        return doMCall(object,params[0],params[1]);
      };

      // the method is a usual method, so test for
      // undo and call it afterwards
      var undoFactory = getUndoFactoryForMethod(method);
      if (undoFactory) {
        var undoFunction = undoFactory.apply(object,params);
        if (undoFunction) undoLog.push(undoFunction);
      };
      return method.apply(object,params);

    }

    function doMethodCall(object,methodname,params) {
      return doMCall(object[methodname],object,params);
    }
    function pushUndo(undoLambda) {
      undoLog.push(undoLambda);
    };
    
    var result = 
      { initLibrary: initLibrary, 
        revert: revert,
        doPropAssignment: doPropAssignment,
        doMethodCall: doMethodCall,
        pushUndo: pushUndo,
      };
    return result;
  })();
