JSConTest.events.register(JSConTest.events.handler.data.create("checker"));  
