 /*c undefined -> undefined  */ 
function deltaBlue() { 
	var o = {};
     o.direction = -1;
	if (!( o.direction != 0)) {
			throw("EORRRORORORO!");
	}

}
