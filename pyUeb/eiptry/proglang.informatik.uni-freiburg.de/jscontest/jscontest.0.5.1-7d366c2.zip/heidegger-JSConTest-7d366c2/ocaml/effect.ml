type t =
  | Default
  | NoTrans
  | OnlyEffect
  | All
