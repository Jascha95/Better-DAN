#!/bin/sh
BN=`basename $1 .test.js`
if [ $BN != $1 ] 
then
    echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" ' >> $BN.html
    echo '         "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">' >> $BN.html
    echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">' >> $BN.html
    echo '  <head>' >> $BN.html
    echo '    <title>Test Framework</title>' >> $BN.html
    echo '    <meta http-equiv="Content-Script-Type" content="text/javascript"/>' >> $BN.html
    echo '    <link href="style.css" rel="stylesheet" type="text/css" />' >> $BN.html
    echo '    <script type="text/javascript" src="testsrandom.js"></script>' >> $BN.html
    echo '    <script type="text/javascript" src="'$BN'.test.js"></script>' >> $BN.html
    echo '    <script type="text/javascript">' >> $BN.html
    echo '      var l1 = TESTS.createWebLogger("'$BN'");' >> $BN.html
    echo '      TESTS.registerLogger(l1);' >> $BN.html
    echo '    </script>' >> $BN.html
    echo '  </head>' >> $BN.html
    echo '  <body onload="TESTS.run(l1.send_stat)">' >> $BN.html
    echo '    <h1>Test Framework</h1>' >> $BN.html
    echo '    <div id="logger"></div>' >> $BN.html
    echo '  </body>' >> $BN.html
    echo '</html>' >> $BN.html
fi