package de.uni_freiburg.informatik.proglang.mservlets.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import de.uni_freiburg.informatik.proglang.mservlets.interfaces.HttpConstants;
import de.uni_freiburg.informatik.proglang.mservlets.interfaces.MServlet;
import de.uni_freiburg.informatik.proglang.mservlets.interfaces.MServletRequest;
import de.uni_freiburg.informatik.proglang.mservlets.interfaces.MServletResponse;
import de.uni_freiburg.informatik.proglang.mservlets.interfaces.MSession;
import de.uni_freiburg.informatik.proglang.mservlets.interfaces.RequestFileParameter;

public class ExampleServlet implements MServlet {

    public void doGet(MServletRequest req, MServletResponse resp) {
        String expectedPath = "/servlets/login.do";
        String path = req.getServletPath();
        if (!expectedPath.equals(path)) {
            throw new RuntimeException("req.getServletPath() returned " + path + ", expected: " + expectedPath);
        }
        String user = req.getParameter("user").getValue();
        String pass = req.getParameter("pass").getValue();
        if (! "demo".equals(pass)) {
            resp.sendError(HttpConstants.HTTP_FORBIDDEN, "access denied for user " + user + " with password " + pass);
        }
        MSession session = req.getSession();
        if (! session.isNew()) {
            throw new RuntimeException("session should be new when doing login");
        }
        session.setAttribute("user", user);
        resp.setContentType("text/html");
        PrintWriter out = null;
        try {
            out = resp.getWriter();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("unexpected IOException when retrieving writer: " + e.getMessage());
        }
        String url = req.encodeURL("/servlets/upload.do");
        out.println("<html><title>Upload</title><body><h1>Upload some file</h1>");
        out.println("<form enctype=\"multipart/form-data\" method=\"post\" action=\"" + url + "\">");
        out.println("<input type=\"file\" name=\"file\">");
        out.println("Comment: <input type=\"text\" name=\"comment\"/>");
        out.println("<input type=\"submit\" name=\"submit\" value=\"Upload\">");
        out.println("</form></body></html>");
    }

    public void doPost(MServletRequest req, MServletResponse resp) {
        String expectedPath = "/servlets/upload.do";
        String path = req.getServletPath();
        if (!expectedPath.equals(path)) {
            throw new RuntimeException("req.getServletPath() returned " + path + ", expected: " + expectedPath);
        }
        String comment = req.getParameter("comment").getValue();
        RequestFileParameter file = (RequestFileParameter) req.getParameter("file");
        MSession session = req.getSession();
        if (session.isNew()) {
            throw new RuntimeException("session should not be new when doing upload");
        }
        String user = (String) session.getAttribute("user");
        resp.setContentType("text/plain");
        PrintWriter out = null;
        try {
            out = resp.getWriter();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("unexpected IOException when retrieving writer: " + e.getMessage());
        }
        out.println("Hello " + user + "!");
        out.println("original file name: " + file.getValue());
        out.println("content type: " + file.getContentType());
        out.println("comment: " + comment);
        if (file.getContentType().startsWith("text/")) {
            out.println("---------------------------------------------------------");
            BufferedReader in = new BufferedReader(new InputStreamReader(file.getInputStream()));
            try {
                String line = in.readLine();
                while (line != null) {
                    out.println(line);
                    line = in.readLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
                out.println("unexpected exception while reading contents of uploaded file: " + e.getMessage());
            }
            out.println("---------------------------------------------------------");
        }
    }

}
