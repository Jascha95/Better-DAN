package de.uni_freiburg.informatik.proglang.mservlets.interfaces;

import java.util.Iterator;

/**
 * Defines an object to provide client request information to a servlet.
 */
public interface MServletRequest {
	
	/**
	 * Returns the part of this request's URL that calls the servlet. This path
	 * starts with a "/" character and includes either the servlet name or a
	 * path to the servlet, but does not include any extra path information or a
	 * query string. Same as the value of the CGI variable SCRIPT_NAME.
	 */
	public String getServletPath();

	/**
	 * Returns the current session associated with this request, or if the
	 * request does not have a session, creates one.
	 */
	public MSession getSession();

	/**
	 * Returns the value of a request parameter, or null if the parameter does
	 * not exist. Request parameters are extra information sent with the
	 * request. For HTTP servlets, parameters are contained in the query string
	 * or posted form data.
	 * 
	 * You should only use this method when you are sure the parameter has only
	 * one value. If the parameter might have more than one value, use
	 * getParameterValues(String).
	 * 
	 * If you use this method with a multivalued parameter, the value returned
	 * is equal to the first value in the array returned by getParameterValues.
	 * 
	 */
	public RequestParameter getParameter(String name);

	/**
	 * Returns an array of RequestParameter objects containing all of the values
	 * the given request parameter has, or null if the parameter does not exist.
	 * 
	 * If the parameter has a single value, the array has a length of 1.
	 * 
	 */
	public RequestParameter[] getParameterValues(String name);

	/**
	 * Returns an Enumeration of RequestParameter objects containing the names
	 * of the parameters contained in this request. If the request has no
	 * parameters, the method returns an empty Enumeration.
	 */
	public Iterator<RequestParameter> getParameterNames();

	/**
	 * Encodes the specified URL by including the session ID in it, or, if
	 * encoding is not needed, returns the URL unchanged. The implementation of
	 * this method includes the logic to determine whether the session ID needs
	 * to be encoded in the URL.
	 */
	public String encodeURL(String url);
}
