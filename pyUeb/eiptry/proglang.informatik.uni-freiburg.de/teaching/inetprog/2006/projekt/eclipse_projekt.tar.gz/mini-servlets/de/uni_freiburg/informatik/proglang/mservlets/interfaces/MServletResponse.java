package de.uni_freiburg.informatik.proglang.mservlets.interfaces;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;

/** 
 * Defines an object to assist a servlet in sending a response to the client. 
 */
public interface MServletResponse {

	/**
	 * Sends an error response to the client using the specified status. The
	 * server defaults to creating the response to look like an HTML-formatted
	 * server error page containing the specified message, setting the content
	 * type to "text/html", leaving other headers unmodified.
	 * 
	 * If the response has already been committed, this method throws an
	 * IllegalStateException. After using this method, the response should be
	 * considered to be committed and should not be written to.
	 */
	public void sendError(int status, String msg);

	/**
	 * Sets the content type of the response being sent to the client, if the
	 * response has not been committed yet. The given content type may include a
	 * character encoding specification, for example,
	 * <code>text/html;charset=UTF-8</code>. The response's character
	 * encoding is only set from the given content type if this method is called
	 * before getWriter is called.
	 * 
	 * This method may be called repeatedly to change content type and character
	 * encoding. This method has no effect if called after the response has been
	 * committed. It does not set the response's character encoding if it is
	 * called after getWriter has been called or after the response has been
	 * committed.
	 * 
	 * Containers must communicate the content type and the character encoding
	 * used for the servlet response's writer to the client if the protocol
	 * provides a way for doing so. In the case of HTTP, the Content-Type header
	 * is used.
	 */
	public void setContentType(String type);

	/**
	 * Returns a PrintWriter object that can send character text to the client.
	 * The PrintWriter uses the character encoding set via setContentType. If
	 * the response's character encoding has not been specified, getWriter uses
	 * ISO-8859-1.
	 * 
	 * Calling flush() on the PrintWriter commits the response.
	 * 
	 * Either this method or getOutputStream() may be called to write the body,
	 * not both.
	 */
	public PrintWriter getWriter() throws IOException;

	/**
	 * Returns an OutputStream suitable for writing binary data in the response.
	 * The servlet container does not encode the binary data.
	 * 
	 * Calling flush() on the ServletOutputStream commits the response. Either
	 * this method or getWriter() may be called to write the body, not both.
	 * 
	 */
	public PrintStream getOutputStream() throws IOException;
}
