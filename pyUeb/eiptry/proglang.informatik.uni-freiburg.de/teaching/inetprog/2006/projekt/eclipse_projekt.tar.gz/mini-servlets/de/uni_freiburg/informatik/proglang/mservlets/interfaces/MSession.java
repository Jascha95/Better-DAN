package de.uni_freiburg.informatik.proglang.mservlets.interfaces;

import java.util.Iterator;

/**
 * 
 * Provides a way to identify a user across more than one page request or visit
 * to a Web site and to store information about that user.
 * 
 * The servlet container uses this interface to create a session between an HTTP
 * client and an HTTP server. The session persists for a specified time period,
 * across more than one connection or page request from the user. A session
 * usually corresponds to one user, who may visit a site many times.
 */
public interface MSession {

	/**
	 * Returns the object bound with the specified name in this session, or null
	 * if no object is bound under the name.
	 */
	public Object getAttribute(String name);

	/**
	 * Binds an object to this session, using the name specified. If an object
	 * of the same name is already bound to the session, the object is replaced.
	 */
	public void setAttribute(String name, Object value);

	/**
	 * Returns an Iterator of String objects containing the names of all the
	 * objects bound to this session.
	 */
	public Iterator<String> getAttributeNames();

	/**
	 * Returns true if the client does not yet know about the session or if the
	 * client chooses not to join the session.
	 */
	public boolean isNew();
}
