package de.uni_freiburg.informatik.proglang.mservlets.interfaces;

/**
 * Represents a parameter of a GET or POST request passed to a servlet. The
 * subinterface RequestFileParameter is used to handle file uploads parameters.
 */
public interface RequestParameter {

	/**
	 * Returns the name of the request parameter.
	 */
	public String getName();

	/**
	 * Returns the value of the request parameter. For a RequestFileParameter,
	 * this is the original name of the file.
	 */
	public String getValue();
}
