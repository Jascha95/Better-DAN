package de.uni_freiburg.informatik.proglang.mservlets.interfaces;

import java.io.InputStream;

/**
 * Represents a file upload parameter of a GET or POST request passed to a
 * servlet.
 */
public interface RequestFileParameter extends RequestParameter {
	
	/**
	 * Returns the content type of the uploaded file.
	 */
	public String getContentType();

	/**
	 * Returns an input stream from which the file's data can be read.
	 */
	public InputStream getInputStream();
}
