package proglang.j2ee.exceptions;

public class BookException extends Exception{
	 
	private static final long serialVersionUID = 1L;

	public BookException() {
	
	}

    public BookException(String msg) {
    	super(msg);
	}
}
