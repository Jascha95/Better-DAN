/**
 * 
 */
package proglang.j2ee.helpers;

import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.naming.Context;
import javax.naming.InitialContext;

import proglang.j2ee.ejbs.BookValue;

/**
 * @author Tobias Langner
 * 
 * The purpose of this class is to provide convenience methods for accessing
 * jms targets of the Bookstore.
 */
public class JmsHelper
{
	/**
	 * Submits a new Order by sending it to the order queue where it gets
	 * asynchronously processed by ProcessOrderBean.
	 * 
	 * @param customer The customer whose order is to be submitted.
	 * @param shoppingCart The shopping cart containing the bought item.  
	 */
	public static boolean submitOrder(PlacedOrder order)
	{
		Context jndiContext = null;
		QueueConnectionFactory factory = null;
		QueueConnection connect;
		QueueSession queueSession;		
		QueueSender sender = null;
		
		try
		{
			jndiContext = new InitialContext();
			factory = (QueueConnectionFactory) jndiContext.lookup("weblogic.jms.ConnectionFactory");
			connect = factory.createQueueConnection();
			queueSession = connect.createQueueSession(false, TopicSession.AUTO_ACKNOWLEDGE);
			
			Queue queue = (Queue) jndiContext.lookup("OrderQueue");					
			sender = queueSession.createSender(queue);
			
			ObjectMessage msg = queueSession.createObjectMessage(order);
			connect.start();  // WICHTIG!!!!
			sender.send(msg);
			connect.close();
		}
		catch (Exception e)
		{			
			e.printStackTrace();
			return false;
		}
		finally
		{
      try { if (null != sender) sender.close(); } catch (Exception ex) {}
      try { if (null != jndiContext) jndiContext.close(); } catch (Exception ex) {}
    }
		return true;
	}
	
	/**
	 * Notifies the NewBooksTopic, that the book <code>newBook</code> has just been published in the book store.
	 * @param newBook The new book that has just been published.
	 */
	public static void announceNewBook(BookValue newBook)
	{
		Context jndiContext = null;
		TopicConnectionFactory factory;
		TopicConnection connect;
		TopicSession session;		
		TopicPublisher publisher = null;
		
		try
		{
			jndiContext = new InitialContext();
			factory = (TopicConnectionFactory) jndiContext.lookup("weblogic.jms.ConnectionFactory");
			connect = factory.createTopicConnection();
			session = connect.createTopicSession(false, TopicSession.AUTO_ACKNOWLEDGE);
			
			Topic topic = (Topic)jndiContext.lookup("NewBooksTopic");			
			publisher = session.createPublisher(topic);
			
			ObjectMessage msg = session.createObjectMessage(newBook);
			connect.start();  // WICHTIG!!!!
			publisher.publish(msg);
			connect.close();
		}
		catch (Exception e)
		{			
			e.printStackTrace();
		}
		finally
		{
      try { if (null != publisher) publisher.close(); } catch (Exception ex) {}
      try { if (null != jndiContext) jndiContext.close(); } catch (Exception ex) {}
    }
	}
}
