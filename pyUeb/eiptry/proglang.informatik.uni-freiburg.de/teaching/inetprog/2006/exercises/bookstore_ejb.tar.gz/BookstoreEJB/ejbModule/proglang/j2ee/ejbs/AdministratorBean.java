package proglang.j2ee.ejbs;


import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.RemoveException;

/**
 * Bean implementation class for Entity Bean: Customer
 * 
 * @ejb.bean name="Administrator" type="CMP" cmp-version="2.x"
 *           schema="Administrator" view-type="local"
 *           jndi-name="Administrator" reentrant="true"
 *           primkey-field="email"
 *  
 * @ejb.persistence table-name="administrator" 
 * 
 * @weblogic.data-source-name "bookstore_ds"
 * 
 * @ejb.pk class="java.lang.String"
 * 
 * @ejb.finder signature="AdministratorLocal findByEmail(java.lang.String email)"
 *   		   query="select object(o) from Administrator o where o.email=(?1)" 
 */

public abstract class AdministratorBean implements EntityBean {

	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getEmail();

	/**
	 * @ejb.persistence 
	 */
	public abstract void setEmail(String email);


	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getFullName();

	/**
	 * @ejb.persistence
	 */
	public abstract void setFullName(String fullName);
	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getPassword();

	/**
	 * @ejb.persistence
	 */
	public abstract void setPassword(String pw);
	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract int getCategory();

	/**
	 * @ejb.persistence
	 */
	public abstract void setCategory(int category);
	
	
	/**
	 * ejbCreate
	 * 
	 * @ejb.create-method 
	 */
	public java.lang.String ejbCreate(String name, String email, String password)
			throws CreateException {
		setFullName(name);
		setEmail(email);
		setPassword(password);
		return null;
	}

	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(String name, String email, String password) throws CreateException {
	}
	
	
	

	public void setEntityContext(EntityContext arg0) throws EJBException,
			RemoteException {

	}

	public void unsetEntityContext() throws EJBException, RemoteException {

	}

	public void ejbRemove() throws RemoveException, EJBException,
			RemoteException {

	}

	public void ejbActivate() throws EJBException, RemoteException {

	}

	public void ejbPassivate() throws EJBException, RemoteException {

	}

	public void ejbLoad() throws EJBException, RemoteException {

	}

	public void ejbStore() throws EJBException, RemoteException {

	}

}
