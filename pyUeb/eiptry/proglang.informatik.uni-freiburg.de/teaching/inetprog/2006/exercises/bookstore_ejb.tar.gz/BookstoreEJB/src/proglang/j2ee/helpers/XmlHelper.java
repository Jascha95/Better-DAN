package proglang.j2ee.helpers;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import proglang.j2ee.ejbs.AuthorValue;
import proglang.j2ee.ejbs.BookValue;
import proglang.j2ee.ejbs.CategoryValue;

public class XmlHelper
{
	public static BookValue[] getBookValuesFromXml(String xml)
	{
		BookValue[] bookValues = null;

		try
		{
			NodeList bookList, authorList, categoryList;
			Element book;
			InputSource is = new InputSource(new StringReader(xml));
			Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is);

			String title, description;
			Double price;

			// normalize text representation
			doc.getDocumentElement().normalize();

			// get books
			bookList = doc.getElementsByTagName("book");
			bookValues = new BookValue[bookList.getLength()];

			// for each book...
			for (int b = 0; b < bookList.getLength(); b++)
			{
				book = (Element) bookList.item(b);
				title = book.getAttribute("title");
				price = Double.parseDouble(book.getAttribute("price"));
				description = book.getElementsByTagName("description").item(0).getChildNodes().item(0)
				.getNodeValue().trim();
				BookValue bookToAdd = new BookValue(null, title, description,
				(int) (price.doubleValue() * 100));

				authorList = ((Element) book.getElementsByTagName("authors").item(0))
				.getElementsByTagName("author");
				categoryList = ((Element) book.getElementsByTagName("categories").item(0))
				.getElementsByTagName("category");

				for (int a = 0; a < authorList.getLength(); a++)
					bookToAdd.addAuthor(new AuthorValue(null, ((Element) authorList.item(a))
					.getAttribute("name")));

				for (int c = 0; c < categoryList.getLength(); c++)
					bookToAdd.addCategory(new CategoryValue(null, ((Element) categoryList.item(c))
					.getAttribute("name"), null));

				bookValues[b] = bookToAdd;
			}

		}
		catch (SAXParseException err)
		{
			System.out.println("** Parsing error" + ", line " + err.getLineNumber() + ", uri "
			+ err.getSystemId());
			System.out.println(" " + err.getMessage());

		}
		catch (SAXException e)
		{
			Exception x = e.getException();
			((x == null) ? e : x).printStackTrace();
			return null;

		}
		catch (Throwable t)
		{
			t.printStackTrace();
			return null;
		}

		return bookValues;
	}
}
