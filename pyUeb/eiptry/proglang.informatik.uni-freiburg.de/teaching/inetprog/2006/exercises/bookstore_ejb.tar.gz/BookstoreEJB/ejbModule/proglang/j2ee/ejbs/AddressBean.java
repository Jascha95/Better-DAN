package proglang.j2ee.ejbs;


import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.RemoveException;

import proglang.j2ee.helpers.Database;

/**
 * Bean implementation class for Entity Bean: Address
 * 
 * @ejb.bean name="Address" type="CMP" cmp-version="2.x"
 *           schema="Address" view-type="local"
 *           jndi-name="Address" reentrant="true"
 *           primkey-field="id"
 *  
 * @ejb.persistence table-name="address" 
 * 
 * @weblogic.data-source-name "bookstore_ds"
 * 
 * @ejb.pk class="java.lang.Integer"
 * 
 * @ejb.value-object
 * 		match="*"
 *             
 */

public abstract class AddressBean implements EntityBean {

	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract Integer getId();

	/**
	 * @ejb.persistence
	 */
	public abstract void setId(Integer id);


	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getStreet();

	/**
	 * @ejb.persistence 
	 */
	public abstract void setStreet(String street);


	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getCity();

	/**
	 * @ejb.persistence
	 */
	public abstract void setCity(String city);
	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getState();

	/**
	 * @ejb.persistence
	 */
	public abstract void setState(String state);
	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getCountry();

	/**
	 * @ejb.persistence
	 */
	public abstract void setCountry(String country);

	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract Integer getZip();

	/**
	 * @ejb.persistence
	 */
	public abstract void setZip(Integer zip);

	/**
	 * @ejb.interface-method
	 */
	public abstract AddressValue getAddressValue();

	/**
	 * ejbCreate
	 * 
	 * @ejb.create-method 
	 */
	public java.lang.Integer ejbCreate(String street, String city, String state, String country, Integer zip)
			throws CreateException {
		
		SurrogateKeysLocal keys;
		try 
		{
			keys = SurrogateKeysUtil.getLocalHome().create();
			setId(new Integer(keys.getNewPrimaryKey(Database.Table.Address)));
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new CreateException(e.getMessage());
		}
		
		setStreet(street);
		setCity(city);
		setCountry(country);
		setState(state);
		setZip(zip);
		return null;
	}

	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(String street, String city, String state, String country, Integer zip) throws CreateException {
	}
	
	public void setEntityContext(EntityContext arg0) throws EJBException,
			RemoteException {

	}

	public void unsetEntityContext() throws EJBException, RemoteException {

	}

	public void ejbRemove() throws RemoveException, EJBException,
			RemoteException {

	}

	public void ejbActivate() throws EJBException, RemoteException {

	}

	public void ejbPassivate() throws EJBException, RemoteException {

	}

	public void ejbLoad() throws EJBException, RemoteException {

	}

	public void ejbStore() throws EJBException, RemoteException {

	}

}
