package proglang.j2ee.ejbs;


import java.rmi.RemoteException;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.RemoveException;

import proglang.j2ee.helpers.Database;

/**
 * Bean implementation class for Entity Bean: Book
 * 
 * @ejb.bean name="Book" type="CMP" cmp-version="2.x"
 *           schema="Book" view-type="local"
 *           jndi-name="Book" reentrant="true"
 *           primkey-field="id"
 *           
 * @ejb.persistence table-name="book"
 * 
 * @weblogic.data-source-name "bookstore_ds"
 * 
 * @weblogic.enable-batch-operations="False"
 * 
 * @ejb.pk class="java.lang.Integer"
 * 
 * @ejb.finder signature="java.util.Collection findAll()" query="select
 *             object(o) from Book o"
 * 
 * @ejb.finder signature="java.util.Collection findByTitle(java.lang.String
 *             title)" query="select object(o) from Book o where o.title like ?1"
 *             
 * @ejb.finder signature="java.util.Collection findByCategory(java.lang.Integer category)"
 * 							query="select object(o) from Book AS o, IN (o.categories) AS cat WHERE cat.id = ?1"
 *
 * @ejb.value-object
 * 		match="*"
 */

public abstract class BookBean implements EntityBean {

	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract Integer getId();

	/**
	 * @ejb.persistence 
	 */
	public abstract void setId(Integer id);


	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getTitle();

	/**
	 * @ejb.persistence
	 * @ejb.interface-method  
	 */
	public abstract void setTitle(String title);

	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getDescription();

	/**
	 * @ejb.persistence
	 * @ejb.interface-method 
	 */	
	public abstract void setDescription(String desc);
	

	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract int getPrice();

	/**
	 * @ejb.persistence
	 * @ejb.interface-method 
	 */
	public abstract void setPrice(int price);

	
	/**	 
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 *   name="Book-Author"
	 *   role-name="Book-has-Authors"
	 *    
	 * @weblogic.relation
	 * 	 join-table-name="book_author"
	 * 
	 * @weblogic.column-map
	 * 	 foreign-key-column="book_id"
	 * 	 key-column="id"
	 *  
	 * @ejb.value-object
	 * 		aggregate="proglang.j2ee.ejbs.AuthorValue"
	 * 		aggregate-name="Author"
	 * 		members="proglang.j2ee.ejbs.AuthorLocal"
	 * 		members-name="Author"
	 * 		relation="external"
	 */
	public abstract Collection getAuthors();
	
	/**
	 * @ejb.interface-method
	 * @param authors
	 */
	public abstract void setAuthors(Collection authors);
	
	
	/**
	 *
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 *   name="FeaturedBooks"
	 *   role-name="Book-is-featured"
	 *    
	 * @weblogic.relation
	 * 	 join-table-name="featured_books"
	 * 
	 * @weblogic.column-map
	 * 	 foreign-key-column="book_id"
	 * 	 key-column="id"
	 * 
	 * @ejb.value-object
	 * 		aggregate="proglang.j2ee.ejbs.CategoryValue"
	 * 		aggregate-name="FeaturedCategory"
	 * 		members="proglang.j2ee.ejbs.CategoryLocal"
	 * 		members-name="featuredCategory"
	 * 		relation="external"
	 */
	public abstract Collection getFeaturedCategories();
	
	/**
	 * @ejb.interface-method
	 */
	public abstract void setFeaturedCategories(Collection cat);
	

	/**
	 * @ejb.interface-method
	 *
	 * @ejb.relation
	 *   name="Book-Category"
	 *   role-name="Book-has-categories"
	 * 
	 * @weblogic.relation
	 * 	 join-table-name="book_category"
	 * 
	 * @weblogic.column-map
	 * 	 foreign-key-column="book_id"
	 * 	 key-column="id"
	 *  
	 * @ejb.value-object
	 * 		aggregate="proglang.j2ee.ejbs.CategoryValue"
	 * 		aggregate-name="Category"
	 * 		members="proglang.j2ee.ejbs.CategoryLocal"
	 * 		members-name="Category"
	 * 		relation="external"
	 */
	public abstract Collection getCategories();
	
	/**
	 * @ejb.interface-method
	 */
	public abstract void setCategories(Collection cat);
	
	/**
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 *   name="Book-OrderItem"
	 *   role-name="Book-has-OrderItems"
	 *   target-ejb="OrderItem"
	 *   target-role-name="OrderItem-has-Book"
	 */
	public abstract Collection getOrderItems();
	
	/**
	 * @ejb.interface-method
	 */
	public abstract void setOrderItems(Collection orders);
	
	/**
	 * @ejb.interface-method 
	 */
	public abstract BookValue getBookValue();
	
	/**
	 * ejbCreate
	 * 
	 * @ejb.create-method 
	 */
	public java.lang.Integer ejbCreate(String title, int price)
			throws CreateException {
		
		SurrogateKeysLocal keys;
		try 
		{
			keys = SurrogateKeysUtil.getLocalHome().create();
			setId(new Integer(keys.getNewPrimaryKey(Database.Table.Book)));
		}
		catch (Exception e) 
		{
			throw new CreateException(e.getMessage());
		}		
		
		setTitle(title);
		setPrice(price);	
		return null;
	}

	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(String title, int price) throws CreateException {
	}

	public void setEntityContext(EntityContext arg0) throws EJBException,
			RemoteException {

	}

	public void unsetEntityContext() throws EJBException, RemoteException {

	}

	public void ejbRemove() throws RemoveException, EJBException,
			RemoteException {

	}

	public void ejbActivate() throws EJBException, RemoteException {

	}

	public void ejbPassivate() throws EJBException, RemoteException {

	}

	public void ejbLoad() throws EJBException, RemoteException {

	}

	public void ejbStore() throws EJBException, RemoteException {

	}

}