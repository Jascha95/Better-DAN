/**
 * 
 */
package proglang.j2ee.ejbs;

import java.util.ArrayList;
import java.util.Collection;


/**
 *
 * <!-- begin-user-doc -->
 * A generated session bean
 * <!-- end-user-doc -->
 * *
 * <!-- begin-xdoclet-definition --> 
 * @ejb.bean name="OrderManager"	
 *           description="A session bean named OrderManager"
 *           display-name="OrderManager"
 *           jndi-name="OrderManager"
 *           type="Stateless" 
 *           transaction-type="Container"
 * 
 * <!-- end-xdoclet-definition --> 
 * @generated
 */

public abstract class OrderManagerBean implements javax.ejb.SessionBean
{

	/** 
	 *
	 * <!-- begin-xdoclet-definition --> 
	 * @ejb.create-method view-type="remote"
	 * <!-- end-xdoclet-definition --> 
	 * @generated
	 *
	 */
	public void ejbCreate()
	{
	}

	/** 
	 * Gibt alle im System verzeichneten Bestellungen als OrdersValues zurück. 
	 * <!-- begin-xdoclet-definition --> 
	 * @ejb.interface-method
	 * <!-- end-xdoclet-definition --> 
	 * @generated
	 */
	public Collection<OrdersValue> getAllOrders()
	{
		Collection<OrdersValue> allOrders = new ArrayList<OrdersValue>();
		Collection<OrdersLocal> ordersLocal = null;
		try
		{
			ordersLocal = (Collection<OrdersLocal>) OrdersUtil.getLocalHome().findAll();
			for (OrdersLocal order : ordersLocal)
			{
				
				allOrders.add(order.getOrdersValue());
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return allOrders;
	}
}
