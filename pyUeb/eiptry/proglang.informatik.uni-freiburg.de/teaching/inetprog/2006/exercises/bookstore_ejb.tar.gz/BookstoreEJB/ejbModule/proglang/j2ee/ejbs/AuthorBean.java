package proglang.j2ee.ejbs;

import java.rmi.RemoteException;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.RemoveException;

import proglang.j2ee.helpers.Database;

/**
 * Bean implementation class for Entity Bean: Author
 * 
 * @ejb.bean
 *   name="Author" type="CMP" cmp-version="2.x"
 *   schema="Author" jndi-name="Author" view-type="local"
 *   reentrant="true" primkey-field="id"
 *   
 * @ejb.persistence table-name="author"
 * 
 * @ejb.pk class="java.lang.Integer"
 * 
 * @ejb.finder signature="java.util.Collection findAll()" query="select
 *             object(o) from Author o"
 * 
 * @ejb.finder signature="java.util.Collection findByName(java.lang.String
 *             name)" query="select object(o) from Author o where o.name =
 *             (?1)"
 *
 * @weblogic.data-source-name "bookstore_ds"
 *
 * @ejb.value-object
 * 		match="*"
 */

public abstract class AuthorBean implements EntityBean {

	/**
	 * @ejb.persistence read-only="false"
	 */
	public abstract void setId(Integer id);
	
	/**
	 * @ejb.persistence
	 * @ejb.interface-method
	 */
	public abstract Integer getId();
	
	/**
	 * @ejb.interface-method
	 * @ejb.persistence read-only="false"
	 */
	public abstract String getName();
	
	/**
	 * @ejb.persistence
	 */
	public abstract void setName(String name);

	
	/**
	 *
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 *   name="Book-Author"
	 *   role-name="Authors-have-Books"
	 *    
	 * @weblogic.relation
	 * 	 join-table-name="book_author"
	 * 
	 * @weblogic.column-map
	 * 	 foreign-key-column="author_id"
	 * 	 key-column="id"
	 *  
	 */
	public abstract Collection getBooks();
	public abstract void setBooks(Collection b);
	
	/**
	 * @ejb.interface-method
	 */
	public abstract AuthorValue getAuthorValue();
	
	/**
	 * ejbCreate
	 * 
	 * @ejb.create-method
	 */
	public Integer ejbCreate(String name)
			throws CreateException {
		SurrogateKeysLocal keys;
		try 
		{
			keys = SurrogateKeysUtil.getLocalHome().create();
			setId(new Integer(keys.getNewPrimaryKey(Database.Table.Author)));
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new CreateException(e.getMessage());
		}		
		
		setName(name);
		return null;
	}
	
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(String name)
			throws CreateException {
	}
	
	
	public void setEntityContext(EntityContext arg0) throws EJBException,
			RemoteException {

	}

	public void unsetEntityContext() throws EJBException, RemoteException {

	}

	public void ejbRemove() throws RemoveException, EJBException,
			RemoteException {

	}

	public void ejbActivate() throws EJBException, RemoteException {

	}

	public void ejbPassivate() throws EJBException, RemoteException {

	}

	public void ejbLoad() throws EJBException, RemoteException {

	}

	public void ejbStore() throws EJBException, RemoteException {

	}

}
