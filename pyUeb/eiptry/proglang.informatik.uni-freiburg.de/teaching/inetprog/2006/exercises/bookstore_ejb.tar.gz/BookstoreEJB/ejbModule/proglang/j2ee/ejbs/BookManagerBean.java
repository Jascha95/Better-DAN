/**
 * 
 */
package proglang.j2ee.ejbs;

import java.rmi.RemoteException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import javax.ejb.EJBException;
import javax.ejb.SessionContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.TopicConnection;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;

import proglang.j2ee.helpers.JmsHelper;

/**
 * @ejb.bean name="BookManager" description="A session bean named BookManager"
 *           display-name="BookManager" jndi-name="BookManager" type="Stateless"
 *           transaction-type="Container"
 */

public abstract class BookManagerBean implements javax.ejb.SessionBean
{
	private SessionContext context;

	private TopicConnection connect;

	private TopicSession session;

	private TopicSubscriber subscriber;

	/**
	 * @ejb.create-method view-type="remote"
	 * @ejb.interface-method
	 */
	public void ejbCreate()
	{
	}

	public void ejbRemove()
	{
		try
		{
			if (null != session)
				session.close();
		}
		catch (Exception ex)
		{
		}
		try
		{
			if (null != connect)
				connect.close();
		}
		catch (Exception ex)
		{
		}
	}

	/**
	 * @ejb.interface-method
	 * @ejb.transaction
	 * 		type="RequiresNew"
	 */
	public void addBook(BookValue bookValue)
	{
		System.out.println("Adding book: " + bookValue);

		Collection _authors = bookValue.getAuthorCollection();
		Collection _categories = bookValue.getCategoryCollection();

		Collection<AuthorLocal> authors = new ArrayList<AuthorLocal>();
		Collection<CategoryLocal> categories = new ArrayList<CategoryLocal>();
		AuthorLocalHome authorHome;
		AuthorLocal author;
		CategoryLocalHome categoryHome;
		CategoryLocal category;
		Collection tmp;

		try
		{
			Iterator it = _authors.iterator();

			// Sammele alle AuthorLocals, d.h. finde bzw. erstelle sie.
			while (it.hasNext())
			{
				authorHome = AuthorUtil.getLocalHome();
				AuthorValue tempAuthor = (AuthorValue) it.next();
				tmp = authorHome.findByName(tempAuthor.getName());

				// TODO: Problem falls Autoren die gleichen Namen haben!
				// In dem Fall wird einfach der erste in der Collection als Author
				// eingetragen.
				if (!tmp.isEmpty())
				{
					author = (AuthorLocal) tmp.iterator().next();
				}
				else
				{
					author = authorHome.create(tempAuthor.getName());
				}
				authors.add(author);
			}

			it = _categories.iterator();
			while (it.hasNext())
			{
				categoryHome = CategoryUtil.getLocalHome();
				CategoryValue tempCategory = (CategoryValue) it.next();
				tmp = categoryHome.findByName(tempCategory.getName());

				if (!tmp.isEmpty())
				{
					category = (CategoryLocal) tmp.iterator().next();
				}
				else
				{
					category = categoryHome.create(tempCategory.getName());
				}
				categories.add(category);
			}

			BookLocal book = BookUtil.getLocalHome().create(bookValue.getTitle(), bookValue.getPrice());
			book.setAuthors(authors);
			book.setCategories(categories);
			book.setDescription(bookValue.getDescription());			
			// Now notify the topic that a new book has been added.
			JmsHelper.announceNewBook(bookValue);
		}
		catch (Exception e)
		{
			context.setRollbackOnly();
			e.printStackTrace();		
		}
	}

	/**
	 * @ejb.interface-method
	 */
	public void addBook(String title, String[] authors, String[] categories, String description, int price)
	{
		BookValue newBook = new BookValue(null, title, description, price);

		AuthorValue tmpAuthor;
		CategoryValue tmpCategory;
		for (int i = 0; i < authors.length; i++)
		{
			tmpAuthor = new AuthorValue(null, authors[i]);
			newBook.addAuthor(tmpAuthor);
		}
		for (int i = 0; i < categories.length; i++)
		{
			tmpCategory = new CategoryValue(null, categories[i], null);
			newBook.addCategory(tmpCategory);
		}

		addBook(newBook);
	}

	/**
	 * @ejb.interface-method
	 * @ejb.transaction type="Required"
	 * 
	 * @param Array von BookValues
	 */
	public void addBooks(BookValue[] books)
	{
		for (int i = 0; i < books.length; i++)
		{
			addBook(books[i]);
		}
	}

	/**
	 * @ejb.interface-method
	 * 
	 * @return Array von BookValues
	 */
	public BookValue[] getAllBooks()
	{
		BookValue[] allBooks = null;
		BookLocal[] localBooks = null;
		try
		{
			localBooks = (BookLocal[]) BookUtil.getLocalHome().findAll().toArray();
			for (int i = 0; i <= localBooks.length; i++)
			{
				allBooks[i] = localBooks[i].getBookValue();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return allBooks;
	}

	public void onMessage(Message message)
	{
		ObjectMessage msg = (ObjectMessage) message;
		DateFormat df = DateFormat.getTimeInstance(DateFormat.LONG);
		try
		{
			System.out.println(" ** [" + df.format(new Date()) + "] BookManager received message: "
			+ (BookValue) msg.getObject());
		}
		catch (JMSException e)
		{
			e.printStackTrace();
		}
	}

	public void setSessionContext(SessionContext arg0) throws EJBException, RemoteException
	{
		this.context = arg0;
	}
}