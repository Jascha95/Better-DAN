package proglang.j2ee.ejbs;

import java.util.Collection;

/**
 * Abstrakte Klasse um OrdersValueObjects Funktionalität hinzufügen zu können.
 */
public abstract class AbstractOrdersValueObject
{
	public abstract Collection getOrderItemsCollection();
	
	public Integer getTotalPrice()
	{
		int sum = 0;
		for (Object obj : getOrderItemsCollection())
		{
			sum += ((OrderItemValue) obj).getTotalPrice();
		}
		
		return sum;
	}
}
