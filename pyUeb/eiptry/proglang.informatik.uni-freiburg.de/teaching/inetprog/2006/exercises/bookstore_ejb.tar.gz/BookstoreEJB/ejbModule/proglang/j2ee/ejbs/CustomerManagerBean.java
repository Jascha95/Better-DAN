/**
 * 
 */
package proglang.j2ee.ejbs;

import java.util.ArrayList;
import java.util.Collection;


/**
 *
 * <!-- begin-user-doc -->
 * A generated session bean
 * <!-- end-user-doc -->
 * *
 * <!-- begin-xdoclet-definition --> 
 * @ejb.bean name="CustomerManager"	
 *           description="A session bean named CustomerManager"
 *           display-name="CustomerManager"
 *           jndi-name="CustomerManager"
 *           type="Stateless" 
 *           transaction-type="Container"
 * 
 * <!-- end-xdoclet-definition --> 
 * @generated
 */

public abstract class CustomerManagerBean implements javax.ejb.SessionBean
{

	/** 
	 *
	 * <!-- begin-xdoclet-definition --> 
	 * @ejb.create-method view-type="remote"
	 * <!-- end-xdoclet-definition --> 
	 * @generated
	 *
	 * //TODO: Must provide implementation for bean create stub
	 */
	public void ejbCreate()
	{
	}

	/** 
	 *
	 * <!-- begin-xdoclet-definition --> 
	 * @ejb.interface-method
	 * <!-- end-xdoclet-definition --> 
	 * @generated
	 *
	 */
	public Collection<CustomerValue> getAllCustomers()
	{
		Collection<CustomerValue> allCustomers = new ArrayList<CustomerValue>();
		Collection<CustomerLocal> customersLocal = null;
		try
		{
			customersLocal = (Collection<CustomerLocal>) CustomerUtil.getLocalHome().findAll();
			for (CustomerLocal customer : customersLocal)
			{
				
				allCustomers.add(customer.getCustomerValue());
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return allCustomers;
	}
}
