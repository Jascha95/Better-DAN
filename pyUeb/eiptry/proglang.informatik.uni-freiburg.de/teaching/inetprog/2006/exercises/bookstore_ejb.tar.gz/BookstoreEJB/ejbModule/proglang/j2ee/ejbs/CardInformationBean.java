package proglang.j2ee.ejbs;


import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.RemoveException;

/**
 * Bean implementation class for Entity Bean: CardInformation
 * 
 * @ejb.bean name="CardInformation" type="CMP" cmp-version="2.x"
 *           schema="CardInformation" view-type="local"
 *           jndi-name="CardInformation" reentrant="true"
 *           primkey-field="id"
 *  
 * @ejb.persistence table-name="cardinformation" 
 * 
 * @weblogic.data-source-name "bookstore_ds"
 *
 * @ejb.pk class="java.lang.String"
 * 
 * @ejb.value-object
 * 		match="*"
 */

public abstract class CardInformationBean implements EntityBean {

	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getId();

	/**
	 * @ejb.persistence
	 */
	public abstract void setId(String id);


	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getCardType();

	/**
	 * @ejb.persistence 
	 */
	public abstract void setCardType(String cardType);


	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getCardHolder();

	/**
	 * @ejb.persistence
	 */
	public abstract void setCardHolder(String cardHolder);
	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract java.util.Date getExpiration();

	/**
	 * @ejb.persistence
	 */
	public abstract void setExpiration(java.util.Date exp);
	
	/**
	 * @ejb.interface-method
	 */
	public abstract CardInformationValue getCardInformationValue();
		
	/**
	 * ejbCreate
	 * 
	 * @ejb.create-method 
	 */
	public String ejbCreate(String cardNumber, String cardType, java.util.Date expiration, String cardHolder)
			throws CreateException {
		setId(cardNumber);
		setCardType(cardType);
		setExpiration(expiration);
		setCardHolder(cardHolder);
		return null; 
	}

	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(String cardNumber, String cardType, java.util.Date expiration, String cardHolder) throws CreateException {
	}	

	public void setEntityContext(EntityContext arg0) throws EJBException,
			RemoteException {

	}

	public void unsetEntityContext() throws EJBException, RemoteException {

	}

	public void ejbRemove() throws RemoveException, EJBException,
			RemoteException {

	}

	public void ejbActivate() throws EJBException, RemoteException {

	}

	public void ejbPassivate() throws EJBException, RemoteException {

	}

	public void ejbLoad() throws EJBException, RemoteException {

	}

	public void ejbStore() throws EJBException, RemoteException {

	}

}
