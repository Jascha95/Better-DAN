package proglang.j2ee.ejbs;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.RemoveException;

import proglang.j2ee.helpers.Database;

/**
 * Bean implementation class for Entity Bean: OrderItem
 * 
 * @ejb.bean name="OrderItem" type="CMP" cmp-version="2.x"
 *           schema="OrderItem" view-type="local"
 *           jndi-name="OrderItem" reentrant="true"
 *           primkey-field="id"
 *           
 * @ejb.persistence table-name="orderitem"
 *
 * 
 * @ejb.pk class="java.lang.Integer"
 * @weblogic.data-source-name "bookstore_ds"
 * 
 * @ejb.value-object
 * 		match="*"
 * 		extends="proglang.j2ee.ejbs.AbstractOrderItemValueObject"
 */

public abstract class OrderItemBean implements EntityBean {
	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract Integer getId();

	/**
	 * @ejb.persistence
	 */
	public abstract void setId(Integer id);
	
	/**
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 *   name="Order-OrderItem"
	 *   role-name="OrderItem-has-Order"
	 *   target-ejb="Orders"
	 *   target-role-name="Order-has-OrderItems"
	 *   target-multiple="true"
	 * 
	 * @weblogic.column-map
	 * 	 foreign-key-column="order_id"
	 * 	 key-column="id"
	 *  
	 */
	public abstract OrdersLocal getOrder();
	
	/**
	 * @ejb.interface-method
	 */
	public abstract void setOrder(OrdersLocal order);
	
	/**
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 *   name="Book-OrderItem"
	 *   role-name="OrderItem-has-Book"
	 *   target-ejb="Book"
	 *   target-role-name="Book-has-OrderItem"
	 *   target-multiple="true"
	 * 
	 * @weblogic.column-map
	 * 	 foreign-key-column="book_id"
	 * 	 key-column="id"
	 *  
	 *  @ejb.value-object
	 *  	aggregate="proglang.j2ee.ejbs.BookValue"
	 *  	aggregate-name="Book"
	 *  	members="proglang.j2ee.ejbs.BookLocal"
	 *  	members-name="Book"
	 *  	relation="external"
	 */
	public abstract BookLocal getBook();
	
	/**
	 * @ejb.interface-method
	 */
	public abstract void setBook(BookLocal book);
	
	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method
	 */
	public abstract Integer getQuantity();
	
	/**
	 * @ejb.interface-method
	 */
	public abstract void setQuantity(Integer q);
	
	/**
	 * @ejb.interface-method
	 */
	public abstract OrderItemValue getOrderItemValue();
	
	/**
	 * @ejb.create-method
	 */
	public Integer ejbCreate(BookLocal book, Integer quantity, OrdersLocal o)
			throws CreateException
	{
		SurrogateKeysLocal keys;
		try 
		{
			keys = SurrogateKeysUtil.getLocalHome().create();
			setId(new Integer(keys.getNewPrimaryKey(Database.Table.OrderItem)));
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new CreateException(e.getMessage());
		}
		
		return null;
	}
	
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(BookLocal book, Integer quantity, OrdersLocal o)
			throws CreateException
	{
		setBook(book);
		setQuantity(quantity);
		setOrder(o);
	}
	
	public void setEntityContext(EntityContext arg0) throws EJBException,
			RemoteException {

	}

	public void unsetEntityContext() throws EJBException, RemoteException {

	}

	public void ejbRemove() throws RemoveException, EJBException,
			RemoteException {

	}

	public void ejbActivate() throws EJBException, RemoteException {

	}

	public void ejbPassivate() throws EJBException, RemoteException {

	}

	public void ejbLoad() throws EJBException, RemoteException {

	}

	public void ejbStore() throws EJBException, RemoteException {

	}

}