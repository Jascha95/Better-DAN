package proglang.j2ee.ejbs;

import java.rmi.RemoteException;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.RemoveException;

import proglang.j2ee.helpers.Database;

/**
 * Bean implementation class for Entity Bean: Category
 * 
 * @ejb.bean name="Category" type="CMP" cmp-version="2.x"
 *           schema="Category" view-type="local"
 *           jndi-name="Category" reentrant="true"
 *           primkey-field="id"
 *  
 * @ejb.persistence table-name="category" 
 * 
 * @weblogic.data-source-name "bookstore_ds"
 * 
 * @ejb.pk class="java.lang.Integer"
 * 
 * @ejb.finder signature="java.util.Collection findAll()" query="select
 *             object(o) from Category o"
 * 
 * @ejb.finder signature="java.util.Collection findByName(java.lang.String
 *             name)" query="select object(o) from Category o where o.name =
 *             (?1)"
 * @ejb.finder signature="java.util.Collection findSubCategories(java.lang.Integer
 * 			   id)"	  query="select object(o) from Category o where o.parent=(?1)"
 * 
 * @ejb.value-object
 * 		match="*"
 */


public abstract class CategoryBean implements EntityBean {
	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract Integer getId();
	
	/**
	 * @ejb.persistence
	 */
	public abstract void setId(Integer id);
	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method
	 */
	public abstract String getName();
	
	/**
	 * @ejb.persistence
	 */
	public abstract void setName(String name);
	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method
	 */
	public abstract Integer getParent();
	
	/**
	 * @ejb.persistence
	 */
	public abstract void setParent(Integer parentID);
	
	
	/**
	 * @ejb.interface-method
	 *
	 * @ejb.relation
	 *   name="Book-Category"
	 *   role-name="Category-has-Books"
	 * 
	 * @weblogic.relation
	 * 	 join-table-name="book_category"
	 * 
	 * @weblogic.column-map
	 * 	 foreign-key-column="category_id"
	 * 	 key-column="id"
	 *  
	 */
	public abstract Collection getBooks();
	public abstract void setBooks(Collection books);
	
	/**
	 *
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 *   name="FeaturedBooks"
	 *   role-name="Category-features-book"
	 *    
	 * @weblogic.relation
	 * 	 join-table-name="featured_books"
	 * 
	 * @weblogic.column-map
	 * 	 foreign-key-column="category_id"
	 * 	 key-column="id"
	 *  
	 */
	public abstract Collection getFeaturedBooks();
	public abstract void setFeaturedBooks(Collection books);
	
	
	/**
	 * @ejb.interface-method
	 */
	public CategoryLocal getParentCategory()
	{
		try {
			return CategoryUtil.getLocalHome().findByPrimaryKey(this.getParent());
		}
		catch(Exception e) {
			return null;
		}
		
	}
	
	/**
	 * @ejb.interface-method
	 */
	public abstract CategoryValue getCategoryValue();
	
	/**
	 * ejbCreate
	 * 
	 * @ejb.create-method
	 */
	public Integer ejbCreate(String name) throws CreateException
	{
		SurrogateKeysLocal keys;
		try 
		{
			keys = SurrogateKeysUtil.getLocalHome().create();
			setId(new Integer(keys.getNewPrimaryKey(Database.Table.Category)));
		}
		catch (Exception e)		
		{
			e.printStackTrace();
			throw new CreateException(e.getMessage());
		}
				
		setName(name);
		setParent(0);
		return null;
	}
	
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(String name)
			throws CreateException {
	}
	
	public void setEntityContext(EntityContext arg0) throws EJBException,
			RemoteException {

	}

	public void unsetEntityContext() throws EJBException, RemoteException {

	}

	public void ejbRemove() throws RemoveException, EJBException,
			RemoteException {

	}

	public void ejbActivate() throws EJBException, RemoteException {

	}

	public void ejbPassivate() throws EJBException, RemoteException {

	}

	public void ejbLoad() throws EJBException, RemoteException {

	}

	public void ejbStore() throws EJBException, RemoteException {

	}

}