package proglang.j2ee.ejbs;

/**
 * Abstrakte Klasse um OrderItemValueObjects Funktionalität hinzufügen zu können.
 */
public abstract class AbstractOrderItemValueObject
{
	public abstract Integer getQuantity();
	
	public abstract BookValue getBook();
	
	public int getTotalPrice()
	{
		return getQuantity()*getBook().getPrice();
	}
}
