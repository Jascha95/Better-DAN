/**
 * 
 */
package proglang.j2ee.exceptions;

/**
 * @author tobias
 *
 */
public class NotLoggedInException extends Exception
{
	public NotLoggedInException(String message)
	{
		super(message);
	}
}
