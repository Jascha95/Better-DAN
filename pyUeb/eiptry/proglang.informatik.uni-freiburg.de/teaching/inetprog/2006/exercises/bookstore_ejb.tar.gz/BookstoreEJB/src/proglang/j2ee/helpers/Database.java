package proglang.j2ee.helpers;

import java.io.Serializable;
import java.sql.Connection;

import javax.naming.Context;
import javax.sql.DataSource;

/*
 * 
 * Entscheidende Frage, von einer DB abstrahieren?
 * Wenn ja, wie wird dann die Instanz über alle Beans verfügbar sein?
 */

public class Database implements Serializable {
	
	public enum Table {
		Address ("id"),
		Author ("id"),
		Book ("id"),
		Category ("id"),
		Customer("id"),
		OrderItem ("id"),
		Orders ("id");
		
		
		String primKeyName;
		
		private Table(String primKeyName) {
			this.primKeyName = primKeyName;
		}
		
		public String toString()
		{
			return this.name().toLowerCase();
		}
		
		public String getPrimKeyName() {
			return this.primKeyName;
		}
	};

	public static Connection establishConnection() {
		Connection conn;
		DataSource ds;
		
		try
		{
			Context jndiContext = new javax.naming.InitialContext();
			ds = (DataSource) jndiContext.lookup("bookstore_ds");
			conn = ds.getConnection();
			return conn;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}			
	};	
}