/**
 * 
 */
package proglang.j2ee.ejbs;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionContext;

import proglang.j2ee.exceptions.BookException;
import proglang.j2ee.exceptions.NotLoggedInException;
import proglang.j2ee.helpers.Database;
import proglang.j2ee.helpers.JmsHelper;
import proglang.j2ee.helpers.PlacedOrder;


/**
 * Bean implementation class for Stateful SessionBean: Model
 * 
 * @ejb.bean name="Model" type="Stateful"
 *           schema="Model" view-type="local"
 *           jndi-name="Model"
 */

public abstract class ModelBean implements javax.ejb.SessionBean 
{
	public enum Caches { categoryBooks,	featuredBooks };
    
	
	private Boolean	loggedIn = false;
	private Boolean	loggedInAdmin = false;
	private CustomerLocal customer = null; // The customer currently logged in
	private CustomerValue selectedCustomer = null; // The customer currently selected by an admin
	private CategoryLocal currentCategory = null;
	private OrdersValue selectedOrder = null;
	private AdministratorLocal admin = null;
	private int countOfMaxBooksOfCache;
	
	private BooksPerPage actualBooksPerPage = BooksPerPage._5;
	private BookValue book = null;
	private ArrayList<BookValue> cachedBooks =
		new ArrayList<BookValue>();
	private ArrayList<BookValue> currentCategorysFeaturedBooks =
		new ArrayList<BookValue>();
	
	private ArrayList<OrderItemValue> shoppingCart = 
		new ArrayList<OrderItemValue>(3);
	
	/**
	 * @ejb.interface-method
	 * 
	 * Aktualisiert entweder den Cache für die Suche und Bücher einer Kategorie 
	 * (cachedBooks) oder den der angepriesenen Bücher 
	 * (currentCategorysFeaturedBooks).
	 * @param cacheToUpdate Entweder cachedBooks od. currentCategorysFeaturedBooks.
	 * @param startEntry	macht nur Sinn bei cached Books; gibt den ersten Eintrag 
	 * 										an, von dem aus |actualBooksPerPage| viele Bücher in den 
	 * 										Cache	geschrieben werden.
	 */
	public void updateCache(Caches cache, int startEntry) throws Exception 
	{
		Connection dbConn = Database.establishConnection();
		if ( dbConn == null ) 
		{ 
			System.out.println("Verbindung zur Datenbank konnte nicht " +
					"hergestellt werden");
			return;
		}

		String prepCatQuery = "SELECT b.id,b.title,b.description,b.price "+
			"FROM book AS b, book_category AS bc "+
			"WHERE bc.category_id="+currentCategory.getId()+" AND bc.book_id = b.id "+
			"ORDER BY b.title "+
			"OFFSET ? "+
			"LIMIT "+actualBooksPerPage.getBooksPerPage()+" ;";
		String prepCountQuery = "SELECT count(*) "+	// Anzahl an Bücher dieser Kategorie
		"FROM book AS b, book_category AS bc "+
		"WHERE bc.category_id="+currentCategory.getId()+" AND bc.book_id = b.id;";
		
		String prepFeatQuery = "SELECT b.id,b.title,b.description,b.price "+
			"FROM book AS b, featured_books AS fb "+
			"WHERE fb.category_id="+currentCategory.getId()+" AND fb.book_id = b.id "+
			"ORDER BY b.title ;";  
		
		Statement stmt_ac; // Autoren und Kategorien auslesen
		PreparedStatement stmt = null, stmt_bc; // bc = maximale Anzahl an Büchern der Kategorie
		ResultSet rs, rs_ac;

		ArrayList<BookValue> cacheToUpdate = null;
		switch (cache)
		{
		case categoryBooks:
			cacheToUpdate = cachedBooks;
			try 
			{
				stmt = dbConn.prepareStatement(prepCatQuery);
				stmt_bc = dbConn.prepareStatement(prepCountQuery);

//			Setzte die maximale Anzahl an Büchern von dieser Kategorie.
				ResultSet bookCount = stmt_bc.executeQuery();
				bookCount.next();
				this.countOfMaxBooksOfCache = bookCount.getInt(1);
				stmt_bc.close();
				
//				setzte Offset
				stmt.setInt(1,startEntry);
			}
			catch(SQLException sqle) 
			{
				sqle.printStackTrace();
				return;
			}
			break;
			
		case featuredBooks:
			cacheToUpdate = currentCategorysFeaturedBooks;
			try 
			{
				stmt = dbConn.prepareStatement(prepFeatQuery);
			}
			catch(SQLException sqle) 
			{
				sqle.printStackTrace();
				return;
			}
			break;
			
		default:
			throw new Exception("Unerwarteter Wert ("+cache+") für das Enum!");				
		}
		

		try 
		{
			stmt_ac = dbConn.createStatement();
		}
		catch(SQLException sqle) 
		{
			sqle.printStackTrace();
			return;
		}
		
		try 
		{
			rs = stmt.executeQuery();
			cacheToUpdate.clear();
			
			while ( rs.next() == true ) 
			{
//				erster Teil des BookValue erzeugen.
				BookValue toAdd = new BookValue(
						rs.getInt(1),			// Buch ID 
						rs.getString(2),	// Buch Titel
						rs.getString(3),	// Buch Beschreibung
						rs.getInt(4)		// Buchpreis 
						);

//				zweiter Teil = AuthorsValue und CategoriesValue setzen:
				
//			SQL Queries für alle Autoren bzw. Kategorien zu dem derzeit 
//			betrachteten Buch. Die Ausgabe ist nach deren Namen aufsteigend
//			sortiert.
			 
				String getAuthors = "SELECT a.name " +
					"FROM author AS a, book_author AS ba " +
					"WHERE ba.book_id = '"+rs.getInt(1)+"' AND ba.author_id = a.id "+
					"ORDER BY a.name;";
				String getCategories = "SELECT c.name " +
					"FROM book_category AS bc, category AS c " +
					"WHERE bc.book_id = '"+rs.getInt(1)+"' AND bc.category_id = c.id "+
					"ORDER BY c.name;";
				
				rs_ac = stmt_ac.executeQuery(getAuthors);
				while ( rs_ac.next() == true ) 
				{
					AuthorValue author = new AuthorValue();
					author.setName(rs_ac.getString(1));
					toAdd.addAuthor(author);
				}
				
				rs_ac = stmt_ac.executeQuery(getCategories);
				while ( rs_ac.next() == true ) 
				{
					CategoryValue cat = new CategoryValue();
					cat.setName(rs_ac.getString(1));
					toAdd.addCategory(cat);
				}
				rs_ac.close();
				
				cacheToUpdate.add(toAdd); 
			}
			stmt_ac.close();
			stmt.close();
			dbConn.close();
		}
		catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Gibt die "angepriesenen" Bücher der aktuellen Kategorie zurück.
	 * @return BookValues der angepriesenen Bücher der aktuellen Kategorie.
	 */
	public ArrayList<BookValue> getFeaturedBooks()
	{
		return this.currentCategorysFeaturedBooks;
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Gibt die gecachten Bücher zu der aktuellen Category zurück.
	 * @return Gecachten Bücher zur aktuellen Category.
	 */
	public ArrayList<BookValue> getCategoryBooks() {
		return this.cachedBooks;
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Eine Alias Funktion zu getCategoryBooks, da im Cache auch das Ergebnis einer
	 * Suche sein kann.
	 * @return gibt die Bücher im Cache zurück (Ein Alias für getCategoryBooks).
	 */
	public ArrayList<BookValue> getCachedBooks() 
	{
		return this.cachedBooks;
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Gibt das aktuelle Buch, für welches sich der User interessiert hat zurück.
	 * D.h. von welchem er die Details sehen wollte.
	 * @return Buch für das sich der User interessierte.
	 */
  public BookValue getBook()
	{
		return book;
	}
  
  
//  /**
//   * ejb.interface-method
//   * 
//   * Gibt die maximale Anzahl an Bücher i
//   * @return
//   */
//	public int getCountOfMaxBooksOfCache()
//	{
//		return countOfMaxBooksOfCache;
//	}

  /**
	 * @ejb.interface-method
	 * 
	 * Leert einen der Caches, d.h. entweder cachedBooks oder 
	 * currentCategorysFeaturedBooks.
	 * @param cache der Cache der geleert werden soll.
	 */
	public void clearCache(Caches cache)
	{
		ArrayList<BookValue> tmp = null;
		switch (cache)
		{
		case categoryBooks:
			tmp = cachedBooks;
			break;
		case featuredBooks:
			tmp = currentCategorysFeaturedBooks;
			break;
		}
		
		tmp.clear();
	}
	
	/** 
	 * @ejb.create-method view-type="local"
	 */
	public void ejbCreate() 
	{
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Gibt Wahr zurück wenn der Nutzer eingelogged ist.
	 * @return TRUE, wenn Nutzer eingelogged ist.
	 */
	public Boolean getLoggedIn()
	{
		return loggedIn;
	}
	
  /**
   * @ejb.interface-method
   * 
   * Gibt Wahr zurück, falls der Nutzer als Admin eingelogged ist.
   * @return TRUE wenn User als Admin eingelogged ist.
   */
  public Boolean getLoggedInAdmin() 
  {
		// TODO: Das hier wieder rauswerfen. Nur jetzt damit jeder Zugriff auf die Admin-Seiten hat.
  		//  return loggedInAdmin;
  		return true;
  }

	/**
	 * @ejb.interface-method
	 * 
	 * Logged einen Nutzer / Admin ein und setzt ggf. loggedIn / loggedInAdmin auf true.
	 * @param email Die email des Admin / Customers
	 * @param password Das Passwort des Admin / Customers
	 * @param adminLogin Wahr wenn der User sich als Admin einloggen will.
	 */
	public boolean logIn(String email, String password, Boolean adminLogin) {
		System.out.println("Logging in...  ");
		try 
		{
			if (adminLogin)
			{
				admin = AdministratorUtil.getLocalHome().findByEmail(email);
				if (admin.getPassword().trim().equals(password))
				{
					loggedIn = true;
					loggedInAdmin = true;
				}					
			}
			else
			{
				customer = CustomerUtil.getLocalHome().findByEmail(email);
				if(customer.getPassword().trim().equals(password))
					loggedIn = true;
				loggedInAdmin = false;
			}
		}
		catch (FinderException fe)
		{
			loggedIn = false;	loggedInAdmin = false;
			customer = null; admin = null;
		}
		catch (Exception e) {
			loggedIn = false;	loggedInAdmin = false;
			customer = null; admin = null; 
			e.printStackTrace();			
		}
		System.out.println("loggedIn Status = " + loggedIn);
		System.out.println("loggedInAdmin Status = " + loggedInAdmin);
		
		return loggedIn;		
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Logged den Benutzer aus, d.h. customer & admin werden auf null gesetzt, 
	 * loggedIn, loggedInAdmin werden auf false gesetzt.
	 * Der Einkaufswagen und die gecachten Bücher werden beibehalten.
	 */
	public void logOut()
	{
		loggedInAdmin = false;
		loggedIn = false;
		customer = null;
		admin = null;
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Gibt den Customer zurück.
	 * @return aktueller CustomerLocal
	 */
	public CustomerLocal getCustomer()
	{
		return customer;
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Gibt die aktuelle CategoryLocal zurück.
	 * @return Die aktuelle CategoryLocal. 
	 */
	public CategoryLocal getCategory() 
	{
		return this.currentCategory;
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Gibt die Anzahl der Bücher, die pro Seite angezeigt werden sollen zurück.
	 * @return Anzahl Bücher pro Seite
	 */
	public BooksPerPage getActualBooksPerPage()
	{
		return actualBooksPerPage;
	}

	/**
	 * @ejb.interface-method
	 * 
	 * Gibt die Anzahl an Seiten zurück die gebraucht werden, um Bücher dieser 
	 * Kategorie / Suche bei den derzeit eingestellten BüchernProSeite anzeigen 
	 * zu können.
	 * @return Anzahl an Seiten, so dass Anz * actualBooksPerPage >= countOfMaxBooksOfCache
	 * 
	 *  TODO: wie kann in der EL Language eine for Schleife definieren, die NICHT über Collections geht?
	 *  	So etwas einfaches wie for (int i=0; i< blubb; i++) { doit } scheint es 
	 *  	dort nicht zu geben.
	 */
	public ArrayList<Integer> getNumberOfPages()
	{
		int numPages = countOfMaxBooksOfCache / actualBooksPerPage.getBooksPerPage();
		if (countOfMaxBooksOfCache % actualBooksPerPage.getBooksPerPage() != 0)
			numPages++;
		ArrayList<Integer> toReturn = new ArrayList<Integer>();
		for (int i=1; i<= numPages; i++)
			toReturn.add(Integer.valueOf(i));
			
		return toReturn;
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Legt die Anzahl der Bücher die pro Seite angezeigt werden sollen fest.
	 * @param actualBooksPerPage Anzahl Bücher pro Seite
	 */
	public void setActualBooksPerPage(BooksPerPage actualBooksPerPage)
	{
		this.actualBooksPerPage = actualBooksPerPage;
	}

	/**
	 * @ejb.interface-method
	 * 
	 * Setzt this.currentCategory auf jene, welche "id" als Primärschlüssel hat.
	 * @param id Der Primärschlüssel der neuen Kategorie.
	 */
	public void setCategory(int id) 
	{
		try 
		{
			currentCategory = (CategoryLocal)CategoryUtil.getLocalHome().findByPrimaryKey(id);
		}
		catch (Exception e) { e.printStackTrace();}
	}
		
	/**
	 * @ejb.interface-method
	 * 
	 * Gibt die alle Unterkategorien zurück.
	 * @return ArrayList<CategoryLocal> mit allen Unterkategorien
	 */
	public ArrayList<CategoryLocal> getSubCategories() {
		ArrayList<CategoryLocal> subCategories = new ArrayList<CategoryLocal>();
		try 
		{
			CategoryLocalHome cat = CategoryUtil.getLocalHome();
			Collection col = cat.findSubCategories(currentCategory.getId());
			Iterator it = col.iterator();
			while ( it.hasNext() )
			{
				CategoryLocal cl = (CategoryLocal) it.next();
//			Da nun rootCategory.parent = rootCategory ist muss der Fall hier 
//			abgefangen werden
				if (cl.getId().equals(currentCategory.getId()))
					continue;
				
				subCategories.add(cl);
			}
		}
		catch (Exception e) { e.printStackTrace(); }
		return subCategories;
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Neuer Kunde wird angelegt. Sollte es nicht funktionieren wird eine 
	 * EJBException geworfen.
	 * @param email Emailadresse des Kunden
	 * @param password Passwort des Kunden
	 * @param name Vollständiger Name des Kunden 
	 */
	public void register(String name, String email, String password) 
							throws EJBException 
	{
		try 
		{
			customer = CustomerUtil.getLocalHome().create(name,email,password);
		}
		catch(Exception e) 
		{ 
			throw new EJBException("Customer couldn't be registered, " +
					"email already exists or some other shit happened."); 
		}
		System.out.println("Customer " + customer.getFullName() + " registered");
	}
	
	/**
	 * @ejb.interface-method
	 *
	 * TODO: Wir könnten das auch noch auf mehr als nur den Titel ausdehnen, dann aber per jdbc Zugriff.
	 * Findet alle Bücher, deren Titel auf den Suchstring toMatch passen und 
	 * speichert sie in den cachedBooks. 
	 * 
	 * @param toMatch String auf den geprüft werden soll
	 */
	public void findMatches(String toMatch){
		try 
		{
			Collection c = BookUtil.getLocalHome().findByTitle("%"+toMatch+"%");
			Iterator it = c.iterator();
			this.cachedBooks.clear();

			while ( it.hasNext() )
			{
				BookValue bookValue = ((BookLocal)it.next()).getBookValue();
				this.cachedBooks.add(bookValue);
			}
//			Sortierung geht mit BookValues nicht mehr, da kein Comparable impl.
//			Collections.sort(cachedBooks);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * @ejb.interface-method
	 * 
	 * Kopiert den Referenzspeicher des ausgewählten Buches in this.book.
	 * @param bookId Die Buchnummer des ausgewählten Buches.
	 * @param cache gibt an in welchem Cache sich das ausgewählte Buch befindet.
	 */
	public void setSelectedBook(int bookId, Caches cache)
	{
		ArrayList<BookValue> tmp = null;
		
		switch (cache) 
		{
			case categoryBooks: 
				tmp = this.cachedBooks; 
				break;
			case featuredBooks:
				tmp = this.currentCategorysFeaturedBooks;
				break;
		}
		
		Iterator it = tmp.iterator();
		this.book = null;
		while ( it.hasNext() )
		{
			BookValue book = (BookValue) it.next();
			
			if (book.getId() == bookId) 
			{
				this.book = book;
				break;
			}
		}
		
	}
	
	/**
	 * @ejb.interface-method
	 * 
	 * Gibt den Einkaufswagen zurück.
	 * @return Den Einkaufswagen
	 */
	public ArrayList<OrderItemValue> getShoppingCart()
	{
		return this.shoppingCart;
	}
	 
	/**
	 * @ejb.interface-method
	 * 
	 * Fügt das derzeitige BookValueSimple "this.book" zu dem Einkaufswagen hinzu.
	 * Sollte dieses Buch schon vorhanden sein wird die Anzahl um die der neuen
	 * Bestellung erhöht.
	 * @param quantity Die Anzahl der Exemplare, die zum Einkaufswagen hinzugefügt 
	 * 				werden sollen
	 */
	public void addCurrentBook(int quantity)
	{
		System.out.println("adding book to Cart: " + book.getTitle());
		 		 
		OrderItemValue newOrder = new OrderItemValue(book.getId(), quantity);
		newOrder.setBook(book);
		 
		if ( shoppingCart.contains(newOrder) )
		{
			OrderItemValue oldOrder = shoppingCart.get(shoppingCart.indexOf(newOrder));
			oldOrder.setQuantity(oldOrder.getQuantity() + quantity);
		}
		else
		{
			shoppingCart.add(newOrder);
		}
	}
	 
	/**
	 * @ejb.interface-method
   * 
   * Aktualisiert die Anzahl der zu bestellenden Exemplare zu einer gegebenen 
   * BuchId.
   * Sollte die Anzahl "0" sein, so wird das Buch aus dem Einkaufswagen entfernt.
   * Ist die Bestellung nicht auffindbar (Die Id nicht unter den bestehenden 
   * Bestellungen) so wird eine Exception geworfen.
   * 
   * @param bookId Die BuchId zu der die Anzahl verändert werden soll.
   * @param quantity Die neue Anzahl der zu bestellenden Exemplare.
   */
  public void updateQuantity(int bookId, int quantity) throws Exception 
  {
  	if ( quantity == 0 ) removeBookFromCart(bookId);
  	
  	System.out.println("Updating book id: " + bookId + " to #:" + quantity);
  	Iterator it = shoppingCart.iterator();
  	boolean orderFound = false;
  	while ( it.hasNext() )
  	{
  		OrderItemValue tmp = (OrderItemValue) it.next();
  		if ( tmp.getBook().getId() == bookId )
  		{
  			tmp.setQuantity(quantity);
  			orderFound = true;
  			return;
  		}
  	}
  	// TODO: Keine passende Exception gefunden, kennst du eine treffendere?
  	if ( !orderFound )
  		throw new Exception("Das Element mit ID: "+bookId+" konnte nicht " +
  												"gefunden werden!");
  }
	
	/**
	 * @ejb.interface-method
	 * 
	 * Entfernt aus das Buch mit der "bookId" aus dem Einkaufswagen.
	 * Sollte das Buch nicht vorhanden sein wird KEINE Exception geworfen.
	 * @param bookId Die Id des zu entfernenden Buches
	 */
	public void removeBookFromCart(int bookId)throws BookException
	{
		Iterator it = shoppingCart.iterator();
		OrderItemValue tmp = null;
		while ( it.hasNext() )
		{
			tmp = (OrderItemValue) it.next();
			if (tmp.getBook().getId() == bookId)
			{
				shoppingCart.remove(tmp);
				break;
			}
		}
	}
	 
	/**
	 * @ejb.interface-method
	 * 
	 * Gibt den aktuellen Einkaufswagen als Bestellung auf.
	 * 
	 * @throws NotLoggedInException falls Customer nicht eingelogged oder keine 
	 * 					Creditkarteninformationen zu dem Customer gespeichert sind
	 * @throws EJBException falls bei der Verarbeitung der OrderItems, der Order
	 * 					oder dem Book etwas unvorhergesehenes passiert.
	 */
	public void placeOrder() throws Exception
	{
		if ( (customer == null) || (customer.getCardInformation() == null) )
			throw new NotLoggedInException("Entweder noch nicht eingelogged oder der User " +
													"hat keine Kreditkarteninformationen gespeichert!");
		boolean ok;
		ok = JmsHelper.submitOrder(new PlacedOrder(customer.getCustomerValue(), shoppingCart));
		
		if(!ok)
			; //TODO: Fehler behandeln
		else
			shoppingCart.clear();	
	}
	
	/**
	 * @ejb.interface-method
	 */
	public BooksPerPage[] getBooksPerPage()
	{
		return BooksPerPage.values();
	}
		
	/**
	 * @ejb.interface-method
	 */
	public Collection<OrdersValue> getAllOrders()
	{
		try
		{
			return OrderManagerUtil.getLocalHome().create().getAllOrders();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * @ejb.interface-method view-type="local"
	 * @param orderId
	 */
	public void setSelectedOrderId(int orderId)
	{
		try
		{			
			this.selectedOrder = OrdersUtil.getLocalHome().findByPrimaryKey(orderId).getOrdersValue();
		}
		catch (Exception e)
		{
			this.selectedOrder = null;
			e.printStackTrace();
		}		
	}
	
	/**
	 * @ejb.interface-method
	 */
	public Collection<CustomerValue> getAllCustomers()
	{
		try
		{
			return CustomerManagerUtil.getLocalHome().create().getAllCustomers();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * @ejb.interface-method
	 */
	public OrdersValue getSelectedOrder()
	{
		return this.selectedOrder;
	}
	
	/**
	 * @ejb.interface-method view-type="local"
	 * @param customerId
	 */
	public void setSelectedCustomerId(int customerId)
	{
		try
		{			
			this.selectedCustomer = CustomerUtil.getLocalHome().findByPrimaryKey(customerId).getCustomerValue();
		}
		catch (Exception e)
		{
			this.selectedOrder = null;
			e.printStackTrace();
		}	
	}
	
	/**
	 * @ejb.interface-method
	 */
	public CustomerValue getSelectedCustomer()
	{
		return this.selectedCustomer;
	}
	       
	public void ejbRemove() 
	{
	}

	public void ejbActivate() 
	{
	}

	public void ejbPassivate() 
	{
	}

	public void setSessionContext(SessionContext sc) 
	{
	}
}
