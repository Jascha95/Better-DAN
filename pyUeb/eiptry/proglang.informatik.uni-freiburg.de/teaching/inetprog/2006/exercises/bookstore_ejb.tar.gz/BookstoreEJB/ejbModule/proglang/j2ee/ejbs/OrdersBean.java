package proglang.j2ee.ejbs;

import java.rmi.RemoteException;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.RemoveException;

import proglang.j2ee.helpers.Database;

/**
 * Bean implementation class for Entity Bean: Orders
 * 
 * @ejb.bean name="Orders" type="CMP" cmp-version="2.x" schema="Orders"
 *           view-type="local" jndi-name="Orders" reentrant="true"
 *           primkey-field="id"
 * 
 * @ejb.persistence table-name="orders"
 * 
 * @weblogic.data-source-name "bookstore_ds"
 * 
 * @ejb.pk class="java.lang.Integer"
 * 
 * @ejb.finder signature="java.util.Collection findAll()" query="select
 *             object(o) from Orders o"
 * 
 * @ejb.value-object
 * 		match="*"
 * 		extends="proglang.j2ee.ejbs.AbstractOrdersValueObject"
 */

public abstract class OrdersBean implements EntityBean
{
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method
	 */
	public abstract Integer getId();

	/**
	 * @ejb.persistence
	 */
	public abstract void setId(Integer id);

	/**
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 * 		name="Order-Customer"
	 * 		role-name="Order-has-Customer"               
	 * 
	 * @weblogic.column-map foreign-key-column="customer" key-column="id"
	 * 
	 * @ejb.value-object
	 * 		aggregate="proglang.j2ee.ejbs.CustomerValue"
	 * 		aggregate-name="Customer"
	 * 		members="proglang.j2ee.ejbs.CustomerLocal"
	 * 		members-name="Customer"
	 * 		relation="external"
	 */
	public abstract CustomerLocal getCustomer();

	/**
	 * @ejb.interface-method
	 */
	public abstract void setCustomer(CustomerLocal cust);

	/**
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 * 		name="Order-OrderItem"
	 * 		role-name="Order-has-OrderItems"
	 * 
	 * @ejb.value-object aggregate="proglang.j2ee.ejbs.OrderItemValue"
	 *                   aggregate-name="OrderItems"
	 *                   members="proglang.j2ee.ejbs.OrderItemLocal"
	 *                   members-name="OrderItem" relation="external"
	 */
	public abstract Collection getOrderItems();

	/**
	 * @ejb.interface-method
	 */
	public abstract void setOrderItems(Collection orders);

	/**
	 * @ejb.interface-method
	 */
	public void addOrderItem(OrderItemLocal o)
	{
		Collection orderItems = getOrderItems();
		orderItems.add(o);
		setOrderItems(orderItems);
	}

	/**
	 * ejbCreate
	 * 
	 * @ejb.create-method
	 */
	public java.lang.Integer ejbCreate(CustomerLocal c) throws CreateException
	{
		SurrogateKeysLocal keys;
		try
		{
			keys = SurrogateKeysUtil.getLocalHome().create();
			setId(new Integer(keys.getNewPrimaryKey(Database.Table.Orders)));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new CreateException(e.getMessage());
		}

		return null;
	}
	
	/**
	 * @ejb.interface-method 
	 */
	public abstract OrdersValue getOrdersValue();
	
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(CustomerLocal c) throws CreateException
	{
		setCustomer(c);
	}

	public void setEntityContext(EntityContext arg0) throws EJBException, RemoteException
	{

	}

	public void unsetEntityContext() throws EJBException, RemoteException
	{

	}

	public void ejbRemove() throws RemoveException, EJBException, RemoteException
	{

	}

	public void ejbActivate() throws EJBException, RemoteException
	{

	}

	public void ejbPassivate() throws EJBException, RemoteException
	{

	}

	public void ejbLoad() throws EJBException, RemoteException
	{

	}

	public void ejbStore() throws EJBException, RemoteException
	{

	}

}