package proglang.j2ee.ejbs;


import java.rmi.RemoteException;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.RemoveException;

import proglang.j2ee.helpers.Database;

/**
 * Bean implementation class for Entity Bean: Customer
 * 
 * @ejb.bean name="Customer" type="CMP" cmp-version="2.x"
 *           schema="Customer" view-type="local"
 *           jndi-name="Customer" reentrant="true"
 *           primkey-field="id"
 *  
 * @ejb.persistence table-name="customer" 
 * 
 * @weblogic.data-source-name "bookstore_ds"
 * 
 * @ejb.pk class="java.lang.Integer"
 * 
 * @ejb.finder signature="java.util.Collection findAll()" query="select
 *             object(o) from Customer o"
 * 
 * @ejb.finder signature="java.util.Collection findByName(java.lang.String
 *             name)" query="select object(o) from Customer o where o.fullName like ?1" 
 * @ejb.finder signature="proglang.j2ee.ejbs.CustomerLocal findByEmail(java.lang.String email)"
 *   		   query="select object(o) from Customer o where o.email=(?1)" 
 *       
 * @ejb.value-object
 * 		match="*"
 */

public abstract class CustomerBean implements EntityBean {
	
	/**
	 * @ejb.persistence read-only="true"
	 * @ejb.interface-method 
	 */
	public abstract Integer getId();

	/**
	 * @ejb.persistence 
	 */
	public abstract void setId(Integer id);

	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getEmail();

	/**
	 * @ejb.persistence 
	 */
	public abstract void setEmail(String email);


	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getFullName();

	/**
	 * @ejb.persistence
	 */
	public abstract void setFullName(String fullName);
	
	/**
	 * @ejb.persistence read-only="false"
	 * @ejb.interface-method 
	 */
	public abstract String getPassword();

	/**
	 * @ejb.persistence
	 */
	public abstract void setPassword(String pw);
	
	/**
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 *   name="Customer-Address"
	 *   role-name="Customer-has-Address"
	 *   target-ejb="Address"
	 *   target-role-name="Address-has-Customer"
	 * 
	 * @weblogic.column-map
	 * 	 foreign-key-column="address_id"
	 * 	 key-column="id"
	 *  
	 * @ejb.value-object
	 * 		compose="proglang.j2ee.ejbs.AddressValue"
	 * 		compose-name="Address"
	 * 		members="proglang.j2ee.ejbs.AddressLocal"
	 * 		members-name="Address"
	 * 		relation="external"
	 */
	public abstract AddressLocal getAddress();
	
	/**
	 * @ejb.interface-method
	 */
	public abstract void setAddress(AddressLocal address);
	
	/**
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 *   name="Customer-CardInformation"
	 *   role-name="Customer-has-CardInformation"
	 *   target-ejb="CardInformation"
	 *   target-role-name="CardInformation-has-Customer"
	 *   
	 *   
	 * @weblogic.column-map
	 * 	 foreign-key-column="card_id"
	 * 	 key-column="id"
	 *  
	 * @ejb.value-object
	 * 		compose="proglang.j2ee.ejbs.CardInformationValue"
	 * 		compose-name="CardInformation"
	 * 		members="proglang.j2ee.ejbs.CardInformationLocal"
	 * 		members-name="CardInformation"
	 * 		relation="external"
	 */
	public abstract CardInformationLocal getCardInformation();
	
	/**
	 * @ejb.interface-method
	 */
	public abstract void setCardInformation(CardInformationLocal cardInfo);

	/**
	 * @ejb.interface-method
	 * 
	 * @ejb.relation
	 *   name="Order-Customer"
	 *   role-name="Customer-has-Order"
	 *   
	 * ejb.value-object
	 * 		aggregate="proglang.j2ee.ejbs.OrdersValue"
	 * 		aggregate-name="Orders"
	 * 		members="proglang.j2ee.ejbs.OrdersLocal"
	 * 		members-name="Orders"
	 * 		relation="external"
	 */
	public abstract Collection getOrders();
	
	/**
	 * @ejb.interface-method
	 */
	public abstract void setOrders(Collection orders);

	/**
	 * @ejb.interface-method
	 */
	public abstract CustomerValue getCustomerValue();
	
	/**
	 * ejbCreate
	 * 
	 * @ejb.create-method 
	 */
	public java.lang.Integer ejbCreate(String name, String email, String password) throws CreateException
	{
		SurrogateKeysLocal keys;
		try 
		{
			keys = SurrogateKeysUtil.getLocalHome().create();
			setId(new Integer(keys.getNewPrimaryKey(Database.Table.Customer)));
		}
		catch (Exception e) 
		{
			throw new CreateException(e.getMessage());
		}
		
		setFullName(name);
		setEmail(email);
		setPassword(password);
		return null;
	}

	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(String name, String email, String password) throws CreateException {
	}
	
	
	

	public void setEntityContext(EntityContext arg0) throws EJBException,
			RemoteException {

	}

	public void unsetEntityContext() throws EJBException, RemoteException {

	}

	public void ejbRemove() throws RemoveException, EJBException,
			RemoteException {

	}

	public void ejbActivate() throws EJBException, RemoteException {

	}

	public void ejbPassivate() throws EJBException, RemoteException {

	}

	public void ejbLoad() throws EJBException, RemoteException {

	}

	public void ejbStore() throws EJBException, RemoteException {

	}

}