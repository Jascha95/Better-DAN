package proglang.j2ee.ejbs;


public class BooksPerPage {

        public static BooksPerPage _5 = new BooksPerPage(5);
        public static BooksPerPage _10 = new BooksPerPage(10);
        public static BooksPerPage _20 = new BooksPerPage(20);
        public static BooksPerPage _40 = new BooksPerPage(40);
        
        private static BooksPerPage[] all = new BooksPerPage[]{_5,_10,_20,_40};
        int booksPerPage;
        
        private BooksPerPage(int number)
        {
            this.booksPerPage = number;
        }
        
//      TODO: Methode schreiben, die zu gegebenem Int den Enumwert zurückgibt.
//      und dabei Enum.valueOf verwenden
        
        public int getBooksPerPage()
        {
            return this.booksPerPage;
        }
        
        public String toString()
        {
            return String.valueOf(this.booksPerPage);
        }
        
        public static BooksPerPage[] values() {
            return all;
        }
}

