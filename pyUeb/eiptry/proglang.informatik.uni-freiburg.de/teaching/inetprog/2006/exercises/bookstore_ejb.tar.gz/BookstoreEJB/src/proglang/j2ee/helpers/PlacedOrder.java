/**
 * 
 */
package proglang.j2ee.helpers;

import java.io.Serializable;
import java.text.DateFormat;
import java.util.Collection;
import java.util.Date;

import proglang.j2ee.ejbs.CustomerValue;
import proglang.j2ee.ejbs.OrderItemValue;

/**
 * @author Tobias Langner
 */
public class PlacedOrder implements Serializable
{
	CustomerValue customer;
	Collection<OrderItemValue> shoppingCart;
	Date date;
	
	public PlacedOrder(CustomerValue customer, Collection<OrderItemValue> shoppingCart)
	{
		this.customer = customer;
		this.shoppingCart = shoppingCart;
		this.date = new Date();
	}

	public CustomerValue getCustomer()
	{
		return customer;
	}

	public Collection<OrderItemValue> getShoppingCart()
	{
		return shoppingCart;
	}
	
	public String toString()
	{
		DateFormat df = DateFormat.getInstance();
		return "Order placed by "+customer.getFullName().trim()+" at "+df.format(date);
	}
}
