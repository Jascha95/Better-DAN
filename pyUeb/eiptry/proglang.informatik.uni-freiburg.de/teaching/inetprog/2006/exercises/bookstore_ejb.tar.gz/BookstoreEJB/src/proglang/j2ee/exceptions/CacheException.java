package proglang.j2ee.exceptions;

public class CacheException extends Exception
{
	public CacheException(String message)
	{
		super(message);
	}
}
