/**
 * 
 */
package proglang.j2ee.ejbs;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.EJBException;
import javax.ejb.SessionContext;

import proglang.j2ee.exceptions.CacheException;
import proglang.j2ee.helpers.Database;
import proglang.j2ee.helpers.Database.Table;

/**
 * 
 * @ejb.bean name="SurrogateKeys" description="A session bean named
 *           SurrogateKeys" display-name="SurrogateKeys"
 *           jndi-name="SurrogateKeys" type="Stateless"
 *           transaction-type="Container"
 * 
 * @generated
 */

public abstract class SurrogateKeysBean implements javax.ejb.SessionBean
{
	private static Map<Database.Table, CachedKeys> cachedKeys;

	private Connection dbConn;

	private static final int KEYS_TO_CACHE = 10;

	private static int beansExistent = 0;
	
	private SessionContext context = null;

	/**
	 * @ejb.create-method view-type="remote"
	 */
	public void ejbCreate()
	{
		beansExistent++;
		cachedKeys = new HashMap<Database.Table, CachedKeys>(Database.Table.values().length);
	}

	/**
	 * Stellt sicher, dass auch nur die tatsächlich verbrauchten Primärschlüssel
	 * als verbraucht in die Datenbank eingetragen werden.
	 * Erst wenn das allerletzte Bean aufgeräumt wird, dann werden nur die tatsächlich
	 * verwendeten Keys in der Datenbank als verbraucht markiert.
	 */
	public void ejbRemove()
	{
		beansExistent--;
		CachedKeys keys;

		if (beansExistent == 0)
		{
			for (Database.Table table : Database.Table.values())
			{
				keys = cachedKeys.get(table);
				if (keys != null && keys.getAvailableCount() > 0)
					updateUsedKeys(table);
			}
		}
	}

	/**
	 * Trägt die tatsächlich verwendeten Schlüssel für die Tabelle <code>table</code>
	 * in die Datenbank ein.
	 * @param table Die Tabelle, deren verwendete Schlüssel aktualisiert werden sollen
	 */
	private void updateUsedKeys(Database.Table table)
	{
		dbConn = Database.establishConnection();
		Statement stmt;

		try
		{
			stmt = dbConn.createStatement();
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
			return;
		}

		try
		{
			String sql = "UPDATE SurrogateKeys SET primKey = " + " ( SELECT MAX("
			+ table.getPrimKeyName() + ") FROM " + table + " ) WHERE tableName='" + table + "';";

			stmt.execute(sql);

			// Gecachte Keys ungültig machen.
			cachedKeys.remove(table);

			dbConn.close();
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
			return;
		}
	}

	/**
	 * Aktualisiert den Primärschlüssel-Cache für die Tabelle <code>table</code>.
	 * @param table Die Tabelle, deren Cache aktualisiert werden soll.
	 * @throws CacheException
	 */
	private void updateCache(Database.Table table) throws CacheException
	{
		dbConn = Database.establishConnection();
		Statement stmt;
		int newKey = -1;
		ResultSet rs;
		
		try
		{
			stmt = dbConn.createStatement();
			
			rs = stmt.executeQuery("SELECT primkey FROM SurrogateKeys WHERE tableName='" + table + "';");
			rs.next();
			newKey = rs.getInt(1) + 1;

			stmt.execute("UPDATE SurrogateKeys SET primKey = primkey+" + KEYS_TO_CACHE
			+ " WHERE tableName='" + table + "';");

			cachedKeys.remove(table);
			cachedKeys.put(table, new CachedKeys(newKey, KEYS_TO_CACHE));

			dbConn.close();
		}
		catch (Exception e)
		{
			cachedKeys.remove(table);
			e.printStackTrace();
			throw new CacheException("An error occured while updating the surrogate keys cache.");
		}
	}
	
	/**
	 * Gibt ein uniquen Primärschlüssel für die Tabelle <code>table</code> zurück.
	 *  
	 * @ejb.interface-method
	 */
	public int getNewPrimaryKey(Table table) throws CacheException
	{
		if (cachedKeys.get(table) == null || !cachedKeys.get(table).hasMoreElements())
		{
			try
			{
				updateCache(table);
			}
			catch (CacheException ce)
			{
				context.setRollbackOnly();
				throw ce;
			}
		}		

		return cachedKeys.get(table).nextElement();
	}
	
	public void setSessionContext(SessionContext arg0) throws EJBException, RemoteException
	{
		this.context = arg0;		
	}
}

/**
 * Hilfsklasse, die zur Verwaltung einer beliebigen Anzahl von Primärschlüsseln
 * verwendet wird.
 * 
 * @author Tobias Langner
 */
class CachedKeys
{
	private int currentKey, keysAvailable;

	public CachedKeys(int first, int count)
	{
		currentKey = first;
		keysAvailable = count;
	}

	public void update(int first, int count)
	{
		currentKey = first;
		keysAvailable = count;
	}

	public boolean hasMoreElements()
	{
		return keysAvailable > 0;
	}

	public Integer nextElement()
	{
		keysAvailable--;
		return currentKey++;
	}

	public int getAvailableCount()
	{
		return keysAvailable;
	}

	public String toString()
	{
		String toReturn = "Available keys: ";
		for (int i = 0; i < keysAvailable; i++)
			toReturn += (currentKey + i) + " ";
		return toReturn;
	}
}