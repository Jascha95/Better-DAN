package proglang.j2ee.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.GregorianCalendar;

import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.jms.TopicSession;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

import proglang.j2ee.ejbs.AddressLocal;
import proglang.j2ee.ejbs.AddressUtil;
import proglang.j2ee.ejbs.BookManagerLocal;
import proglang.j2ee.ejbs.BookManagerUtil;
import proglang.j2ee.ejbs.BookValue;
import proglang.j2ee.ejbs.BooksPerPage;
import proglang.j2ee.ejbs.CardInformationLocal;
import proglang.j2ee.ejbs.CardInformationUtil;
import proglang.j2ee.ejbs.CustomerLocal;
import proglang.j2ee.ejbs.ModelBean;
import proglang.j2ee.ejbs.ModelLocal;
import proglang.j2ee.ejbs.ModelUtil;
import proglang.j2ee.ejbs.ModelBean.Caches;
import proglang.j2ee.helpers.XmlHelper;

/**
 * Servlet implementation class for Servlet: test
 * 
 * @web.servlet name="Controller" display-name="Controller"
 * 
 * @web.servlet-mapping url-pattern="*.do"
 * 
 */

public class Controller extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet
{
	/*
	 * (non-Java-doc)
	 * 
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */

	private static final long serialVersionUID = 1L;

	ModelLocal model;

	public Controller()
	{
		super();
	}

	/*
	 * (non-Java-doc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// versuche, Seite auszuwerten
		try
		{
			HttpSession session = request.getSession();
			String command = request.getServletPath();
			ModelLocal model = (ModelLocal) session.getAttribute("model");

			if (model == null)
			{
				model = ModelUtil.getLocalHome().create();
				session.setAttribute("model", model);
			}

			// enter the bookstore
			if (command.equals("/bookstore.do"))
			{
				getServletContext().getRequestDispatcher("/jsp/Welcome_Page.jsp").forward(request, response);
			}
			// kleiner Test für die neue updateCache(...) funktion.
			else if (command.equals("/dbtest.do"))
			{
				model.setCategory(22); // Thriller
				model.updateCache(Caches.categoryBooks, 0);
				response.getWriter().println("Tschaka ich habs! \n <br />" + model.getCategoryBooks());
			}

			// view the shoppingcart
			else if (command.equals("/view_cart.do"))
			{
				getServletContext().getRequestDispatcher("/jsp/Shoppingcart.jsp").forward(request, response);
			}

			// you have to login if you want to buy something
			else if (command.equals("/login.do"))
			{
				getServletContext().getRequestDispatcher("/jsp/Login.jsp").forward(request, response);
			}

			// you search a book?
			else if (command.equals("/search.do"))
			{
				String searchString = request.getParameter("searchString");
				request.setAttribute("searchStr", searchString);
				model.findMatches(searchString);
				getServletContext().getRequestDispatcher("/jsp/Search_Result.jsp").forward(request, response);
			}

			// Buchdetails anzeigen
			else if (command.equals("/display.do"))
			{
				int bookId = Integer.parseInt(request.getParameter("id"));
				String featured = request.getParameter("featured");

				if ((featured != null) && featured.equalsIgnoreCase("true"))
					model.setSelectedBook(bookId, Caches.featuredBooks);
				else
					model.setSelectedBook(bookId, Caches.categoryBooks);

				getServletContext().getRequestDispatcher("/jsp/Details.jsp").forward(request, response);
			}

			// Forward um einen Account zu erstellen
			else if (command.equals("/register.do"))
			{
				getServletContext().getRequestDispatcher("/jsp/Customer_Registration.jsp").forward(request, response);
			}

			else if (command.equals("/welcome.do"))
			{
				model.setCategory(0); // 0 = Kategorie "All"
				getServletContext().getRequestDispatcher("/jsp/Welcome_Page.jsp").forward(request, response);
			}

			// auf der loginseite
			else if (command.equals("/logged_in.do"))
			{
				String email = request.getParameter("emailaddress");
				String password = request.getParameter("password");

				// Check if User wants to log in as admin.
				String strAdminLogin = request.getParameter("adminLogin");
				boolean adminLogin = (strAdminLogin != null) && strAdminLogin.equals("on");

				// TODO: logIn muss ein bool zurückgeben welches angibt, ob die der
				// login-Vorgang erfolgreich war.
				boolean loggedIn = model.logIn(email, password, adminLogin);

				if (loggedIn)
					getServletContext().getRequestDispatcher("/jsp/Welcome_Page.jsp").forward(request, response);
				else
					getServletContext().getRequestDispatcher("/jsp/Login_Error_Page.jsp").forward(request, response);
			}
			// Die ganze Anmeldung is in einer Transaktion verpackt, damit nach einer
			// unvollständigen Anmeldung kein Problem mit bereits bestehenden
			// Customern
			// gibt.
			else if (command.equals("/thank_you_registration.do"))
			{
				if (request.getParameter("password").equals(request.getParameter("password_rep")))
				{
					Context jndiContext = new InitialContext();
					UserTransaction ut = (UserTransaction) jndiContext.lookup("java:comp/UserTransaction");
					ut.begin();
					model.register(request.getParameter("fullname"), request.getParameter("emailaddress"), request
							.getParameter("password"));
					CustomerLocal customer = model.getCustomer();

					// erstelle neues AddressLocal mit Customerdaten
					AddressLocal address = AddressUtil.getLocalHome().create(request.getParameter("street"),
							request.getParameter("city"), request.getParameter("state"), request.getParameter("country"),
							new Integer(request.getParameter("zip")));

					// erstelle neues CardInformationLocal mit Customerdaten
					CardInformationLocal cardInfo = CardInformationUtil.getLocalHome().create(
							request.getParameter("creditcard_no"),
							request.getParameter("cards"),
							new GregorianCalendar(Integer.parseInt(request.getParameter("Month")), Integer.parseInt(request
									.getParameter("Year")), 1).getTime(), request.getParameter("cardholder"));

					customer.setAddress(address);
					customer.setCardInformation(cardInfo);
					ut.commit();
					getServletContext().getRequestDispatcher("/jsp/Thank_You_Registration.jsp").forward(request, response);
				}
				else
					getServletContext().getRequestDispatcher("/jsp/Customer_Registration_Error_Page.jsp").forward(request,
							response);
			}

			else if (command.equals("/add_to_cart.do"))
			{
				int quantity = Integer.parseInt(request.getParameter("quantity"));
				model.addCurrentBook(quantity);
				getServletContext().getRequestDispatcher("/jsp/Shoppingcart.jsp").forward(request, response);
			}

			else if (command.equals("/edit_account.do"))
			{
				getServletContext().getRequestDispatcher("/jsp/Customer_Registration.jsp").forward(request, response);
			}

			else if (command.equals("/logout.do"))
			{
				model.logOut();
				getServletContext().getRequestDispatcher("/jsp/Thank_You.jsp").forward(request, response);
			}

			else if (command.equals("/update.do"))
			{
				Enumeration e = request.getParameterNames();
				while (e.hasMoreElements())
				{
					String att = (String) e.nextElement();
					if (att.startsWith("quantity"))
					{
						int bookId = Integer.parseInt(att.substring(8));
						int quantity = Integer.parseInt(request.getParameter(att));
						model.updateQuantity(bookId, quantity);
					}
				}
				getServletContext().getRequestDispatcher("/jsp/Shoppingcart.jsp").forward(request, response);
			}

			else if (command.equals("/buy.do"))
			{
				if (model.getLoggedIn())
				{
					getServletContext().getRequestDispatcher("/jsp/Order_Information.jsp").forward(request, response);
				}
				else
				{
					getServletContext().getRequestDispatcher("/jsp/Customer_Registration.jsp").forward(request, response);
				}
			}

			else if (command.equals("/continue_shopping.do"))
			{
				getServletContext().getRequestDispatcher("/jsp/Categories.jsp").forward(request, response);
			}

			else if (command.equals("/thank_you.do"))
			{
				model.placeOrder();
				getServletContext().getRequestDispatcher("/jsp/Thank_You.jsp").forward(request, response);
			}

			else if (command.equals("/browse.do"))
			{
				model.setCategory(0); // Rootkategorie = aktuelle Kategorie
				model.clearCache(Caches.categoryBooks);
				model.clearCache(Caches.featuredBooks);
				getServletContext().getRequestDispatcher("/jsp/Categories.jsp").forward(request, response);
			}

			else if (command.equals("/browseSub.do"))
			{
				model.setCategory(Integer.parseInt(request.getParameter("category")));
				request.setAttribute("currentPage", 1);
				model.updateCache(Caches.categoryBooks, 0);
				model.updateCache(Caches.featuredBooks, 0);
				getServletContext().getRequestDispatcher("/jsp/Categories.jsp").forward(request, response);
			}

			else if (command.equals("/delete_item.do"))
			{
				System.out.println("Deleting item --> " + request.getParameter("id"));
				model.removeBookFromCart(Integer.parseInt(request.getParameter("id")));
				getServletContext().getRequestDispatcher("/jsp/Shoppingcart.jsp").forward(request, response);
			}

			else if (command.equals("/listOrders.do"))
			{
				getServletContext().getRequestDispatcher("/jsp/List_Orders.jsp").forward(request, response);
			}
			
			else if (command.equals("/orderDetails.do"))
			{
				int orderId = Integer.parseInt(request.getParameter("id"));
				model.setSelectedOrderId(orderId);
				getServletContext().getRequestDispatcher("/jsp/Order_Details.jsp").forward(request, response);
			}
			
			else if (command.equals("/listCustomers.do"))
			{
				getServletContext().getRequestDispatcher("/jsp/List_Customers.jsp").forward(request, response);
			}
			
			else if (command.equals("/customerDetails.do"))
			{
				int customerId = Integer.parseInt(request.getParameter("id"));
				model.setSelectedCustomerId(customerId);
				getServletContext().getRequestDispatcher("/jsp/Customer_Details.jsp").forward(request, response);
			}

			else if (command.equals("/addBooks.do"))
			{
				try
				{
					getServletContext().getRequestDispatcher("/jsp/Add_Books.jsp").forward(request, response);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}

			else if (command.equals("/do_addBooks.do"))
			{
				String content = request.getParameter("content");
				String xml = "<?xml version=\"1.0\" encoding=\"ISO-8859-2\"?>\n<books>\n" + content + "\n</books>";
				BookManagerLocal bookManager = BookManagerUtil.getLocalHome().create();
				BookValue[] books = XmlHelper.getBookValuesFromXml(xml);
				if (books != null)
					bookManager.addBooks(books);
				else
					System.out.println("Error when trying to add books...");
			}

			else if (command.equals("/changeBooksPerPage.do"))
			{
				BooksPerPage tmp;
				int page = Integer.parseInt(request.getParameter("page"));
				int newBooksPerPage = Integer.parseInt(request.getParameter("bPP"));
				int oldBooksPerPage = model.getActualBooksPerPage().getBooksPerPage();
				switch (newBooksPerPage)
				{
				case 5:
					tmp = BooksPerPage._5;
					break;

				case 10:
					tmp = BooksPerPage._10;
					break;

				case 20:
					tmp = BooksPerPage._20;
					break;

				case 40:
					tmp = BooksPerPage._40;
					break;

				default:
					throw new Exception("Übergebener Wert für die Anzahl der Seiten (" + newBooksPerPage
							+ ") ist nicht vorgesehen!");
				}
				model.setActualBooksPerPage(tmp);
				// alte Position auf neue Seite umrechnen
				int currentPosition = oldBooksPerPage * page;
				int newPage = currentPosition / newBooksPerPage;
				// untere Grenze abfangen
				if (newPage == 0)
					newPage++;
				// obere Grenze abfangen (Es wurde angenommen dass 40 Bücher angezeigt
				// werden, obwohl es gar nicht so viele gibt => Seitenzahl viel zu
				// hoch).
				ArrayList<Integer> maxPages = model.getNumberOfPages();
				if (newPage > maxPages.size())
					newPage = maxPages.size();
				request.setAttribute("currentPage", newPage);

				int offset = (newPage - 1) * newBooksPerPage;
				model.updateCache(Caches.categoryBooks, offset);

				getServletContext().getRequestDispatcher("/jsp/Categories.jsp").forward(request, response);
			}

			else if (command.equals("/goToPage.do"))
			{
				int currentPage = Integer.parseInt(request.getParameter("page"));
				request.setAttribute("currentPage", currentPage);
				int startEntry = ((currentPage - 1) * model.getActualBooksPerPage().getBooksPerPage());
				model.updateCache(Caches.categoryBooks, startEntry);

				getServletContext().getRequestDispatcher("/jsp/Categories.jsp").forward(request, response);
			}
			else if (command.equals("/testQueue.do"))
			{
				Context jndiContext = null;
				QueueConnectionFactory factory = null;
				QueueConnection connect;
				QueueSession queueSession;

				QueueSender sender = null;
				try
				{
					jndiContext = new InitialContext();
					factory = (QueueConnectionFactory) jndiContext.lookup("weblogic.jms.ConnectionFactory");
					connect = factory.createQueueConnection();
					queueSession = connect.createQueueSession(false, TopicSession.AUTO_ACKNOWLEDGE);

					Queue queue = (Queue) jndiContext.lookup("OrderQueue");
					sender = queueSession.createSender(queue);

					TextMessage msg = queueSession.createTextMessage("testMessage");
					connect.start(); // WICHTIG!!!!
					sender.send(msg);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
				finally
				{
					try
					{
						if (null != sender)
							sender.close();
					}
					catch (Exception ex)
					{
					}
					try
					{
						if (null != jndiContext)
							jndiContext.close();
					}
					catch (Exception ex)
					{
					}
				}
			}

		}
		catch (Exception e)
		{
			System.out.println("Yeap Exception");
			e.printStackTrace();
		}
	}

	/*
	 * (non-Java-doc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}
}