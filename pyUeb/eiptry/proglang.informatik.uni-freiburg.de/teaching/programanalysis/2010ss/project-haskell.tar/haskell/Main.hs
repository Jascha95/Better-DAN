module Main where

import AST
import Parser
import PrettyPrint
import Scanner
import Text.PrettyPrint
import Test.QuickCheck

-- test it
main :: IO ()
main = do 
        let fname = "examples/ex1.fun"
        input <- readFile fname
        let res = parseTokens pTerm (tokenize fname input)
        case res of
         Left errs -> putStrLn $ head errs
         Right tree -> do 
                         putStrLn $ render $ prettyTerm PRoot False tree

prop_Id ast =
  collect (depth ast) $ Right ast == parseTokens pTerm (tokenize "" (render $ prettyTerm PRoot False ast))

t = check defaultConfig{configMaxTest=500} prop_Id
