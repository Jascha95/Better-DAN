module Parser where

-- import the the library functions from uulib
import UU.Parsing
import UU.Scanner

-- import our custom made Alex-scanner
import Scanner


-- Some boilerplate code to use the parser
-- Give `parse tokens' to your parser and a list of tokens, returned by the `scanTokens'
-- function exported by the Scanner module, then you get either a list of strings with error
-- messages in case of a parse error, or the parse tree.
type TokenParser a = Parser Token a

parseTokens :: TokenParser a -> [Token] -> Either [String] a
parseTokens p tks
  = if null msgs
    then final `seq` Right v
    else Left (map show msgs)
  where
    steps = parse p tks
    msgs  = getMsgs steps
    (Pair v final) = evalSteps steps


-- define an AST tree
type Var = String
type Lab = Int

data Stmt
  = Assign Lab Var AExp 
  | Skip Lab
  | If Lab BExp Stmt Stmt
  | While Lab BExp Stmt
  | Seq Stmt Stmt
  deriving Show

data AExp
  = Ident String
  | Const Int
  | NumOp Nop AExp AExp
  deriving Show

data BExp
  = CTrue
  | CFalse
  | Boolop Bop BExp BExp
  | Relop Rop AExp AExp
  deriving Show

data Nop = Plus | Times | Minus deriving Show
data Bop = And deriving Show
data Rop = Ls | Gt deriving Show

-- code for the parser
-- Note: * make sure that the parser is not left recursive
--       * make sure that the parser is not ambiguous
--           (by introducing priority levels for the operators)


-- Expr -> Factor | Factor + Expr
pAExp :: TokenParser AExp
pAExp
  =   pFactor 
  <|> NumOp Plus <$> pFactor <* pKey "+" <*> pAExp
  <|> NumOp Minus <$> pFactor <* pKey "-" <*> pAExp

-- Factor -> Term | Term * Factor
pFactor :: TokenParser AExp
pFactor
  =   pTerm
  <|> NumOp Times <$> pTerm <* pKey "*" <*> pFactor

-- Term -> Var
-- Term -> Int
pTerm :: TokenParser AExp
pTerm
  =   Ident <$> pVarid
  <|> (Const . read) <$> pInteger16
  <|> (\_ e _ -> e) <$> pKey "(" <*> pAExp <*> pKey ")"


pBExp :: TokenParser BExp
pBExp 
  = pBConst
  <|> Boolop And <$> pBConst <* pKey "&" <*> pBExp
  <|> Relop  Ls  <$> pAExp <* pKey "<" <*> pAExp
  <|> Relop  Gt  <$> pAExp <* pKey ">" <*> pAExp
  

pBConst :: TokenParser BExp
pBConst 
   =  CTrue  <$ pKey "true"
  <|> CFalse <$ pKey "false"

pStmt :: TokenParser Stmt
pStmt 
  = pChainl (Seq <$ pKey ";") pSingleStmt 
 
pSingleStmt :: TokenParser Stmt
pSingleStmt 
  =   Assign 0 <$> pVarid <* pKey ":=" <*> pAExp
  <|> Skip 0 <$ pKey "skip"
  <|> If 0 <$ pKey "if" <*> pBExp <* pKey "{"  <*> pStmt <* pKey "}"  <* pKey "else" <* pKey "{" <*> pStmt <* pKey "}" 
  <|> While 0 <$ pKey "while" <*> pBExp <* pKey "do" <* pKey "{" <*> pStmt <* pKey "}"


-- test it
main :: IO ()
main = do 
        let fname = "tests/fac.wh"
        input <- readFile fname
        let res = parseTokens pStmt (tokenize fname input)
        case res of
         Left errs -> putStrLn $ head errs
         Right tree -> putStrLn $ show tree
       
