import java.util.Map;

import whilelang.analysis.GAnalysisAdapter;
import whilelang.node.AAndBop;
import whilelang.node.AAssignStmt;
import whilelang.node.ABoolopBexp;
import whilelang.node.ACfalseBexp;
import whilelang.node.AConstAexp;
import whilelang.node.ACtrueBexp;
import whilelang.node.AEqRop;
import whilelang.node.AGeqRop;
import whilelang.node.AGtRop;
import whilelang.node.AIfStmt;
import whilelang.node.AInt;
import whilelang.node.ALeqRop;
import whilelang.node.ALsRop;
import whilelang.node.AMinusNop;
import whilelang.node.ANumopAexp;
import whilelang.node.AOrBop;
import whilelang.node.APlusNop;
import whilelang.node.AProgram;
import whilelang.node.ARelopBexp;
import whilelang.node.ASeqStmt;
import whilelang.node.ASkipStmt;
import whilelang.node.ATimesNop;
import whilelang.node.AVar;
import whilelang.node.AVarAexp;
import whilelang.node.AWhileStmt;
import whilelang.node.EOF;
import whilelang.node.Node;
import whilelang.node.Start;
import whilelang.node.PStmt;

public class PrettyVisitor extends GAnalysisAdapter<String,Integer> {
	
	private Map<PStmt, Integer> labels;
	
	
	
	public String getString(Start ast) {
		return ast.apply(this,0);
	}

	public String getString(Start ast,Map<PStmt,Integer> labels) {
		this.labels = labels;
		return ast.apply(this,0);
	}

	
	private String getLabelAndIndent (int i,PStmt stmt) {
		String s = "";
		if (this.labels != null) {
			Integer l = this.labels.get(stmt);
			if (l != null) {
				s += l + ": ";
			}
		}
		
		while (i>0) {
			s += "  ";
			--i;
		}
		return s;
	}
	
	@Override
	public String caseAEqRop(AEqRop node, Integer helper) {
		return "==";
	}

	@Override
	public String caseAGeqRop(AGeqRop node, Integer helper) {
		return ">=";
	}

	@Override
	public String caseALeqRop(ALeqRop node, Integer helper) {
		return "<=";
	}

	@Override
	public String caseAOrBop(AOrBop node, Integer helper) {
		return "|";
	}

	@Override
	public String defaultCase(Node node, Integer helper) {
		throw new RuntimeException("not implemented yet");
	}

	
	@Override
    public String caseAWhileStmt(AWhileStmt node, Integer helper)
    {
            String guard = node.getBexp().apply(this, 0);
            String body = node.getStmt().apply(this, helper + 1);
            return getLabelAndIndent(helper,node) + "while " + guard + " do {\n" + body + "}";
    }

	@Override
	public String caseAAndBop(AAndBop node, Integer helper) {
		return "&";		
	}

	@Override
	public String caseAAssignStmt(AAssignStmt node, Integer helper) {
		String lhs = node.getVar().apply(this,0);
		String rhs = node.getAexp().apply(this, 0);
		return getLabelAndIndent(helper,node) + lhs + " := " + rhs;
	}

	@Override
	public String caseABoolopBexp(ABoolopBexp node, Integer helper) {
		String left = node.getLeft().apply(this,0);
		String right = node.getRight().apply(this,0);
		String bop = node.getBop().apply(this,0);
		return "(" + left + " " + bop + " " + right + ")";
	}

	@Override
	public String caseACfalseBexp(ACfalseBexp node, Integer helper) {
		return "false";
	}

	@Override
	public String caseAConstAexp(AConstAexp node, Integer helper) {
		return node.getInt().apply(this,0);
	}

	@Override
	public String caseACtrueBexp(ACtrueBexp node, Integer helper) {
		return "true";
	}

	@Override
	public String caseAGtRop(AGtRop node, Integer helper) {
		return ">";
	}

	@Override
	public String caseAIfStmt(AIfStmt node, Integer helper) {
		String test = node.getBexp().apply(this,0);
		String tbranch = node.getTrueStmt().apply(this,helper+1);
		String fbranch = node.getFalseStmt().apply(this,helper+1);
		return getLabelAndIndent(helper,node) + "if "+ test + " then {\n" + tbranch + 
			"\n" + getLabelAndIndent(helper,null) + "   } else { \n" + fbranch + "}"; 
	}

	@Override
	public String caseAInt(AInt node, Integer helper) {
		return node.getInt().getText();
	}

	@Override
	public String caseALsRop(ALsRop node, Integer helper) {
		return "<";
	}

	@Override
	public String caseAMinusNop(AMinusNop node, Integer helper) {
		return "-";
		}

	@Override
	public String caseANumopAexp(ANumopAexp node, Integer helper) {
		String left = node.getLeft().apply(this,0);
		String right = node.getRight().apply(this,0);
		String nop = node.getNop().apply(this,0);
		return "(" + left + " " + nop + " " + right + ")";
	}

	@Override
	public String caseAPlusNop(APlusNop node, Integer helper) {
		return "+";
	}

	@Override
	public String caseAProgram(AProgram node, Integer helper) {
		return node.getStmts().apply(this, helper);
	}

	@Override
	public String caseARelopBexp(ARelopBexp node, Integer helper) {
		String left = node.getLeft().apply(this,0);
		String right = node.getRight().apply(this,0);
		String rop = node.getRop().apply(this,0);
		return "(" + left + " " + rop + " " + right + ")";

	}

	@Override
	public String caseASeqStmt(ASeqStmt node, Integer helper) {
		String s1 = node.getLeft().apply(this,helper);
		String s2 = node.getRight().apply(this,helper);
		return  s1 + ";\n" + s2;
	}

	@Override
	public String caseASkipStmt(ASkipStmt node, Integer helper) {
		return getLabelAndIndent(helper,node) + "skip";
	}

	@Override
	public String caseATimesNop(ATimesNop node, Integer helper) {
		return "*";
	}

	@Override
	public String caseAVar(AVar node, Integer helper) {
		return node.getVar().getText();
	}

	@Override
	public String caseAVarAexp(AVarAexp node, Integer helper) {
		return node.getVar().apply(this,0);
	}

	@Override
	public String caseEOF(EOF node, Integer helper) {
		return "";
	}

	@Override
	public String caseStart(Start node, Integer helper) {
		return node.getPProgram().apply(this, helper);
	}

	

}
