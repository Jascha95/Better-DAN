/* Create an AST, then invoke our interpreter. */
import java.io.*;
import java.util.Map;

import whilelang.lexer.Lexer;
import whilelang.node.PStmt;
import whilelang.node.Start;
import whilelang.parser.Parser;

public class Main {
		public static void main(String[] args) {
		if (args.length > 0) {
			try {
				Lexer lexer = new Lexer(new PushbackReader(
						new FileReader(args[0]), 1024));
				Parser parser = new Parser(lexer);
				Start ast = parser.parse();
				
				/* You should implement the PrettyVisitor and print the AST with labels */
				LabelingVisitor lab = new LabelingVisitor();
				Map<PStmt,Integer> labels = lab.getLabels(ast);
				
				PrettyVisitor print = new PrettyVisitor();
				System.out.println(print.getString(ast,labels));
				
				FlowVisitor flow = new FlowVisitor();
				
				
		    } catch (Exception e) {
				//System.err.println(e);
				e.printStackTrace(System.err);
			}
		} else {
			System.err.println("usage: java <inputFile>");
			System.exit(1);
		}
	
	}
	
	
	
}