import whilelang.analysis.GAnalysisAdapter;


public class FlowVisitor<PStmt> extends GAnalysisAdapter<PStmt,PStmt>{

}
