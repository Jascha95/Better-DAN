import java.util.HashMap;
import java.util.Map;

import whilelang.analysis.DepthFirstAdapter;
import whilelang.node.AAssignStmt;
import whilelang.node.AIfStmt;
import whilelang.node.ASkipStmt;
import whilelang.node.AWhileStmt;
import whilelang.node.PStmt;
import whilelang.node.Start;



public class LabelingVisitor extends DepthFirstAdapter {

	public Map<PStmt, Integer> getLabels(Start ast) {
		labels = new HashMap<PStmt,Integer>();
		nextFree = 0;
		ast.apply(this);
		return labels;
	}
	
	private Map<PStmt, Integer> labels;
	private int nextFree;
	
	private void addNode(PStmt node) {
		labels.put(node, nextFree ++);
	}
	
	@Override
	public void inAAssignStmt(AAssignStmt node) {
		addNode(node);
	}
	
	@Override
	public void inAIfStmt(AIfStmt node) {
		addNode(node);
	}

	@Override
	public void inASkipStmt(ASkipStmt node) {
		addNode(node);
	}
	@Override
	public void inAWhileStmt(AWhileStmt node) {
		addNode(node);
	}
	
	

}
