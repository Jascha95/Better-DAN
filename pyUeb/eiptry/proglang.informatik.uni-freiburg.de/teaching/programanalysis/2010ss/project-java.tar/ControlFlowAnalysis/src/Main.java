/* Create an AST, then invoke our interpreter. */
import java.io.*;
import fun.lexer.Lexer;
import fun.node.Start;
import fun.parser.Parser;

public class Main {
		public static void main(String[] args) {
		if (args.length > 0) {
			try {
				Lexer lexer = new Lexer(new PushbackReader(
						new FileReader(args[0]), 1024));
				Parser parser = new Parser(lexer);
				Start ast = parser.parse();
				
			    PrettyVisitor print = new PrettyVisitor();
				System.out.println(print.getString(ast));
				
		    } catch (Exception e) {
				//System.err.println(e);
				e.printStackTrace(System.err);
			}
		} else {
			System.err.println("usage: java <inputFile>");
			System.exit(1);
		}
	
	}
	
	
	
}