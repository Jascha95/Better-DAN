module Parser where

-- import the the library functions from uulib
import UU.Parsing
import UU.Scanner

-- import our custom made Alex-scanner
import Scanner

import Data.List as List
import Data.IntMap as Map

-- Some boilerplate code to use the parser
-- Give `parse tokens' to your parser and a list of tokens, returned by the `scanTokens'
-- function exported by the Scanner module, then you get either a list of strings with error
-- messages in case of a parse error, or the parse tree.
type TokenParser a = Parser Token a

parseTokens :: TokenParser a -> [Token] -> Either [String] a
parseTokens p tks
  = if List.null msgs
    then final `seq` Right v
    else Left (List.map show msgs)
  where
    steps = parse p tks
    msgs  = getMsgs steps
    (Pair v final) = evalSteps steps

-- define an AST tree
type Var = String
type Lab = Int

data Stmt
  = Assign Lab Var AExp 
  | Skip Lab
  | If Lab BExp Stmt Stmt
  | While Lab BExp Stmt
  | Seq Stmt Stmt
  deriving (Show, Eq)

data AExp
  = Ident String
  | Const Int
  | NumOp Nop AExp AExp
  deriving (Show, Eq)

data BExp
  = CTrue
  | CFalse
  | Neg BExp
  | Boolop Bop BExp BExp
  | Relop Rop AExp AExp
  deriving (Show,Eq)

data Nop = Plus | Times | Minus deriving (Show, Eq)
data Bop = And | Or deriving (Show, Eq)
data Rop = Ls | Gt | Leq | Geq | Eq deriving (Show, Eq)

-- code for the parser
-- Note: * make sure that the parser is not left recursive
--       * make sure that the parser is not ambiguous
--           (by introducing priority levels for the operators)


-- AExp -> Factor | Factor + AExp | Factor - AExp
pAExp :: TokenParser AExp
pAExp
  =   pFactor 
  <|> NumOp Plus <$> pFactor <* pKey "+" <*> pAExp
  <|> NumOp Minus <$> pFactor <* pKey "-" <*> pAExp

-- Factor -> Term | Term * Factor
pFactor :: TokenParser AExp
pFactor
  =   pTerm
  <|> NumOp Times <$> pTerm <* pKey "*" <*> pFactor

-- Term -> Var | Int | (Term)
pTerm :: TokenParser AExp
pTerm
  =   Ident <$> pVarid
  <|> (Const . read) <$> pInteger16
  <|> pParens pAExp 

-- BExp -> 
pBExp :: TokenParser BExp
pBExp 
   =  pAnd
  <|> Boolop Or <$> pAnd <* pKey "|" <*> pBExp

pAnd :: TokenParser BExp
pAnd 
   =  pComp
  <|> Boolop Or <$> pComp <* pKey "&" <*> pAnd

pComp :: TokenParser BExp
pComp 
  = pBSingle
  <|> Relop  Ls  <$> pAExp <* pKey "<" <*> pAExp
  <|> Relop  Gt  <$> pAExp <* pKey ">" <*> pAExp
  <|> Relop  Leq <$> pAExp <* pKey "<=" <*> pAExp
  <|> Relop  Geq <$> pAExp <* pKey ">=" <*> pAExp
  <|> Relop  Eq  <$> pAExp <* pKey "==" <*> pAExp

pBSingle :: TokenParser BExp
pBSingle
   =  CTrue  <$ pKey "true"
  <|> CFalse <$ pKey "false"
  <|> Neg <$ pKey "!" <*> pBSingle
  <|> pParens pBExp

pStmt :: TokenParser Stmt
pStmt 
  = pChainl (Seq <$ pKey ";") pSingleStmt 
 
pSingleStmt :: TokenParser Stmt
pSingleStmt 
  =   Assign 0 <$> pVarid <* pKey ":=" <*> pAExp
  <|> Skip 0 <$ pKey "skip"
  <|> If 0 <$ pKey "if" <*> pBExp <* pKey "{"  <*> pStmt <* pKey "}"  <* pKey "else" <* pKey "{" <*> pStmt <* pKey "}" 
  <|> While 0 <$ pKey "while" <*> pBExp <* pKey "do" <* pKey "{" <*> pStmt <* pKey "}"


-- pretty printing  of AST

prettyLab :: Int -> Int -> String
prettyLab l offset = show l ++ ": " ++ replicate offset ' '

prettyStmt :: Stmt -> Int -> String
prettyStmt stmt offset =
  case stmt of
    Assign l var exp -> prettyLab l offset ++ var ++ " := " ++ prettyAExp exp
    Skip l -> prettyLab l offset ++ "skip"
    If l test s1 s2 -> prettyLab l offset ++ "if " ++ prettyBExp test ++ "\n" 
                          ++ prettyStmt s1 (offset + 3) ++ "\n   else\n" ++ prettyStmt s2 (offset + 3)
    While l guard body -> prettyLab l offset ++ "while " ++ prettyBExp guard ++ " do\n" ++ prettyStmt body (offset + 3) 
    Seq s1 s2 -> prettyStmt s1 offset ++ ";\n" ++ prettyStmt s2 offset
  
prettyAExp :: AExp -> String
prettyAExp aexp =
  case aexp of
    Ident s -> s
    Const i -> show i
    NumOp op e1 e2 -> "(" ++ prettyAExp e1 ++ prettyNop op ++ prettyAExp e2 ++ ")"

prettyBExp :: BExp -> String
prettyBExp bexp =
  case bexp of
    CTrue -> "true"
    CFalse -> "false"
    Neg e -> "!(" ++ prettyBExp e ++ ")" 
    Boolop op e1 e2 -> "(" ++ prettyBExp e1 ++ prettyBop op ++ prettyBExp e2 ++")"
    Relop op e1 e2 -> "(" ++ prettyAExp e1 ++ prettyRop op ++ prettyAExp e2 ++ ")"
    
prettyNop :: Nop -> String
prettyNop op =
  case op of
     Plus  -> "+"
     Minus -> "-"
     Times -> "*"

prettyRop :: Rop -> String
prettyRop op =
  case op of
     Ls  -> "<"
     Gt  -> ">"
     Leq -> "<="
     Geq -> ">="
     Eq  -> "=="

prettyBop :: Bop -> String
prettyBop op =
   case op of
      And -> "&"
      Or  -> "|"

prettyLists :: [(Int,[AExp])] -> String
prettyLists rows = foldl (\s (i,e) -> s ++ show i ++ ": " ++ (show (List.map prettyAExp e)) ++ "\n") [] rows 
          


