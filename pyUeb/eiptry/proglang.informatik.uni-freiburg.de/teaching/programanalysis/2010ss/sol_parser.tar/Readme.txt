Install software:
-- You will need some Haskell compiler. 
   Preferably, you should install the Haskell Plattform.
-- For the scanner, you need alex. It should be included in the Plattform, if not run: 
     cabal install alex
-- For the parser, you need the uulib package:
     cabal install uulib

Compile scanner: 
-- compile with alex -o Scanner.hs -g Scanner.x 
-- This gives Scanner.hs

Compile parser:
-- You can try to run the program so far with
     runghc Main.hs 
-- Alternatively, you can start the interpreter ghci and load it 
     >:l Main.hs
   You can then run it with
     > main 

Make sure you have the tests directory in the same folder,
otherwise it will not find the test file.

------------------
Diff to previous version: 
Extended Scanner and Parser with some more relational operators (<=,>=,==) and or (||).
Added pretty-printer for AST.

