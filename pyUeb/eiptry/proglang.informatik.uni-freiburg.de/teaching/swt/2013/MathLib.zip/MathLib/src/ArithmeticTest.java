import static org.junit.Assert.*;

import org.junit.Test;


public class ArithmeticTest {

	@Test
	public void testMax() {
		assertEquals(2, Arithmetic.max(1, 2));
	}

	@Test
	public void testAbs() {
		assertEquals(2, Arithmetic.abs(-2));
	}

	@Test
	public void testDivIntInt() {
		assertEquals(2, Arithmetic.div(5, 2));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testDivIntIntThrows() {
		Arithmetic.div(6, 0);
	}

	@Test
	public void testDivFloatFloat() {
		assertEquals(0.33333333d, Arithmetic.div(1.0d, 3.0d), 0.0000001d);
	}

}
