
public class Arithmetic {
	public static int max(int a, int b) {
		return (a > b) ? a : b;
	}
	
	public static int abs(int a) {
		return (a >= 0) ? a : -a;
	}
	
	public static int div(int dividend, int divisor) {
		if (divisor != 0) {
			return dividend / divisor;
		} else {
			throw new IllegalArgumentException("Division by 0");
		}
	}
	
	public static double div(double dividend, double divisor) {
		if (divisor != 0) {
			return dividend / divisor;
		} else {
			throw new IllegalArgumentException("Division by 0");
		}
	}
}
