package v20110608;

import static org.junit.Assert.*;

import org.junit.Test;

public class Ex1Test {

	@Test
	public void testFind_min() {
		int [] a1 = {1};
		int r1 = Ex1.find_min(a1);
		int e1 = 1;
		assertEquals(e1, r1);
		
		int [] a2 = {1,2,3};
		int r2 = Ex1.find_min(a2);
		int e2 = 1;
		assertEquals(e2, r2);
		
		int [] a3 = {3,2,1};
		int r3 = Ex1.find_min(a3);
		int e3 = 1;
		assertEquals(e3, r3);
		
		int [] a4 = {4,2,3};
		int r4 = Ex1.find_min(a4);
		int e4 = 2;
		assertEquals(e4, r4);
		
		int [] a5 = {0,0};
		int r5 = Ex1.find_min(a5);
		int e5 = 0;
		assertEquals(e5, r5);
	}
	
	@Test(expected=NullPointerException.class)
	public void testFind_min_null() {
		Ex1.find_min(null);
	}
	
	@Test(expected=Exception.class)
	public void testFind_min_empty() {
		int [] a1 = {};
		Ex1.find_min(a1);
	}

	private static final int ITERATIONS = 1000;

	@Test
	public void testInsert_Randomly() {
		for(int i=0; i<ITERATIONS; i++) {
			testInsert_oneRun();
		}
	}

	private void testInsert_oneRun() {
		int [] x = generateSortedArrayRandomly();
		int n = generateIntRandomly();
		int [] r = Ex1.insert(x, n);
		assertTrue(isSortedArray(r));
		assertTrue(x.length+1 == r.length);
		int testedLessThanN = -1;
		for(int i=0; i<x.length; i++) {
			if(x[i] <= n) {
				assertTrue(x[i] == r[i]);
				testedLessThanN = i;
			} else {
				assertTrue(x[i] == r[i+1]);
			}
		}
		assertTrue(r[testedLessThanN+1] == n);
		
	}

	private boolean isSortedArray(int[] r) {
		// TODO Auto-generated method stub
		return false;
	}

	private int generateIntRandomly() {
		// TODO Auto-generated method stub
		return 0;
	}

	private int[] generateSortedArrayRandomly() {
		// TODO Auto-generated method stub
		return null;
	}


}
