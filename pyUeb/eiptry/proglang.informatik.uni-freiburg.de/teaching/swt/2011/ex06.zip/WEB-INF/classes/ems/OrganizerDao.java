package ems;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;



@Stateless
public class OrganizerDao{
	@PersistenceContext protected EntityManager em;
	
	public void persist(Organizer organizer) {
    	
    	em.persist(organizer);
      	
    }
	//query to 
	public Organizer get(String username, String eventname) {
		String queryString = "SELECT o FROM Organizer o WHERE o.username = '"+username+
								"' AND o.eventname = '"+eventname+"'";
		List<Organizer> result = em.createQuery(queryString, Organizer.class).getResultList();

		if (result.size() != 1)
			return null;
		else
			return result.get(0);
	}
	
	public boolean exist(String username, String eventname) {
		if (this.get(username, eventname) != null)
			return true;
		else
			return false;
	}
	//query to check is user is organizer.
	public List<Organizer> getByUsername(String username){

		String queryString =
			"SELECT o FROM Organizer o WHERE o.username = '" + username + "'";
		List<Organizer> result = em.createQuery(queryString, Organizer.class).getResultList();

		return result;
	}
	
	public List<Organizer> getByEventname(String eventname){
		String queryString =
			"SELECT o FROM Organizer o WHERE o.eventname = '" + eventname + "'";
		return em.createQuery(queryString, Organizer.class).getResultList();
	}
	//method used to remove events-user
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public boolean remove(String username, String eventname) {
		Organizer o = get(username, eventname);
		if (o != null) {
			em.remove(o);
			return true;
		} else {
			return false;
		}
	}
}
