package ems;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class Organizer implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue public Long id;
	private String username;
	private String eventname;
	
	public Organizer(String username, String eventname){
		this.username = username;
		this.eventname = eventname;
	}
	
	public String getUsername(){
		return username;
	}
	
	public String getEventname(){
		return eventname;
	}
}
