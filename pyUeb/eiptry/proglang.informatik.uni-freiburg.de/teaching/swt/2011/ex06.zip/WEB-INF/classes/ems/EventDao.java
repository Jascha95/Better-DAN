package ems;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;	
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;




@Stateless
public class EventDao {
	
	@PersistenceContext private EntityManager em;
	
	public void persist(Event event) {
    	
    	em.persist(event);
      	
    }
	
	//To check if exist an agent!
	public boolean existByName(String name){
		if (getByName(name) == null)
			return false;
		else
			return true;
	}
	
	//Query to find event name.
	public Event getByName(String name){
		String queryString = "SELECT e FROM  Event e WHERE e.name = '"+name+"'";
		List<Event> result = em.createQuery(queryString, Event.class).getResultList();
		if (result.size() != 1)
			return null;
		else
			return result.get(0);
	}
	
	
	public List<Event> getPrice() {
        TypedQuery<Event> query = em.createQuery(
            "SELECT e.price FROM Participant p, Event e WHERE p.eventname = e.name", Event.class);
        return query.getResultList();
    }
	
	
	public List<Event> getByNames(List<String> names){
		
		List<Event> objects = new ArrayList<Event>();
		Event object;
		for (String name: names){
			object = getByName(name);
			if (object != null && !objects.contains(object)) objects.add(object);
		}
		return objects;
	}
	//Remove event.
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void removeByName(String name) {
    	
    	Event event = (Event)em.getReference(Event.class, name);
    	
    	
    	if (event != null) {  
    	em.remove(em.merge(event));
    	
    		}else 
    			System.out.println("No Event found");
    }
	//query to get price and name from Event table.
	public List<Event> getAllEvent() {
        TypedQuery<Event> query = em.createQuery(
            "SELECT e FROM Event e", Event.class);
        return query.getResultList();
    }
	
}
