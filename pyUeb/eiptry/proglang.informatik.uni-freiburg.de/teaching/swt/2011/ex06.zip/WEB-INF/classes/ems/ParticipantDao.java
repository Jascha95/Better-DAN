package ems;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;




@Stateless
public class ParticipantDao {
	@PersistenceContext protected EntityManager em;
	
	public void persist(Participant participant) {
    	
    	em.persist(participant);
      	
    }

	public Participant get(String username, String eventname) {
		String queryString = "SELECT p FROM Participant p WHERE p.username = '"+username+
								"' AND p.eventname = '"+eventname+"'";
		
		List<Participant> result = em.createQuery(queryString, Participant.class).getResultList();
		if (result.size() != 1)
			return null;
		else
			return result.get(0);
	}
	
	public boolean exist(String username, String eventname) {
		if (this.get(username, eventname) != null)
			return true;
		else
			return false;
	}
	
	public List<Participant> getpartEvent() {
        TypedQuery<Participant> query = em.createQuery(
            "SELECT p FROM Participant p ORDER BY p.id", Participant.class);
        return query.getResultList();
    }
	
		
	public List<Participant> getByUsername(String username){
		String queryString =
			"SELECT p FROM Participant p WHERE p.username = '" + username + "'";
		
		return em.createQuery(queryString, Participant.class).getResultList();
	}
	
	public List<Participant> getByEventname(String eventname){
		String queryString =
			"SELECT p FROM Participant p WHERE p.eventname = '" + eventname + "'";
		return em.createQuery(queryString, Participant.class).getResultList();
	
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public boolean remove(String username, String eventname) {
		Participant p = get(username, eventname);
		if (p != null) {
			em.remove(p);
			return true;
		} else {
			return false;
		}
	}
	
	public List<Participant> getAll() {
        TypedQuery<Participant> query = em.createQuery(
            "SELECT p FROM Participant p", Participant.class);
        return query.getResultList();
    }
	
	
}
