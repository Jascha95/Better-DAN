package ems;

import java.util.List;
import javax.ejb.Stateless;	
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;



@Stateless
public class UserDao {
	@PersistenceContext protected EntityManager em;
	
	public void persist(UserAccount account) {
    	
    	em.persist(account);
    
    	
    }
	
	
	public UserAccount getByName(String name){
		String queryString = "SELECT u FROM  UserAccount u  WHERE u.name = '"+name+"'";
		List<UserAccount> result = em.createQuery(queryString, UserAccount.class).getResultList();
		if (result.size() != 1)
			return null;
		else
			return result.get(0);
	}
	
	
	
	public boolean existByName(String name){
		if (getByName(name) == null)
			return false;
		else
			return true;
	}
	
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void toggleorg(String name){
		UserAccount account = getByName(name);
		account.setorg(!account.getorg());
		em.merge(account);
		em.flush();
	}
	public List<UserAccount>getorgs(){  
		 TypedQuery<UserAccount> query = em.createQuery("SELECT u FROM UserAccount u WHERE u.org = TRUE", UserAccount.class);
		 return query.getResultList();
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void removeByName(String name) {
    	
    	UserAccount account = (UserAccount)em.getReference(UserAccount.class, name);
    	
    	
    	if (account != null) {  
    	em.remove(em.merge(account));
    	
    		}else 
    			System.out.println("No User found");
    }
	
	public List<UserAccount> getAllUser() {
        TypedQuery<UserAccount> query = em.createQuery(
            "SELECT u FROM UserAccount u", UserAccount.class);
        return query.getResultList();
    }

}
