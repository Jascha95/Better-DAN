package ems;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.ejb.EJB;
import javax.persistence.TypedQuery;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(name="EventServlet", urlPatterns="/EventServlet")
public class EventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@EJB EventDao eventDao;
	@EJB UserDao userDao;
	@EJB OrganizerDao organizerDao;
	@EJB ParticipantDao participantDao;
	

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//create a variable to store the current session 
		String loggedInName = LoginServlet.loggedInName(request.getSession());
		
		if (loggedInName != null) {	
			UserAccount loggedInAccount = userDao.getByName(loggedInName);

			request.setAttribute("username", loggedInName);

			//all the list that will be used in order to display data in combobox
			//and for our methods.
			List<Participant> partEvent = participantDao.getpartEvent();
			request.setAttribute("partEvent", partEvent);

					
			List<Event> allEvents = eventDao.getAllEvent();
			request.setAttribute("allEvents", allEvents);			
			
			
			List<Event> partEvents = this.getPartEvents(loggedInName);
			request.setAttribute("partEvents", partEvents);
			
			
			List<Event> orgEvents = this.getOrgEvents(loggedInName);
			request.setAttribute("orgEvents", orgEvents);
			
			
			List<UserAccount> accounts = userDao.getAllUser();
			request.setAttribute("accounts", accounts);
			
			
			
			if (loggedInAccount.getorg()){
				request.getRequestDispatcher("/organizer.jsp").forward(request, response);
				request.setAttribute("Org", true);
			
		 
			}
		} else System.out.println("EventServlet.doGet");
		request.getRequestDispatcher("/event.jsp").forward(request, response);
	}


	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("EventServlet.doPost()");
		String action = request.getParameter("event");
		String loggedInName = LoginServlet.loggedInName(request.getSession());
		//message to display on interface		
		String gralMsg = null;
		String ticketMsg = null;
		String printT = null;
		//check which action/button has been pressed.
		if (action.equals("Buy")){
			String num = request.getParameter("numberTicketCombo");
			String pre = request.getParameter("ticketEventCombo");
			Integer n_ticket = Integer.valueOf(num);
			ticketMsg = billTicket(loggedInName, n_ticket, pre, request);
			request.setAttribute("ticketMsg", ticketMsg);
			doGet(request, response);
		}
		else if (action.equals("eTickets")){ 
			printT = printTicket(request);
			request.setAttribute("printT", printT);
			request.getRequestDispatcher("/eTicket.jsp").forward(request, response);
			doGet(request, response);
		}else if (action.equals("Create Event")){
			gralMsg = createEvent(loggedInName, request.getParameter("createEventName"), request.getParameter("createEventPrice"));
		} else if (action.equals("Remove Event")){
			gralMsg = removeEvent(request.getParameter("chooseEventCombo"));
		} else if (action.equals("Register")){
			gralMsg = takePartInEvent(loggedInName, request.getParameter("chooseEventCombo"));
		} else if (action.equals("Cancel")){
			gralMsg = cancelParticipation(loggedInName, request.getParameter("purchEventCombo"));
		} 
		else {
			gralMsg = "Unknown";
		}
		
		request.setAttribute("Message", gralMsg);
		doGet(request, response);
	}
	
	
	//method for the creation of an event.
	public String createEvent(String userName, String eventName, String eventPrice){
		if (!eventName.equals("") && !eventDao.existByName(eventName)){
			eventDao.persist(new Event(eventName, eventPrice));
	
			organizeEvent(userName, eventName);
			return null;
		} else return "Event already exist!";
	}
	
	
	//method to remove an event (created by organizer)
	public String removeEvent(String eventName){
		if (eventDao.existByName(eventName)){
			
			List<Participant> participants = participantDao.getByEventname(eventName);
			for (Participant p: participants){
				participantDao.remove(p.getUsername(), p.getEventname());	
			}
			
			List<Organizer> organizers = organizerDao.getByEventname(eventName);
			for (Organizer o: organizers){
				organizerDao.remove(o.getUsername(), o.getEventname());	
			}
			
			eventDao.removeByName(eventName);
			return null;
		} else return "This event does not exist";
	}
	
	
	//method to register user and event.
	public String takePartInEvent(String username, String eventname){
		if (userDao.existByName(username) && eventDao.existByName(eventname)){
			if (!participantDao.exist(username, eventname)){
				participantDao.persist(new Participant(username, eventname));
				return null;
			} else return username + " you are already registered for " + eventname;
		} else return "Participant/Event does not exist"; 
	}
	
	//method to control the number of tickets-events
	public String billTicket(String username, int number, String pre, HttpServletRequest request){
	int index = pre.lastIndexOf(',');
		String name = pre.substring(index+1);
		String price = pre.substring(0, index);
		int pri = Integer.valueOf(price);
		Integer total = 0;
		
		Event aEvent = eventDao.getByName(name);
		
		
		HttpSession session = request.getSession();
		
		List<Event> tList = (List<Event>) session.getAttribute("ticketsList");
		
		if(tList==null){
			tList = new ArrayList<Event>();
		}
		for (int i = 0; i < number; i++) {
			tList.add(aEvent);
			
		}
		
		session.setAttribute("ticketsList", tList);
				
		total = pri*number;
		
		
		return "Dear"+" "+" "+" "+username + " "+"you bought "+number+" "+""+ "tickets"+"for"+" "+" "+" "+name+ " " + "Your the total is" + " "+total;
		 
		}
	
		
	//method to print ticket.
	public String printTicket(HttpServletRequest request){
		//get the current session and create a list for the purchased events.
		HttpSession session = request.getSession();
		List<Event> tList = (List<Event>) session.getAttribute("ticketsList");
		String toReturn = "";
		int price = 0;
		int sum =0;
		for (Event event : tList) {
			toReturn += event.getName();
			price = Integer.valueOf(event.getPrice());
			price -= 5;
			sum+=price;
			toReturn += " final price:" + price +"<br/>";
			
		}
		toReturn += " total price:" + sum +"<br/>";
			return toReturn;
		 
	}
	
	//method for the relation organizer-event
	public String organizeEvent(String username, String eventname){
		if (userDao.existByName(username) && eventDao.existByName(eventname)){
			if (!organizerDao.exist(username, eventname)){
				organizerDao.persist(new Organizer(username, eventname));
				return null;
			} else return null;//username + " has organized " + eventname;
		} else return null; //"Participant/Event does not exist";

	}
	
	
	
	//method to remove registration from user and event. 
	public String cancelParticipation(String username, String eventname){
		if (participantDao.exist(username, eventname)){
			participantDao.remove(username, eventname);
			return null;
		} else return username + " does not participate in " + eventname;
	}
	

	//List participant and events
	public List<Event> getPartEvents(String username){
	
		List<Participant> participants = participantDao.getByUsername(username);
	
		List<String> eventnames = new ArrayList<String>();
		for (Participant p: participants){
			eventnames.add(p.getEventname());
		}
	
		List<Event> events = eventDao.getByNames(eventnames);
		return events;
	}
	
	
	//query for all events created by organizer.
	public List<Event> getOrgEvents(String username){
	
		List<Organizer> organizers = organizerDao.getByUsername(username);
		
	
		List<String> eventnames = new ArrayList<String>();
		for (Organizer o: organizers){
			eventnames.add(o.getEventname());
		}
	
		List<Event> events = eventDao.getByNames(eventnames);
		return events;
	}
	
	
	//once the user has logout, then the object and list for tickets is removed
	public static String logout(HttpServletRequest request){
		HttpSession session = request.getSession(false);
		if (session!=null){
			session.setAttribute("loggedIn", false);
			session.invalidate();
			return null;
		} else return "Sign out";
	}
	
	
	

}
