package ems;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet(name="RegisterServlet", urlPatterns="/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	//Injected DAO EJB
	@EJB UserDao userDao;
	
	UserAccount result;
	
	
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("RegisterServlet.doGet");
		request.getRequestDispatcher("/register.jsp").forward(request, response);
	}

	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("actionRegister");
		//do the registration.
		if (action.equals("Register")){
			String name = request.getParameter("username");
			String password1 = request.getParameter("password1");
			String password2 = request.getParameter("password2");
			boolean registerSuccess = register(userDao, request, response, name, password1, password2);
			if (registerSuccess){
				response.sendRedirect("EventServlet");
				LoginServlet.login(userDao, request, response, name, password1);
				return;
    		}
		}
		doGet(request, response);
	}
	
	
	
	
	public static boolean register(UserDao userDao, HttpServletRequest request, HttpServletResponse response, String name, String password1, String password2){
		 //messages in case the user do a mistake.
		if (name.equals("")){
			request.setAttribute("Message", "Missing username!");
			return false;
		} else if (!password1.equals(password2)){
			request.setAttribute("Message", "Passwords are not equal");
			return false;
		} else if (password1.equals("")){
			request.setAttribute("Message", "Missing password!");
			return false;
		} else if (userDao.existByName(name)){
			request.setAttribute("Message", "Duplicate username!");
			return false;
		} else {
			 //if there is not an organizer, then create it
			if (userDao.getorgs().size() == 0)
			
				userDao.persist(new UserAccount(name, password1, true));
			else //otherwise create a participant.
				userDao.persist(new UserAccount(name, password1));
			}return true;
			
		}
	}


