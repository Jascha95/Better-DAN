package ems;

import java.io.Serializable;
import javax.persistence.Entity;	
import javax.persistence.Id;


@Entity
public class UserAccount implements Serializable{
	private static final long serialVersionUID = 1L;

	// persistent 
	@Id private String name;
	private String password;
	private boolean org;
	
	public UserAccount(String name, String password, boolean org){
		this.name = name;
		this.password = password;
		this.org = org;
	}
	
	public UserAccount(String name, String password){
		this(name, password, false);
	}
	
	public String getName(){
		return name;
	}
	
	public String getPassword(){
		return password;
	}
	
	public boolean getorg(){
		return org;
	}
	
	public void setorg(boolean org){
		this.org = org;
	}
}
