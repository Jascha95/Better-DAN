package ems;

import java.io.Serializable;
import java.util.Set;

//import javax.jdo.annotations.Column;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Event implements Serializable{
	private static final long serialVersionUID = 1L;
	
	// persistent object for Event
	@Id private String name;
	
	public String price;
	
    
	public Event(String name, String price){
		this.name = name;
		this.price = price;
	}
	
	public String getName(){
		return name;
	}
	
	public String getPrice(){
		return price;
	}

}
