package ems;

import java.io.IOException;
import java.util.ArrayList;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



@WebServlet(name="LoginServlet", urlPatterns="/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	//Injected DAO EJB
	@EJB UserDao userDao;
 
	

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/login.jsp").forward(request, response);
	}

	

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("actionLogin");
		
		//check if login has been pressed
		if (action.equals("Login")){
			//if organizer exist, then display organizer.jsp page
			Boolean org = (Boolean) request.getAttribute("org"); 
			if (org != null && org == true){
				request.getRequestDispatcher("/organizer.jsp").forward(request, response);
			}
				boolean loginSuccess = login(userDao, request, response, request.getParameter("nameField"), request.getParameter("passwordField"));
			if (loginSuccess){
				
				response.sendRedirect("EventServlet");
				return;
			}
		}
		doGet(request, response);
	}
	
	
	
		public static boolean login(UserDao emsDao, HttpServletRequest request, HttpServletResponse response, String name, String password){
		//verify if fields are complete to login, if they are, then get the session otherwise, send a message. 
		if (name.equals("")){
			request.setAttribute("Message", "Please input a username");
			return false;
		} else if(!emsDao.existByName(name) || !password.equals(emsDao.getByName(name).getPassword())) {
			request.setAttribute("Message", "Incorrect Credentials");
			return false;
		} else {
			HttpSession session = request.getSession(true);
			session.setAttribute("loggedIn", true);
			session.setAttribute("username", name);
			return true;
		}
	}
	
	
	
	public static String loggedInName(HttpSession session){
	
		if (session != null && (Boolean) session.getAttribute("loggedIn") != null && (Boolean) session.getAttribute("loggedIn") == true){
			return (String) session.getAttribute("username");
		} else {
			return null;
		}
	}
}
