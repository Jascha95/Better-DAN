package ems;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import ems.Event;


@Entity
public class Participant implements Serializable{
	private static final long serialVersionUID = 1L;

	
	// persistent
	@Id @GeneratedValue public Long id;
	private String username;
	private String eventname;
	
	@ManyToMany(mappedBy="eventname")
	
	public Set<Event> getName(){
		
		return getName();
	}
	public Participant(String username, String eventname){
		this.username = username;
		this.eventname = eventname;
	}
	
	public String getUsername(){
		return username;
	}
	
	public String getEventname(){
		return eventname;
	}
	
	
	    	
}
