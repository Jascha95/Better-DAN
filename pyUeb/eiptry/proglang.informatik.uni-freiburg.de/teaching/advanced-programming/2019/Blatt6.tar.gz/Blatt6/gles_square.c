// Copyright 2019 Philipp Klaus Krause, Albert-Ludwigs-Universität Freiburg
// Source code under CC0 1.0

#include <GLES/gl.h>
#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

// In case of a GLFW error, just print an error message to stderr.
static void error_callback(int error, const char* description) {
    fputs(description, stderr);
}

// Close the window when Esc is pressed
static void
key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}

// 2D coordiantes of the corners of a square.
// Ordered for easy rendering as two triangles that share two of their corners.
const GLfloat square_corners[] = {
    0.0f, 0.0f,
    0.8f, 0.0f,
    0.0f, 0.8f,
    0.8f, 0.8f,
    };

int main(void) {
    // Initialize GLFW
    GLFWwindow *window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit()) {
        return -1;
    }

    // We want an OpenGL ES 1.1 (or compatible, but I don't think
    // Khronos will ever release OpenGL ES 1.2) context.
    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_ES_API);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 1);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);

    // Create a window.
    window = glfwCreateWindow(640, 480,
        "White square in otherwise black window", 0, 0);
    if (!window) {
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    // Print some information on the OpenGL ES driver
    printf("Renderer: %s\n", glGetString(GL_RENDERER));
    printf("Version: %s\n", glGetString(GL_VERSION));

    glfwSetKeyCallback(window, key_callback);
    while (!glfwWindowShouldClose(window)) {
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        float ratio = (float) width / (float) height;
        glViewport(0, 0, width, height);

        // Clear the color buffer (to default black clear color)
        glClear(GL_COLOR_BUFFER_BIT);

        // Use a projection suitable for 2D graphics.
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrthof(-ratio, ratio, -1.f, 1.f, 1.f, -1.f);

        // No rotation, etc for now.
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        // Draw the square
        glVertexPointer(2, GL_FLOAT, 0, square_corners);
        glEnableClientState(GL_VERTEX_ARRAY);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

        // Buffer swap to display the new window content.
        glFlush();
        glfwSwapBuffers(window);

        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}

