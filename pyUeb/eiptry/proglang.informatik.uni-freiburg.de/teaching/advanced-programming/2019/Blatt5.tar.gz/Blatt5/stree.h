// Copyright 2019 Philipp Klaus Krause, Albert-Ludwigs-Universität Freiburg
// Source code under CC0 1.0

#ifndef STREE_H_
#define STREE_H_ 1

// Ein Binärbaum von Strings.
struct stree_node_t;

struct stree_node_t {
    const char *string;
    struct stree_node_t *left;
    struct stree_node_t *right;
};

typedef struct stree_node_t *stree_t;

// Initalisiert Baum.
void stree_init(stree_t *stree);

// Fügt eine Kopie eines Strings in den Baum ein.
// Gibt bei Erfolg eine Zeiger auf den Baume zurück, sonst 0.
stree_t *stree_insert(stree_t *stree, const char *string);

// Such einen String im Baum. Gibt einen Zeiger auf die Kopie im Baum zurück,
// falls der String gefunden wurde, sonst 0.
const char *stree_find(const stree_t *stree, const char *string);

// Gibt den Speicher frei.
void stree_destroy(stree_t *stree);

// Beispiel zur Verwendung:
// stree_t stree;
// stree_init(&stree);
// Bei echter Verwendung sollte man den Rückgabewert von stree_insert testen,
// und gegebenenfalls den Fehler behandlen.
// stree_insert(&stree, "test");
// stree_destroy(&stree);

#endif  // STREE_H_

