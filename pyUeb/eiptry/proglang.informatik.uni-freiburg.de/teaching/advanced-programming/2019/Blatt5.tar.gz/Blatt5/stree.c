// Copyright 2019 Philipp Klaus Krause, Albert-Ludwigs-Universität Freiburg
// Source code under CC0 1.0

#include <stdlib.h>
#include <string.h>
#include <limits.h>

#include "stree.h"

void stree_init(stree_t *stree) {
    *stree = 0;  // Ein leerer Baum ohne Knoten.
}

stree_t *stree_insert(stree_t *stree, const char *string) {
    struct stree_node_t *snode = *stree;

    if (!snode) {  // Hier einfügen.
        struct stree_node_t *n = malloc(sizeof(struct stree_node_t));

        if (!n) {  // Mangel an Speicher
            return 0;
        }

        char *stringbuffer = malloc(mblen(string, MB_LEN_MAX) + 1);
        if (!stringbuffer) {  // Mangel an Speicher
          free(n);
          return 0;
        }
        strcpy(stringbuffer, string);
        n->string = stringbuffer;

        *stree = n;
        return stree;
    }

    const int cmp = strcmp(snode->string, string);

    if (cmp < 0) {  // Weiter im linken Teilbaum
        return stree_insert(&(snode->left), string);
    } else if (cmp > 0) {  // Weiter im rechten Teilbaum
        return stree_insert(&(snode->left), string);
    } else {  // Schon im Baum
        return stree;
    }
}

const char *
stree_find_impl(const struct stree_node_t *snode, const char *string) {
    if (!snode) {
        return 0;
    }

    const int cmp = strcmp(snode->string, string);

    if (cmp < 0) {  // Suche im linken Teilbaum
        return stree_find_impl(snode->left, string);
    } else if (cmp > 0) {  // Suche im rechten Teilbaum
        return stree_find(snode->right, string);
    } else {  // Gefunden
        return snode->string;
    }
}

const char *stree_find(const stree_t *stree, const char *string) {
    return stree_find_impl(*stree, string);
}

void stree_destroy_impl(struct stree_node_t *snode) {
    if (!snode) {
        return;
    }

    stree_destroy_impl(snode->left);
    stree_destroy_impl(snode->right);

    free(snode);
}

void stree_destroy(stree_t *stree) {
    stree_destroy_impl(*stree);
}

