open Mini_java

exception Type_error of string

module Classtab = Map.Make(struct
                             type t = Id.clazz
                             let compare = Id.cmp_class
                           end)

module Fieldtab = Map.Make(struct
                             type t = Id.clazz * Id.field
                             let compare = Utils.cmp_pair Id.cmp_class Id.cmp_field
                           end)

module Methtab = Map.Make(struct
                            type t = Id.clazz * Id.meth
                            let compare = Utils.cmp_pair Id.cmp_class Id.cmp_meth
                          end)

type t = (class_def Classtab.t * fdecl Fieldtab.t * mdef Methtab.t)

(* Records a class definition in the symbol table. *)
let add_class (tab, f, m) class_def = 
  (Classtab.add class_def.class_name class_def tab, f, m)

(* Records a field declaration together with its defining class 
   in the symbol table. *)
let add_field (c, tab, m) clazz fdecl = 
  let field = fdecl.fdecl_name in
  let key = (clazz, field) in
    if Fieldtab.mem key tab
    then raise (Type_error ("Duplicate field " ^ Id.string_from_field field ^ 
                              " in class " ^ Id.string_from_class clazz))
    else (c, Fieldtab.add key fdecl tab, m)

(* Records a method definition together with its defining class 
   in the symbol table. *)
let add_meth (c, f, tab) clazz mdef = 
  let meth = mdef.mdef_name in
  let key = (clazz, meth) in
    if Methtab.mem key tab
    then raise (Type_error ("Duplicate method " ^ Id.string_from_meth meth ^ 
                              " in class " ^ Id.string_from_class clazz))
    else (c, f, Methtab.add key mdef tab)

(* Finds the class definition for the given class name in the symbol table. *)
let find_class (tab, _, _) clazz = 
  try Classtab.find clazz tab with
      Not_found -> 
        raise (Type_error ("Undefined class: " ^ Id.string_from_class clazz ^
                           "(should already be detected by the desugarer)"))

(* Finds the definition of the super class of the given class name 
   in the symbol table. *)
let find_superclass symtab clazz = 
  let class_def = find_class symtab clazz in
    match class_def.class_super with
        None -> None
      | Some clazz' -> Some (find_class symtab clazz')

let rec find_superclass_until symtab clazz f = 
  let class_def = find_class symtab clazz in
    match f class_def with
        Some x -> Some x
      | None -> 
          begin
            match class_def.class_super with
                None -> None
              | Some clazz' -> find_superclass_until symtab clazz' f
          end

(* Searches for the field declaration for the given class and field name. 
   Superclasses are search recursively until the field is found. 
   The functions returns a pair (cd, fdecl) where fdecl is the declaration
   of the field and cd is the actual class definition which contains it. *)
let find_field ((_, tab, _) as symtab) clazz field = 
  let has_field cd = 
    try Some (cd, Fieldtab.find (cd.class_name, field) tab) with Not_found -> None 
  in
    match find_superclass_until symtab clazz has_field with
        Some x -> x
      | None -> raise (Type_error ("Class " ^ Id.string_from_class clazz ^ 
                                     " does not contain field " ^ 
                                     Id.string_from_field field))

(* Searches for the method definition for the given class and method name. 
   Superclasses are search recursively until the method is found. 
   The functions returns a pair (cd, meth) where meth is the definition
   of the method and cd is the actual class definition which contains it. *)
let find_meth ((_, _, tab) as symtab) clazz meth = 
  let has_meth cd = 
    try Some (cd, Methtab.find (cd.class_name, meth) tab) with Not_found -> None 
  in
    match find_superclass_until symtab clazz has_meth with
        Some x -> x
      | None -> raise (Type_error ("Class " ^ Id.string_from_class clazz ^ 
                                     " does not contain method " ^ 
                                     Id.string_from_meth meth))

(* Environment for local variables *)
module Env = Map.Make(struct
                        type t = Id.var
                        let compare = Id.cmp_var
                      end)

type env = ty Env.t
let add_var env var ty = Env.add var ty env
let find_var env var =
  try Env.find var env with
      Not_found -> raise (Type_error ("Undefined variable: " ^ 
                                        Id.string_from_var var))
