open Mini_java

let dummy_class_id = Id.mk_class "**dummy class**"
let object_class_id = Id.mk_class "Object"
let string_class_id = Id.mk_class "String"
let to_string_meth_id = Id.mk_meth "toString"

let to_string_meth = { mdef_visibility = Public;
                       mdef_restype = Ty_class string_class_id;
                       mdef_args = [];
                       mdef_name = to_string_meth_id;
                       mdef_code = [] }

let object_class =
  { class_name = object_class_id;
    class_visibility = Public;
    class_super = None;
    class_fdecls = [];
    class_mdefs = [to_string_meth] }

let string_class = 
  { class_name = string_class_id;
    class_visibility = Public;
    class_super = Some object_class_id;
    class_fdecls = [];
    class_mdefs = [] }

let predefined_classes = [object_class; string_class]
  
