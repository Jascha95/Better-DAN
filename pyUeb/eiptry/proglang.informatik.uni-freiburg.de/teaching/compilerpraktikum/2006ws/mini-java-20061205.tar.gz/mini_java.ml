(*pp ./pp tywith *)

type typrim = Typrim_bool | Typrim_int | Typrim_void with pp

type ty = Ty_class of Id.clazz
        | Ty_prim of typrim
        | Ty_anyref  (* A subtype of any reference (i.e. class) type. Only to be
                        used as the type for null! *)
 with pp

type expr = 
    Expr_int of int
  | Expr_bool of bool
  | Expr_strlit of string
  | Expr_new of Id.clazz
  | Expr_var of Id.var
    (* To compile field access, we need access to the static type of the first
       expression, which we store in the last component of Expr_field.
       Before typechcking, this component is Mini_java_prelude.dummy_class_id. *)
  | Expr_field of (expr * Id.clazz * Id.field)
    (* As for field access, Id.clazz is the static type of the first expression. *)
  | Expr_mcall of (expr * Id.clazz * Id.meth * expr list)
  | Expr_null
  | Expr_plus of (expr * expr)
  | Expr_minus of (expr * expr)
  | Expr_times of (expr * expr)
  | Expr_div of (expr * expr)
  | Expr_uminus of expr
  | Expr_and of (expr * expr)
  | Expr_or of (expr * expr)
  | Expr_not of expr
  | Expr_lt of (expr * expr)
  | Expr_leq of (expr * expr)
  | Expr_gt of (expr * expr)
  | Expr_geq of (expr * expr)
  | Expr_eq of (expr * expr)
  | Expr_neq of (expr * expr)
  | Expr_cast of (ty * expr)
  with pp

type stmt = 
    Stmt_if of (expr * block)
  | Stmt_if_else of (expr * block * block)
  | Stmt_while of (expr * block)
  | Stmt_return of expr
  | Stmt_vardecl of (ty * Id.var * expr option)
    (* As for field access, Id.clazz is the static type of the first expression. *)
  | Stmt_assign_field of (expr * Id.clazz * Id.field * expr)
  | Stmt_assign_var of (Id.var * expr)
  | Stmt_expr of expr
  with pp      

and block = stmt list with pp

type visibility = Private | Protected | Public with pp
    
type mdef = { mdef_visibility : visibility;
              mdef_restype : ty;
              mdef_args : (ty * Id.var) list;
              mdef_name : Id.meth;
              mdef_code : block } with pp

type fdecl = { fdecl_type : ty;
               fdecl_name : Id.field;
               fdecl_init : expr option } with pp

type class_def = { class_name : Id.clazz;
                   class_visibility : visibility;
                   class_super : Id.clazz option;
                   class_fdecls : fdecl list;
                   class_mdefs : mdef list } with pp

type program = class_def list

let pp_program p = Tywith.pp_list pp_class_def p
