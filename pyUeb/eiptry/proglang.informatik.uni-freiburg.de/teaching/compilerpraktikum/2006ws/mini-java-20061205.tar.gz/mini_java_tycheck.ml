open Mini_java
open Mini_java_symtab

type symtab = Mini_java_symtab.t
type env = Mini_java_symtab.env

let is_subtype symtab ty1 ty2 = failwith "is_subtype not yet implemented"

let rec tyof_expr symtab class_def env expr = 
  failwith "tyof_expr not yet implemented"

let tycheck_stmt symtab class_def env stmt = 
  failwith "tycheck_stmt not yet implemented"

let tycheck_fdecl symtab class_def fdecl = 
  failwith "tycheck_fdecl not yet implemented"

let tycheck_mdef symtab class_def mdef = 
  failwith "tycheck_mdef not yet implemented"

let tycheck_class symtab class_def = 
  failwith "tycheck_class not yet implemented"
