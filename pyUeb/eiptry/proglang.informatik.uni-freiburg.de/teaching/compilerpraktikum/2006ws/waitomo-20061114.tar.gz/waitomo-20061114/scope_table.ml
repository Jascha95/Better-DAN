type ('a, 'b) tab = ('a, 'b tab_val) Hashtbl.t

and 'a tab_val = TabVal of (('a tab_entries) ref)

and 'a tab_entries = ('a tab_entry) list

and 'a tab_entry = 'a tab_val (* points to the head of the entry list *)
                   * 'a       (* value *)

type 'a scope_stack = (('a tab_entries) list) Stack.t

type ('a, 'b) t = ('a, 'b) tab * 'b scope_stack

let create () = 
  (Hashtbl.create 97, Stack.create ())

let open_scope (tab, stack) = 
  Stack.push [] stack

let close_scope (tab, stack) = 
  let rec remove_entries = function
      [] -> ()
    | ((x::xs) :: rest) ->
        let TabVal tab_val = fst x in
          tab_val := xs;
          remove_entries rest
    | ([] :: rest) ->
        failwith "close_scope: invalid scope_stack."
  in remove_entries (Stack.pop stack)


let add (tab, stack) name value = 
  let TabVal tab_val = 
    try Hashtbl.find tab name
    with Not_found ->
      let v = TabVal (ref []) in
        Hashtbl.add tab name v;
        v
  in 
  let entry = (TabVal tab_val, value) in
  let entries = entry :: !tab_val in
  let top = Stack.pop stack in
    tab_val := entries;
    (* It is ok to add 'entries' to the list on top of the stack, even if
       the variable is already defined in this scope. That's because
       a prior definition appears later in this list and so when the scope
       is closed is deleted after the new definition. *)
    Stack.push (entries :: top) stack

let find (tab, stack) name = 
  let TabVal tab_val =  Hashtbl.find tab name in
    match !tab_val with
        ((x,y) :: rest) -> y
      | [] -> raise Not_found

let test () = 
  let print x = 
    print_endline ("a = " ^ find x "a")
  in
  let x = create () in
    begin
      open_scope x;
      add x "a" "1"; 
      print x;         (* a = 1 *)
      open_scope x;
      add x "a" "2";
      print x;         (* a = 2 *)
      add x "a" "2'";
      print x;         (* a = 2' *)
      close_scope x;
      print x          (* a = 1 *)
    end

