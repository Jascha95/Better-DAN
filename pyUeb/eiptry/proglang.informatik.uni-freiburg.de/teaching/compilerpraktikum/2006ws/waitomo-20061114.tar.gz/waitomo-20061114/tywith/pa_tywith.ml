(*pp camlp4o pa_extend.cmo q_MLast.cmo -loc loc *)

(** Tywith camlp4 Parser

    This code was inspired by the code printer generator code in the
    camlp4 tutorial. The work remaining is mostly about supporting
    further types and more generators.
    
    @version 0.45
    @author Martin Sandin
    @since Feb 2005
  *)

(** Utility functions.
  *)

let ( *** ) f g x = f (g x)

let tpl a b = (a,b)

let list_mapi f xs =
   let rec aux ix =
      function
      | [] -> []
      | x::xs -> f ix x::aux (ix + 1) xs in
   aux 1 xs

let rec range l u = if l = u then [] else l::range (l + 1) u


(** Generator registration.
  *)

module GeneratorMap = Map.Make(String)
let generators = ref GeneratorMap.empty

(** Adds a generator to the register. *)
let add_generator id e = generators := GeneratorMap.add id e !generators

(** Removes a generator from the register. *)
let rem_generator id = generators := GeneratorMap.remove id !generators

(** Generates a tuple of lists of functions and types. *)
let generate loc ty id =
   try GeneratorMap.find id !generators ty
   with Not_found ->
      failwith ("Tywith: '"^ id ^"' is not a supported generator.")
   
   
(** Code generation module.
  *)
  
module Gen =
   struct
      let rec ty_path =
         function
         | <:ctyp< $lid:id$ >> | <:ctyp< $uid:id$ >> -> [id]
         | <:ctyp< $t1$ . $t2$ >> ->
            (match ty_path t2 with [n] -> n | _ -> assert false)::ty_path t1
         | _ -> raise (Invalid_argument "ty_path")
         
      let rec path_expr loc =
         function
         | [n] when n.[0] = Char.uppercase n.[0] -> <:expr< $uid:n$ >>
         | [n] -> <:expr< $lid:n$ >>
         | n::ns -> <:expr< $path_expr loc ns$ . $path_expr loc [n]$ >>
         | _ -> raise (Invalid_argument "path_expr") 

      let rec fold_ty ~appl ~arrw ~tupl ~parm ~path =
         let aux t = fold_ty ~appl ~arrw ~tupl ~parm ~path t in
         function
         | <:ctyp< $t1$ $t2$ >> -> appl (aux t1) (aux t2)
         | <:ctyp< ( $list:tys$ ) >> -> tupl (List.map aux tys)
         | <:ctyp< $lid:tname$ >> -> path [tname]
         | <:ctyp< '$tpname$ >> -> parm tpname
         | <:ctyp< $_$ . $_$ >> as t -> path (ty_path t)
         | <:ctyp< $t1$ -> $t2$ >> -> arrw (aux t1) (aux t2)
         | _ -> failwith "Unknown type."
         
      let apply loc e es =
         List.fold_left
            (fun eacc e -> <:expr< $eacc$ $e$ >>) e es
            
      let abstract loc e ns =
         List.fold_right
            (fun n e -> <:expr< fun $n$ -> $e$ >>) ns e
            
      let idp loc id = <:patt< $lid:id$ >>

      let ide loc id = <:expr< $lid:id$ >>
      
      let id loc = <:expr< fun x -> x >>
      
      let apply_new_args loc id =
         let aux ix e =
            let n = id ^ string_of_int ix in
            (idp loc n,  <:expr< $e$ $lid:n$ >>) in
         List.split *** list_mapi aux 
         
      let apply_patts loc =
         List.fold_left (fun pacc p -> <:patt< $pacc$ $p$ >>)
         
      let vdef loc id ex = (idp loc id, ex)
      
      let bind loc=
         List.fold_right
            (fun (p,e) eacc -> <:expr< let $p$ = $e$ in $eacc$ >>)
   end


(** Helper functions.
  *)

let switch_tdef ((loc, name), tparams, tdef, cl) common =
   common loc name tparams
      (fun ~alias ~sum ~record ->
         match tdef with
         | <:ctyp< [ $list:vars$ ] >> -> sum vars
         | <:ctyp< $lid:_$ >>
         | <:ctyp< ( $list:_$ ) >>
         | <:ctyp< $_$ -> $_$ >>
         | <:ctyp< $_$ $_$ >> -> alias tdef
         | <:ctyp< { $list:flds$ } >> -> record flds
         | _ -> failwith ("Unknown type"))

let sum_function loc ty_expr expf alts =
   let branch (loc, cnstr, tys) =
      let (ps, es) =
         Gen.apply_new_args loc "p" (List.map (ty_expr loc) tys) in
      (Gen.apply_patts loc <:patt< $uid:cnstr$ >> ps,
       None, expf loc cnstr es) in
   <:expr< fun [ $list:List.map branch alts$ ] >>

let rec_function loc ty_expr mk_expr flds =
   let (ns, es) =
      List.split (List.map
         (fun (loc, name, mut, ty) ->
            (name, <:expr< $ty_expr loc ty$ $lid:name$ >>))
         flds) in
   let ps = List.map (Gen.idp loc) ns in
   <:expr< fun { $list:List.combine ps ps$ } -> $mk_expr ns ps es$ >>
  
(** Function names for specific types.
  *)
   
let map_expr loc =
   function
   | ["list"] -> <:expr< List.map >>
   | ["array"] -> <:expr< Array.map >>
   | ["map"] -> <:expr< Array.map >>
   | ["ref"] -> <:expr< Tywith.map_ref >>
   | ["t";"Lazy"] | ["lazy_t"] -> <:expr< Tywith.map_lazy >>
   | ["option"] -> <:expr< Tywith.map_option >>
   | "t"::path -> Gen.path_expr loc ("map"::path)
   | tn::path -> Gen.path_expr loc (("map_"^tn)::path)
   | _ -> assert false (* no empty paths *)

let string_of_expr loc =
   function
   | ["string"] -> <:expr< fun x -> "\""^ String.escaped x ^"\"" >>
   | ["int32"] -> <:expr< Int32.to_string >>
   | ["int64"] -> <:expr< Int64.to_string >>
   | ["nativeint"] -> <:expr< Nativeint.to_string >>
   | ["list"] -> <:expr< Tywith.string_of_list >>
   | ["array"] -> <:expr< Tywith.string_of_array >>
   | ["option"] -> <:expr< Tywith.string_of_option >>
   | ["char"] -> <:expr< Tywith.string_of_char >>
   | ["t";"Lazy"] | ["lazy_t"] -> <:expr< Tywith.string_of_lazy >>
   | ["ref"] -> <:expr< Tywith.string_of_ref >>
   | "t"::path -> Gen.path_expr loc ("to_string"::path)
   | tn::path -> Gen.path_expr loc (("string_of_"^tn)::path)
   | _ -> assert false (* no empty paths *)

let pp_expr loc =
   function
   | ["string"] -> <:expr< Tywith.pp_string >>
   | ["int"] -> <:expr< Tywith.pp_prim string_of_int >>
   | ["bool"] -> <:expr< Tywith.pp_prim string_of_bool >>
   | ["int32"] -> <:expr< Tywith.pp_prim Int32.to_string >>
   | ["int64"] -> <:expr< Tywith.pp_prim Int64.to_string >>
   | ["nativeint"] -> <:expr< Tywith.pp_prim Nativeint.to_string >>
   | ["list"] -> <:expr< Tywith.pp_list >>
   | ["array"] -> <:expr< Tywith.pp_array >>
   | ["option"] -> <:expr< Tywith.pp_option >>
   | ["char"] -> <:expr< Tywith.pp_char >>
   | ["t";"Lazy"] | ["lazy_t"] -> <:expr< Tywith.pp_lazy >>
   | ["ref"] -> <:expr< Tywith.pp_ref >>
   | "t"::path -> Gen.path_expr loc ("to_string__whats_this"::path)
   | tn::path -> Gen.path_expr loc (("pp_"^tn)::path)
   | _ -> assert false (* no empty paths *)
   
let parse_expr loc =
   function
   | ["string"] -> <:expr< Tywith.parse_string >>
   | ["char"] -> <:expr< Tywith.parse_char >>
   | ["int"] -> <:expr< Tywith.parse_int >>
   | ["int32"] -> <:expr< Tywith.parse_int32 >>
   | ["int64"] -> <:expr< Tywith.parse_int64 >>
   | ["nativeint"] -> <:expr< Tywith.parse_nativeint >>
   | ["list"] -> <:expr< Tywith.parse_list >>
   | ["array"] -> <:expr< Tywith.parse_array >>
   | ["option"] -> <:expr< Tywith.parse_option >>
   | ["lazy"] -> <:expr< Tywith.parse_lazy >>
   | ["ref"] -> <:expr< Tywith.parse_ref >>
   | tn::path -> Gen.path_expr loc (("parse_"^tn)::path)
   | _ -> assert false (* no empty paths *)


(** Generator modules.
  *)

(** Module for generating "string_of_<type>" functions.
  *)
module Generate_string_of =
   struct
      let rec str_sep loc sep =
         function
         | [] -> <:expr< "" >>
         | [e] -> e
         | e::es -> <:expr< $e$ ^ $str:sep$ ^ $str_sep loc sep es$ >>
   
      (** Generate expression from a type. *)
      let type_expr loc = (* -> function *)
         Gen.fold_ty
            ~appl:(fun e1 e2 -> <:expr< $e1$ $e2$ >>)
            ~arrw:(fun e1 e2 -> <:expr< fun _ -> "<fun>" >>)
            ~tupl:(fun es ->
                  let ps, es = Gen.apply_new_args loc "p" es in
                  <:expr< fun ($list:ps$) -> "("^ $str_sep loc "," es$ ^")" >>)
            ~path:(string_of_expr loc)
            ~parm:(Gen.ide loc *** (^) "of__")

      (** Generate string_of_<type> function. *)
      let generate tdef = switch_tdef tdef
         (fun loc name tps case ->
            let body = case
               ~alias:(type_expr loc)
               ~sum:(sum_function loc type_expr
                  (fun loc cnstr -> function
                   | [] -> <:expr< $str:cnstr$ >>
                   | exs -> <:expr< $str:cnstr^" ("$ ^
                                    $str_sep loc "," exs$ ^")">>))
               ~record:(rec_function loc type_expr
                  (fun ns ps es -> 
                   let fstrs = List.map2
                     (fun n e -> <:expr< $str:n ^"="$ ^ $e$ >>)
                     ns es
                   in <:expr< "{"^ $str_sep loc ";" fstrs$ ^"}" >>))
            in Gen.vdef loc
               ("string_of_"^name)
               (Gen.abstract loc body (List.map
                  (Gen.idp loc *** (^) "of__" *** fst) tps)))
             
      let () = add_generator "string_of" (fun td -> ([generate td], []))
   end

(** Module for generating "pp_<type>" functions.
    Added by Stefan Wehr <wehr@informatik.uni-freiburg.de>, 2006-10-20.

    A pretty-printing function for <type> has type '<type> -> bool -> unit'
    where the first parameter specifies whether or not outer parens should
    be added to the result.
  *)
module Generate_pp =
   struct
     let rec str_sep loc sep = function
       | [] -> <:expr< fun _ -> () >>
       | [e] -> <:expr< fun _ -> $e$ Tywith.false__ >>
       | e::es -> <:expr< fun _ ->
                            let _ = $e$ Tywith.false__ in 
                            let _ = Format.print_string ($str:sep$) in
                            let _ = Format.print_space () in
                              $str_sep loc sep es$ () >>

     let str_sep' loc sep = function
        | [] -> <:expr< fun _ -> () >>
        | [e] -> e
        | l -> <:expr< fun _ -> Tywith.pp_enclosed "(" ")" 
                                  $str_sep loc sep l$ >>
   
      (** Generate expression from a type. *)
      let type_expr loc = (* -> function *)
         Gen.fold_ty
            ~appl:(fun e1 e2 -> <:expr< $e1$ $e2$ >>)
            ~arrw:(fun e1 e2 -> <:expr< fun b -> pp_raw_string "<fun>" b >>)
            ~tupl:(fun es ->
                     let ps, es = Gen.apply_new_args loc "p" es 
                      in <:expr< fun ($list:ps$) b -> $str_sep' loc "," es$ b >>
                  )
            ~path:(pp_expr loc)
            ~parm:(Gen.ide loc *** (^) "__")

      (** Generate string_of_<type> function. *)
      let generate tdef = switch_tdef tdef
         (fun loc name tps case ->
            let body = case
               ~alias:(fun ctyp -> <:expr< fun x b -> $type_expr loc ctyp$ x b>>)
               ~sum:(sum_function loc type_expr
                  (fun loc cnstr -> function
                   | [] -> <:expr< fun b -> Tywith.pp_raw_string ($str:cnstr$) b>>
                   | exs -> <:expr< fun b -> Tywith.pp_constr $str_sep' loc "," exs$
                                               $str:cnstr$ b
                            >>))
               ~record:(rec_function loc type_expr
                  (fun ns ps es -> 
                   let fstrs = List.map2
                     (fun n e -> <:expr< 
                                   Tywith.pp_key_value $str:n$ $e$ 
                                 >>)
                     ns es
                   in <:expr< 
                        fun _ -> Tywith.pp_enclosed "{" "}" $str_sep loc ";" fstrs$
                      >>))
            in Gen.vdef loc
               ("pp_"^name)
               (Gen.abstract loc body (List.map
                  (Gen.idp loc *** (^) "__" *** fst) tps)))
             
      let () = add_generator "pp" (fun td -> ([generate td], []))
   end

(** Module for generating "map_<type>" functions.
  *)
module Generate_map =
   struct
      let clean_ex loc (has_param, f_ex) =
         if has_param then f_ex else Gen.id loc
         
      (** Generate expression from a type. *)
      let type_expr loc ty = (* -> (depends on tparam, function) *)
         let aux = Gen.fold_ty
            ~appl:(fun (b1, e1) (b2, e2) ->
                  let has_p = b1 || b2 in
                  (has_p, <:expr< $e1$ $clean_ex loc (b2, e2)$ >>))
            ~arrw:(fun (b1, _) (b2, _) -> 
                  if b1 || b2
                     then failwith "Can't create map over function type containing type parameters."
                     else (false, Gen.id loc))
            ~tupl:(fun bes ->
                  let has_p = List.fold_right ((||) *** fst) bes false in
                  let ps, es =
                     Gen.apply_new_args loc "p" (List.map (clean_ex loc) bes) in
                  (has_p, <:expr< fun ($list:ps$) -> ($list:es$) >>))
            ~path:(tpl false *** map_expr loc)
            ~parm:(tpl true *** Gen.ide loc *** (^) "f_") ty
         in clean_ex loc aux
      
      (** Generate map_<type> function. *)
      let generate tdef = switch_tdef tdef
         (fun loc name tps case ->
            let body = case
               ~alias:(type_expr loc)
               ~sum:(sum_function loc type_expr
                        (fun loc cnstr ->
                         Gen.apply loc <:expr< $uid:cnstr$ >>))
               ~record:(rec_function loc type_expr
                        (fun ns ps es ->
                         <:expr< { $list:List.combine ps es$ } >>))
            in Gen.vdef loc
               ("map_"^ name)     
               (Gen.abstract loc body
                  (List.map ((Gen.idp loc) *** (^) "f_" *** fst) tps)))

      let () = add_generator "map" (fun td -> ([generate td], []))
   end


(** Module for generating "fold_<type>" functions.
  *)
module Generate_fold =
   struct
         
      let clean_ex loc (has_f, an, f_ex) =
         match an with
         | Some [] -> (true, <:expr< rec_fold >>)
         | _ -> (has_f, if has_f then f_ex else Gen.id loc)
         
      (** Generate expression from a type. *)
         (* -> (depends on tparam,
                remaining argument names in application, function) *)
      let type_expr (gtname, gtps) loc ty = 
         let aux = Gen.fold_ty
            ~appl:(fun (b_fun, a_fun, e_fun) (b_arg, a_arg, e_arg) ->
                  let a =
                     match a_fun with
                     | Some (n::ns) when (Some [n]) = a_arg -> Some ns
                     | _ -> None in
                  let (b_arg, e_arg) = clean_ex loc (b_arg, a_arg, e_arg) in
                  (b_fun || b_arg, a, <:expr< $e_fun$ $e_arg$ >>))
            ~arrw:(fun _ _ -> (false, None, Gen.id loc))
            ~tupl:(fun baes ->
                  let (bs, aes) = (List.split (List.map (clean_ex loc) baes)) in
                  let has_f = List.fold_left (||) false bs in
                  let ps, es = Gen.apply_new_args loc "p" aes in
                  (has_f, None, <:expr< fun ($list:ps$) -> ($list:es$) >>))
            ~path:(function
                   | [tname] as t when tname = gtname ->
                     (false, Some gtps, map_expr loc t)
                   | path -> (false, None, map_expr loc path))
            ~parm:(fun tpname ->
                  (false, Some [tpname], <:expr< "any expression" >>)) ty
         in snd (clean_ex loc aux)
      
      (** Generate fold_<type> function. *)
      let generate tdef = switch_tdef tdef
         (fun loc name tps case ->
            let t_expr = type_expr (name, List.map fst tps) in
            let fold_func pnames body =
               let fex =
                  Gen.apply loc
                     (Gen.ide loc ("fold_"^ name))
                     (List.map (Gen.ide loc) pnames) in
               let ex = <:expr< let rec_fold x = $fex$ x in $body$ >> in
               Gen.abstract loc ex (List.map (Gen.idp loc) pnames) in
            let body = case
               ~alias:(t_expr loc)
               ~sum:(fun vars ->
                  fold_func
                     (List.map (fun (_, c, _) -> "of_"^ c) vars)
                     (sum_function loc t_expr
                        (fun loc cnstr ->
                         Gen.apply loc (Gen.ide loc ("of_"^ cnstr))) vars))
               ~record:(fun flds ->
                  fold_func
                     (["of_"^ name])               
                     (rec_function loc t_expr
                        (fun ns ps ->
                         Gen.apply loc (Gen.ide loc ("of_"^ name)))
                        flds))
            in Gen.vdef loc ("fold_"^name) body)
                  
      let () = add_generator "fold" (fun td -> ([generate td], []))
   end


(** Module for generating "parse_<type>" functions.
  *)
module Generate_parse =
   struct
      let spec loc sym = <:expr< Tywith.parse_spec $str:sym$ >>
      let sec loc sym e = <:expr< Tywith.ParserTools.sec ($spec loc sym$) $e$ >>
      let strm loc e = <:expr< $e$ strm >>
      
      let parse_sep_seq loc opn sep cls =
         function
         | [] -> ((fun n -> n), [])
         | es ->
            let vns = List.map ((^) "v" *** string_of_int)
               (range 0 (List.length es)) in
            let bnds = List.map2 (fun e n ->
                (Gen.idp loc n,
                 strm loc (sec loc (if n = "v0" then opn else sep) e)))
                es vns in
            (Gen.bind loc (bnds@[<:patt<_>>, strm loc (spec loc cls)]),
             List.map (Gen.ide loc) vns)

      (** Generate expression from a type. *)
      let type_expr loc = (* -> function *)
         Gen.fold_ty
            ~appl:(fun e1 e2 -> <:expr< $e1$ $e2$ >>)
            ~arrw:(fun _ _ -> failwith "Can't create parse for function type.")
            ~tupl:(fun es ->
                  let (pef, pes) = parse_sep_seq loc "(" "," ")" es in
                  let te = <:expr< ($list:pes$) >> in
                  <:expr< fun strm -> $pef te$ >>)
            ~path:(parse_expr loc)
            ~parm:(Gen.ide loc *** (^) "parse__")
     
      (** Generate parse_<type> function. *)
      let generate tdef = switch_tdef tdef
         (fun loc name tps case ->
            let body = case
               ~alias:(strm loc *** type_expr loc)
               ~sum:(fun vars ->
                     let branch (loc, cnstr, tys) =
                        let (fe, vs) =
                           parse_sep_seq loc "(" "," ")"
                              (List.map (type_expr loc) tys) in
                        (<:patt< $str:cnstr$ >>, None,
                         fe (Gen.apply loc <:expr< $uid:cnstr$ >> vs)) in
                     let brs = List.map branch vars
                        @ [<:patt< _ >>, None, <:expr< assert False >>] in
                     <:expr< match Tywith.parse_id strm with [ $list:brs$ ] >>)
               ~record:(fun flds ->
                     let (fps, fes) =
                        List.split (List.map
                           (fun (loc, name, _, ty) ->
                              (Gen.idp loc name,
                               sec loc name (sec loc "=" (type_expr loc ty))))
                           flds) in
                     let (pef, pes) = parse_sep_seq loc "{" ";" "}" fes in
                     pef <:expr< {$list:List.combine fps pes$} >>) in
            Gen.vdef loc
               ("parse_"^ name)
               (let ps = List.map (Gen.idp loc *** (^) "parse__" *** fst) tps in
                Gen.abstract loc body (ps@[Gen.idp loc "strm"])))
                     
      let () = add_generator "parse" (fun td -> ([generate td], []))
   end
   
   
(** Functions for interpreting derivation types.
  *)

let both fa fb (a, b) = (fa a, fb b) 

let gen_derived_defs loc (ty, drvs) =
   let derived = List.map (generate loc ty) drvs in
   both List.concat List.concat (List.split derived)


(** Syntax extension.
  *)
  
DELETE_RULE
  Pcaml.str_item: "type"; LIST1 Pcaml.type_declaration SEP "and"
END

EXTEND
   GLOBAL: Pcaml.str_item;
   with_decl:
   [[ td=Pcaml.type_declaration; "with"; idl=LIST1 LIDENT SEP "," -> (td, idl)
   |  td=Pcaml.type_declaration -> (td, []) ]];

   Pcaml.str_item:
   [[ "type"; twdl=LIST1 with_decl SEP "and" ->
      let tys = List.map fst twdl in
      let (der_vals, der_tys) =
         both List.concat List.concat
            (List.split (List.map (gen_derived_defs loc) twdl)) in
      let tydef = <:str_item< type $list:tys@der_tys$ >> in
      let valdef = <:str_item< value rec $list:der_vals$ >> in
      match der_vals with
      | [] -> tydef
      | _ -> <:str_item< declare $tydef$; $valdef$; end >> ]]
  ;
END
