#!/bin/sh

DIST_DIR="waitomo-`date +'%Y%m%d'`"
DIST_FILE="$DIST_DIR.tar.gz"

if [ -e "$DIST_DIR" ] ; then
    rm -rf "$DIST_DIR"
fi

if [ -e "$DIST_FILE" ] ; then
    rm "$DIST_FILE"
fi

echo "DIST_DIR: $DIST_DIR"
echo "DIST_FILE: $DIST_FILE"

#svn export . "$DIST_DIR" || exit 1
svn export https://abacus.informatik.uni-freiburg.de/svn/progrep/projects/waitomo/code/compiler/ "$DIST_DIR" || exit 1
echo "Export completed, directory: $DIST_DIR"

tar cfz "$DIST_FILE" "$DIST_DIR" || exit 1
echo "Archive complete, file: $DIST_FILE"

