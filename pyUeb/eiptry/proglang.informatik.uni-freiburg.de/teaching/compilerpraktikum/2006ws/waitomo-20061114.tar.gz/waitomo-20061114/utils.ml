type ('a, 'b) either = Left of 'a | Right of 'b

let is_left = function 
  | Left _ -> true
  | Right _ -> false

let is_right = function 
  | Right _ -> true
  | Left _ -> false

let rec split_either = function
    [] -> ([], [])
  | (x::xs) -> let (l, r) = split_either xs in
               match x with
                   Left y -> (y::l, r)
                 | Right y -> (l, y::r)

let id x = x

let (@@) f x = f x
