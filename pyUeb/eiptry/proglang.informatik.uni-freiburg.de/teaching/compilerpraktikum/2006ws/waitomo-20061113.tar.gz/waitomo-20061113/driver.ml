(*pp ./pp trace *)

let lexbuf_from_file fname = 
  let chan = open_in fname in
  let buf = Lexing.from_channel chan in
  let cur_pos = buf.Lexing.lex_curr_p in
  let start_pos = buf.Lexing.lex_start_p in
    buf.Lexing.lex_curr_p <- { cur_pos with Lexing.pos_fname = fname };
    buf.Lexing.lex_start_p <- { start_pos with Lexing.pos_fname = fname };
    buf

let do_parse fname = 
  let buf = lexbuf_from_file fname in
    try
      Parser.cunit Lexer.token buf
    with Parsing.Parse_error ->
      failwith (Lexer.error_msg buf)

(* commandline options *)
type phase = Parsing | Desugar | All

let phase_strings = [(Parsing, "parsing"); (Desugar, "desugar"); (All, "all")]

let string_of_phase p =
  try List.assoc p phase_strings with Not_found -> 
    FATAL "variable 'phase_strings' not in sync with type definition 'phase'"


let phase_of_string s =
  try 
    match List.find (fun (_, s') -> s = s') phase_strings with (p,_) -> p
  with Not_found ->
    raise (Arg.Bad ("Invalid phase: " ^ s))

type options = { mutable opt_phase : phase; mutable input_file : string option }

let options = { opt_phase = All; input_file = None }

let if_phase p f =
  if options.opt_phase = p then (f (); exit 0) else ()
      
let enable_trace_level s =
  let level = 
    try Trace.level_of_string s 
    with Invalid_argument _ -> raise (Arg.Bad ("Invalid trace level: " ^ s))
  in
    Trace.enable_level level

let arg_spec_list = 
  [("-phase", Arg.String (fun s -> options.opt_phase <- phase_of_string s),
    "Stop and print result after given phase. Valid phases: " 
    ^ String.concat ", " (List.map snd phase_strings));
   ("-trace", Arg.String enable_trace_level, 
    "Enable the given trace level. Valid levels: " 
    ^ String.concat ", " Trace.level_names)
  ]

let main () =
  Arg.parse arg_spec_list (fun s -> options.input_file <- Some s)
    "Usage: waitomo [-phase p] input-file";
  match options.input_file with
      None -> failwith "No input file given."
    | Some f ->
        let ast = do_parse f in
        let _ = 
          if_phase Parsing 
            (fun () -> print_endline (Tywith.run_pp (Syntax.Ast.pp_program ast))) in
        let dst = Desugar.desugar_program ast in
        let _ =
          if_phase Desugar
            (fun () -> print_endline (Tywith.run_pp (Syntax.Dst.pp_program dst))) in
          () (* more phases to follow *)

let _ =
  try main () with Failure s -> prerr_endline ("ERROR: " ^ s)
