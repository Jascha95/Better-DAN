#!/bin/sh

`dirname $0`/run_parser.sh "$*"| grep -v '^$' | grep -v 'Objective Caml version' | egrep '^# Exception|^[^#]' 