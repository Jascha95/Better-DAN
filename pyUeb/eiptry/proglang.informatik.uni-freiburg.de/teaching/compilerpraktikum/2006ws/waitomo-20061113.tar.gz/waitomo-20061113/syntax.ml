(*pp ./pp tywith *)

(* 
  This module defines two modules 'Ast' and 'Dst' containing the type 
  definitions for
   + abstract syntax trees, and
   + desugered syntax trees.
*)

(* the signature for variable parts in the definition of syntax trees *)
module type VAR_PARTS = sig
  type ty
  type inst_class
  type inst_iface
  type bound_annot
  type constr
  val pp_ty : ty -> bool -> unit
  val pp_inst_class : inst_class -> bool -> unit
  val pp_inst_iface : inst_iface -> bool -> unit
  val pp_bound_annot : bound_annot -> bool -> unit
  val pp_constr : constr -> bool -> unit
end

(* the variable parts of abstract syntax trees *)
module Var_parts_ast = struct
  type bound_annot = Bound_explicit 
                   | Bound_implicit
                   with pp
  type ty = 
      Ty_var of Id.tyvar 
    | Ty_class of inst_class
    | Ty_exact of ty
    | Ty_exist of (Id.tyvar list * constr list * ty)
    | Ty_unknown of (Id.unknown * ty list)
    with pp
  and inst_class = (Id.clazz * ty list) with pp
  and inst_iface = (Id.iface * ty list) with pp
  and constr = 
      Constr_class of (Id.tyvar * inst_class)
    | Constr_iface of (ty list * bound_annot * inst_iface)
    with pp
end

(* the variable parts of desugered syntax trees *)
module Var_parts_dst = struct
  type bound_annot = Bound_explicit 
                   | Bound_implicit
                   with pp
  type ty = 
      Ty_var of Id.tyvar 
    | Ty_class of inst_class
    | Ty_exact of ty
    | Ty_exist of (Id.tyvar list * constr list * ty)
    | Ty_prim of typrim
    with pp
  and inst_class = (Id.clazz * ty list) with pp
  and inst_iface = (Id.iface * ty list) with pp
  and constr = 
      Constr_class of (Id.tyvar * inst_class)
    | Constr_iface of (ty list * bound_annot * inst_iface)
    with pp
  and typrim = Typrim_bool | Typrim_int | Typrim_void with pp
end

(* the functor which constructs a syntax tree module from its variable parts *)
module Mk_syntax_tree = functor (V: VAR_PARTS) -> struct
 
  type expr = 
      Expr_int of int
    | Expr_bool of bool
    | Expr_new of V.inst_class
    | Expr_var of Id.var
    | Expr_field of (expr * Id.field)
    | Expr_null
    | Expr_cast of (V.ty * expr)
    | Expr_mcall of (expr * Id.meth * V.ty list * expr list)
    | Expr_icall of (V.inst_iface * V.ty list * Id.meth * V.ty list * expr list)
    with pp

  type stmt = 
      Stmt_if of (expr * block)
    | Stmt_if_else of (expr * block * block)
    | Stmt_while of (expr * block)
    | Stmt_return of expr
    | Stmt_vardecl of (V.ty * Id.var * expr option)
    | Stmt_assign_field of (expr * Id.field * expr)
    | Stmt_assign_var of (Id.var * expr)
    | Stmt_expr of expr
    with pp      

  and block = stmt list with pp
  
  type modifier = Static | Nonstatic with pp
    
  type mdef = { mdef_tyvars : Id.tyvar list;
                mdef_constrs : V.constr list;
                mdef_restype : V.ty;
                mdef_args : (V.ty * Id.var) list;
                mdef_name : Id.meth;
                mdef_code : block;
                mdef_modifier : modifier } with pp
  
  type mdec = { mdec_tyvars : Id.tyvar list; 
                mdec_constrs : V.constr list;
                mdec_restype : V.ty;
                mdec_argtypes : V.ty list;
                mdec_name : Id.meth;
                mdec_modifier : modifier } with pp
  
  type cmdec = { cmdec_tyvar : Id.tyvar;
                 cmdec_mdecs : mdec list } with pp
  
  type fdecl = { fdecl_type : V.ty;
                 fdecl_name : Id.field;
                 fdecl_init : expr option } with pp
  
  type impl_def = { impl_tyvars : Id.tyvar list; 
                    impl_constrs : V.constr list;
                    impl_implementers : V.ty list;
                    impl_iface : V.inst_iface;
                    impl_smdefs : mdef list } with pp
  
  type ext_def = { ext_class : Id.clazz;
                   ext_tyvars : Id.tyvar list; 
                   ext_constrs : V.constr list;
                   ext_mdefs : mdef list } with pp
  
  type iface_def = { iface_implementers : Id.tyvar list;
                     iface_name : Id.iface;
                     iface_tyvars : Id.tyvar list;
                     iface_constrs : V.constr list;
                     iface_smdecs : mdec list;
                     iface_cmdecs : cmdec list } with pp
  
  type class_def = { class_name : Id.clazz;
                     class_tyvars : Id.tyvar list;
                     class_constrs : V.constr list;
                     class_super : V.inst_class option;
                     class_fdecls : fdecl list;
                     class_mdefs : mdef list } with pp
  
  type definition = 
      Class_def of class_def
    | Iface_def of iface_def
    | Ext_def of ext_def
    | Impl_def of impl_def
    with pp

  let pp_program p = Tywith.pp_list pp_definition p
end

module Ast = struct
  include Mk_syntax_tree(Var_parts_ast)
  include Var_parts_ast
end

module Dst = struct
  include Mk_syntax_tree(Var_parts_dst)
  include Var_parts_dst
  let mk_prim_type = function
      "void" -> Typrim_void
    | "int" -> Typrim_int
    | "bool" -> Typrim_bool
    | s -> raise (Invalid_argument s)
end

