(** Tywith Utility Module

    This module contains maps, string_of, and parser functions for several types
    provided with the OCaml standard library. The Tywith parser special-cases
    these so including this file when compiling is necessary if your types
    include standard types (such as list).
     
    @version 0.45
    @author Martin Sandin
    @since Feb 2005
  *)

open Format
  
(** Exceptions.
  *)
  
exception No_parse of int


(** String of functions.
  *)

let string_of_list string_of__a ls =
   "["^ String.concat ";" (List.map string_of__a ls) ^"]"

let string_of_array string_of__a ar =
   "[|"^ String.concat ";" (Array.to_list (Array.map string_of__a ar)) ^"|]"

let string_of_option string_of__a =
  function
  | Some x1 -> "Some ("^ string_of__a x1 ^")"
  | None -> "None"
  
let string_of_lazy string_of__a lz =
   "lazy ("^ string_of__a (Lazy.force lz) ^")"
  
let string_of_ref string_of__a rf =
   "ref ("^ string_of__a (!rf) ^")"

let string_of_unit () = "()"

let string_of_char c =
   "\'"^ Char.escaped c ^"\'"
    
    
(** Pretty-printing functions
    Added by S. Wehr <wehr@informatik.uni-freiburg.de>, 2006-10-20
*)

let pp_enclosed s1 s2 f =
  open_box 0;
  print_string s1;
  open_box 0;
  f false;
  close_box ();
  print_string s2;
  close_box ()

let with_parens f b =
  if not b then f false else pp_enclosed "(" ")" f

let gen_pp_list f ls op cl delim = 
  let rec pp = function
    | [] -> ()
    | [x] -> f x false
    | (x :: xs) -> (f x false; print_char delim; print_space (); pp xs)
  in pp_enclosed op cl (fun _ -> pp ls)

let pp_list pp__a ls _ =
  gen_pp_list pp__a ls "[" "]" ';'

let pp_array pp__a ar _ =
  gen_pp_list pp__a (Array.to_list ar) "[|" "|]" ';'

let pp_unit () _ = open_box 0; print_string "()"; close_box ()

let pp_char c _ =
  print_string ("\'"^ Char.escaped c ^"\'")

let has_white s =
  let is_white c = c = ' ' || c = '\t' || c = '\n' || c = '\r' in
  let res = ref false in
  let _ = String.iter (fun c -> res := is_white c) s in
    !res

let pp_string s _ = 
  print_string ("\""^ String.escaped s ^"\"")

let pp_raw_string s b = 
  if has_white s
  then with_parens (fun _ -> print_string s) b
  else print_string s

let pp_prim f x b = pp_raw_string (f x) b

let pp_constr f name b = 
  with_parens (fun _ ->
                 open_box 2;
                 print_string name;
                 print_space ();
                 f true;
                 close_box ()) b

let pp_option pp__a opt b = 
  match opt with
    | Some x -> 
        pp_constr (fun b -> pp__a x b) "Some" b
    | None -> 
        pp_raw_string "None" b
  
let pp_lazy pp__a lz b =
  pp_constr (fun b -> pp__a (Lazy.force lz) b) "lazy" b
  
let pp_ref pp__a rf b =
  pp_constr (fun b -> pp__a (!rf) b) "ref" b

let pp_key_value s f _ = 
  open_box 2;
  print_string s;
  print_space ();
  print_char '=';
  print_space ();
  open_box 2;
  f false;
  close_box ();
  close_box ()

let run_pp f =
  let buf = Buffer.create 32 in
  (* The out function performs the pretty-printer output. It is called with 
     a string s, a start position p, and a number of characters n; it is 
     supposed to output characters p to p + n - 1 of s. *)
  let out s p n = Buffer.add_substring buf s p n in
    Format.set_formatter_output_functions out (fun () -> ());
    f false;
    Format.print_flush ();
    Buffer.contents buf

let false__ = false

(** Map functions.
  *)
  
let map_option f_a =
  function
  | Some x1 -> Some (f_a x1)
  | None -> None
  
let map_ref f_a v =
   ref (f_a !v)

let map_lazy f_a v =
   lazy (f_a (Lazy.force v))


(** State machine tool module.
  *)
module Smac =
   struct
      type 's response = Move of 's | Stay | Leave | Break

      let over_stream start tf strm =
         let rec aux state =
            match Stream.peek strm with
            | None -> []
            | Some c ->
               let (out, trans) = tf state c in
               let put os = match out with None -> os | Some o -> o::os in
               match trans with
               | Move state -> Stream.next strm; put (aux state)
               | Stay -> Stream.next strm; put (aux state)
               | Leave -> Stream.next strm; put []
               | Break -> put []
         in aux start

      (** Change state. *)
      let move s = (None, Move s)
      let pmove out s = (Some out, Move s)

      (** Stay in state. *)
      let stay = (None, Stay)
      let pstay out = (Some out, Stay)

      (** Leave consuming token. *)
      let leave = (None, Leave)
      let pleave out = (Some out, Leave)

      (** Break now without consuming token. *)
      let break = (None, Break)
      let pbreak out = (Some out, Break)
      
   end

         
(** Parser tool module.
  * Functions for tokenizing a stream and combining parsers.
  *)
module ParserTools =
   struct
      let char_string c =
         let s = String.copy "x" in
         s.[0] <- c; s
         
      let char_stringlist cls =
         let rec iter f n = function [] -> () | e::es -> (f n e; iter f (n + 1) es) in
         let str = String.create (List.length cls) in
         iter (fun ix c -> str.[ix] <- c) 0 cls;
         str
      let show strm = char_stringlist (Stream.npeek 50 strm)

      let acc_token start p strm =
         match Smac.over_stream start p strm with
         | [] -> raise (No_parse (Stream.count strm))
         | cs -> String.concat "" cs

      let rec stream_nnext n strm =
         if n == 0
            then ()
            else (ignore (Stream.next strm); stream_nnext (n - 1) strm)

      let spec_token tok strm =
         let n = String.length tok in
         if char_stringlist (Stream.npeek n strm) = tok
            then (stream_nnext n strm; tok)
            else raise (No_parse (Stream.count strm))
      
      let number_token =
         acc_token ()
            (fun _ c -> match c with
            | '0'..'9' | '.' | '-' -> Smac.pstay (char_string c)
            | _ -> Smac.break)

      type state =  Starting | Running | Escaping | Collecting of string
      
      let id_token =
         acc_token Starting
            (fun state c -> match c with
            | 'a'..'z' | 'A'..'Z' | '_' -> Smac.pmove (char_string c) Running
            | '0'..'9' | '\'' ->
               if state == Starting then Smac.break
               else Smac.pstay (char_string c)
            | _ -> Smac.break)
            
      let munge_spaces strm =
         try ignore (acc_token ()
            (fun _ -> function
            | '\n' | ' ' | '\r' | '\t' -> Smac.stay
            | _ -> Smac.break) strm)
         with No_parse _ -> ()
        
      
      let escaping_tf opn cls =
         function
         | Starting ->
            (fun c -> if c = opn then Smac.move Running else Smac.break)
         | Running ->
            (function
            | '\\' -> Smac.move Escaping
            | c when c = cls -> Smac.pleave ""
            | c -> Smac.pstay (char_string c))
         | Escaping ->
            (function
            | '0'..'9' -> Smac.move (Collecting "")
            | c -> Smac.pmove
               (match c with 'n' -> "\n"|'t' -> "\t"|'b' -> "\b"
                |'r' -> "\r"| c -> char_string c)
               Running)
         | Collecting str ->
            (function
            | '0' .. '9' as c ->
               let str = str ^ char_string c in
               if String.length str = 3
                  then Smac.pmove
                     (char_string (Char.chr (int_of_string str)))
                     Running
                  else Smac.move (Collecting str)
            | _ -> raise (Invalid_argument "escaping_tf"))
            
      let string_token =
          acc_token Starting (escaping_tf '\"' '\"')

      let char_token =
         acc_token Starting (escaping_tf '\'' '\'')
              

      let sec a b strm =
         ignore (a strm);
         b strm
         
      let fis a b strm =
         let v = a strm in
         ignore(b strm);
         v
         
      let ret a v strm =
         ignore (a strm);v

      let seq a b strm =
         let v = a strm in v::b strm
         
      let chc a b strm =
         try a strm
         with No_parse _ -> b strm
   end


(** Parser functions.
  *)

(* Utility functions. *)

open ParserTools

let parse_token mk tk strm = 
   mk (sec munge_spaces tk strm)

let parse_spec tok =
   parse_token (fun x -> x) (spec_token tok)

let (+::+) = seq
let (|+|) = chc
let (++) = sec
let (-+) s = sec (parse_spec s)
let (--) s1 s2 = sec (parse_spec s1) (parse_spec s2)
let (+-) p s = fis p (parse_spec s)      
let (=>) s = ret (parse_spec s)

let parse_seq opn sep cls p_a =
   let rec parse_tail strm =
      (cls => []
       |+| sep -+ p_a +::+ parse_tail) strm in
   opn -+ (cls => [] |+| p_a +::+ parse_tail)
   
let parse_id =
   parse_token (fun x -> x) id_token

(* Datatype parsers. *)

let parse_int =
   parse_token int_of_string number_token

let parse_float =
   parse_token float_of_string number_token

let parse_nativeint =
   parse_token Nativeint.of_string number_token

let parse_int32 =
   parse_token Int32.of_string number_token
   
let parse_int64 =
   parse_token Int64.of_string number_token

let parse_string =
   parse_token (fun x -> x) string_token

let parse_char =
   parse_token (fun x -> x.[0]) char_token

let parse_list p_a = parse_seq "[" ";" "]" p_a

let parse_array p_a strm = Array.of_list (parse_seq "[|" ";" "|]" p_a strm)

let parse_lazy parse__a strm =
   let r = ("lazy" -- "(" ++ parse__a +- ")") strm in
   lazy r

let parse_ref parse__a strm =
   ref (("ref" -- "(" ++ parse__a +- ")") strm)

let parse_option parse__a strm =
  match parse_id strm with
  | "Some" -> Some (("(" -+ parse__a +- ")") strm)
  | "None" -> None
  | _ -> assert false

