open Syntax.Ast

let mk_inst_class (name, tyvars) =
  (Id.mk_class name, tyvars)

let mk_inst_iface (name, tyvars) =
  (Id.mk_iface name, tyvars)

let mk_class name tyvars constrs super fields methods = 
  { class_name = Id.mk_class name; 
    class_tyvars = tyvars;
    class_constrs = constrs;
    class_super = super;
    class_fdecls = fields;
    class_mdefs = methods } 

let mk_mdef tyvars modifier (name, constrs, resty, args, body) = 
  { mdef_tyvars = tyvars;
    mdef_constrs = constrs;
    mdef_restype = resty;
    mdef_args = args;
    mdef_name = Id.mk_meth name;
    mdef_code = body;
    mdef_modifier = modifier }

let mk_method_dec name modifier tyvars constrs resty argtys =
  { mdec_tyvars = tyvars;
    mdec_constrs = constrs;
    mdec_restype = resty;
    mdec_argtypes = List.map fst argtys;
    mdec_name = Id.mk_meth name;
    mdec_modifier = modifier }

let mk_iface_def implementers name tyvars constrs smdecs cmdecs =
  let real_cmdecs = List.map (fun (id, mdecs) -> { cmdec_tyvar = Id.mk_tyvar id;
                                                   cmdec_mdecs = mdecs }) cmdecs
   in { iface_name = Id.mk_iface name;
        iface_implementers = implementers;
        iface_tyvars = tyvars;
        iface_constrs = constrs;
        iface_smdecs = smdecs;
        iface_cmdecs = real_cmdecs }

let mk_ext_def name tyvars constrs methods = 
  { ext_class = Id.mk_class name;
    ext_tyvars = tyvars;
    ext_constrs = constrs;
    ext_mdefs = methods }

let mk_impl_def tyvars iface types constrs smdefs =
  { impl_tyvars = tyvars;
    impl_constrs = constrs;
    impl_implementers = types;
    impl_iface = mk_inst_iface iface;
    impl_smdefs = smdefs }

let mk_iface_constr types annot iface = 
  Constr_iface (types, annot, mk_inst_iface iface)

let mk_class_constr tyvar clazz =
  Constr_class (Id.mk_tyvar tyvar, mk_inst_class clazz)

let mk_existential tyvars constrs ty =
  Ty_exist (List.map Id.mk_tyvar tyvars, constrs, ty)

let mk_mcall expr (name, tyvars, args) = 
  Expr_mcall (expr, Id.mk_meth name, tyvars, args)

let mk_icall iface types (name, tyvars, args) =
  Expr_icall (mk_inst_iface iface, types, Id.mk_meth name, tyvars, args)

let mk_cast_from_expr expr1 expr2 =
  let unknown_from_var v = Id.mk_unknown (Id.string_from_var v) in
    match expr1 with
      | Expr_var x -> Expr_cast (Ty_unknown (unknown_from_var x, []), expr2)
      | _          -> raise Parsing.Parse_error
