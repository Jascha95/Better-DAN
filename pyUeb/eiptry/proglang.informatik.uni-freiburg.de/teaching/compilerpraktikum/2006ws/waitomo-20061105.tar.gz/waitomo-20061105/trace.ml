type level = int

let levels = 
  [|(* general trace levels, must be present *)
    ("debug", "D", false);
    ("info", "I", false);
    ("warn", "W", true);
    ("fatal", "F", true);
    (* application specific trace levels, can be adjusted to your needs *)
  |]

let level_of_string s = 
  let rec f i =
    if i >= Array.length levels then None
    else if (let name, _, _ = levels.(i) in name = s)
    then Some i
    else f (i + 1)
  in 
    match f 0 with
        Some i -> i
      | None   ->
          invalid_arg ("Trace.get_level_index: Illegal level string: " ^ s)
      
let debug = level_of_string "debug"
let info = level_of_string "info"
let warn = level_of_string "warn"
let fatal = level_of_string "fatal"

let rec enable_level i = 
  let name, sname, is_enabled = levels.(i) in
    levels.(i) <- (name, sname, true);
    if i <= warn then enable_level (i + 1)

let rec disable_level i = 
  if i = warn || i = fatal then
    failwith "Trace levels 'warn' and 'fatal' cannot be disabled"
  else
    let name, sname, is_enabled = levels.(i) in
      levels.(i) <- (name, sname, false);
      if i >= 1 then disable_level (i - 1)

let is_enabled i = let _, _, b = levels.(i) in b

let toggle_level i = 
  if is_enabled i then disable_level i
  else enable_level i

let level_names = 
  let first (x, _, _) = x in
    Array.to_list (Array.map first levels)

let level_id i = let (_, y, _) = levels.(i) in y
  
let trace_fmt = format_of_string 

let trace fname lineno level fmt = 
  let f s = 
    prerr_endline s;
    if level = fatal then exit 127 else ()
  in
    if is_enabled level then
      Printf.ksprintf f ("[%2s %s:%d] " ^^ fmt) 
        (level_id level) fname lineno
    else
      Printf.ksprintf ignore fmt

let fatal fname lineno fmt = 
  trace fname lineno fatal fmt;
  failwith "code never reached!"
