(*pp ./pp trace *)

(* This module implements the transformation AST -> DST (where DST stands
   for "desugared syntax tree". The transformation detects the sort of
   each identifier (i.e. whether it's a type variable, a class name,
   a field identifier, ...), makes identifiers unique, and
   expands syntactic sugar.
*)

open Utils

module Ast = Syntax.Ast
module Dst = Syntax.Dst

exception Desugar_error of string

module type ID = 
sig 
  type t 
  val to_string : t -> string 
  val descr : string 
end

module Def_ids = functor(I: ID) ->
  (struct
     let tab = Hashtbl.create 23
     let add x = Hashtbl.add tab (I.to_string x) ()
     let assert_is_defined x =
       let s = I.to_string x in
         try 
           Hashtbl.find tab s; x
         with Not_found -> 
           raise (Desugar_error ("Undefined " ^ I.descr ^ ": " ^ s))
   end : 
   sig
     val add : I.t -> unit
     val assert_is_defined : I.t -> I.t
   end)

module Scoped_ids = functor(I: sig include ID val fresh : t -> t end) ->
  (struct
     let tab = Scope_table.create ()
     let lookup x =
       try 
         Scope_table.find tab x
       with Not_found -> 
         raise (Desugar_error ("Undefined " ^ I.descr ^ ": " ^ I.to_string x))
     let add x =
       let x' = I.fresh x in 
         Scope_table.add tab x x'; x'
     let open_scope () = Scope_table.open_scope tab
     let close_scope () = Scope_table.close_scope tab
     let with_scope f = open_scope(); let x = f () in close_scope (); x
   end :
   sig
     val lookup : I.t -> I.t
     val add : I.t -> I.t
     val open_scope : unit -> unit
     val close_scope : unit -> unit
     val with_scope : (unit -> 'a) -> 'a
   end)

module Def_classes = Def_ids(struct
                               type t = Id.clazz
                               let to_string = Id.string_from_class
                               let descr = "class"
                             end)

module Def_ifaces = Def_ids(struct
                              type t = Id.iface
                              let to_string = Id.string_from_iface
                              let descr = "interface"
                            end)

module Scoped_vars = Scoped_ids(struct
                                  type t = Id.var
                                  let to_string = Id.string_from_var
                                  let descr = "variable"
                                  let fresh = Id.fresh_var
                                end)

module Scoped_tyvars = Scoped_ids(struct
                                    type t = Id.tyvar
                                    let to_string = Id.string_from_tyvar
                                    let descr = "type variable"
                                    let fresh = Id.fresh_tyvar
                                  end)

let rec desugar_type = function
    Ast.Ty_var v -> Dst.Ty_var (Scoped_tyvars.lookup v)
  | Ast.Ty_class inst_class -> Dst.Ty_class (desugar_inst_class inst_class)
  | Ast.Ty_exact ty -> Dst.Ty_exact (desugar_type ty)
  | Ast.Ty_exist (tyvars, constrs, ty) ->
      Scoped_tyvars.open_scope ();
      let tyvars' = List.map Scoped_tyvars.add tyvars in
      let constrs' = List.map desugar_constr constrs in
      let ty' = desugar_type ty in
        Scoped_tyvars.close_scope (); Dst.Ty_exist (tyvars', constrs', ty')
  | Ast.Ty_unknown (id, []) ->
      (try
         Dst.Ty_prim (Dst.mk_prim_type (Id.string_from_unknown id))
       with Invalid_argument _ ->
         try 
           let tyvar = Id.mk_tyvar (Id.string_from_unknown id) in
           let tyvar' = Scoped_tyvars.lookup tyvar in
             Dst.Ty_var tyvar'
         with Desugar_error _ ->
           unknown_as_class (id, [])
      )
  | Ast.Ty_unknown inst_unknown ->
      unknown_as_class inst_unknown

and unknown_as_class (id, tys) =
  let clazz = Id.mk_class (Id.string_from_unknown id) in
    Dst.Ty_class (desugar_inst_class (clazz, tys))

and desugar_inst_class (clazz, tys) = 
  (Def_classes.assert_is_defined clazz, List.map desugar_type tys)

and desugar_inst_iface (iface, tys) = 
  (Def_ifaces.assert_is_defined iface, List.map desugar_type tys)

and desugar_constr = function
    Ast.Constr_class (tyvar, inst_class) ->
      Dst.Constr_class (Scoped_tyvars.lookup tyvar, desugar_inst_class inst_class)
  | Ast.Constr_iface (tys, ba, inst_iface) ->
      Dst.Constr_iface (List.map desugar_type tys, desugar_bound_annot ba, 
                        desugar_inst_iface inst_iface)

and desugar_bound_annot = function
    Ast.Bound_implicit -> Dst.Bound_implicit
  | Ast.Bound_explicit -> Dst.Bound_explicit


let rec desugar_expr = function
    Ast.Expr_int i -> Dst.Expr_int i
  | Ast.Expr_bool b -> Dst.Expr_bool b
  | Ast.Expr_new inst_class -> Dst.Expr_new (desugar_inst_class inst_class)
  | Ast.Expr_var x -> let x' = Scoped_vars.lookup x in Dst.Expr_var x'
  | Ast.Expr_field (e, f) -> let e' = desugar_expr e in Dst.Expr_field (e', f)
  | Ast.Expr_null -> Dst.Expr_null
  | Ast.Expr_cast (ty, e) -> Dst.Expr_cast (desugar_type ty, desugar_expr e)
  | Ast.Expr_mcall (e, m, tys, es) ->
      let e' = desugar_expr e in
      let tys' = List.map desugar_type tys in
      let es' = List.map desugar_expr es in
        Dst.Expr_mcall (e', m, tys', es')
  | Ast.Expr_icall (iface, tys1, m, tys2, es) ->
      let iface' = desugar_inst_iface iface in
      let tys1' = List.map desugar_type tys1 in
      let tys2' = List.map desugar_type tys2 in
      let es' = List.map desugar_expr es in
        Dst.Expr_icall (iface', tys1', m, tys2', es')

let rec desugar_stmt = function
    Ast.Stmt_if (e, block) ->
      let e' = desugar_expr e in
      let block' = desugar_block block in
        Dst.Stmt_if (e', block')
  | Ast.Stmt_if_else (e, block1, block2) ->
      let e' = desugar_expr e in
      let block1' = desugar_block block1 in
      let block2' = desugar_block block2 in
        Dst.Stmt_if_else (e', block1', block2')
  | Ast.Stmt_while (e, block) ->
      let e' = desugar_expr e in
      let block' = desugar_block block in
        Dst.Stmt_while (e', block')
  | Ast.Stmt_return e -> let e' = desugar_expr e in Dst.Stmt_return e'
  | Ast.Stmt_vardecl (ty, var, opt_expr) -> (
      try
        (* to model java' scoping rules, we disallow redefinitions *)
        let _ = Scoped_vars.lookup var in
          raise (Desugar_error ("Variable already defined: " 
                                ^ Id.string_from_var var))
      with Not_found ->
        let ty' = desugar_type ty in
        let var' = Scoped_vars.add var in
        let opt_expr' = 
          match opt_expr with
              None -> None
            | Some e -> Some (desugar_expr e)
        in 
          Dst.Stmt_vardecl (ty', var', opt_expr')
    )
  | Ast.Stmt_assign (e1, f, e2) ->
      let e1' = desugar_expr e1 in
      let e2' = desugar_expr e2 in
        Dst.Stmt_assign (e1', f, e2')
  | Ast.Stmt_expr e -> let e' = desugar_expr e in Dst.Stmt_expr e'

and desugar_block b = 
  Scoped_vars.open_scope ();
  let b' = List.map desugar_stmt b in
    Scoped_vars.close_scope (); b'
          
let desugar_modifier = function
    Ast.Static -> Dst.Static
  | Ast.Nonstatic -> Dst.Nonstatic

let desugar_mdef mdef = 
  let _ = ITRACE "desugaring method definition %s" 
    (Id.string_from_meth mdef.Ast.mdef_name) in
  let _ = Scoped_tyvars.open_scope () in
  let _ = Scoped_vars.open_scope () in
  let tyvars' =  List.map Scoped_tyvars.add mdef.Ast.mdef_tyvars in
  let args' = List.map (fun (t,v) -> (desugar_type t,
                                      Scoped_vars.add v)) mdef.Ast.mdef_args in
  let mdef' = 
    { Dst.mdef_tyvars = tyvars';
      Dst.mdef_constrs = List.map desugar_constr mdef.Ast.mdef_constrs;
      Dst.mdef_restype = desugar_type mdef.Ast.mdef_restype;
      Dst.mdef_args = args';
      Dst.mdef_name = mdef.Ast.mdef_name;
      Dst.mdef_code = desugar_block mdef.Ast.mdef_code;
      Dst.mdef_modifier = desugar_modifier mdef.Ast.mdef_modifier }
  in
    Scoped_tyvars.close_scope ();
    Scoped_vars.close_scope ();
    mdef'
  
let desugar_mdec mdec = 
  let _ = ITRACE "desugaring method declaration %s" 
    (Id.string_from_meth mdec.Ast.mdec_name) in
  let _ = Scoped_tyvars.open_scope () in
  let tyvars' = List.map Scoped_tyvars.add mdec.Ast.mdec_tyvars in
  let mdec' = 
    { Dst.mdec_tyvars = tyvars';
      Dst.mdec_constrs = List.map desugar_constr mdec.Ast.mdec_constrs;
      Dst.mdec_restype = desugar_type mdec.Ast.mdec_restype;
      Dst.mdec_argtypes = List.map desugar_type mdec.Ast.mdec_argtypes;
      Dst.mdec_name = mdec.Ast.mdec_name;
      Dst.mdec_modifier = desugar_modifier mdec.Ast.mdec_modifier }
  in
    Scoped_tyvars.close_scope ();
    mdec'

let desugar_cmdec cmdec =
  ITRACE "desugaring method declarations for class %s" 
    (Id.string_from_tyvar cmdec.Ast.cmdec_tyvar);
  { Dst.cmdec_tyvar = Scoped_tyvars.lookup cmdec.Ast.cmdec_tyvar;
    Dst.cmdec_mdecs = List.map desugar_mdec cmdec.Ast.cmdec_mdecs }

let desugar_fdecl fdecl = 
  ITRACE "desugaring field %s" (Id.string_from_field fdecl.Ast.fdecl_name);
  { Dst.fdecl_type = desugar_type fdecl.Ast.fdecl_type;
    Dst.fdecl_name = fdecl.Ast.fdecl_name;
    Dst.fdecl_init = match fdecl.Ast.fdecl_init with
                       | None -> None
                       | Some e -> Some (desugar_expr e) }

let desugar_impl_def impl = Scoped_tyvars.with_scope @@ fun () -> 
  let tyvars' = List.map Scoped_tyvars.add impl.Ast.impl_tyvars in
    { Dst.impl_tyvars = tyvars';
      Dst.impl_constrs = List.map desugar_constr impl.Ast.impl_constrs;
      Dst.impl_implementers = List.map desugar_type impl.Ast.impl_implementers;
      Dst.impl_iface = desugar_inst_iface impl.Ast.impl_iface;
      Dst.impl_smdefs = List.map desugar_mdef impl.Ast.impl_smdefs }

let desugar_ext_def ext = Scoped_tyvars.with_scope @@ fun () ->
  let tyvars' = List.map Scoped_tyvars.add ext.Ast.ext_tyvars in
    { Dst.ext_class = Def_classes.assert_is_defined ext.Ast.ext_class;
      Dst.ext_tyvars = tyvars';
      Dst.ext_constrs = List.map desugar_constr ext.Ast.ext_constrs;
      Dst.ext_mdefs = List.map desugar_mdef ext.Ast.ext_mdefs }

let desugar_iface_def iface = Scoped_tyvars.with_scope @@ fun () ->
  let tyvars' = List.map Scoped_tyvars.add iface.Ast.iface_tyvars in
  let implementers' = List.map Scoped_tyvars.add iface.Ast.iface_implementers in
    { Dst.iface_tyvars = tyvars';
      Dst.iface_implementers = implementers';
      Dst.iface_name = iface.Ast.iface_name;
      Dst.iface_constrs = List.map desugar_constr iface.Ast.iface_constrs;
      Dst.iface_smdecs = List.map desugar_mdec iface.Ast.iface_smdecs;
      Dst.iface_cmdecs = List.map desugar_cmdec iface.Ast.iface_cmdecs }

let desugar_class_def clazz = Scoped_tyvars.with_scope @@ fun () ->
  let tyvars' = List.map Scoped_tyvars.add clazz.Ast.class_tyvars in
    { Dst.class_name = clazz.Ast.class_name;
      Dst.class_tyvars = tyvars';
      Dst.class_constrs = List.map desugar_constr clazz.Ast.class_constrs;
      Dst.class_super = (match clazz.Ast.class_super with
                           | None -> None
                           | Some inst_class -> Some (desugar_inst_class 
                                                        inst_class));
      Dst.class_fdecls = List.map desugar_fdecl clazz.Ast.class_fdecls;
      Dst.class_mdefs = List.map desugar_mdef clazz.Ast.class_mdefs }

let desugar_definition = function
    Ast.Class_def cd -> 
      let name = Id.string_from_class cd.Ast.class_name in
      let _ = ITRACE "desugaring class %s" name in
      let res = Dst.Class_def (desugar_class_def cd) in
      let _ = ITRACE "finished desugaring class %s" name in
        res
  | Ast.Iface_def id -> 
      let name = Id.string_from_iface id.Ast.iface_name in
      let _ = ITRACE "desugaring interface %s" name in
      let res = Dst.Iface_def (desugar_iface_def id) in
      let _ = ITRACE "finished desugaring interface %s" name in
        res
  | Ast.Ext_def ed -> 
      let name = Id.string_from_class ed.Ast.ext_class in
      let _ = ITRACE "desugaring extension of class %s" name in
      let res = Dst.Ext_def (desugar_ext_def ed) in
      let _ = ITRACE "finished desugaring extension of class %s" name in
        res
  | Ast.Impl_def id -> 
      let name = Id.string_from_iface (fst id.Ast.impl_iface) in
      let _ = ITRACE "desugaring implementation of interface %s" name in
      let res = Dst.Impl_def (desugar_impl_def id) in
      let _ = ITRACE "finished implementation of interface %s" name in
        res

let desugar_program defs = 
  let enter_class_iface = function
      Ast.Class_def cd -> Def_classes.add cd.Ast.class_name
    | Ast.Iface_def id -> Def_ifaces.add id.Ast.iface_name
    | _            -> ()
  in
    List.iter enter_class_iface defs;
    List.map desugar_definition defs

