(*pp ./pp tywith *)

type clazz   = Class of string with pp
type iface   = Iface of string with pp
type tyvar   = Tyvar of string with pp
type field   = Field of string with pp
type meth    = Meth of string with pp
type var     = Var of string with pp
type unknown = Unknown of string with pp

let mk_class s = Class s
let mk_iface s = Iface s
let mk_tyvar s = Tyvar s
let mk_field s = Field s
let mk_meth s = Meth s
let mk_var s = Var s
let mk_unknown s = Unknown s

let string_from_class (Class s) = s
let string_from_iface (Iface s) = s
let string_from_tyvar (Tyvar s) = s
let string_from_field (Field s) = s
let string_from_var (Var s) = s
let string_from_meth (Meth s) = s
let string_from_unknown (Unknown s) = s

let cmp_class (Class s) (Class s') = String.compare s s'
let cmp_iface (Iface s) (Iface s') = String.compare s s'
let cmp_tyvar (Tyvar s) (Tyvar s') = String.compare s s'
let cmp_field (Field s) (Field s') = String.compare s s'
let cmp_meth (Meth s) (Meth s') = String.compare s s'
let cmp_var (Var s) (Var s') = String.compare s s'

let fresh tbl s = 
  try
    let next_free = Hashtbl.find tbl s in
      Hashtbl.add tbl s (next_free+1);
      s ^ "_" ^ string_of_int next_free
  with Not_found -> 
    Hashtbl.add tbl s 1;
    s
    
let var_tbl = Hashtbl.create 13
let fresh_var (Var s) = 
  let s' = fresh var_tbl s in Var s'

let tyvar_tbl = Hashtbl.create 13
let fresh_tyvar (Tyvar s) = 
  let s' = fresh tyvar_tbl s in Tyvar s'
      
