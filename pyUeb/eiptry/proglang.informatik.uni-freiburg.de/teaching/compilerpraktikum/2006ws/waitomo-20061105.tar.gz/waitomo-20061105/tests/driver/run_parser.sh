#!/bin/sh

if [ -z "$1" ] ; then
    echo "Usage: $0 FILE"
    exit 1
fi

if [ ! -e "$1" ] ; then
    echo "Input file $1 does not exist"
    exit 1
fi

OBJS="tywith/tywith.cmo utils.cmo ast.cmo parser.cmo lexer.cmo"
TOP=../..

ocaml -I $TOP $OBJS <<EOF
#use "driver.ml";;
do_parse "$1";;
EOF
