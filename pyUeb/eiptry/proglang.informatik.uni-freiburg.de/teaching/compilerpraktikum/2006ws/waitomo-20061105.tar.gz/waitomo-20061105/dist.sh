#!/bin/sh

DIST_DIR="waitomo-`date +'%Y%m%d'`"
DIST_FILE="$DIST_DIR.tar.gz"

if [ -e "$DIST_DIR" ] ; then
    rm -rf "$DIST_DIR"
fi

if [ -e "$DIST_FILE" ] ; then
    rm "$DIST_FILE"
fi

svn export . "$DIST_DIR"
echo "Export completed, directory: $DIST_DIR"

tar cfz "$DIST_FILE" "$DIST_DIR"
echo "Archive complete, file: $DIST_FILE"

