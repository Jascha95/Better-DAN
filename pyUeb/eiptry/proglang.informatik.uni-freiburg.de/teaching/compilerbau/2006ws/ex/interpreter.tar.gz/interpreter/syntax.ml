type 'ident t =
    Int of int
  | Builtin of 'ident * 'ident t list
  | If of 'ident t * 'ident t * 'ident t
  | Ident of 'ident
  | Let of 'ident * 'ident t * 'ident t
  | Function of 'ident * 'ident list * 'ident t
  | Apply of 'ident t * 'ident t list

