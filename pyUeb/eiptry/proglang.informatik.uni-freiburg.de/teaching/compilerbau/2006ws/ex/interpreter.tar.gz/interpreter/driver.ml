let lexbuf_from_file fname = 
  let chan = open_in fname in
  let buf = Lexing.from_channel chan in
  let cur_pos = buf.Lexing.lex_curr_p in
  let start_pos = buf.Lexing.lex_start_p in
    buf.Lexing.lex_curr_p <- { cur_pos with Lexing.pos_fname = fname };
    buf.Lexing.lex_start_p <- { start_pos with Lexing.pos_fname = fname };
    buf

let main () = 
  let argv = Sys.argv in
    if Array.length argv <> 2 then failwith "USAGE: call-cc FILE"
    else 
      begin
        let fname = argv.(1) in
        let buf = lexbuf_from_file fname in
          try
            let exp = Parser.exp Lexer.token buf in
            let res = Evalcc.top_eval exp in
              print_endline ("RESULT: " ^ res)
          with 
              Parsing.Parse_error ->
                failwith (Lexer.error_msg buf)
      end

let _ =
  try
    main ()
  with
      Failure s -> print_endline ("ERROR: " ^ s)
