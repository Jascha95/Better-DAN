(* environment manipulation *)
type 'value env = (string * 'value) list

let extend env x v = ((x,v)::env)

let rec extends env xs vs =
  match (xs, vs) with
      (x::xs, v::vs) ->
        extends (extend env x v) xs vs
    | ([], []) ->
        env

let lookup x env = 
  try List.assoc x env with
      Not_found -> failwith ("Undefined variable: " ^ x)
