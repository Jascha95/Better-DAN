type re = Symbol of char
        | Union of (re * re)
        | Concat of (re * re)
        | Repeat of re

let rec string_of_re = function
    Symbol x -> "Symbol(" ^ String.make 1 x ^ ")"
  | Union(re1,re2) -> "Union(" ^ string_of_re re1 ^ ", " ^ string_of_re re2 ^ ")"
  | Concat(re1,re2) -> "Concat(" ^ string_of_re re1 ^ ", " ^ string_of_re re2 ^ ")"
  | Repeat re -> "Repeat(" ^ string_of_re re ^ ")"

