#!/bin/sh

ocamlyacc parser.mly || exit 1
ocamllex lexer.mll || exit 1
ocamlc -o re re.ml parser.mli parser.ml lexer.ml driver.ml || exit 1