let parse s = 
  let lexbuf = Lexing.from_string s in
    Parser.re Lexer.token lexbuf

let check s re =
  try
    let re' = parse s in
      if re = re'
      then print_endline ("OK: " ^ s)
      else print_endline ("FAIL: Parsing " ^ s ^ " results in " ^ Re.string_of_re re'
                            ^ ", expected " ^ Re.string_of_re re)
  with
      Parsing.Parse_error ->
        print_endline ("FAIL: Parsing " ^ s ^ " results in a parse error")

let a = Re.Symbol 'a'
let b = Re.Symbol 'b'
let c = Re.Symbol 'c'
