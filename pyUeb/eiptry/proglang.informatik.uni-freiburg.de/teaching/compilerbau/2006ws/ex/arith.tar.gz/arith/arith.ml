open Searchtree

type op = Add | Sub | Mul | Div

type expr = Number of int | Binop of (expr * op * expr)
          | Var of string | Let of (string * expr * expr)

let fun_of_binop = function
    Add -> (+)
  | Sub -> (-)
  | Mul -> ( * )
  | Div -> (/)

let rec eval env = function
    Number i -> Some i
  | Var s -> find s env
  | Let (s, e1, e2) ->
      (match eval env e1 with
           None -> None
         | Some i -> eval (insert s i env) e2)
  | Binop (i, op, j) -> 
      match eval env i with
          None   -> None
        | Some l ->
            match eval env j with
                None   -> None
                | Some r -> 
                    if r = 0 && op = Div then None
                    else Some (fun_of_binop op l r)
