let lex s = 
  let buf = Lexing.from_string s in
  let rec do_lex acc = 
    match Lexer.token buf with
        Lexer.EOF -> List.rev acc
      | t   -> do_lex (t::acc)
  in
    do_lex []

let parse s = 
  let tokens = lex s in
    match Parser.parse tokens with
        (e, []) -> e
      | (_, x::_) -> failwith ("Not all tokens consumed, next token: "
                                 ^ Lexer.string_of_token x)

let eval s = 
  let e = parse s in
    Arith.eval Searchtree.empty e

let test s exp = 
  let pp = function
      None -> "None"
    | Some i -> "Some(" ^ string_of_int i ^ ")"
  in
    print_string ("Evaluating " ^ s ^ " ... ");
    try 
      let res = eval s in
        if exp = res
        then print_endline ("OK, result: " ^ pp res)
        else print_endline ("FAIL, expected: " ^ pp exp ^ ", computed: " ^ pp res)
    with
        Failure s -> print_endline ("FAIL: " ^ s)
      | Lexer.Parse_error -> print_endline ("FAIL: Parse_error")
      | e -> raise e

let _ =
  test "1" (Some 1);

  
