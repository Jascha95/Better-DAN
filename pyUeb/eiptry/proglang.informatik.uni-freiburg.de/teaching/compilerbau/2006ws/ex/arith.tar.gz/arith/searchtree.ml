type ('a, 'b) tree = Node of ('a * 'b * ('a, 'b) tree * ('a, 'b) tree) 
                   | Leaf

let empty = Leaf

let rec insert k v = function
    Leaf -> 
      Node (k, v, Leaf, Leaf)
  | Node (k', v', l, r) ->
      if k < k' then Node (k', v', insert k v l, r)
      else if k > k' then Node (k', v', l, insert k v r)
      else Node (k, v, l, r)

let rec find k = function
    Leaf -> None
  | Node (k', v, l, r) ->
      if k < k' then find k l
      else if k > k' then find k r
      else Some v
