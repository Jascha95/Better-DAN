var RIGHT_INDEX_ROW_HEIGHT = 8;
var PATH_TO_IMAGES = "images/";
var TYPE_WINDOW = "type.html";
var NAVIGATOR_WINDOW = "navigator.html";
var TYPE_BROWSER_MIN_WIDTH = 400;
var TYPE_BROWSER_MIN_HEIGHT = 200;
var ERROR_NAVIGATOR_MIN_WIDTH = 400;
var ERROR_NAVIGATOR_MIN_HEIGHT = 190;

// # of rows per image in the right navigation bar
var current_block_size;

// type window mode: show the bars above and below the 
// current selection or not
var show_bars = true;

// variable being defined by module description file
var tyError;

// variable storing the current highlighted node
var currentHLNode;

// variable referencing every id to it's linenr
var idToLineNr = new Array();

// add typop as an event handler to all spans after loading the document
function typebrowserInit(){
  createIndexButtons(); // not yet correctly positioned
  initSpanEvents();
  initAnchorTags();
  navigatorPopup(NAVIGATOR_WINDOW);
  initSpanMerger();
}

// add the onclick events to applicable span and div elements
function initSpanEvents() {
  var node;
  var onclickFun = function(event) { 
    event.stopPropagation(); // cancellation of the bubble
    typePopup(TYPE_WINDOW);  // popping up the type window
    if (currentHLNode) {     // if the window exists already         
      typop(this);     
      pop_gen();             // we have to repaint
    } else {                 // otherwise it's done by onupdate 
      typop(this);           // to ensure complete loading of doc
    }
  };
  var allSpans = document.getElementsByTagName('span');
  for (var i=0; i < allSpans.length; i++) {
    node = allSpans[i];
    if (node.id.substr(0,1) == 'c') {
      node.onclick = onclickFun;
    }
  }
}

//to add id's to all anchor tags after loading the document
function initAnchorTags(){

  var node;
  var mainDiv = document.getElementById("sourcediv");
  mainDiv.style.width = window.innerWidth - 100;
  var idCount = linkDocument(document.getElementById('sourcediv'), 0);

  div = document.getElementById('rightIndex');
  current_block_size = Math.max(1, Math.ceil(RIGHT_INDEX_ROW_HEIGHT*idCount/(window.innerHeight-75)));
  
  var table = document.createElement("table");
  table.className = "rightIndex";
  table.cellpadding = "0px";
  table.cellspacing = "0px";
  for (var i=0; i<idCount; i+=current_block_size) {
    var row         = document.createElement("tr");
    row.className   = "rightIndex";
    row.id          = "t" + Math.floor(i / current_block_size);
    row.onclick     = scrollViewGen("a" + i);
    for (var j = 0; j<6; j++) {
      var cell       = document.createElement("td");
      if (j == 0 || j == 5) cell.className = "rightIndexLean";
      else cell.className = "rightIndex";
      cell.priority  = 0;
      row.appendChild(cell);
    }
    table.appendChild(row);
  }
  div.appendChild(table);
}

function scrollViewGen(ref) {
  return function() { scrollView(ref); }; 
}

// walks through the whole document, attaching the id to the as and creating idToLineNr
function linkDocument(currentNode, lineNr) {
  if (!currentNode) return lineNr;
  if (currentNode.id && currentNode.id.substr(0, 1) == "c") 
    idToLineNr[currentNode.id.substr(1)] = lineNr;
  if (currentNode.nodeName && currentNode.nodeName == "A") {
    currentNode.setAttribute("id", "a"+lineNr);
    lineNr ++;
  }
  lineNr = Math.max(lineNr, linkDocument(currentNode.firstChild, lineNr));
  return Math.max(lineNr, linkDocument(currentNode.nextSibling, lineNr));
}

function createIndexButtons () {
  // The div containing the right index button is created (including content)
  var indexButtonDiv = document.createElement('div');
  indexButtonDiv.className = 'rightIndexButton';
  var input = document.createElement('input');
  input.className = 'rightIndexButton';
  input.value     = "Hide Index";
  input.type      = "button";
  input.id        = 'rightIndexButton';
  input.onclick   = swapRightIndex;
  indexButtonDiv.appendChild(input);

  // The div containing the right index is created (excluding content)
  var rightIndexDiv = document.createElement('div');
  rightIndexDiv.id='rightIndex';
  rightIndexDiv.className ='source rightIndex';

  var body = document.getElementsByTagName('body')[0];
  body.appendChild(indexButtonDiv);
  body.appendChild(rightIndexDiv); 
}

// traverse the sourcediv and try to coalesce spans
function initSpanMerger () {
  var spanNodes = document.getElementsByTagName ('span');
  var testRE = /l([0-9]+)-r\1/;
  for (var i = 0; i<spanNodes.length; i++) {
    var thisNode = spanNodes[i];
    var nodeId = thisNode.id;
    if (!nodeId)
      continue;
    var nodeNumber = nodeId.match(/^c([0-9]+)$/);
    if (nodeNumber) {
      var testString = thisNode.firstChild.id + "-" + thisNode.lastChild.id;
      var tested = testString.match(testRE);
      if (tested) {
	thisNode.removeChild(thisNode.firstChild);
	thisNode.removeChild(thisNode.lastChild);
	spanMerge (nodeNumber[1], tested[1]);
      }
    }
  }
  // var message = "equivalenceClasses";
  // for (i in equivalenceClasses)
  // message += "\n " + i + " -> [" + equivalenceClasses[i] + "]";
  // alert (message);
}

var equivalenceClasses = {};
var equivalenceIds = {};
function getEquivalenzClass (id) {
  // oops, forgot about path compression...
  var parent;
  var current = id;
  while (parent = equivalenceIds[current]) {
    current = parent;
  }
  if (current == id && !equivalenceClasses[current]) {
    equivalenceClasses[current] = [current];
  }
  return current;
}

function spanMerge (id1, id2) {
  var ec1 = getEquivalenzClass(id1);
  var ec2 = getEquivalenzClass(id2);
  if (ec1 != ec2) {
    var cl1 = equivalenceClasses[ec1];
    var cl2 = equivalenceClasses[ec2];
    if (cl1.length > cl2.length) {
      equivalenceIds[ec2] = ec1;
      for (var i = 0; i<cl2.length; i++) {
	cl1[cl1.length] = cl2[i];
      }
      delete equivalenceClasses[ec2];
    } else {
      equivalenceIds[ec1] = ec2;
      for (var i = 0; i<cl1.length; i++) {
	cl2[cl2.length] = cl1[i];
      }
      delete equivalenceClasses[ec1];
    }
  }
}

function swapRightIndex(){
  var rightIndex = document.getElementById('rightIndex');
  var button = document.getElementById('rightIndexButton');
  if (rightIndex.style.visibility == 'hidden') {
    rightIndex.style.visibility = "visible";
    button.value = "Hide Index";
  } else {
    rightIndex.style.visibility = "hidden";
    button.setAttribute("value", "Show Index");
  }
}

/* generic highlighting: 
   first argument: className of highlighting
   second argument: priority of this highlighting action
   following args: ids.
*/
function highlight () {
  var el, cls;
  var cls = arguments[0];
  var thisPriority = arguments[1];   // priority of this highlighting
  var newPriority;                   // priority of the node after highlighting:
  if (cls == "") newPriority = 0;    // least if it was a lowlightinging
  else newPriority = thisPriority;   // priority of this highlighting otherwise

  // var trace = "highlight('"+cls+"'";
  for (var i=2; i < arguments.length; i++) {
    // trace += ","+arguments[i]
    if (el = document.getElementById (arguments[i])) {
      el.className = cls;
      if (el.id && el.id.substr(0,1) == "c") {
	var aId_num = idToLineNr[el.id.substr(1)];
	var cells = document.getElementById("t"+Math.floor(aId_num / current_block_size)).childNodes;
	switch (cls) {
	case "intro" :
	  cells = Array(cells[1]); break;
	case "elim" : 
	  cells = Array(cells[2]); break;
	case "flow" :
	  cells = Array(cells[3]); break;
	case "nested" :
	  cells = Array(cells[4]); break;
	}
	//	alert("New Class = "+cls);
	for (var j=0; j<cells.length; j++) {
	  if (cells[j].priority <= thisPriority) {
	    cells[j].className = cls;
	    cells[j].priority = newPriority;
	  }
	}
      }
      // trace += "*"
    }
  }
  // alert (trace+")");
}

function lowlightPhrase(kind) {
  return function(current) {
    highlight ('', kind, 'l'+current, 'r'+current, 'c'+current);
  }
}

function highlightPhrase(kind) {
  return function(b) {
    var bleft  = b+' '+b+'-border left';
    var bright = b+' '+b+'-border right';
    return function (current) {
      highlight (bleft,  kind, 'l'+current);
      highlight (bright, kind, 'r'+current);
      highlight (b,      kind, 'c'+current);
    };
  }
}

function setValue (doc,id,val) {
  var el = doc.getElementById (id);
  if (el) el.value = val;
}

function forallNested (f, xs) {
  switch (typeof xs) {
  case "object":
    for (var i=0; i<xs.length; i++)
      forallNested (f, xs[i]);
    break;
  default:
    f (xs);
  }
}

function flatten (xss, which) {
  if (which) alert("flatten: "+which);
  var r = new Array ();
  var l = 0;
  for (var i=0; i<xss.length; i++) {
    var xs = xss[i];
    for (var j=0; j<xs.length; j++) {
      r[l++] = xs[j];
    }
  }
  return r;
}

function map (f, xs) {
  var r = new Array (xs.length);
  for (var i=0; i<xs.length; i++)
    r[i] = f (xs[i], i);
  return r;
}

// get (nested) array of *all* ids for flowClass i
function getLocations (fc) {
  var labels = tyError.flowClassLabels[fc];
  if (labels) {
    var r = new Array (labels.length);
    for (var i=0; i<labels.length; i++)
      r[i] = labToIds (labels[i]);
    return r;
  }
  else
    return [];
}

function labToIds (lab) {
  return tyError.mappingAnnData[lab][2];
}

// get introduction ids for flowclass i
function getIntros (i) {
  var fc = tyError.flowClasses[i];
  return getIntrosTypeList (fc.typeList);
}

function getIntrosTypeList (tys) {
  return map (getIntrosLabTyTerm, tys);
}

function getIntrosLabTyTerm (ty) {
  return map (labToIds, ty.pos);
}

// get elimination ids for flowclass i
function getElims (i) {
  var fc = tyError.flowClasses[i];
  return getElimsTypeList (fc.typeList);
}

function getElimsTypeList (tys) {
  return map (getElimsLabTyTerm, tys);
}

function getElimsLabTyTerm (ty) {
  return map (labToIds, ty.neg);
}

function getNestedErrorLocations (i) {
  var locs = [];
  for (var d = 0; (locs[d] = getErrorLocations (i,d)).length > 0 ; d++)
    ;
  return locs;
}

// access for error locations
function getErrorLocations (i, depth) {
  var errorFc = tyError.flowClassesMulti[i];
  var errorFcPreds = tyError.flowClasses[errorFc].preds;
  if (depth >= 0 && depth < errorFcPreds.length) {
    var depthFcs = errorFcPreds[depth];
    return map (getLocations, depthFcs);
  }
  return [];
}

function getErrorIntros (i) {
  return getIntros (tyError.flowClassesMulti[i]);
}

function getErrorElims (i) {
  return getElims (tyError.flowClassesMulti[i]);
}

// UI stuff
var selected_te = -1;
var radioButton_selected = -1;
//when we select radio button in popup window 
//this function will be initiated first

function select_te (doc, i) {
  
  var el; 
  var locs;
  if (selected_te >= 0) { 
    lowlightErrorLocations(selected_te);            
    el = doc.getElementById ("te"+selected_te);   
    if (el)
      el.checked = false;
  }
  selected_te = i;
  setValue (doc,'current', i);
  el = doc.getElementById ("te"+selected_te); // Der Radiobutton zu dem aktuellen Typfehler.
  if (el) {
    el.checked = true;
    radioButton_selected = 0;
    highlightNestedErrorLocations (selected_te);
    highlightErrorLocations (selected_te);
    highlightErrorElims (selected_te);
    highlightErrorIntros (selected_te);
    navWindow_display();
    radioButton_selected = -1; 
  }
  return 0;
}

function lowlightErrorLocations (i) {
  if (i<0) return;
  forallNested (lowlightPhrase(7), getNestedErrorLocations (i));
  // here -- getNestedErrorLocations (i)== locs[]
  forallNested (lowlightPhrase(7), getErrorElims(i));
  forallNested (lowlightPhrase(7), getErrorIntros(i));
}

// highlight locations according to class cls
function highlightLocations (cls, locs) {
  forallNested (highlightPhrase(7) (cls), locs);
}

function final_Locations(totalLocs){
  var sortedLocs = new Array();
  sortedLocs = totalLocs.sort(compareNumbers);
  sortedLocs = removeDuplicates(sortedLocs);
  sortedLocs = skip_samelineIds(sortedLocs);
  return sortedLocs;
}

function compareNumbers(a, b){return a - b}

function removeDuplicates(with_dups){// to remove duplicates in a sorted array
  var temp=new Array();
  for(i=0;i<with_dups.length;i++){
    if(with_dups[i]==with_dups[i+1]) {continue}
    temp[temp.length]=with_dups[i];
  }
  return temp;
}

function skip_samelineIds(errorLocs){
  var temp = 0;
  var count =0;
  var diffLineIds = new Array();
  for (var i=0; i<errorLocs.length; i++){
    var id = "c"+errorLocs[i]; 
    var node  = document.getElementById(id); //alert("node_id  "+id);
    if (node) {
      var id_lineValue = node.offsetTop; //alert(" node.offsetTop "+node.offsetTop);
    
      if (temp != id_lineValue){
	diffLineIds[count++] = errorLocs[i];
	temp = id_lineValue;
      }
    }
  }
  return diffLineIds;
}

function scrollView(node_id){ // to scroll the view to a given node in the document
  var node  = document.getElementById(node_id);
  window.scrollTo(node.offsetLeft,node.offsetTop-200);
  // alert("node.offsetLeft="+node.offsetLeft+" node.offsetTop "+node.offsetTop);
}

var total_errorLocs = new Array();
var errorCount = -1;
var final_errorLocs = new Array();
function highlightErrorLocations (i) {
  if (i<0) return;
  var locs = getErrorLocations (i, 0);
  total_errorLocs = new Array();
  error_locationsWithIds(locs); 
  final_errorLocs = new Array();
  final_errorLocs = final_Locations(total_errorLocs);
  if( radioButton_selected != 0){
    firstErrorLocation();
  } 
  errorCount = -1;
  highlightLocations ('flow', locs);
}
function error_locationsWithIds(locs){ 
  switch (typeof locs) {
 case "number":
    errorCount = errorCount +1 ;
    var errorLocs = new Array();
    errorLocs[errorCount] = locs; 
    total_errorLocs[errorCount] = errorLocs[errorCount]; 
    //alert("count= "+errorCount +" errorLocs "+ errorLocs[errorCount]+ " locs= "+ locs);
    break;
  case "object": 
    for (var i=0; i<locs.length; i++){          
      error_locationsWithIds(locs[i]); 
    }
    break;
  default:
    break;   
  }
}

var error_array_elNum =0;
function firstErrorLocation(){
  var errorLocs = final_errorLocs;
  if(errorLocs.length){
    error_array_elNum =0;
    scrollView("c"+errorLocs[0]);
  }
}
function prevErrorLocation(){
   var errorLocs = final_errorLocs;
  if(errorLocs.length){
    error_array_elNum = error_array_elNum - 1; 
    if(error_array_elNum+1 == 0){
      error_array_elNum = errorLocs.length-1;  
    }
    scrollView("c"+errorLocs[error_array_elNum]);
  }
}
function nextErrorLocation(){
   var errorLocs = final_errorLocs;
  if(errorLocs.length){
    error_array_elNum = error_array_elNum + 1; 
    if(error_array_elNum+1 > errorLocs.length ){
      error_array_elNum = 0;  
    }
    scrollView("c"+errorLocs[error_array_elNum]);
  }
}
function lastErrorLocation(){
   var errorLocs = final_errorLocs;
  if(errorLocs.length){
    var len = errorLocs.length; 
    scrollView("c"+errorLocs[len-1]);
  }
}

var total_nestedLocs = new Array();
var nestedCount = -1;
var final_nestedLocs = new Array();
function highlightNestedErrorLocations (i) {  
  if (i<0) return; 
  var locs = getNestedErrorLocations (i);
  total_nestedLocs = new Array();
  nested_locationsWithIds(locs); 
  final_nestedLocs = new Array();
  final_nestedLocs = final_Locations(total_nestedLocs);
  if( radioButton_selected != 0){
    firstNestedLocation();
  }
  nestedCount = -1; 
  highlightLocations ('nested', locs);
}
function nested_locationsWithIds(locs){
  switch (typeof locs) {
  case "number":
    nestedCount = nestedCount +1 ;
    var nestedLocs = new Array();
    nestedLocs[nestedCount] = locs;
    total_nestedLocs[nestedCount] = nestedLocs[nestedCount]; 
    //alert("count "+ nestedCount+" nestedLocs "+ nestedLocs[nestedCount]+ " locs "+ locs);
    break;
  case "object":
    for (var i=0; i<locs.length; i++){   	      		       
      nested_locationsWithIds(locs[i]);       
    }
    break;
  default:
    break;   
  }
}
var nested_array_elNum = 0;
function firstNestedLocation(){
  var nestedLocs = final_nestedLocs;
  
  if(nestedLocs.length){
    nested_array_elNum = 0;
    scrollView("c"+nestedLocs[0]);
  }
}
function prevNestedLocation(){
  var nestedLocs = final_nestedLocs;
  if(nestedLocs.length){
    nested_array_elNum = nested_array_elNum - 1; 
    if(nested_array_elNum+1 == 0){
      nested_array_elNum = nestedLocs.length-1;  
    }
    scrollView("c"+nestedLocs[nested_array_elNum]);
  }
}
function nextNestedLocation(){
  var nestedLocs = final_nestedLocs;
  if(nestedLocs.length){
    nested_array_elNum = nested_array_elNum + 1; 
    if(nested_array_elNum+1 > nestedLocs.length ){
      nested_array_elNum = 0;
    }
    scrollView("c"+nestedLocs[nested_array_elNum]);
  }
}
function lastNestedLocation(){
  var nestedLocs = final_nestedLocs;
  if(nestedLocs.length){
    var len = nestedLocs.length; 
    scrollView("c"+nestedLocs[len-1]);
  }
}

var total_introsLocs = new Array();
var introsCount = -1;
var final_introsLocs = new Array();
function highlightErrorIntros (i) {
  if (i<0) return;
  var locs = getErrorIntros (i); 
  total_introsLocs = new Array();
  intros_locationsWithIds(locs);
  final_introsLocs = new Array();
  final_introsLocs = final_Locations(total_introsLocs);
  if( radioButton_selected != 0){
    firstElementLocation();
  }
  introsCount = -1;
  highlightLocations ('intro', locs);
}
function intros_locationsWithIds(locs){
  switch (typeof locs) {
   case "number":
     introsCount = introsCount +1 ;
     var introsLocs = new Array();
     introsLocs[introsCount] = locs;
     total_introsLocs[introsCount] = introsLocs[introsCount];
     //alert("count "+ introsCount+" introLocs "+ introsLocs[introsCount]+ " locs "+ locs);
     break;
  case "object":
    for (var i=0; i<locs.length; i++){
      intros_locationsWithIds(locs[i]);
    }
    break;
  default:
    break;
  }
}
var intro_array_elNum = 0;
function firstElementLocation(){
    var introsLocs = final_introsLocs;
  if(introsLocs.length){
    intro_array_elNum = 0;
    scrollView("c"+introsLocs[0]);
  }
}
function prevElementLocation(){
   var introsLocs = final_introsLocs;
  if(introsLocs.length){
    intro_array_elNum = intro_array_elNum - 1;
    if(intro_array_elNum+1 == 0){
      intro_array_elNum = introsLocs.length-1;
    }
    scrollView("c"+introsLocs[intro_array_elNum]);
  }
}
function nextElementLocation(){
   var introsLocs = final_introsLocs;
  if(introsLocs.length){
    intro_array_elNum = intro_array_elNum + 1;
    if(intro_array_elNum+1 > introsLocs.length ){
      intro_array_elNum = 0;
    }
    scrollView("c"+introsLocs[intro_array_elNum]);
  }
}
function lastElementLocation(){
   var introsLocs = final_introsLocs;
  if(introsLocs.length){
    var len = introsLocs.length;
    scrollView("c"+introsLocs[len-1]);
  }
}

var total_elimsLocs = new Array();
var elimsCount = -1;
var final_elimsLocs = new Array();
function highlightErrorElims (i) {
  if (i<0) return;
  var locs = getErrorElims (i);
  total_elimsLocs = new Array();
  elims_locationsWithIds(locs);
  final_elimsLocs = new Array();
  final_elimsLocs = final_Locations(total_elimsLocs);
  if( radioButton_selected != 0){
    firstElimsLocation();
  }
  elimsCount = -1;
  highlightLocations ('elim', locs);
}
function elims_locationsWithIds(locs){ 
  switch (typeof locs) {
  case "number":
    elimsCount = elimsCount +1 ;
    var elimsLocs = new Array();
    elimsLocs[elimsCount] = locs;
    total_elimsLocs[elimsCount] = elimsLocs[elimsCount];
    //alert("count= "+elimsCount +" elimLocs "+ elimsLocs[elimsCount]+ " locs= "+ locs);
    break;
  case "object":
    for (var i=0; i<locs.length; i++){
      elims_locationsWithIds(locs[i]); 
    }
    break;
  default:
    break;
  }
}
var elim_array_elNum = 0;
function firstElimsLocation(){
  var elimsLocs = final_elimsLocs;
  if(elimsLocs.length){
    elim_array_elNum = 0;
    scrollView("c"+elimsLocs[0]);
  }
}
function prevElimsLocation(){
  var elimsLocs = final_elimsLocs;
  if(elimsLocs.length){
    elim_array_elNum = elim_array_elNum - 1;
    if(elim_array_elNum+1 == 0){
      elim_array_elNum = elimsLocs.length-1;
    }
    scrollView("c"+elimsLocs[elim_array_elNum]);
  }
}
function nextElimsLocation(){
  var elimsLocs = final_elimsLocs;
  if(elimsLocs.length){
    elim_array_elNum = elim_array_elNum + 1;
    if(elim_array_elNum+1 > elimsLocs.length ){
      elim_array_elNum = 0;
    }
    scrollView("c"+elimsLocs[elim_array_elNum]);
  }
}
function lastElimsLocation(){
  var elimsLocs = final_elimsLocs;
  if(elimsLocs.length){
    scrollView("c"+elimsLocs[elimsLocs.length-1]);
  }
}



function output (out, template) {
  switch (typeof template) {
  case "string":
    out.write (template);
    break;
  case "object":
    for (var i = 0; i<template.length; i++)
      output (out, template[i]);
    break;
  default:
    out.write (template);
  }
}

// constructs the selection dom-tree of the navigator window
function createSelector(navigatorWindow) {
  var table = document.createElement('table');
  for (var i = 0; i < tyError.flowClassesMulti.length; i++) {
    var flowClass = tyError.flowClassesMulti[i];
    var row = document.createElement('tr');
    row.appendChild(createSelectorRadioCell(navigatorWindow.document, i));
    var nametd = document.createElement('td');
    var hyperlink = document.createElement('a');
    hyperlink.setAttribute("href", "javascript:void 0;");
    hyperlink.onclick = createSelectorFunction(navigatorWindow.document, i);
    hyperlink.appendChild(document.createTextNode(createErrorType(flowClass)));
    hyperlink.appendChild(document.createElement('br'));
    hyperlink.appendChild(createTypeList(tyError.flowClassesMulti[i]));
    hyperlink.appendChild(document.createElement('br'));
    hyperlink.appendChild(document.createTextNode("kind: "+tyError.flowClasses[flowClass].kindStr));
    nametd.appendChild(hyperlink);
    row.appendChild(nametd);
    table.appendChild(row);
  }
  if (table.hasChildNodes()) {
    navigatorWindow.document.getElementById('selectorwindow').appendChild(table);
  } else {
    var noerrors = document.createTextNode("No Type Errors in this document.");
    navigatorWindow.document.getElementById('selectorwindow').appendChild(noerrors);
  }
  var lowestPoint = navigatorWindow.document.getElementById('lowest_point');
  var new_y_size = Math.max((absTop(lowestPoint) + 30), ERROR_NAVIGATOR_MIN_HEIGHT);
  lowestPoint = navigatorWindow.document.getElementById('right_point');
  var new_x_size = absLeft(lowestPoint) + 50;
  navigatorWindow.resizeTo(new_x_size, new_y_size);
}

function createSelectorFunction(doc, index) {
  return function() { select_te(doc, index); };
}

function createSelectorRadioCell(doc, i) {
  var radio = document.createElement('input');
  radio.setAttribute("id", "te"+i);
  radio.setAttribute("type", "radio");
  radio.setAttribute("name", "te"+i);
  radio.setAttribute("value", "te"+i);
  radio.onclick = createSelectorFunction(doc, i);
  var cell = document.createElement('td');
  cell.setAttribute("valign", "top");
  cell.appendChild(radio);
  return cell;
}

function createErrorType(flowClassMulti) {
  var sep = "";
  var retString = "";
  if (tyError.flowClasses[flowClassMulti].recHead) {
    sep = "/";
    retString = "recursive type";
  }
  if (tyError.flowClasses[flowClassMulti].typeList.length > 1)
    retString = retString + sep + "type clash";
  return retString;
}
      
function createTypeList(flowClassMulti) {
  var mainSpan = document.createElement('span');
  var typeList = tyError.flowClasses[flowClassMulti].typeList;
  for (var i = 0; i < typeList.length; i++) {
    var codeNode = document.createElement('code');
    codeNode.appendChild(createTypeTerm(typeList[i].cons));
    mainSpan.appendChild(codeNode);
    if (typeList[i].pos.length) {
      var prodSpan = document.createElement('span');
      prodSpan.className = "intro";
      prodSpan.appendChild(document.createTextNode("produced"));
      mainSpan.appendChild(document.createTextNode(" "));
      mainSpan.appendChild(prodSpan);
    }
    if (typeList[i].neg.length) {
      var elimSpan = document.createElement('span');
      elimSpan.className = "elim";
      elimSpan.appendChild(document.createTextNode("consumed"));
      mainSpan.appendChild(document.createTextNode(" "));
      mainSpan.appendChild(elimSpan);
    }
    mainSpan.appendChild(document.createTextNode(" | "));
  }
  mainSpan.removeChild(mainSpan.lastChild);
  return mainSpan; 
}


function createTypeTerm (ty) {
  switch (ty[0]) {
  case "TCon":
    return document.createTextNode(ty[1]);
  case "TAp":
    return document.createTextNode(ty[1]+"@"+ ty[2]);
  }
}

function fcChildren (fc) {
  return getChildren (fcNodeInfo) (fc);
}

function fcNodeInfo (fc) {
  return tyError.flowClasses[fc].typeList;
}

function fcNodeKind (fc) {
  return tyError.flowClasses[fc].kind;
}

function fcNodeHasKindStar (fc) {
  return tyError.flowClasses[fc].kindStr == "*";
}

function flowClassToTable (sharedStyle, fc) {
  return typeGraphToTable (fcChildren, fcNodeInfo, document, sharedStyle, fc);
}

// fc is a flowclass
function flowClassToTextNodes (sharedStyle, fc) {
  return typeGraphToTextNodes (fcChildren, fcNodeInfo, document, sharedStyle, fc);
}

// !!! construction
function flowClassToHtml (fc) {
  return typeGraphToHtml (fcChildren, fcNodeInfo, document, fc);
}

// returns a single ul-node
function typeGraphToHtml (getChildren, getInfo, dom, fc) {
  var loop_header = cycle_detection (getChildren, fc);
  var visited = {};
  var subnodes = typeGraphToElementNodes (getInfo, dom, visited, loop_header, fc);
  return wrapAsDivOfDiv (dom, subnodes);
}

function wrapAsDivOfDiv (dom, subnodes) {
  var ul = dom.createElement('div');
  for (var i=0; i<subnodes.length; i++)
    ul.appendChild (dom.createElement('div')).appendChild(subnodes[i]);
  return ul;
}  

// inactive: uses too much screen space
function wrapAsUl (dom, subnodes) {
  var ul = dom.createElement('ul');
  for (var i=0; i<subnodes.length; i++)
    ul.appendChild (dom.createElement('li')).appendChild(subnodes[i]);
  return ul;
}

// inactive: too much space; destroys whitespace rendering
function wrapAsTable (dom, subnodes) {
  var table = dom.createElement('table');
  for (var i=0; i<subnodes.length; i++) {
    var tr = dom.createElement('tr');
    tr.appendChild (dom.createElement('td')).appendChild(subnodes[i]);
    table.appendChild(tr);
  }
  return table;
}

// typeNodeHighlighter must be applied to an HTMLElement node and a flowclass
// the node supposedly represents a type; it is highlighted when the pointer
// is moved over it. In addition, all locations belonging to the flowclass are
// also highlighted.
function typeNodeHighlighter (node, myfc, pos) {
  // pos is the position in the flowclass's type list
  // compute locations lazily
  var locs;
  var highlightClass;
  var introLocs;
  var elimLocs;
  var init =
    function () {
      locs = getLocations (myfc);
      highlightClass = fcNodeHasKindStar(myfc) ? "typenode" : "consnode";
      if (pos == undefined) {
	introLocs = [];
	elimLocs = [];
      } else {
	var ty = tyError.flowClasses[myfc].typeList[pos];
	introLocs = getIntrosLabTyTerm (ty);
	elimLocs  = getElimsLabTyTerm (ty);
	locs = [locs, introLocs, elimLocs];
      }
      init = function () { return };
    };

  node.onmouseover =
    function (ev) {
      init();
      node.className = highlightClass;
      forallNested (highlightPhrase(3) (highlightClass), locs);
      forallNested (highlightPhrase(3) ('intro'), introLocs);
      forallNested (highlightPhrase(3) ('elim'), elimLocs);
      ev.stopPropagation();
    };
  node.onmouseout =
    function (ev) {
      init();
      node.className = "";
      forallNested (lowlightPhrase(3), locs);
      ev.stopPropagation();
    };
}
    
// returns a list of element nodes representing flowclass fc
function typeGraphToElementNodes (getInfo, dom, visited, loop_header, fc) {
  function spineToElementNodes (fc) {
    return function (spine) {
      // alert ("spineToElementNodes (["+spine+"])");
      var span = dom.createElement('span');
      var decoration = [];
      
      // transform the spine's head
      var result = "";
      var head = spine[0];
      var headPos = head.pos;
      switch (head.type) {
      case "number":
	result += "#" + head;
	break;
      case "string":
	result += head;
	break;
      default :
	return "Illegal spine starting with "+spine[0];
      }

      //some fully applied constructors have special printing formats
      if (spine.length == 1) {
	decoration = [result];
      } else if (head == "[]" && spine.length == 2) {
	decoration = ["[", "]"];
      } else if (head == "(->)" && spine.length == 3) {
	decoration = ["(", " -> ", ")"];
      } else if (head.match(/^\(,*\)$/) && spine.length == head.length) {
	decoration = head.match(/./g);
      } else {
	decoration[0] = "("+result+" ";
	for (var i=1; i<spine.length; i++)
	  decoration[i] = " ";
	decoration[spine.length-1].replace (/.$/, ")");
      }
      // alert ("decoration is "+decoration);
      // must eta-expand, otherwise crash
      decoration = map (function (node) { return dom.createTextNode (node) }, decoration);
      span.appendChild (decoration[0]);
      span.className = "fc"+fc+"-"+headPos;

      // transform the spine's tail
      var allspans = [span];
      for (var i=1; i<spine.length; i++) {
	var subNodes = nodeToElementNodes (spine[i]);
	var newspans =
	  map (
	       function (span) {
		 return (
		    map (
			 function (sub) {
			   var myspan = span.cloneNode(true);
			   myspan.appendChild(sub.cloneNode(true));
			   myspan.appendChild(decoration[i].cloneNode(true));
			   return myspan;
			 },
			 subNodes));
	       },
	       allspans);
	allspans = flatten(newspans);
      }
      return allspans;
    }
  }

  function nodeToElementNodes (fc) {
    if (loop_header[fc]) {
      if (visited[fc])
	return [dom.createTextNode ("#"+fc)];
      else
	visited[fc] = true;
    }
    var spines = fcSpines (getInfo, loop_header, fc);
    var result = flatten (map (spineToElementNodes (fc), spines));
    delete visited[fc];
    return result;
  }

    function fixupSpansNode (node) {
      if (node.nodeName == "SPAN"
	  && node.className
	  && node.className.match ("^fc")) {
	var fcAndPos = node.className.match (/[0-9]+/g);
	typeNodeHighlighter (node, fcAndPos[0], fcAndPos[1]);
      }
      // for all nodes:
      fixupSpansNodeList (node.childNodes);
    }

    function fixupSpansNodeList (nodeList) {
      for (var i=0; i<nodeList.length; i++)
	fixupSpansNode (nodeList[i]);
    }

    // alert ("typeGraphToElementNodes ("+fc+")");
    var r = nodeToElementNodes (fc);
  fixupSpansNodeList (r);
  return r;
}

// returns an array of all spines
// all multivocal nodes are expanded
// a spine is an array where the first entry is either an fc or the
// name of a constructor, all remaining entries are fcs
function fcSpines (getInfo, loop_header, fc) {

  function typeSpines (fc) {
    return function (ty, pos) {
      // pos is the position in the type list of the type variable
      // returns an array of spines for ty
      var result = "";
      var v = ty.cons;
      switch (v[0]) {
      case "TAp":
	var spines = nodeSpines (v[1]);
	return map (function (spine) {
     	              var result = new Number (v[2]);
		      result.type = "number";
		      result.fc = fc;
		      result.pos = pos;
     	              spine[spine.length] = result;
		      return spine;},
		    spines);
      case "TCon":
	if (loop_header[fc])
	  result += "#"+fc+"=";
	result += v[1];
	result = new String (result);
	result.type = "string";
	result.fc = fc;
	result.pos = pos;
	return [[result]];
      default:
	return "{{{found type tag "+v[0]+"}}}";
      }
    }
  }
    
  function nodeSpines (fc) {
    var typeList = getInfo (fc);
    if (typeList.length == 0) {
      var result = new Number (fc);
      result.type = "number";
      result.fc = fc;
      // result.pos left undefined;
      return [[result]];
    } else {
      return flatten (map (typeSpines (fc), typeList));
    }
  }

  return nodeSpines (fc);
}


function typeGraphToTextNodes (getChildren, getInfo, dom, sharedStyle, start) {
  function render (node, pos, ty) {
    var result;
    var v = ty.cons;
    switch (v[0]) {
    case "TAp":
      result = dom.createElement('span');
      result.appendChild(dom.createTextNode("("));
      result.appendChild(visit(v[1]));
      result.appendChild(dom.createTextNode(" "));
      result.appendChild(visit(v[2]));
      result.appendChild(dom.createTextNode(")"));
      typeNodeHighlighter (result, node, pos);
      return result;
    case "TCon":
      result = dom.createElement('span');
      result.appendChild(dom.createTextNode(v[1]));
      typeNodeHighlighter (result, node, pos);
      return result;
    default:
      return dom.createTextNode("{{{found type tag "+v[0]+"}}}");
    }
  }
    
  function renderList (node, typeList) {
    var result = dom.createElement('span');
    if (typeList.length > 1)
      result.appendChild(dom.createTextNode("< "));
    result.appendChild(render (node, 0, typeList[0]));
    for (var i=1; i<typeList.length; i++) {
      result.appendChild(dom.createTextNode(" | "));
      result.appendChild(render (node, i, typeList[i]));
    }
    if (typeList.length > 1)
      result.appendChild(dom.createTextNode(" >"));
    return result;
  }

  function visitShared (node) {
    var typeList = getInfo(node);
    var result = dom.createElement('span');
    typeNodeHighlighter (result, node);
    if (dfInfo.visited[node]>1 || typeList.length == 0)
      // dfInfo.dfn[node] gives nicer numbers, which are not comparable
      result.appendChild(dom.createTextNode("#" + node));
    if (visited[node] || typeList.length == 0)
      return result;
    else {
      visited[node]=true;
      if (result.hasChildNodes())
	result.appendChild(dom.createTextNode("="));
    }
    result.appendChild(renderList (node, typeList));
    return result;
  }

  function visitUnshared (node) {
    var typeList = getInfo(node);
    var result = dom.createElement('span');
    typeNodeHighlighter (result, node);
    if (loop_header[node] || typeList.length == 0)
      result.appendChild(dom.createTextNode("#" + node));
    if (visited[node] || typeList.length == 0)
      return result;
    else {
      visited[node]=true;
      if (loop_header[node])
	result.appendChild(dom.createTextNode("="));
    }
    result.appendChild(renderList (node, typeList));
    delete visited[node];
    return result;
  }

  var dfInfo = dft (getChildren, start);
  var loop_header = cycle_detection (getChildren, start);
  var visited = {};
  
  var visit = sharedStyle ? visitShared : visitUnshared;

  return visit (start);
}

//
function typeGraphToTable (getChildren, getInfo, dom, sharedStyle, start) {

  function visitTy (fc, ty, pos) {
    var result, table, tr, td, at;
    result = dom.createElement('span');
    at = dom.createAttribute('id');
    at.nodeValue = "draw" + nr;
    result.setAttributeNode (at);
    typeNodeHighlighter (result, fc, pos);

    var mynr = nr;
    var v = ty.cons;
    switch (v[0]) {
    case "TCon":
      var con = v[1];
      if (con=="(->)")
	con = "->";
      else if (con=="[]")
	con = "[ ]";
	
      result.appendChild(dom.createTextNode(con));
      return result;
    case "TAp":
      table = dom.createElement('table');
      tr = dom.createElement('tr');
      td = dom.createElement('td');
      tr.appendChild(td);
      td = dom.createElement('td');
      at = dom.createAttribute('style');
      at.nodeValue = "padding-bottom: 10px; font-size: 30%;";
      td.setAttributeNode (at);
      result.appendChild(dom.createTextNode('@'));
      td.appendChild(result);
      tr.appendChild(td);
      td = dom.createElement('td');
      tr.appendChild(td);
      table.appendChild(tr);

      tr = dom.createElement('tr');
      td = dom.createElement('td');
      at = dom.createAttribute('valign');
      at.nodeValue = "top";
      td.setAttributeNode (at);
      at = dom.createAttribute('style');
      at.nodeValue = "white-space:nowrap;";
      td.setAttributeNode (at);
      edge (mynr, nr+1);
      td.appendChild(visit(v[1]));
      tr.appendChild(td);
      td = dom.createElement('td');
      tr.appendChild(td);
      td = dom.createElement('td');
      at = dom.createAttribute('valign');
      at.nodeValue = "top";
      td.setAttributeNode (at);
      at = dom.createAttribute('style');
      at.nodeValue = "white-space:nowrap;";
      td.setAttributeNode (at);
      edge (mynr, nr+1);
      td.appendChild(visit(v[2]));
      tr.appendChild(td);
      table.appendChild(tr);
      return table;
    }
  }

  function visit (fc) {
    var result, table, tr, td, at;
    var typeList = getInfo (fc);
    nr++;
    if (visited[fc] || typeList.length==0) {
      result = dom.createElement('span');
      at = dom.createAttribute('id');
      at.nodeValue = "draw" + nr;
      result.setAttributeNode (at);
      result.appendChild(dom.createTextNode("#"+fc));
      if (visited[fc]) edge (nr, visited[fc]);
      typeNodeHighlighter (result, fc);
      return result;
    }
    visited[fc] = nr;
    if (typeList.length==1) {
      result = visitTy (fc, typeList[0], 0)
    } else {
      table = dom.createElement('table');
      tr = dom.createElement('tr');
      td = dom.createElement('td');
      at = dom.createAttribute('colspan');
      at.nodeValue = "" + typeList.length;
      td.setAttributeNode (at);
      at = dom.createAttribute('align');
      at.nodeValue = "center";
      td.setAttributeNode (at);
      at = dom.createAttribute('style');
      at.nodeValue = "padding-bottom: 10px;";
      td.setAttributeNode (at);
      result = dom.createElement('span');
      at = dom.createAttribute('id');
      at.nodeValue = "draw" + nr;
      result.setAttributeNode(at);
      result.appendChild(dom.createTextNode('||#'+fc+'#||'));
      typeNodeHighlighter (result, fc);
      td.appendChild(result);
      tr.appendChild(td);
      table.appendChild(tr);

      tr = dom.createElement ('tr');
      for (var i=0; i<typeList.length; i++) {
	td = dom.createElement('td');
	at = dom.createAttribute('valign');
	at.nodeValue = "top";
	td.setAttributeNode (at);
	nr++;
	edge (visited[fc], nr);
	td.appendChild(visitTy(fc, typeList[i], i));
	tr.appendChild(td);
      }
      table.appendChild(tr);
      result = table;
    }
    delete visited[fc];
    return result;
  }

    function edge (from, to) {
      E[E.length] = [from, to];
    }

  var nr = 0;
  var visited = {};
  var E = [];
  var loop_header = cycle_detection (getChildren, start);
  
  return { htmlNode: visit (start),
		       edges: E
		       };
}

function getChildren (getInfo) {
  return function (n) {
    
    function succ (ty) {
      var v = ty.cons;
      switch (v[0]) {
      case "TAp":
	return [v[1], v[2]];
      default:
	return [];
      }
    }
      
    return flatten (map (succ, getInfo(n)));
  }
}

// depth-first traversal
// returns object with properties
// visited: object that maps node to #times visited
// dfList: array of visited nodes in depth-first ordering
// dfn: object that maps node to its df number
function dft (succ, start) {
  var current, successors;
  var dfn = {};
  var dfList = new Array();
  var stack = [start];
  var sp = 1;
  var visited = {};
  while (sp > 0) {
    current = stack[--sp];
    if (visited[current]++)
      continue;
    visited[current] = 1;
    dfn[current] = dfList.length;
    dfList[dfList.length] = current;
    successors = succ(current);
    for (var i in successors) {
      stack[sp++] = successors[i];
    }
  }
  return {visited: visited, dfList: dfList, dfn: dfn};
}

// cycle detection
// returns array of loop headers
function cycle_detection (succ, start) {

  function visit (node) {
    if (visiting[node]) {
      loop_header[log[visiting[node]-1]] = true;
    } else {
      log[top++] = node;
      visiting[node] = top;
      var successors = succ (node);
      for (var i in successors)
	visit (successors[i]);
      visiting[node] = 0;
      top--;
    }
  }

  var loop_header = {};
  var visiting = {};
  var log = [];
  var top = 0;
  visit (start);
  return loop_header;
}

// popups

function typop(el) { 
  // maybe we are nested?
  var elementId = el.id.substr(1);
  while (!document.getElementById('l'+elementId)) {
    el = getParentNode(el.parentNode);
    elementId = el.id.substr(1);
  }
  currentHLNode = el;
}

var typeGraphDisplayStyle = 'shared';
function setTypeGraphDisplayStyle(style) {
  typeGraphDisplayStyle = style;
  pop_gen();
}


function pop_gen() {
  var message;
  var nodes;
  var result;
  var edges = null;  
  var ustr = currentHLNode.id; 

  if (ustr) {
    var labs = getLabels(currentHLNode); 
    if (labs) {  
      // XXX test labs!
      var fc = tyError.mappingTypes[labs[0]][1];
      switch (typeGraphDisplayStyle) {
      case "gshared":
	result = flowClassToTable(false, fc);
	nodes = [result.htmlNode];
	edges = result.edges;
	break;
      case "listed":
	nodes = [flowClassToHtml(fc)];
	break;
      case "unshared":
	nodes = [flowClassToTextNodes(false, fc)];
	break;
      case "shared":
      default:
	// obsolete: message = tyError.flowClasses[fc].typeStr;
	nodes = [flowClassToTextNodes(true, fc)];
	break;
      }
      popupContents(nodes);
    } else {
      popupString("No label for this node");
    }
    // resizing the window to fit the whole graphic
    resizeAppropriately();
    popupDraw(edges);
    tempHighlight(descendants (currentHLNode));	
    arrowUpdate();
  }
}

function popupString(str) {
  // the following does not seem to be necessary
  // .replace (/&/g, "&amp;").replace (/</g, "&lt;").replace (/>/g, "&gt;");
  var myMessage = document.createTextNode(str);
  popupContents ([myMessage]);
}

function popupContents (nodes) {

  var tyWin = typePopup(TYPE_WINDOW);
  var doc = tyWin.document;
  var parent = doc.getElementById("TypeWindowTemporary");
  restoreHighlighted();
  if (parent != null) {
    while(parent.firstChild)
      parent.removeChild (parent.firstChild);
  }
  var parent = doc.getElementById("TypeWindowMessage");
  if (parent != null) {
    while(parent.firstChild)
      parent.removeChild (parent.firstChild);
    for (var i=0; i<nodes.length; i++)
      parent.appendChild (nodes[i]);
  }
}


var popupDraw_Timeout = 0;

function popupDraw (edges) {

  function drawEdge (i) {
    return function () {
      // check termination
      if (tyWin.closed
	  || i >= edges.length)
	return;
      // TODO: display progress

      var edge = edges[i];
      var from = edge[0];
      var to   = edge[1];
      var fromNode = doc.getElementById("draw"+from);
      var toNode = doc.getElementById("draw"+to);
      if (fromNode && toNode) {
	var fromX = absLeft(fromNode) + fromNode.offsetWidth/2;
	var fromY = absTop(fromNode)  + fromNode.offsetHeight;
	if (from < to) {
	  // forward edge
	  var toX = absLeft(toNode) + toNode.offsetWidth/2;
	  var toY = absTop(toNode);
	  ctx.draw(fromX, fromY, toX, toY);
	} else {
	  // back edge or cross edge
	  // just a stub of an arrow
	  var toX = fromX + fromNode.offsetWidth/2;
	  var toY = fromY + fromNode.offsetHeight/2;
	  ctx.vline(fromY, toY, fromX);
	  ctx.hline(fromX, toX, toY);
	  ctx.arrowRight (toX, toY);
	}
      } else {
	alert ("popupDraw: fromNode= "+fromNode+", toNode= "+toNode);
      }

      // initiate next round of drawing
      popupDraw_Timeout = window.setTimeout(drawEdge(i+1), 5);
    }
  }

  if (popupDraw_Timeout)
    window.clearTimeout (popupDraw_Timeout);

  var tyWin = typePopup(TYPE_WINDOW);
  var doc = tyWin.document;
  var ctx = makeContext(doc);
  ctx.clearImage();
  if (!edges)
    return;
  // now we have edges to draw:
  drawEdge (0) ();
}

var restoreHighlighted = function () { return }
function tempHighlight(nodelist){ //highlights nodes which are selected in TypeWindow navigation
  var restore = new Array(nodelist.length);
  for (var i=0; i<nodelist.length; i++) {
    restore[i] = nodelist[i].className;
    if (show_bars) {
      nodelist[i].className = "typop " + restore[i];
    }
  }
  restoreHighlighted = function () { //to restore highlighted nodes by TypeWindow navigation
    for (var i=0; i<nodelist.length; i++) {
      if (show_bars) {
	nodelist[i].className = restore[i];
      }
    }
  }
}


function descendants (node) { //alert("node= "+node);
  var acc = [];
  descendants_acc (node, acc);
  return acc;
}

function descendants_acc (node, acc) {
  if (node.nodeType==1) {	// an element node
    acc[acc.length] = node;
    var children = node.childNodes;
    for (var i=0; i<children.length; i++)
      descendants_acc (children[i], acc);
  }
}


//Navigation functionality in the Type window

function currentNode(){ // Highlights the current node

  restoreHighlighted();
  var current_node = document.getElementById(currentHLNode.id);// alert(" Current Node "+ current_node.id);
  currentHLNode = current_node;  
  pop_gen();
  return true;
}

function getLabels(nodeX) {
  // check whether current node has labels
  var ustr = nodeX.id;
  if (ustr) {
    var ec = getEquivalenzClass (ustr.substr (1));
    for (var unique in equivalenceClasses[ec]) {
      var labs = tyError.mappingUniques[equivalenceClasses[ec][unique]];
      if (labs)
	return labs;
    }
  }
  return null;
}

function node_typeStr(nodeY) {
  // returns type string of current node( only if node has lables)
  
  var labs = getLabels(nodeY); 
  var fc = tyError.mappingTypes[labs[0]][1]; 
  var typeErr = tyError.flowClasses[fc].typeStr;
  
  return typeErr;
}              
	
var navWindow;

function navigatorPopup(url) {
  
  navWindow = window.open(url, tyError.moduleName, 'width=800, height=600, left=300, top=200, status=0, resizable=1, directories=0, toolbar=0, scrollbars=1, reload=1, hotkeys=0, dependent=1, alwaysRaised=1' );
  navWindow.focus();
  return false;  
}

var typeWindow = null;
function typePopup(url) {
  
  if (!typeWindow || typeWindow.closed) {
  
    typeWindow = window.open(url, "TypePopupWindow", 'width=800, height=600, left=300, top=200, status=0, resizable=1, directories=0, toolbar=0, scrollbars=1, reload=1, hotkeys=0, dependent=1, alwaysRaised=1' );

  }
  typeWindow.focus();
  return typeWindow;
}

function closeChildren(){
  close_typeWindow();
  close_navWindow();
}

function close_typeWindow() {
  if(typeWindow){
    typeWindow.close();
  }
  
}
function close_navWindow() {
  if(navWindow){
    navWindow.close();
  }
}

function navWindow_display() { 
  if (final_introsLocs.length){ 
    //navWindow.document.navigatorForm.prevIntros.disabled = true;
    navWindow.document.navigatorForm.prevIntros.style.visibility= 'hidden';
    navWindow.document.navigatorForm.producer.style.visibility = 'visible';
    //navWindow.document.navigatorForm.nextIntros.disabled = true;
    navWindow.document.navigatorForm.nextIntros.style.visibility= 'hidden';
  }
  else{
    navWindow.document.navigatorForm.prevIntros.style.visibility = 'hidden';
    navWindow.document.navigatorForm.producer.style.visibility = 'hidden';
    navWindow.document.navigatorForm.nextIntros.style.visibility = 'hidden';
  }
  if (final_elimsLocs.length){ 
    navWindow.document.navigatorForm.prevElims.style.visibility = 'hidden';
    navWindow.document.navigatorForm.nextElims.style.visibility = 'hidden';
    navWindow.document.navigatorForm.consumer.style.visibility = 'visible';
    
  }
  else{
    navWindow.document.navigatorForm.prevElims.style.visibility = 'hidden';
    navWindow.document.navigatorForm.consumer.style.visibility = 'hidden';
    navWindow.document.navigatorForm.nextElims.style.visibility = 'hidden';
  }
  
  if(final_errorLocs.length){ 
    navWindow.document.navigatorForm.prevError.style.visibility = 'hidden';
    navWindow.document.navigatorForm.nextError.style.visibility = 'hidden';
    navWindow.document.navigatorForm.errorBtn.style.visibility = 'visible';
    
  }
  else{
    navWindow.document.navigatorForm.prevError.style.visibility = 'hidden';
    navWindow.document.navigatorForm.errorBtn.style.visibility = 'hidden';
    navWindow.document.navigatorForm.nextError.style.visibility = 'hidden';
  }
  
  if(final_nestedLocs.length){ 
    navWindow.document.navigatorForm.prevNested.style.visibility = 'hidden';
    navWindow.document.navigatorForm.nextNested.style.visibility = 'hidden';
    navWindow.document.navigatorForm.nestedBtn.style.visibility = 'visible';
    
  }
  else{
    navWindow.document.navigatorForm.prevNested.style.visibility = 'hidden';
    navWindow.document.navigatorForm.nestedBtn.style.visibility = 'hidden';
    navWindow.document.navigatorForm.nextNested.style.visibility = 'hidden';
  }
}

function clearBtn_display(){  

    navWindow.document.navigatorForm.prevIntros.style.visibility ='visible';
    navWindow.document.navigatorForm.producer.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextIntros.style.visibility = 'visible';
 
    navWindow.document.navigatorForm.prevElims.style.visibility ='visible';
    navWindow.document.navigatorForm.consumer.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextElims.style.visibility = 'visible';

    navWindow.document.navigatorForm.prevError.style.visibility = 'visible';
    navWindow.document.navigatorForm.errorBtn.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextError.style.visibility = 'visible';

    navWindow.document.navigatorForm.prevNested.style.visibility = 'visible';
    navWindow.document.navigatorForm.nestedBtn.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextNested.style.visibility = 'visible';
}


function producerBtn_display() {  
  if (final_introsLocs.length == 1){ 
    navWindow.document.navigatorForm.prevIntros.style.visibility = 'hidden';
    navWindow.document.navigatorForm.producer.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextIntros.style.visibility = 'hidden';
  }
  else{
    navWindow.document.navigatorForm.prevIntros.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextIntros.style.visibility = 'visible';
  }
}

function consumerBtn_display() {  
  if (final_elimsLocs.length == 1){ 
    navWindow.document.navigatorForm.prevElims.style.visibility = 'hidden';
    navWindow.document.navigatorForm.consumer.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextElims.style.visibility = 'hidden';
  }
  else{
    navWindow.document.navigatorForm.prevElims.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextElims.style.visibility = 'visible';
  }
}

function errorBtn_display() { 
  if (final_errorLocs.length == 1){ 
    navWindow.document.navigatorForm.prevError.style.visibility = 'hidden';
    navWindow.document.navigatorForm.errorBtn.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextError.style.visibility = 'hidden';
  }
  else{
    navWindow.document.navigatorForm.prevError.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextError.style.visibility = 'visible';
  }
}

function nestedBtn_display() { 
  if (final_nestedLocs.length == 1){ 
    navWindow.document.navigatorForm.prevNested.style.visibility = 'hidden';
    navWindow.document.navigatorForm.nestedBtn.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextNested.style.visibility = 'hidden';
  }
  else{
    navWindow.document.navigatorForm.prevNested.style.visibility = 'visible';
    navWindow.document.navigatorForm.nextNested.style.visibility = 'visible';
  }
}

//////////////////////////////////////////////////////////////////////
// line drawing module
function signum(x) {
  return x > 0 ? 1 : x < 0 ? -1 : 0;
}

function isImage (node) {
  if (node==null) return false;
  return (node.nodeType == 1 && node.nodeName == "IMG");
}

function absLeft (node) {
  var left;
  for (left = node.offsetLeft; node = node.offsetParent; )
    left += node.offsetLeft;
  return left;
}

function absTop (node) {
  var left;
  for (left = node.offsetTop; node = node.offsetParent; )
    left += node.offsetTop;
  return left;
}

function makeContext (doc) {

  function draw (x0,y0, x9,y9) {
    var dx = x9-x0;
    var dy = y9-y0;
    var sx = signum(dx);
    var sy = signum(dy);
    var dx0 = dx = Math.abs(dx);
    var dy0 = dy = Math.abs(dy);
    plot (x0,y0);
    if (dx0 < dy0) {
      while (x0 != x9 && y0 != y9) {
	y0 += sy;
	dy -= dx;
	if (dy <= 0) {
	  x0 += sx;
	  dy = dy0;
	}
	plot (x0, y0);
      }
    } else if (dy0 < dx0) {
      while (x0 != x9 && y0 != y9) {
	x0 += sx;
	dx -= dy;
	if (dx <= 0) {
	  y0 += sy;
	  dx = dx0;
	}
	plot (x0, y0);
      }
    } else {
      while (dx--) {
	plot (x0 += sx, y0 += sy);
      }
    }
  }

  function plot (x,y) {
    putImage ("one-pixel.xbm", x, y, 1, 1);
  }

  function hline (x0, x9, y) {
    var deltax1 = x9-x0+1;
    putImage ("one-pixel.xbm", Math.min (x0,x9), y, deltax1, 1);
  }

  function vline (x0, x9, y) {
    var deltax1 = x9-x0+1;
    putImage ("one-pixel.xbm", y, Math.min(x0,x9), 1, deltax1);
  }

  function rectangle (x0,y0,w,h){
    hline(x0,x0+w,y0);
    hline(x0,x0+w,y0+h);
    vline(y0,y0+h,x0);
    vline(y0,y0+h,x0+w);
  }

  function diagMain (x0,y0){
    putImage("ll2ur.xbm",x0,y0,4,4);
  }

  function diagAux (x0,y0){
    putImage("ul2lr.xbm",x0,y0,4,4);
  }
  // arrow functions place tip at coordinate
  function arrowUp (x0,y0){
    diagMain(x0-3,y0);
    diagAux(x0,y0);
  }

  function arrowDown (x0, y0) {
    diagAux(x0-3,y0-3);
    diagMain(x0,y0-3);
  }

  function arrowLeft (x0,y0) {
    diagMain(x0,y0-3);
    diagAux(x0,y0);
  }

  function arrowRight (x0,y0) {
    diagAux(x0-3,y0-3);
    diagMain(x0-3,y0);
  }

  function putImage (name,x,y,w,h){
    var body = doc.getElementsByTagName("body")[0];
    var newImage = doc.createElement("img");
    newImage.setAttribute("height", h);
    newImage.setAttribute("width", w);
    newImage.setAttribute("src", PATH_TO_IMAGES + name);
    newImage.style.position = "absolute";
    newImage.style.top = y;
    newImage.style.left = x;
    body.appendChild (newImage);
  }

  function clearImage () {
    var body = doc.getElementsByTagName("body")[0];
    while (isImage(body.lastChild)) {
      body.removeChild (body.lastChild);
    }
  }
  // draw a rectangular frame around an element
  function makeFrame (el) {
    rectangle (el.offsetLeft, el.offsetTop, el.offsetWidth, el.offsetHeight);
  }

  // main program
  return (
  {
  arrowUp: arrowUp,
	     arrowDown: arrowDown,
	     arrowLeft: arrowLeft,
	     arrowRight: arrowRight,
	     clearImage: clearImage,
	     draw: draw,
	     vline: vline,
	     hline: hline
  }
  );
}

// Resizes the type window so that the message bar
// is shown completely
function resizeAppropriately() {
  var tyWin = typePopup(TYPE_WINDOW);
  var doc = tyWin.document;
  
  var lowestPoint = doc.getElementById('lowest_point');
  if (lowestPoint) {
    var new_x_size = Math.max((absLeft(lowestPoint) + 35), TYPE_BROWSER_MIN_WIDTH);
    var new_y_size = Math.max((absTop(lowestPoint) + 30), TYPE_BROWSER_MIN_HEIGHT);
    tyWin.resizeTo(new_x_size, new_y_size);
  }
}




/*

  Navigator Functions

*/


// Generating the proper output into the selection field






/*

   Type Browser Functions
    


*/

// Turning the bars on and off
function swapBars() {
  var tyWin = typePopup(TYPE_WINDOW);
  var doc = tyWin.document;
  var swapButton = doc.getElementById('swapArrow');
  if (show_bars) {
    restoreHighlighted();
    swapButton.setAttribute("src", PATH_TO_IMAGES+"button/center_with_barX.png");
    swapButton.setAttribute("alt", "Show Bars");
    show_bars = false;
  } else {
    show_bars = true;
    tempHighlight(descendants(currentHLNode));
    swapButton.setAttribute("src", PATH_TO_IMAGES+"button/center_with_x.png");
    swapButton.setAttribute("alt", "Hide Bars");
  }
}
    
// closing the type window
function closeTypeWindow() {
  show_bars = true;
  currentHLNode = null;
  restoreHighlighted();
  close_typeWindow();
}

// Setting the buttons properly

function arrowUpdate() {

  var tyWin = typePopup(TYPE_WINDOW);
  var doc = tyWin.document;
  var original_node = document.getElementById(currentHLNode.id);   
  var foundTarget = false;

  var parent = getParentNode(original_node.parentNode);
  if (parent) activateArrow(1, parent, doc);
  else deactivateArrow(doc.getElementById('topArrow'), 'top_empty.png');

  var leftSibling = getLeftSiblingNode(original_node.previousSibling);
  if (leftSibling) activateArrow(2, leftSibling, doc);
  else deactivateArrow(doc.getElementById('leftArrow'), 'left_empty.png');

  var rightSibling = getRightSiblingNode(original_node.nextSibling);
  if (rightSibling) activateArrow(3, rightSibling, doc);
  else deactivateArrow(doc.getElementById('rightArrow'), 'right_empty.png');

  var child = getChildNode(original_node.childNodes);
  if (child) activateArrow(4, child, doc);
  else deactivateArrow(doc.getElementById('bottomArrow'), 'bottom_empty.png');
}


function getParentNode(currentNode) {
  if (!currentNode) return null;
  if (currentNode.id && currentNode.id.substr(0,1) == "c") {
    // This can be the parent, but it still may be nested in another node - 
    // in the nested case the l resp. r tags have been removed. 
    var currentId = currentNode.id.substr(1);
    if (document.getElementById("l"+currentId)) return currentNode;
  }
  return getParentNode(currentNode.parentNode);
}

function getLeftSiblingNode(currentNode) {
  if (!currentNode) return null;
  if (currentNode.id && currentNode.id.substr(0,1) == "c") {
    return currentNode;
  }
  return getLeftSiblingNode(currentNode.previousSibling);
}

function getRightSiblingNode(currentNode) {
  if (!currentNode) return null;
  if (currentNode.id && currentNode.id.substr(0,1) == "c") {
    return currentNode;
  }
  return getRightSiblingNode(currentNode.nextSibling);
}

function getChildNode(currentNodes) {
  for (var index = 0; index < currentNodes.length; index ++) {
    if (currentNodes[index].id != null && currentNodes[index].id.substr(0,1) == "c") {
      // This can be the child, but it still may be nested in another node -
      // in the nested case the l resp. r tags have been removed.
      var currentId = currentNodes[index].id.substr(1);
      if (document.getElementById("l"+currentId)) return currentNodes[index];
    }
    var tempResult = getChildNode(currentNodes[index].childNodes);
    if (tempResult) return tempResult;
  }
  return null;
}


// turning the arrows of the type window on and off.

function activateArrow(index, newNode, doc) {
  var namesArray = new Array("", "top", "left", "right", "bottom");
  var arrow = doc.getElementById(namesArray[index]+"Arrow");
  arrow.setAttribute("src", PATH_TO_IMAGES+"button/"+namesArray[index]+"_arrow.png");
  arrow.setAttribute("class", "typeButton");
  arrow.setAttribute("tabindex", index);
  arrow.onclick = changeNodeFunction(newNode);
}
function deactivateArrow(node, emptyImage) {
  node.setAttribute("src", PATH_TO_IMAGES+"button/"+emptyImage);
  node.removeAttribute("class");
  node.removeAttribute("alt");
  node.removeAttribute("tabindex");
  node.removeAttribute("onclick");
}
function changeNodeFunction(newNode) {
  return function() {
    restoreHighlighted();
    currentHLNode = newNode;
    pop_gen(); 
  };
}
