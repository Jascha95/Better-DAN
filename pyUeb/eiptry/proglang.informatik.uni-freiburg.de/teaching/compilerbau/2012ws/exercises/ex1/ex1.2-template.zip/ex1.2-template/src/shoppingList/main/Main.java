package shoppingList.main;

/* Create an AST, then invoke our interpreter. */

import shoppingList.gen.lexer.Lexer;
import shoppingList.gen.node.Start;
import shoppingList.gen.parser.Parser;

public class Main {
    public static void main(String[] args) {
        if (args.length > 0) {
            /* Form AST */

            /* Get interpreter going */

        } else {
            System.err.println("usage: java Main inputFile");
            System.exit(1);
        }
    }

}