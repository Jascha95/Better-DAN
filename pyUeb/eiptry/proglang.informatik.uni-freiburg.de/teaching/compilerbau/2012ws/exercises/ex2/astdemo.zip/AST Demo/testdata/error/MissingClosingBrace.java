class BinaryTree{
    public static void main(String[] a){
	System.out.println(new BT().Start());
    }
// missing close-brace