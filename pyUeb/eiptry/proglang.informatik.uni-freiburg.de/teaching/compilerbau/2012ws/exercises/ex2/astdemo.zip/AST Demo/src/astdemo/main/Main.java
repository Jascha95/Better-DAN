package astdemo.main;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PushbackReader;

import astdemo.lexer.Lexer;
import astdemo.lexer.LexerException;
import astdemo.node.Start;
import astdemo.parser.Parser;
import astdemo.parser.ParserException;

/**
 * Main entry point for the expression parser.
 * 
 * @author geffken
 * @author anton
 */
public class Main {

	/**
	 * Main method. Read a file.
	 * @param args must contain just one filename.
	 */
	public static void main(String[] args){
		if(args.length == 1) {
			String filename = args[0];
			try {
				parseToAST(filename);

				System.out.print("Parse OK");
				
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(2);
			}
		}
		else {
			System.err.println("Expected: one file name");
			System.exit(1);
		}
	}

	/**
	 * Parse the file and create the AST
	 * @param filename a filename
	 * @return an AST
	 * @throws FileNotFoundException if the file is not found
	 * @throws ParserException in case of syntax errors
	 * @throws LexerException in case of syntax errors
	 * @throws IOException in case of file IO errors
	 */
	private static Start parseToAST(String filename)
			throws FileNotFoundException, ParserException, LexerException,
			IOException {
		Lexer lexer = new Lexer(new PushbackReader(new FileReader(filename)));
		Parser parser = new Parser(lexer);
		Start ast = parser.parse();
		return ast;
	}
}
