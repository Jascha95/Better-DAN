class ExprLetrec extends Expr {
    String var, param;
    Expr expr, body;
    ExprLetrec(String var, String param, Expr expr, Expr body) {
        this.var = var;
        this.param = param;
        this.expr = expr;
        this.body = body;
    }
    public String toString() {
        return "letrec " + this.var + "(" + this.param + ") = " + this.expr + " in " + this.body;
    }
}