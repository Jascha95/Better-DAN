class ExprLet extends Expr {
    String var;
    Expr expr;
    Expr body;
    ExprLet(String var, Expr expr, Expr body) {
        this.var = var;
        this.expr = expr;
        this.body = body;
    }
    public String toString() {
        return "let " + this.var + " = " + this.expr + " in " + this.body;
    }
}