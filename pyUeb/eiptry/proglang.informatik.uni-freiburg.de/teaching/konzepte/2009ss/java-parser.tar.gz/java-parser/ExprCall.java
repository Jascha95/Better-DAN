class ExprCall extends Expr {
    Expr rator, rand;
    ExprCall(Expr rator, Expr rand) {
        this.rator = rator;
        this.rand = rand;
    }
    public String toString() {
        return "(" + this.rator + " " + this.rand + ")";
    }
}