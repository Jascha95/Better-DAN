class ExprTry extends Expr {
    Expr expr;
    String var;
    Expr handler;
    ExprTry(Expr expr, String var, Expr handler) {
        this.expr = expr;
        this.var = var;
        this.handler = handler;
    }
    public String toString() {
        return "try " + this.expr + " catch(" + this.var + ") " + this.handler;
    }
}