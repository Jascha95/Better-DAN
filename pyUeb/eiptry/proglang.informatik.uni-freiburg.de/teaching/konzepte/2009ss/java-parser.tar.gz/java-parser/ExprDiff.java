class ExprDiff extends Expr {
    Expr left, right;
    ExprDiff(Expr left, Expr right) {
        this.left = left;
        this.right = right;
    }
    public String toString() {
        return "-(" + this.left + ", " + this.right + ")";
    }    
}