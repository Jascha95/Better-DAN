class ExprIf extends Expr {
    Expr test, then, alt;
    ExprIf(Expr test, Expr then, Expr alt) {
        this.test = test;
        this.then = then;
        this.alt = alt;
    }
    public String toString() {
        return "if " + this.test + " then " + this.then + " else " + this.alt;
    }    
}