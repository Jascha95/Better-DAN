class ExprRaise extends Expr {
    Expr expr;
    ExprRaise(Expr expr) {
        this.expr = expr;
    }
    public String toString() {
        return "raise " + this.expr;
    }
}