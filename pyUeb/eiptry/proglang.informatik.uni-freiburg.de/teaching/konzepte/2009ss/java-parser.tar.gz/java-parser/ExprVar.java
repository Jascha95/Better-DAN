class ExprVar extends Expr {
    String var;
    ExprVar(String var) {
        this.var = var;
    }
    public String toString() {
        return this.var;
    }
}