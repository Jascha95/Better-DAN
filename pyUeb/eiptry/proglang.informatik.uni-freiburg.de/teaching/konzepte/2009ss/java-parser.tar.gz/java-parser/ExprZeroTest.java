class ExprZeroTest extends Expr {
    Expr expr;
    ExprZeroTest(Expr expr) {
        this.expr = expr;
    }
    public String toString() {
        return "zero?(" + this.expr + ")";
    }
}