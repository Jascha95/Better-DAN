class ExprConst extends Expr {
    int val;
    ExprConst(int val) {
        this.val = val;
    }
    public String toString() {
        return "" + this.val;
    }
}