import org.antlr.runtime.*;

public class LetrecMain {
    public static void main(String[] args) throws Exception {
        ANTLRInputStream input = new ANTLRInputStream(System.in);
        LetrecLexer lexer = new LetrecLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        LetrecParser parser = new LetrecParser(tokens);
        Expr expr = parser.prog();
        System.out.println(expr);
    }
}
