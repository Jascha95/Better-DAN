class ExprProc extends Expr {
    String param;
    Expr body;
    ExprProc(String param, Expr body) {
        this.param = param;
        this.body = body;
    }
    public String toString() {
        return "proc(" + this.param + ") " + this.body;
    }
}