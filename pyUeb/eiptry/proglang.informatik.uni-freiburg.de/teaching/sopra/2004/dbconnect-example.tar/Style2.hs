module Style2 (
  -- * Extended Style Type
  Style2,
  -- * Form and Page Creation
  style2StandardQuery,
  standardCssPage,
  formatStyles
  )
where

import CGI
import Prelude hiding (head, map, span, div, init)

import qualified Prelude as Pre(head, map, span, div)



-- | Gives a Style a css Name. This type is used to construct a section with a style tag in the generated html-Page
-- Example (".datatable",   "border-color" :=: "black":^:"background-color":=:"#FFFFFF")
type Style2 = (String, Style)




-- | Takes the title of a page and a monadic HTML value for the contents of the page and a List of Style2 definitions. Wraps the contents in a form so that input fields and buttons may be used inside.
style2StandardQuery :: String -> WithHTML x CGI ()->[Style2] ->  CGI()
style2StandardQuery ttl elems styles  = do
  ask (standardCssPage ttl (makeForm elems) styles )

-- | create a standard HTML page from a title string and body elements and adds a bundle of Style2 definitions to the page
standardCssPage :: Monad cgi => String -> WithHTML y cgi () -> [Style2] ->  WithHTML x cgi ()
standardCssPage ttl nodes css_def =
  html (do head 
	       (do title (text ttl)
	           style (do (attr "type" "text/css")
	                     (text ("\n"++(formatStyles css_def)))))
           (body (a $ do attr "name" "TOP"
                         h1 (text ttl)) >> nodes))


{- ------------
  Interna
------------ -}

formatStyle :: Style2 -> String
formatStyle (name, style) =
   name ++ "{ " ++ (show style) ++ " }\n"

formatStyles :: [Style2] -> String
formatStyles styles = foldl1 (++) (Pre.map formatStyle styles)

