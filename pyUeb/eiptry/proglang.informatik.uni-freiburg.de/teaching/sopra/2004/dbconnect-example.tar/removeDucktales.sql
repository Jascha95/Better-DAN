
DROP TABLE persons;