/*
 * Created on Jan 19, 2005
 *
 */

public class Coordinate {


	/**
	 * the value of the abscissa of this coordinate
	 */	
	private int abscissa;
	/**
	 * the value of the ordinate of this coordinate
	 */
	private int ordinate;
	
	
	/** 
	 * Creates a coordinate set to the systems origin.
	 */
	public Coordinate() {
		abscissa = 0;
		ordinate = 0;
	}

	/**
	 * Creates a new coordinate with the respective values
	 * 
	 * @param abscissa - new abscissa of the coordinate
	 * @param ordinate - new ordinate of the coordinate
	 */
	public Coordinate(int abscissa, int ordinate) {
		this.abscissa = abscissa;
		this.ordinate = ordinate;
	}
	
	
	/**
	 * returns the abscissa of this coordinate
	 * 
	 * @return - the abscissa
	 */
	public int getAbscissa() {
		return abscissa;
	}
	
	/**
	 * sets the abscissa to a new value
	 * 
	 * @param abscissa - new abscissa value
	 */
	public void setAbscissa(int abscissa) {
		this.abscissa = abscissa;
	}
	
	/**
	 * returns the ordinate of this coordinate
	 * 
	 * @return - the ordinate
	 */
	public int getOrdinate() {
		return ordinate;
	}
	
	/**
	 * sets the ordinate to a new value
	 * 
	 * @param ordinate - new ordinate value
	 */
	public void setOrdinate(int ordinate) {
		this.ordinate = ordinate;
	}
	
	/**
	 * sets the Coordinate to reside at the new position
	 * 
	 * @param abscissa - abscissa value of new position
	 * @param ordinate - ordinate value of new position
	 */
	public void moveTo(int abscissa, int ordinate) {
		this.abscissa = abscissa;
		this.ordinate = ordinate;
	}
	
	/** 
	 * moves the Coordinate relatively by the given parameters
	 * 
	 * @param deltaAbscissa - distance to move in x-direction
	 * @param deltaOrdinate - distance to move in y-direction
	 */
	public void moveBy(int deltaAbscissa, int deltaOrdinate) {
		this.abscissa += deltaAbscissa;
		this.ordinate += deltaOrdinate;
	}
	
	/**
	 * clones the Coordinate
	 * 
	 * @return - a new Coordinate at the same position
	 */
	public Object clone() {
		return new Coordinate(abscissa, ordinate);
	}
	
	/** 
	 * pretty print of Coordinate
	 * 
	 * @return - A pretty print of the Coordinate
	 */
	public String toString() {
		return "("+abscissa+", "+ordinate+")";
	}
}
