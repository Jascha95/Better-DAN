import java.util.Enumeration;
import javax.swing.JInternalFrame;

/*
 * Created on Jan 18, 2005
 *
 */

public interface WorkitemInterface {

	/**
	 * Returns the name of the Workitem.
	 * The name of every Workitem has to be unique
	 * within it's workspace. It can be used to reference
	 * the workitem.
	 * 
	 * @return - The name of the Workitem
	 * @see - setName(String sWorkitemName);
	 */
	public String getName();
	
	/**
	 * Sets the name of the Workitem.
	 * 
	 * @param sWorkitemName - The new name of the Workitem
	 * @return - whether the name could be changed (was unique within the Workspace)
	 * @see - getName
	 */
	public boolean setName(String sWorkitemName);
	
	/** 
	 * Sets an attribute to the value.
	 * 
	 * @param sAttributeName - The name of the Attribute
	 * @param sAttributeValue - The value of the Attribute
	 * @see - getAttribute 
	 */
	public void setAttribute(String sAttributeName, String sAttributeValue);
	
	/**
	 * Returns the value of a certain Attribute. If the attribute
	 * is not set, <code>null</code> is returned.
	 * 
	 * @param - sAttributeName - The name of the Attribute
	 * @return - The corresponding Value or <code>null</code> if it was not set
	 * @see - setAttribute(String sAttributeName, String sAttributeValue)
	 */
	public String getAttribute(String sAttributeName);
	
	/**
	 * Removes an Attribute from the Workitem
	 * 
	 * @param - sAttributeName - The name of the Attribute to be removed
	 * @return - The value, the Attribute had or <code>null</code> if there was no such Attribute
	 */
	public String removeAttribute(String sAttributeName);
	
	/**
	 * Returns an Enumeration of all AttributeNames of the Workitem
	 * 
	 * @return - All AttributeNames or <code>null</code> if the Workitem has no attributes at all
	 */
	public Enumeration getAttributeNames();
	
	/**
	 * Returns left sibling of this Workitem
	 * 
	 * @return - The left Sibling or <code>null</code> if such Workitem doesn't exist
     */	
	public WorkitemInterface getLeftSibling();
	 
	 /**
	 * Returns right sibling of this Workitem
	 * 
	 * @return - the right Sibling or <code>null</code> if such Workitem doesn't exist	
	 */
	 public WorkitemInterface getRightSibling();
    
    /**
     * Clones this Workitem
     *
     * @param - sNewWorkitemName - The name of the cloned Workitem (the name of the cloned Workitem should be unique) 
     * @return - whether the Workitem could be cloned
     */
        
    public boolean copy(String sNewWorkitemName);
     
    /**
     * Accepts a Visitor
     * 
     *
     */
    public Object accept(VisitorInterface v);
    
    /**
     * Returns a JInternalFrame-Object, which represents this Workitem 
     * and can be added to a JDesktopPane
     * 
     * @return - a graphical representation of the Workitem
     */
    public JInternalFrame getGraphicalRepresentation();
    
    /**
     * Loads a Workitem from a file
     *
     * @param - sFilename - The name of the file to be read
     * @return - a Workitem being loaded
     */
    
    public WorkitemInterface load(String sFilename) throws NoSuchFileException;
    
    /**
     * Saves a Workitem to a file
     *
     *
     * @return - XML representation of saved Workitem of<code>null</code> if the operation was not successful
     */
    
    public String save(String sFilename);
}
