import java.util.Enumeration;

/*
 * Created on Jan 18, 2005
 *
 */

public interface SpreadsheetInterface {

/**
 * Returns Cell with requested index
 * 
 * @param coord - the coordinate of the cell
 * 
 * @return - requested Cell or <code>null</code>, if there is no such cell in the Spreadsheet
 * @throws - IndexOutOfBoundsException if there was no cell with the specified coordinates
 * 
 */
public CellInterface getCell(Coordinate coord) throws IndexOutOfBoundsException;

/**
 * Returns all Cells 
 *
 * @return - an Enumeration of all Cells of the Spreadsheet, or an empty Enumeration, if there are no cells in the Spreadsheet
 *
 */
public Enumeration getAllCells();

/**
 * Returns number of cells of the Spreadsheet
 * 
 * @return - an number of all cells of the Spreadsheet
 */
public int getNumberOfCells();

/**
 * Returns x-dimension of the Spreadsheet
 * 
 * 
 * @return - the number of cells in the x-dimension
 * @see - getYDimension();
 */
public int getXDimension();

/**
 * Returns y-dimension of the Spreadsheet
 * 
 *
 * @return - the number of cells in the y-dimension
 * @see - getXDimension();
 */
public int getYDimension();

/**
 * Returns row with requested index
 *
 * @param - iRow - the index of the requested row
 * @return - an Enumeration of cells with requested index
 * @throws - IndexOutOfBoundsException if there was no row with the specified index
 *
 */
public Enumeration getRow(int iIndex) throws IndexOutOfBoundsException;

/**
 *Returns column with requested index 
 *
 *
 * @param - iColumn - the index of the requested column
 * @return - an Enumeration of cells with requesten index
 * @throws - IndexOutOfBoundsException if there was no column with the specified index
 */
public Enumeration getColumn(int iIndex) throws IndexOutOfBoundsException;

/**
 * Initializes the values of cells of the row
 * 
 * @param - iIndex - index of the row to be replaced
 *          enCells - new Enumeration Cells value for the row 
 * @return - whether the row with index iIndex has a new value
 * @throws - IndexOutOfBoundsException - if the iIndex is less than 0
 * @see - setColumn()
 */
public boolean setRow(int iIndex, Enumeration enCells) throws IndexOutOfBoundsException;

/**
 * Initializes the values of cells of the column
 * 
 * @param - iIndex - index of the column to be replaced
 *          enCells -new Enumeration Cells value for the column
 * @return - whether the column with index iIndex has a new value
 * @throws - IndexOutOfBoundsException - if the iIndex is less than 0
 * @see - setRow()
 */
public boolean setColumn(int iIndex, Enumeration enCells) throws IndexOutOfBoundsException;

/**
 * Appends an empty row to the Spreadsheet
 *
 * @return - whether the row was added
 *
 */
public boolean appendRow();

/**
 * Inserts a row at the specified position into the spreadsheet
 * 
 * @param - iPosition - the index after which the row should be inserted
 * @return - Whether the row was inserted.
 * @throws - IndexOutOfBoundsException - if the iPosition is less than 0
 *
 */
public boolean insertRow(int iPosition) throws IndexOutOfBoundsException;

/**
 * Appends an empty column to the spreadsheet
 *
 * @return - whether the column was added
 *
 */
public boolean appendColumn();

/**
 * Inserts a column at the specified position into the spreadsheet 
 * 
 * @param - iPosition - the index after which the column should be inserted
 * @return - whether the row was added
 * @throws - IndexOutOfBoundsException - if the iPosition is less than 0
 *
 */
 public boolean insertColumn(int iPosition) throws IndexOutOfBoundsException;
 
 /**
  * Copies a rectangular area into the clipboard.
  * The area may range from one single cell to a row, a column or to anything with a rectangular shape.
  *
  * @param - upperLeftCorner - the coordinates of the upper left corner of the area to be copied (inclusive)
  * 	   - lowerRightCorner - the coordinates of the lower right corner of the area to be copied (inclusive)
  * @return - whether the area could be grabbed.
  * @throws - IndexOutOfBoundsException - if one of the coordinates contains a negative value
  */
 
 public boolean copyArea(Coordinate upperLeftCorner, Coordinate lowerRightCorner) throws IndexOutOfBoundsException;
 
 /**
  * Swaps two Rows
  * 
  * @param - iIndex1 - first index of the row to be swapped
  *          iIndex2 - second index of the row to be swapped
  * @return - whether the rows were swapped
  * @see - swapColumns(int iIndex1, int iIndex2)
  * @throws - IndexOutOfBoundsException - if one of the indices is less than 0 
  */
 
 public boolean swapRows(int iIndex1, int iIndex2) throws IndexOutOfBoundsException;
   
 /**
  * Swaps two Columns
  * 
  * 
  * @param - iIndex1 - first index of the column to be swapped
  *          iIndex2 - second index of the column to be swapped
  * @return - whether the columns were swapped
  * @throws - IndexOutOfBoundsException - if one of the indices is less than 0 
  */
 public boolean swapColumns(int iIndex1, int iIndex2) throws IndexOutOfBoundsException;
 
 /**
   * Sets the value of cells in the area to empty
   * The area may range from one single cell to a row, a column or to anything with a rectangular shape.
   *
   * @param - upperLeftCorner - the coordinates of the upper left corner of the area to be erased
   * 	    - lowerRightCorner - the coordinates of the lower right corner of the area to be erased
   * @return - whether the area could be erased.
  * @throws - IndexOutOfBoundsException - if one of the coordinates contains a negative value
   */
 
  public boolean eraseArea(Coordinate upperLeftCorner, Coordinate lowerRightCorner) throws IndexOutOfBoundsException;
 
  /**
	 * Removes whole colums to which the area belongs
	 * The area may range from one single cell to a row, a column or to anything with a rectangular shape.
	 *
	 * @param - upperLeftCorner - the coordinates of the upper left corner of the Area to be removed
	 * 	      - lowerRightCorner - the coordinates of the lower right corner of the Area to be removed
	 * @return - whether the area could be erased.
	 * @throws - IndexOutOfBoundsException - if one of the coordinates contains a negative value
	 *	 */
 
  public boolean removeColumns(Coordinate upperLeftCorner, Coordinate lowerRightCorner) throws IndexOutOfBoundsException;
 
  /**
	   * Removes whole rows to which the area belongs
	   * The area may range from one single cell to a row, a column or to anything with a rectangular shape.
	   *
	   * @param - upperLeftCorner - the coordinates of the upper left corner of the Area to be removed
	   * 	      - lowerRightCorner - the coordinates of the lower right corner of the Area to be removed
	   * @return - whether the area could be erased.
	   * @throws - IndexOutOfBoundsException - if one of the coordinates contains a negative value
	   */
 
	public boolean removeRows(Coordinate upperLeftCorner, Coordinate lowerRightCorner) throws IndexOutOfBoundsException;
}
