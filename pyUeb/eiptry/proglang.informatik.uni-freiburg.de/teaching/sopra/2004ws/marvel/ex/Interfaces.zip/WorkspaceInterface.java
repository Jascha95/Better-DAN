import java.util.Enumeration;

/*
 * Created on Jan 18, 2005
 *
 */

public interface WorkspaceInterface {

	/**
	 * Returns the Root
	 *
	 * @return - returns the WorkspaceManager
	 *
	 */
	public WorkspaceManagerInterface getWorkspaceManager();
	
 
	/**
	 * Returns an Enumeration of all Workitems in this Workspace
	 * 
	 * @return - All Children or empty Enumeration if there are no children 
	 */	 
	 public Enumeration getWorkitems();
	
	/**
	 * Returns the Workitem with the requested index in the list of all children of the Workspace
	 *
	 * @param - iIndex - the index of the requested child in the list of all children of the Workspace
	 * @return - the child with requested index
	 * @throws - IndexOutOfBoundsException if there was no Child at the specified index
	 */
	public WorkitemInterface getWorkitem(int iIndex) throws IndexOutOfBoundsException;
	 
	 /**
	  * Returns index of the Workitem in the list of all children of the Workspace
	  *
	  * @param - wi - the Workitem to be found in the list of all children of the Workspace
	  * @return - the index of the requested child or <code>-1</code> if there is no such Workitem in the Workspace
	  */
	 public int indexOf(WorkitemInterface wi);
	 
	 /**
	  * Inserts Workitem in the list of all children of the Workspace.
	  * 
	  * @param - wi - the Workitem to be inserted
	  *          iPosition - the index in the list of all children of the Workspace 
	  * @return - whether the index of inserted child has value iPosition
	  **/
	 public boolean insertWorkitem(WorkitemInterface wi, int iPosition);
	 
	 /**
	  * Returns number of all Workitems in the Workspace
	  * 
	  * @return - number of children of the Workspace
	  */
	 public int size();

	/**
	 * Appends a Workitem to this Workspace
	 * 
	 * @param - The Workitem to be added
	 * @return - whether the Workitem could be added 
	 */	  
	public boolean appendWorkitem(WorkitemInterface wi);
    
	/**
	 * Remove a Workitem from the list of this Workspace
	 * 
	 * @param - sWorkitemName - The name of the child to be removed 
	 * @return - the Workitem, which was removed or <code>null</code> if there was no such Workitem in the Workspace 
	 */
	public WorkitemInterface removeWorkitem(String sWorkitemName);
    
	/**
	 * Returns first Workitem from the list of all children of the Workspace
	 * 
	 * @return - The first Workitem from the list of all children of the Workspace or <code>null</code> if there are no children at all
	 */
	public WorkitemInterface getFirstWorkitem();
    
	/**
	 * Returns last Workitem from the list of all children of the Workspace
	 * 
	 * @return - The last Workitem from the list of all children of the Workspace or <code>null</code> if there are no children at all
	 */
	public WorkitemInterface getLastWorkitem();
}

