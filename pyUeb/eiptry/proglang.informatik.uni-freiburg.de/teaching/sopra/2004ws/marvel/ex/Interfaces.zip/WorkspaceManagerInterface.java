import javax.swing.JDesktopPane;

/*
 * Created on Jan 19, 2005
 *
 */

public interface WorkspaceManagerInterface {

/**
 * Returns main Program
 *
 * @return - the main Program
 */
public MarvelInterface getMain(); 

/**
 * Returns the root Workspace
 *
 * @return - the root Workspace 
 */ 
public WorkspaceInterface getRoot(); 

 /**
  * Sets the root Workspace to the parameter
  * 
  * @param - wsi the new root-Workspace
  */
 public void setRoot(WorkspaceInterface root);

 /**
  * Returns a JDesktopPane-Object, which suffices as an container for
  * all Workitems in the root of this WorkspaceManager (and the root
  * itself)
  *
  * @return - a graphical representation of the Workitem
  */
 public JDesktopPane getGraphicalRepresentation();

}
