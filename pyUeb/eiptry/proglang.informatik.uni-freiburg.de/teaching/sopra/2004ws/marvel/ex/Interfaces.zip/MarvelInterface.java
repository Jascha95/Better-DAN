/*
 * Created on Jan 19, 2005
 */
public interface MarvelInterface {

	/**
	 * Is not of interest yet, will be given in the future 
	 * (only included because there is a reference in 
	 * WorkspaceMangerInterface)
	 */

}
