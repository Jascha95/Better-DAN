/*
 * Created on Jan 19, 2005
 *
 *
 */

public interface NumberCellInterface {

/**
 * Returns the number value of the cell 
 *
 * @return - the cell value
 * @see - setValue(); 
 */

public double getValue();

/**
 * Sets the value of the cell to number
 *
 * @param - dValue - the value of the cell to set
 * @see - getValue();
 */
public void setValue(double dValue);

}
