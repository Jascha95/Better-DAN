/*
 * Created on Jan 19, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author levchuk
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface VisitorInterface {

	/**
	 * visits a Workspace
	 * @param wsi - the Workspace which is visited
	 * @return - the Object calculated by the Visitor
     */
	public Object visitWorkspace(WorkspaceInterface wsi);
	

	/**
	 * visits a Spreadsheet
	 * @param wsi - the Spreadsheet which is visited
	 * @return - the Object calculated by the Visitor
	 */ 
	public Object visitSpreadsheet(SpreadsheetInterface si);

}
