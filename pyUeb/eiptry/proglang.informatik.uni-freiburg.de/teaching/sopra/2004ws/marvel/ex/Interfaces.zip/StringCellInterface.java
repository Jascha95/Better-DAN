/*
 * Created on Jan 19, 2005
 *
 */

public interface StringCellInterface {
	
	/**
	 * gets the String Value of the cell
	 * 
	 * @return - the cell value
	 */
	public String getValue();
	
	/**
	 * sets the String Value of the cell
	 * 
	 * @param - sValue - the new value
	 */
	public void setValue(String sValue);

}
