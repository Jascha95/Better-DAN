/*
 * Created on Jan 18, 2005
 *
 *
 */


public interface CellInterface {

/**
 * Returns value of the cell converted to String   
 *
 * @return - the cell value
 * @see - toDouble();	
 */
public String display();


/**
 *Calculate value of the cell
 *
 *@param voCells - vector of cells
 *@param sFunktion - name of the function
 *
 *@return - the object cell value
 * 
 */
public Cell calculate(Vector voCells, String sFunction);
}
