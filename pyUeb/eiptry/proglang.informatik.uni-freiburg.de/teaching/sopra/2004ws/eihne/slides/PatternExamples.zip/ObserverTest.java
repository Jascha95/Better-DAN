/* 
The observer classes

 Every observer has an Estate to look over and an 
 update function, which is called in case the state
 of the estate changes.
*/
abstract class Observer {               
   protected Estate subj;
   public abstract void update(); 
}

// The dog is one observer looking after the estate.
class Dog extends Observer {    
    
    // At construction time it stores the estate and 
    // notifies the estate of its presence.
    public Dog(Estate e) {    
	System.out.println("Cave Canem");
	subj = e;
	subj.attach(this); 
    }

    // in case of a statechange it looks whether there
    // was a housebreak or not - and reacts to it.
    public void update() {
	if (subj.housebreak) 
	    System.out.println("bow-wow! grrrr! wow-wow wuff!");
	else 
	    System.out.println("dog wags its tail");
    }
}                                    

// the following two classes are similar to the dog.
class AlarmDevice extends Observer {

    public AlarmDevice(Estate e) {
	System.out.println("The DATE System protects your estate!");
	subj = e;  
	subj.attach(this);
    }

    public void update() {
	if (subj.housebreak) 
	    System.out.println("DRRRRRRRRRRRRRRRRRRRRRIIIIIIIIIIIIIIIIIIIIIING!");
    } 
}

class Watchman extends Observer {

    public Watchman(Estate e) {
	System.out.println("Watchman Walter watching you're estate!");
	subj = e;  
	subj.attach(this); 
    } 

    public void update() {
	if (subj.housebreak) {
	    System.out.println("Stop or I'll shoot!");
	} else {
	    System.out.println("Let's get some donuts.");
	}
    }
}                                   

/*
The Estate is the subject to be watched.
It manages an Array of observers.
*/
class Estate {

    private Observer[] observers = new Observer[9];
    private int observerCount = 0;
    public boolean housebreak;

    // add a new observer
    public void attach(Observer o) {
	if (observerCount == 8) {
	    System.out.println("The estate is already well protected.");
	} else {
	    observers[observerCount] = o;
	    observerCount++;
	}
    }

    // This functions calls the update() function of all attached
    // observers.
    private void notifyObservers() {
	for (int i = 0; i < observerCount; i++) {
	    observers[i].update();
	}
    }

    // changes the state of the house - observers are notified
    public void breakIn() {
	System.out.println("Somenone tries to break in!");
	housebreak = true;
	notifyObservers();
    }

    // changes the state of the house - observers are notified
    public void runAway() {
	System.out.println("The burglar runs away...");
	housebreak = false;
	notifyObservers();
    }
}

/*
Let's see if an estate can be protected...
*/
public class ObserverTest {

   public static void main( String[] args ) {
      Estate myVilla = new Estate();
      System.out.println("I'm a little paranoid, so I'll protect my Villa!");
      new Watchman(myVilla);
      System.out.println();
      myVilla.breakIn();
      System.out.println();
      myVilla.runAway();
      System.out.println();
      new Dog(myVilla);
      new AlarmDevice(myVilla);
      myVilla.breakIn();
      System.out.println();
      myVilla.runAway();
   }
}
