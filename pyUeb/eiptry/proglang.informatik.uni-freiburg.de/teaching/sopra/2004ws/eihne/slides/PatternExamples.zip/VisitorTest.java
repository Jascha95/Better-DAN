/*
Boolean expressions have only one thing in common:
They have to accept a visitor. And return an Object -
which is the most general class allowing us to return
any Object, but forcing us to do a lot of casting (see
below).
*/
abstract class BoolExpr {
    public abstract Object accept(Visitor v);
}

/*
The different parts of a Boolean Expression are classes 
on their own. Not has one Boolean Expression as argument,
And and Or two. Obvious, isn't it?
All these classes do nothing but accept visitors in calling
the corresponding method of the visitor class.
*/
class True extends BoolExpr {
    public Object accept(Visitor v) {return v.visitTrue(this);}
}
class False extends BoolExpr {
    public Object accept(Visitor v) {return v.visitFalse(this);}
}
class Not extends BoolExpr {
    public BoolExpr be1;
    public Not(BoolExpr b) {be1 = b;}
    public Object accept(Visitor v) {return v.visitNot(this);}
}
class And extends BoolExpr {
    public BoolExpr be1;
    public BoolExpr be2;
    public And(BoolExpr b1, BoolExpr b2) {
	be1 = b1;
	be2 = b2;
    }
    public Object accept(Visitor v) {return v.visitAnd(this);}
}
class Or extends BoolExpr {
    public BoolExpr be1;
    public BoolExpr be2;
    public Or(BoolExpr b1, BoolExpr b2) {
	be1 = b1;
	be2 = b2;
    }
    public Object accept(Visitor v) {return v.visitOr(this);}
}

/*
Visitors have to implement a behaviour on all possible nodes
of Boolean Expressions.
Observe that the return value is Object - so we can implement
visitors with different return values, but we also have to 
do a lot of Type-Casting. 
*/
abstract class Visitor {
    public abstract Object visitTrue(True b);
    public abstract Object visitFalse(False b);
    public abstract Object visitNot(Not b);
    public abstract Object visitAnd(And b);
    public abstract Object visitOr(Or b);
}
/* 
Two implementations of visitor - an evaluation of a term 
and a pretty print. Only the first is described in extenso
*/
class EvalVisitor extends Visitor {
    // We have to implement the behaviour on any BoolExpr Class.
    // we must return Objects, hence we have to encapsulate the
    // boolean values into Boolean Objects.
    public Object visitTrue(True b) {return new Boolean(true);}
    public Object visitFalse(False b) {return new Boolean(false);}
    public Object visitNot(Not b) {
	// Of the return value of b.be1.accept(this) Java only knows
	// that it's an object. We know that it is a Boolean Object
	// and hence can cast it to Boolean. But to manipulate it we
	// have to take the value out of the Object (.booleanValue()).
	boolean b1 = ((Boolean)(b.be1.accept(this))).booleanValue();
	// in returning we have to put it back into an Object.
	return new Boolean(!b1);
    }
    public Object visitAnd(And b) {
	boolean b1 = ((Boolean)(b.be1.accept(this))).booleanValue();
	boolean b2 = ((Boolean)(b.be2.accept(this))).booleanValue();
	return new Boolean(b1 && b2);
    }
    public Object visitOr(Or b) {
	boolean b1 = ((Boolean)(b.be1.accept(this))).booleanValue();
	boolean b2 = ((Boolean)(b.be2.accept(this))).booleanValue();
	return new Boolean(b1 || b2);
    }
}
class PrettyPrintVisitor extends Visitor {
    public Object visitTrue(True b) {return "true";}
    public Object visitFalse(False b) {return "false";}
    public Object visitNot(Not b) {return "(NOT "+((String)(b.be1.accept(this)))+")";}
    public Object visitAnd(And b) {
	String b1 = (String)(b.be1.accept(this));
	String b2 = (String)(b.be2.accept(this));
	return "("+b1+" AND "+b2+")";
    }
    public Object visitOr(Or b) {
	String b1 = (String)(b.be1.accept(this));
	String b2 = (String)(b.be2.accept(this));
	return "("+b1+" OR "+b2+")";
    }
}

/*
Testing class
*/
public class VisitorTest {
    public static void main(String args[]) {
	BoolExpr b = new Not(new And(new True(), new Or(new False(), new True())));
	System.out.print(b.accept(new PrettyPrintVisitor()));
	System.out.println(" is "+b.accept(new EvalVisitor()));
    }
}
