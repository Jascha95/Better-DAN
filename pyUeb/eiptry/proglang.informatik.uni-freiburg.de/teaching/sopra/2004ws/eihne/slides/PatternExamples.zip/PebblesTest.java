/*
The component defines which functions have to work
on all the components. 
*/
abstract class Component {
    public abstract void display();
    public abstract void repaint(String newColor);
}

/*
A leaf class, which implements the display and
repaint methods for itself.
*/
class Pebble extends Component {

    private String color;
    
    public Pebble(String c) {
	color = c;
    }
    
    public void display() {
	System.out.println(color+" Pebble");
    }
    public void repaint(String nc) {
	color = nc;
    }
}

/*
A node class...
*/
class Bag extends Component {

    // ... collects some Components (you could put
    // a bag into a bag)...
    private Component[] content;
    private int pos;
    private int size;
    
    public Bag(int s) {
	size = s;
        content = new Component[s];
	pos = 0;
    }

    public void add(Component c) {
	if (pos<size) {
	    content[pos] = c;
	    pos++;
	} else {
	    System.out.println("Bag is full!");
	}
    }

    // ... and if you call the functions, it traverses
    // all of it's content and calls the functions on 
    // them, too.
    public void display() {
	System.out.println("In my bag I find:");
	for (int i = 0; i<pos; i++) {
	    content[i].display();
	}
    }
    public void repaint(String c) {
	for (int i = 0; i<pos; i++) {
	    content[i].repaint(c);
	}
    }
}

/*
The testing class
*/
public class PebblesTest {
    
    public static void main (String args[]) {
	Bag myBag = new Bag(10);
	myBag.add(new Pebble("grey"));
	myBag.add(new Pebble("white"));
	myBag.add(new Pebble("black"));
	System.out.println("I found a grey, a white and a black pebble!");
	myBag.display();
	System.out.println();
	myBag.repaint("blue");
	System.out.println("OH NO! My bag fell into a bucket of blue paint!");
	myBag.display();
    }
}
	

		  


    
    
    
