/*
 * The Game interface, which controls the whole - err - game 
 * (that was redundant, wasn't it?). 
 * This class should offer a constructor without any arguments.
 */
public interface TicTacToeGame {

	/*
	 * The Players involved in the game are identified by their marks.
	 */
	final static int CROSS = 0;
	final static int NOUGHT = 1;

	/*
	 * Assigns a board to this game.
	 */
	public void setBoard(TicTacToeBoard board);
	
	/*
	 * Assigns a first Player to this game.
	 */
	public void setFirstPlayer(TicTacToePlayer p);
	
	/*
	 * Assigns a second Player to this game.
	 */
	public void setSecondPlayer(TicTacToePlayer p);
	 
	/*
	 * Starts the game, including cleaning up the board, 
	 * and handing the game over to the first player. 
	 */
	public void startGame();
	
	/*
	 * Returns the Player whose turn it is.
	 */
	public TicTacToePlayer getActivePlayer();
	
	/*
	 * Returns the Board of the Game.
	 */
	public TicTacToeBoard getBoard();  
		
	/*
	 * The active player decided to mark position p -
	 * so the GUI has to be updated, the Player changes
	 * and was there a victory or maybe it's a draw already?
	 */
	public void makeMove(Position p);
}
