/*
 * A Player used in the Tic Tac Toe Game.
 * He may use the Game he is in.
 */
public interface TicTacToePlayer {
	
	/* 
	 * Accepting a turn. This starts of the computer AI, doesn't do much
	 * in case of a human player.
	 */
	public void acceptTurn();
	
	/*
	 * Finishing a Turn. This method is called by the ActionListener if 
	 * a player clicked into a free field. Doesn't do much in case of a
	 * computer player.
	 */
	public void setMark(Position p);
	
	/* 
	 * Returns the name of the Player.
	 */
	public String getName();
}
