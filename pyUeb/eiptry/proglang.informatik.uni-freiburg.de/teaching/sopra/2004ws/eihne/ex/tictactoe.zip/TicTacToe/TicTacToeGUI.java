/*
 * The Graphical User Interface of the Tic Tac Toe Game. 
 * It should make use of a TicTacToeActionListener, but not 
 * implement it.  
 */
public interface TicTacToeGUI {
	
	/*
	 * Creates the GUI with one Menu "Game" (items New Game and Exit),
	 * 9 buttons resembling the board
	 * and a status bar.
	 * Action Listeners are added.
	 */
	public void createGUI();
	
	/* 
	 * Removes all marks in the board, and enables the usage
	 * of all fields again.
	 */
	public void clearBoard();
	
	/*
	 * Sets the message in the label to text.
	 */
	public void setLabelText(String text);
	
	/*
	 * Sets a mark resembling player markStyle into a field and 
	 * disables it.
	 */
	public void tickField(Position p, int markStyle);
	
	/*
	 * Disables all fields
	 */
	public void freezeBoard();
}
