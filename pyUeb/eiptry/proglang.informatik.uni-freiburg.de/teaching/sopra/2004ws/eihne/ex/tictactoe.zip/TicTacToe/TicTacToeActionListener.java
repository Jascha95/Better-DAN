import java.awt.event.ActionListener;

/*
 * Dieses Interface stellt die Methoden zur Verfuegung, die
 * benoetigt werden um die einzelnen Aktionen zu ueberwachen.
 */

public interface TicTacToeActionListener extends ActionListener {

    /*
     * Diese final-Variablen werden von der GUI benutzt um die
     * korrekten Kommandos an uns zu schicken.
     */
	final static String EXIT = "exit";
	final static String NEW_GAME = "newgame";

	/*
	 * Liefert einen String zurueck, der fuer das Kommando
	 * "setze Feld x, y" steht. 
	 */
	public String getSetFieldCommand(Position p);
		
	/* 
	 * von ActionListener ist auch die Methode actionPerformed(ActionEvent e)
	 * geerbt - auch diese muss natuerlich implementiert werden, obwohl
	 * sie hier nicht noch einmal auftaucht.
	 */
	
}
