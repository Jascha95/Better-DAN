/*
 * This is the logic resemblance of the board. It manages the GUI as well
 * (so it has to know about the GUI). 
 * The GUI is not accessed by any other class - they all refer to the board,
 * hence there are many methods which simply pass the commands to the GUI.
 */
public interface TicTacToeBoard {

	/*
	 * Values which indicate the state of each field
	 */
	final static int CROSS = 0;
	final static int NOUGHT = 1;
	final static int FREE = -1;
	
	/*
	 * Calculates who won. Return value is analogous to 
	 * the constants. If nobody won, TicTacToeBoard.FREE 
	 * is returned.
	 */
	public int whoWon();
	
	/*
	 * Calculates whether the game was a draw.
	 */
	public boolean isDraw();
	
	/*
	 * Returns the state of the field at Position p according
	 * to the constants.
	 */
	public int getFieldState(Position p);
	
	/*
	 * Removes all marks from the board, and cleans up the
	 * GUI as well. 
	 */
	public void clearBoard();
	
	/*
	 * sets the mark markType (according to constants) at
	 * position p. Updates the GUI as well.
	 */
	public void tickField(Position p, int markType);
	
	/*
	 * Shows a message in the label of the GUI.
	 */
	public void showMessage(String text);
	
	/*
	 * Freezes the board such that no action may be taken (e.g.
	 * after one won the game, no one should be allowed to mark
	 * free fields.
	 * This affects mainly the GUI.
	 */
	public void freezeBoard();
}
