package de.unifreiburg.twodeedoo.view;

/**
 * I want to run from time to time.
 * @author anton
 *
 */
public interface ISchedulable {
	/**
	 * Perform some work. 
	 * @param elapsedTimeMillis time in ms since last call.
	 * @return true: this should be run again, false: finished, don't call again.
	 */
	boolean run(int elapsedTimeMillis);

	/**
	 * an {@link ISchedulable} which does nothing.
	 */
	ISchedulable NULL_OBJECT = new ISchedulable() {
		/**
		 * Don't do anything, but keep on running
		 */
		@Override
		public boolean run(int elapsedTimeMillis) {
			return true;
		}
	};
}
