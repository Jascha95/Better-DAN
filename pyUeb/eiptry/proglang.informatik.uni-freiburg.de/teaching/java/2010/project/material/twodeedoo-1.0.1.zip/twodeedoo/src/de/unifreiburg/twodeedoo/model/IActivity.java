package de.unifreiburg.twodeedoo.model;

import de.unifreiburg.twodeedoo.view.IKeyHandler;
import de.unifreiburg.twodeedoo.view.ISchedulable;

/**
 * A company contains actors and runs them.
 * @author konrad
 *
 */
public interface IActivity extends ISchedulable, IKeyHandler {
	/**
	 * Add an actor
	 * @param a an actor that isn't yet in this {@link IActivity}.
	 */
	void addActor(IActor a);

	/**
	 * Replace this activity with another activity. Does not necessarily replace the Scene.
	 * @param otherActivity another IActivity.
	 */
	void switchToActivity(IActivity otherActivity);
	
}
