package de.unifreiburg.twodeedoo.view;

/**
 * The game as a whole, seen from the {@link SceneView}.
 * @author anton
 *
 */
public interface IGame {
	
	/**
	 * Restart the game from square one.
	 */
	void restart();
	
	/**
	 * Quit the game without further questions.
	 */
	void quit();
}
