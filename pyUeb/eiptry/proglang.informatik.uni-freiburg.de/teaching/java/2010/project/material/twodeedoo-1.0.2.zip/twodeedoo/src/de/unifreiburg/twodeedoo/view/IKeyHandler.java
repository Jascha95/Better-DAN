package de.unifreiburg.twodeedoo.view;

import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Handler of keyboard events, but mostly independent from AWT.
 * (Does not need {@link KeyEvent} instances, unlike {@link KeyListener},
 * and {@link KeyEvent} instances need a {@link Component}, bad for testing).
 * @author anton
 *
 */
public interface IKeyHandler {
	/**
	 * a key has been pressed.
	 * @param keyCode a code from {@link KeyEvent}, e.g. {@link KeyEvent#VK_LEFT}
	 */
	void keyPressed(int keyCode);
	/**
	 * a key has been released.
	 * @param keyCode a code from {@link KeyEvent}, e.g. {@link KeyEvent#VK_LEFT}
	 */
	void keyReleased(int keyCode);

	/**
	 * {@link IKeyHandler} which does nothing.
	 */
	IKeyHandler NULL_OBJECT = new IKeyHandler() {
		/** ignore. */
		@Override
		public void keyReleased(int keyCode) {
		}
		
		/** ignore. */
		@Override
		public void keyPressed(int keyCode) {
		}
	};
}
