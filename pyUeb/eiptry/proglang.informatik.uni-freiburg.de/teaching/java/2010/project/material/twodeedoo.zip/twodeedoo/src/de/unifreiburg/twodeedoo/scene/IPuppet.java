package de.unifreiburg.twodeedoo.scene;

import de.unifreiburg.twodeedoo.view.IPainter;

/**
 * I'm an {@link IPainter} which can be moved around.
 * 
 * 
 * @author anton
 *
 */
public interface IPuppet extends IPainter {
	/**
	 * Move the reference point to new coordinates.
	 * @param x x coordinate in the scene of my reference point
	 * @param y y coordinate in the scene of my reference point.
	 */
	void moveAbs(int x, int y);
	
	/**
	 * X coordinate
	 * @return x coordinate in scene units
	 */
	int getX();
	
	/**
	 * Y coordinate 
	 * @return y coordinate in scene units
	 */
	int getY();
}
