package de.unifreiburg.twodeedoo.scene;

import java.awt.Graphics;

/**
 * Implementation base for {@link IPuppet}s.
 * @author anton
 *
 */
abstract public class AbstractPuppet implements IPuppet {

	/**
	 * x position of refence point, scene units
	 */
	protected int x;
	/**
	 * y position of reference point, scene units.
	 */
	protected int y;

	/**
	 * The containing scene. Initially not an interesting scene.
	 */
	protected IScene containingScene = IScene.NULL_OBJECT;
	
	/**
	 * Initialize coordinates.
	 * @param x reference point position's x in scene units
	 * @param y reference point position's y in scene units
	 */
	public AbstractPuppet(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}

	/**
	 * Move to a position on scene.
	 * @param x scene x coordinate of reference point, scene units
	 * @param y scene y coordinate of reference point, scene units
	 */
	@Override
	public void moveAbs(int x, int y) {
		this.x = x;
		this.y = y;
	}
	/**
	 *@see IPuppet#getX()  
	 */
	@Override
	public int getX() {
		return x;
	}
	/**
	 *@see IPuppet#getY()  
	 */
	@Override
	public int getY() {
		return y;
	}

	/**
	 * Paint to this graphics.
	 */
	abstract public void paint(Graphics g);

	/**
	 * Remove me from my containing puppet.
	 * @see de.unifreiburg.twodeedoo.scene.IPuppet#removeFromScene()
	 */
	@Override
	public void removeFromScene() {
		this.containingScene.removePuppet(this);
	}

	/** 
	 * Update my containment
	 * @see de.unifreiburg.twodeedoo.scene.IPuppet#setContainingScene(de.unifreiburg.twodeedoo.scene.IScene)
	 */
	@Override
	public void setContainingScene(IScene scene) {
		this.containingScene = scene;
	}

	
}
