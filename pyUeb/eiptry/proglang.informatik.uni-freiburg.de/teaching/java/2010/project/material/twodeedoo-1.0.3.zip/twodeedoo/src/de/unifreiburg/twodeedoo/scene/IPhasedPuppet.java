package de.unifreiburg.twodeedoo.scene;


/**
 * a {@link IPuppet} which can change its appearance to one
 * of many (1..) phases selected by index (at least 0 but less than getNumberOfPhases)
 * 
 * @author anton
 *
 */
public interface IPhasedPuppet extends IPuppet {
	/**
	 * Which phase to draw from now on
	 * @param phase must be at least 0 and less than {@link #getNumberOfPhases()}
	 */
	void setPhase(int phase);
	/**
	 * How many phases?
	 * @return number of phases (at least 1)
	 */
	int getNumberOfPhases();
}
