package de.unifreiburg.twodeedoo.view;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;


/**
 * A rectangular part of a {@link BufferedImage}. Can draw itself
 * on a {@link Graphics}.
 * 
 * @author konrad
 *
 */
public class ImagePart implements IBrush {
	/**
	 * The image.
	 */
	private BufferedImage image;
	/**
	 * x coordinate of upper-left corner of the interesting part of {@link #image}.
	 * (Image coordinates)
	 */
	private final int ulCornerX;
	/**
	 * y coordinate of upper-left corner of the interesting part of {@link #image}.
	 * (Image coordinates)
	 */
	private final int ulCornerY;
	/**
	 * Width of the interesting part in pixels.
	 */
	private final int width;
	/**
	 * Height of the interesting part in pixels.
	 */
	private final int height;

	/**
	 * Create from image and some coordinates inside it. 
	 * @param image a {@link BufferedImage} as obtained from e.g. {@link ImageIO#read(java.io.File)}
	 * @param ulCornerX pixel coordinates of upper left corner of intersting part in image
	 * @param ulCornerY
	 * @param width width in pixel of interesting part
	 * @param height height in pixel of interesting part.
	 */
	public ImagePart(BufferedImage image, int ulCornerX, int ulCornerY, int width, int height) {
		super();
		this.image = image;
		this.ulCornerX = ulCornerX;
		this.ulCornerY = ulCornerY;
		this.width = width;
		this.height = height;
	}
	/**
	 * Take the whole image.
	 * @param image some image all of which will be painted.
	 */
	public ImagePart(BufferedImage image) {
		this(image, 0, 0, image.getWidth(), image.getHeight());
	}
	/**
	 * Paint.
	 */
	@Override
	public void paint(Graphics g, int x, int y){
		g.drawImage(image, 
				x, y, 
				x+ width,
				y+ height,
				ulCornerX, ulCornerY,
				ulCornerX+width, ulCornerY+height,
				null);
	}
}
