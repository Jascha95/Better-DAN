package de.unifreiburg.twodeedoo.model.test;

import static org.junit.Assert.*;

import java.security.spec.EllipticCurve;

import org.junit.Before;
import org.junit.Test;

import de.unifreiburg.twodeedoo.model.BaseActor;
import de.unifreiburg.twodeedoo.model.SimpleActivity;
import de.unifreiburg.twodeedoo.scene.IScene;


public class SimpleActivityAddRemoveTest {

	private SimpleActivity activity;
	private FakeGameController gameController;
	private IScene scene;

	private class CountingActor extends BaseActor {
		public CountingActor(IScene scene) {
			super(scene);
		}
		public int totalElapsedTime = 0;
		public int timeOfDeath = 1000;
		
		@Override
		public boolean run(int elapsedTimeMillis) {
			totalElapsedTime += elapsedTimeMillis;
			return totalElapsedTime < timeOfDeath;
		}
		
	}
	
	@Before
	public void setUp() {
		this.scene = IScene.NULL_OBJECT;
		this.gameController = new FakeGameController(); 
		this.activity = new SimpleActivity(scene, gameController);
	}
	
	@Test
	public void testAddSetsContainer(){
		CountingActor a1 = new CountingActor(scene);
		activity.addActor(a1);
		assertSame(activity, a1.getContainer());
	}

	@Test
	public void testAddGivesTimeslices(){
		CountingActor a1 = new CountingActor(scene);
		activity.addActor(a1);
		activity.run(100);
		assertEquals(100, a1.totalElapsedTime);
	}

	@Test
	public void testRunRespectsActorReturnValueTrue(){
		CountingActor a1 = new CountingActor(scene);
		activity.addActor(a1);
		activity.run(100);
		assertEquals(100, a1.totalElapsedTime);
		activity.run(200);
		assertEquals(300, a1.totalElapsedTime);
	}

	@Test
	public void testRunRemovesActorWhenReturnValueIsFalse(){
		CountingActor a1 = new CountingActor(scene);
		activity.addActor(a1);
		activity.run(2000);
		assertEquals(2000, a1.totalElapsedTime);
		activity.run(1);
		assertEquals(2000, a1.totalElapsedTime);
		assertNotSame(activity, a1.getContainer());
	}
	
	@Test
	public void testRemoveRemovesActorFromInside(){
		final CountingActor a1 = new CountingActor(scene);
		CountingActor a2 = new CountingActor(scene) {
			/**
			 * Remove a1 from the actorship.
			 */
			@Override
			public boolean run(int elapsedTimeMillis) {
				boolean wannaLive = super.run(elapsedTimeMillis);
				((SimpleActivity)getContainer()).removeActor(a1);
				return wannaLive;
			}
			
		};
		activity.addActor(a1);
		activity.addActor(a2);
		activity.run(500);
		int a1Time =  a1.totalElapsedTime;
		activity.run(100);
		assertEquals("a1 not run again", a1Time, a1.totalElapsedTime);
	}
	@Test
	public void testAddAddsActorFromInside(){
		final CountingActor a1 = new CountingActor(scene);
		CountingActor a2 = new CountingActor(scene) {
			public boolean hasAdded = false;
			/**
			 * Add a1 to the actorship.
			 */		
			@Override
			public boolean run(int elapsedTimeMillis) {
				if(!hasAdded){
					getContainer().addActor(a1);
					hasAdded = true;
				}
				boolean wannaLive = super.run(elapsedTimeMillis);
				return wannaLive;
			}
			
		};
		activity.addActor(a2);
		activity.run(500);
		int a1Time =  a1.totalElapsedTime;
		activity.run(100);
		assertEquals("a1 has run", 100+a1Time, a1.totalElapsedTime);
	}
	@Test
	public void testAddActorIsIdempotent(){
		final CountingActor a1 = new CountingActor(scene);
		activity.addActor(a1);
		activity.addActor(a1);
		activity.run(1);
		assertEquals("a1 has run once", 1, a1.totalElapsedTime);
	}
}
