package de.unifreiburg.twodeedoo.view;

/**
 * As much of the SceneView as the model needs to know
 * @author anton
 *
 */
public interface IGameController {
	/**
	 * Set the main schedulable. There is one.
	 * @param schedulable some {@link ISchedulable}
	 */
	void setMainSchedulable(ISchedulable schedulable);
	
	/**
	 * Get the {@link ISchedulable} which is scheduled for each frame.
	 * @return some {@link ISchedulable}.
	 */
	ISchedulable getMainSchedulable();
	
	/**
	 * Set the handler which receives the keys. There is only one.
	 * @param handler the new key handler
	 */
	void setKeyHandler(IKeyHandler handler);
	
	/**
	 * Get the handler which receives the keys.
	 * @return some key handler.
	 */
	IKeyHandler getKeyHandler();
}
