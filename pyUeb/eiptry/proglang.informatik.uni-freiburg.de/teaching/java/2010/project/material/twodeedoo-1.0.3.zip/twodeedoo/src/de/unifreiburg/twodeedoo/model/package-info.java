/**
 * Game model (actors, activities)
 * <p>
 * This package deals with the world simulation model of the game.
 * {@link IActor}s simulate one part of the world, e.g. the position and speed
 * of the player. They are also notified of keyboard events.
 * <p>
 * {@link IActivity}s group multiple related {@link IActor}s so that they can
 * be replaced simultaneously: you could e.g. have an {@link IActivity} for each
 * level of the game and another {@link IActivity} for the in-game menu.
 * 
 */
package de.unifreiburg.twodeedoo.model;


