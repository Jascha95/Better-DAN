package de.unifreiburg.twodeedoo.scene;

import java.awt.Graphics;

/**
 * Implementation base for {@link IPuppet}s.
 * @author anton
 *
 */
abstract public class AbstractPuppet implements IPuppet {

	/**
	 * x position of refence point, scene units
	 */
	protected int x;
	/**
	 * y position of reference point, scene units.
	 */
	protected int y;

	/**
	 * Initialize coordinates.
	 * @param x reference point position's x in scene units
	 * @param y reference point position's y in scene units
	 */
	public AbstractPuppet(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}

	/**
	 * Move to a position on scene.
	 * @param x scene x coordinate of reference point, scene units
	 * @param y scene y coordinate of reference point, scene units
	 */
	@Override
	public void moveAbs(int x, int y) {
		this.x = x;
		this.y = y;
	}
	/**
	 *@see IPuppet#getX()  
	 */
	@Override
	public int getX() {
		return x;
	}
	/**
	 *@see IPuppet#getY()  
	 */
	@Override
	public int getY() {
		return y;
	}

	/**
	 * Paint to this graphics.
	 */
	abstract public void paint(Graphics g);

}
