package de.unifreiburg.twodeedoo.model;

import de.unifreiburg.twodeedoo.scene.IPuppet;
import de.unifreiburg.twodeedoo.scene.IScene;

/**
 * I move my {@link IPuppet} along  a linear path.
 * @author konrad
 *
 */
public class LinearMotionActor extends BaseActor implements IActor {

	/**
	 * The {@link IPuppet} I move.
	 */
	private IPuppet puppet;
	/**
	 * x coordinate (in scene units) of the puppet's reference point
	 */
	protected double x;
	/**
	 * y coordinate (in scene units) of the puppet's reference point
	 */
	protected double y;
	/**
	 * x velocity (in scene units per ms) 
	 */
	private double vx;
	/**
	 * y velocity (in scene units per ms) 
	 */
	private double vy;

	/**
	 * Create a new actor.
	 * @param scene scene to put new puppets on
	 * @param puppet what to move
	 * @param x0 start coordinate in scene
	 * @param y0 start coordinate in scene
	 * @param vx x component of velocity, scene units/ms
	 * @param vy y component of velocity, scene units/ms
	 */
	public LinearMotionActor(IScene scene, IPuppet puppet, int x0, int y0, 
			double vx, double vy){
		super(scene);
		this.setPuppet(puppet);
		this.x = x0;
		this.y = y0;
		this.vx = vx;
		this.vy = vy;
	}
	
	/**
	 * Update the coordinates according to the elapsed time.
	 * @param elapsedTimeMillis time since last call in ms
	 */
	@Override
	public boolean run(int elapsedTimeMillis) {
		this.x += (vx * elapsedTimeMillis);
		this.y += (vy * elapsedTimeMillis);
		getPuppet().moveAbs((int)x,(int) y);
		return true;
	}

	/**
	 * Set a new velocity
	 * @param vx in scene units per ms
	 * @param vy in scene units per ms
	 */
	public void setVelocity(double vx, double vy){
		this.vx = vx;
		this.vy = vy;
	}
	
	/**
	 * @return the x component of the velocity (scene units per ms) 
	 */
	public double getVelocityX(){
		return vx;	
	}
	/**
	 * @return the y component of the velocity (scene units per ms) 
	 */
	public double getVelocityY(){
		return vy;
	}

	/**
	 * Change the puppet which will be moved around. Caller's responsibility
	 * to put it on the scene.
	 * @param puppet a non-null puppet.  
	 */
	public void setPuppet(IPuppet puppet) {
		this.puppet = puppet;
	}

	/**
	 * @return the puppet which would be moved the next time.
	 */
	public IPuppet getPuppet() {
		return puppet;
	}
}
