package de.unifreiburg.twodeedoo.view;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.JComponent;
import javax.swing.Timer;


/**
 * I display the contents of a scene at regular intervals. 
 * 
 * Caution: I own a {@link Timer} which creates a thread when running,
 * so be sure to call {@link #stop()} during shutdown.
 * 
 * @author anton
 *
 */
public class SceneView extends JComponent implements IGameController {
	
	/**
	 * Initial delay of timer in ms. Will be changed after first refresh.
	 */
	private static final int INITIAL_DELAY = 15;
	/**
	 * For serialization. Eclipse complains if I lack this.
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Minimum delay between frames in ms
	 */
	private static final int MIN_DELAY = 16;
	/**
	 * The model. Will be called to update itself for each update,
	 * and will receive key events.
	 */
	private ISchedulable mainSchedulable;
	
	/**
	 * Key handler which receives our keys.
	 */
	private IKeyHandler keyHandler;
	/**
	 * The scene, or something which paints itself onto a {@link Graphics}.
	 */
	private IPainter scene;
	
	/**
	 * The timer to schedule the next model update.
	 */
	private Timer timer;

	/**
	 * Wall-clock time of the last model update.
	 */
	private long millisLastRun=0;
	
	/**
	 * Width of the display area
	 */
	private int width;
	
	/**
	 * Height of the display area
	 */
	private int height;
	
	private Queue<InputEvent> inputQueue = new LinkedList<InputEvent>();
	
	/**
	 * Init. This installs dummy instances for {@link #mainSchedulable}, {@link #keyHandler}
	 * and {@link #scene}. Replace them using setters when you feel like it.
	 */
	public SceneView(int width, int height){
		this.width = width;
		this.height = height;
		this.mainSchedulable = ISchedulable.NULL_OBJECT;
		this.keyHandler = IKeyHandler.NULL_OBJECT;
		this.scene = IPainter.NULL_OBJECT;
	}

	/**
	 * Swing demands a repainting. Paint the scene and schedule the next update.
	 */
	@Override
	public void paint(Graphics g) {
		scene.paint(g);
		restartTimerIfExpired();
	}

	/**
	 * Start the timer for regular model updates.
	 */
	public void initTimer() {
		millisLastRun = System.currentTimeMillis();
		this.timer = new Timer(INITIAL_DELAY, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				long millisNow = System.currentTimeMillis();
				int elapsedTime = (int) (millisNow - millisLastRun);
				millisLastRun = millisNow;
				feedInputEvents();
				mainSchedulable.run(elapsedTime);
				repaint();
			}
		});
		timer.setRepeats(false);
		timer.start();
	}

	protected void feedInputEvents() {
		for(InputEvent ie : inputQueue){
			ie.sendTo(keyHandler);
		}
		inputQueue.clear();
	}

	/**
	 * Schedule the next update so that we get as many FPS as possible,
	 * but without refreshing earlier than {@link #MIN_DELAY} after the last time.
	 */
	private void restartTimerIfExpired() {
		if(timer.isRunning()) {
			// if the timer is still running, no need to restart it.
			return;
		}
		long millisNow = System.currentTimeMillis();
		long remainingTime = (millisLastRun - millisNow) + MIN_DELAY ; // TODO reason about overflows
		if(remainingTime < 0) {
			remainingTime = 1;
		}
		timer.setDelay((int) remainingTime);
		timer.restart(); 
	}

	/**
	 * Stop the timer, so that we may get rid of the timer thread.
	 * Call this before closing the window.
	 */
	public void stop(){
		timer.stop();
	}
	
	/**
	 * Prepare for keyboard input. Window must be visible.
	 */
	public void initKey() {
		requestFocus();
		// use an ad-hoc adapter to filter AWT key events down to Twodeedoo key events
		addKeyListener(new KeyListener() {
			/** Ignore */
			@Override
			public void keyTyped(KeyEvent e) {
			}
			
			/** Dispatch to activity */
			@Override
			public void keyReleased(KeyEvent e) {
				inputQueue.add(InputEvent.makeReleased(e.getKeyCode()));
			}
			
			/** Dispatch to activity */
			@Override
			public void keyPressed(KeyEvent e) {
				inputQueue.add(InputEvent.makePressed(e.getKeyCode()));
			}
		});
	}

	/**
	 * Set the scene
	 * @param scene something that can paint to a {@link Graphics}, usually an IScene.
	 */
	public void setScene(IPainter scene) {
		this.scene = scene;
	}

	/**
	 * How big do we want the window to be?
	 */
	@Override
	public Dimension getPreferredSize() {
		return new Dimension(width, height);
	}

	/**
	 * @return the mainSchedulable
	 */
	public ISchedulable getMainSchedulable() {
		return mainSchedulable;
	}

	/**
	 * @param mainSchedulable the mainSchedulable to set
	 */
	public void setMainSchedulable(ISchedulable mainSchedulable) {
		this.mainSchedulable = mainSchedulable;
	}

	/**
	 * @return the keyHandler
	 */
	public IKeyHandler getKeyHandler() {
		return keyHandler;
	}

	/**
	 * @param keyHandler the keyHandler to set
	 */
	public void setKeyHandler(IKeyHandler keyHandler) {
		this.keyHandler = keyHandler;
	}

	/**
	 * @return the width
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * @return the height
	 */
	public int getHeight() {
		return height;
	}
}
