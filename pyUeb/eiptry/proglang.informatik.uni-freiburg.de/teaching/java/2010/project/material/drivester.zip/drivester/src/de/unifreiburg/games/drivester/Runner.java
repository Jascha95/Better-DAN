package de.unifreiburg.games.drivester;

import javax.swing.SwingUtilities;

/**
 * This class contains just the main method of the game.
 * @author anton
 *
 */
public class Runner {

	/**
	 * Everything happens in {@link DrivesterGameApp}. Start one.
	 * @param args ignored.
	 */
	public static void main(String[] args) {
		DrivesterGameApp app = new DrivesterGameApp();
		
		// must do that in GUI thread (oh threads, love them).
		SwingUtilities.invokeLater(app); 
		
	}

}
