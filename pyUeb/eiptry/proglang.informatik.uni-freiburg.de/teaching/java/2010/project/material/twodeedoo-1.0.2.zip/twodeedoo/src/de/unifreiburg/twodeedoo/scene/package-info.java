/**
 * Scene management (Scene, Puppets)
 * <p>
 * The {@link IScene} is a plane with {@link IPuppet}s on it.
 * {@link IScene}s draw to Swing graphics contexts when asked to.
 * Implementations of {@link IScene} can transform coordinates in order
 * to achieve scaling, clipping, scrolling, etc; however, the
 * {@link SimpleScene} implementation does not do any of these.
 * <p>
 * {@link IPuppet}s occupy one particular place on the {@link IScene},
 * and they know how to paint themselves. Puppets stay on the scene in the same place 
 * until you move or {@link IPuppet#removeFromScene()} remove them.
 * <p>
 * Two implementations of {@link IPuppet}s are provided: {@link MultiImagePartPuppet}
 * (which displays any of a collection of bitmaps) and {@link SimpleTextPuppet}
 * (which displays text in Swing's standard font).
 */
package de.unifreiburg.twodeedoo.scene;

