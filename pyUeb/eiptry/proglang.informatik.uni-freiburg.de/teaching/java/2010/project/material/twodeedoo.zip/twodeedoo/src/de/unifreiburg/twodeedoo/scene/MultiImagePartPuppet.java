package de.unifreiburg.twodeedoo.scene;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import de.unifreiburg.twodeedoo.view.IBrush;

/**
 * {@link IPhasedPuppet} implementation which paints
 *  one of a collection of {@link IBrush}es.
 */
public class MultiImagePartPuppet extends AbstractPuppet implements IPhasedPuppet{

	/**
	 * Currently visible phase, index into {@link #brushes}.
	 */
	private int currentIndex;
	/**
	 * All the {@link IBrush}es I can paint.
	 */
	private List< IBrush> brushes;
	
	/**
	 * Create new. Must supply the first {@link IBrush} right now so that I 
	 * never have 0 of them. Inits coordinates 0,0.
	 * @param imagePart some {@link IBrush}, will become phase 0.
	 */
	public MultiImagePartPuppet(IBrush imagePart) {
		super(0,0);
		this.currentIndex = 0;
		this.brushes = new ArrayList<IBrush>();
		this.brushes.add(imagePart);
	}

	/**
	 * Add a {@link IBrush}.
	 * @param part some {@link IBrush}.
	 * @return the phase of the newly added {@link IBrush}.
	 */
	public int addImagePart(IBrush part){
		this.brushes.add(part);
		return this.brushes.size() - 1;
	}
	
	/**
	 * Change to a different phase.
	 * @param phase a valid index into the brush list.
	 * @throws IndexOutOfBoundsException if invalid.  
	 */
	@Override
	public void setPhase(int phase) {
		this.currentIndex = phase;
		this.brushes.get(phase); // throw an exception if invalid.
	}

	/**
	 * How many phases.
	 */
	@Override
	public int getNumberOfPhases() {
		return brushes.size();
	}

	/**
	 * Delegate painting to brush.
	 */
	@Override
	public void paint(Graphics g) {
		IBrush brush = this.brushes.get(currentIndex);
		// assumption: scene coordinates = screen coordinates.
		brush.paint(g, x, y);
	}

}
