package de.unifreiburg.games.drivester.model;

import java.awt.event.KeyEvent;

import de.unifreiburg.twodeedoo.model.BaseActor;
import de.unifreiburg.twodeedoo.model.IActivity;
import de.unifreiburg.twodeedoo.model.LinearMotionActor;
import de.unifreiburg.twodeedoo.scene.IPhasedPuppet;
import de.unifreiburg.twodeedoo.scene.IScene;

/** 
 * Controls a car: turn left, turn right, accelerate mercilessly.
 * @author anton
 *
 */
public class CarActor extends BaseActor {
	/**
	 * Acceleration in scene units per ms squared. 
	 */
	private static final double ACCELERATION = 0.0005;

	/**
	 * 	Current phase we've put the car to. 
	 */
	private int currentPhase;
	
	/**
	 * Speed of the car
	 */
	private double v;

	/**
	 * This actor pushes our car along its path
	 */
	private LinearMotionActor linearActor;

	/**
	 * The car puppet. Phases 0 right, 1 down, 2 left, 3 up.
	 */
	private IPhasedPuppet carPuppet;

	/**
	 * When the show is over, turn off the lights, turn off the lights
	 * (or switch to this activity)
	 */
	private IActivity gameOverActivity;
	
	/**
	 * Start at a position.
	 * @param puppet a car puppet, phase 0 facing right, 1 down, 2 left, 3 up.
	 * @param x0 scene coordinates
	 * @param y0 scene coordinates
	 * @param v velocity (driving to the right) in scene units per ms
	 */
	public CarActor(IScene scene, IPhasedPuppet puppet, int x0, int y0, double v,
			IActivity gameOverActivity) {
		super(scene);
		this.gameOverActivity = gameOverActivity;
		this.linearActor = new LinearMotionActor(scene, puppet, x0, y0, v, 0);
		this.carPuppet = puppet;
		this.currentPhase = 0;
		this.v = v;
	}

	/**
	 * turn left, change velocity, change picture
	 */
	public void turnLeft() {
		changePhase(-1);
		updateLinearMotion();
	}

	/**
	 * turn right, change velocity, change picture
	 */
	public void turnRight() {
		changePhase(+1);
		updateLinearMotion();
	}

	/**
	 * Set the {@link #linearActor} velocity according to our phase. 
	 */
	private void updateLinearMotion() {
		switch(currentPhase){
		case 0:
			linearActor.setVelocity(v, 0);
			break;
			
		case 1:
			linearActor.setVelocity(0, v);
			break;
			
		case 2:
			linearActor.setVelocity(-v, 0);
			break;
			
		case 3:
			linearActor.setVelocity(0, -v);
			break;
		}
	}

	/**
	 * Compute new phase
	 * @param deltaPhase +1 means 90 degrees clockwise
	 */
	private void changePhase(int deltaPhase) {
		int phase = (4+currentPhase + deltaPhase) % 4;
		carPuppet.setPhase(phase);
		currentPhase = phase;
	}

	/**
	 * When running, increase the velocity,
	 *  have the linear actor push the car around
	 * and check if we're in a Game Over situation.
	 */
	@Override
	public boolean run(int elapsedTimeMillis) {
		updateLinearMotion();
		linearActor.run(elapsedTimeMillis);
		v += ACCELERATION * elapsedTimeMillis;
		// TODO collision is a Scene concern.
		if(carPuppet.getX() < 0 || carPuppet.getY() < 0 || carPuppet.getX() > 704 
				|| carPuppet.getY() > 536
				){
			gameOver();
		}
		return true;
	}

	/**
	 * Switch to the Game-over activity
	 */
	private void gameOver() {
		this.container.switchToActivity(gameOverActivity);
	}

	/**
	 * Handle key-press events (we ignore keyReleased for now) 
	 * @param keyCode a key code as in {@link KeyEvent}.
	 */
	@Override
	public void keyPressed(int keyCode) {
		switch(keyCode){
		case KeyEvent.VK_RIGHT:
			turnRight();
			break;
		case KeyEvent.VK_LEFT:
			turnLeft();
			break;
		}
	}

	/**
	 * For testing, replace the internal {@link #linearActor}. 
	 * @param linearMotion
	 */
	public void setLinearMotionActor(LinearMotionActor linearMotion) {
		this.linearActor = linearMotion;
	}

}
