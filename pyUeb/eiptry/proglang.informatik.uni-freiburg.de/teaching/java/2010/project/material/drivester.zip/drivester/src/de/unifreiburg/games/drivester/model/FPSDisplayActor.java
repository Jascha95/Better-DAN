package de.unifreiburg.games.drivester.model;

import de.unifreiburg.twodeedoo.model.BaseActor;
import de.unifreiburg.twodeedoo.model.IActor;
import de.unifreiburg.twodeedoo.scene.IScene;
import de.unifreiburg.twodeedoo.scene.ITextPuppet;

/**
 * I display the last FPS value on my text puppet.
 * @author anton
 *
 */
public class FPSDisplayActor extends BaseActor implements IActor {

	/**
	 * Where I display the FPS value
	 */
	private ITextPuppet puppet;
	
	/**
	 * Ctor.
	 * @param display a text puppet which will receive a text like "100 fps"
	 */
	public FPSDisplayActor(IScene scene, ITextPuppet display){
		super(scene);
		this.puppet = display;
	}
	
	/**
	 * Compute FPS from elapsed time and display it.
	 */
	@Override
	public boolean run(int elapsedTimeMillis) {
		int showFps  = 0;
		if(elapsedTimeMillis > 0) {			
			double fps = 1000.0/elapsedTimeMillis;
			showFps = (int) fps;
		}	
		puppet.setText(String.format("%3d fps", showFps));
		return true;
	}

}
