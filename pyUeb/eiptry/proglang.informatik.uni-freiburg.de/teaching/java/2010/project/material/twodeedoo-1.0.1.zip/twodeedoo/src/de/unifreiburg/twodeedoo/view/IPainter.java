package de.unifreiburg.twodeedoo.view;

import java.awt.Graphics;

/**
 * I can paint something onto a {@link Graphics} when I'm told to.
 * I know where on the graphics to paint.
 */
public interface IPainter {
	/**
	 * Paint something on my coordinates on the given graphics context.
	 * @param g some graphics context.
	 */
	void paint(Graphics g);
	
	/**
	 * {@link IPainter} instance which does nothing.
	 */
	IPainter NULL_OBJECT = new IPainter() {
		/** Do nothing. */
		@Override
		public void paint(Graphics g) {}
	};
}
