package de.unifreiburg.twodeedoo.model;

import de.unifreiburg.twodeedoo.view.ISchedulable;
import de.unifreiburg.twodeedoo.view.IKeyHandler;

/**
 * I simulate some well-defined part of the world. 
 * @author konrad
 *
 */
public interface IActor extends ISchedulable, IKeyHandler{
	/**
	 * Set the container of this actor. An actor may be contained
	 * by up to one {@link IActivity}.
	 * @param container some {@link IActivity}, or null to become uncontained.
	 */
	void setContainer(IActivity container);
}
