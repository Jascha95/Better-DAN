package de.unifreiburg.twodeedoo.view;

import java.awt.Graphics;

/**
 * I can paint myself to some location of your choice on a {@link Graphics}.
 * Unlike {@link IPainter}, I have no coordinates of my own.
 * 
 * @author anton
 *
 */
public interface IBrush {
	/**
	 * Paint somewhere on this graphics.
	 * @param g the {@link Graphics}
	 * @param x x coordinate (screen units)
	 * @param y y coordinate (screen units)
	 */
	void paint(Graphics g, int x, int y);
}
