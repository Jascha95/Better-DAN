package de.unifreiburg.twodeedoo.scene;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import de.unifreiburg.twodeedoo.view.IPainter;

/**
 * Simple {@link IScene} as a composite of {@link IPainter}s.
 * Always paints the whole stage, first-added puppets first.
 * No coordinate transformations.
 */
public class SimpleScene implements IScene {

	/**
	 * All the puppets, bottom to top.
	 */
	private List<IPainter> puppets = new ArrayList<IPainter>() ;
	
	/**
	 * Paint in order of {@link #puppets}
	 */
	@Override
	public void paint(Graphics g) {
		for(IPainter puppet : puppets){
			puppet.paint(g);
		}
	}

	/**
	 * Append another {@link IPuppet}. Will be painted last.
	 * Append only if not yet in this scene.
	 */
	@Override
	public void addPuppet(IPuppet puppet){
		if(!this.puppets.contains(puppet)){
			this.puppets.add(puppet);
			puppet.setContainingScene(this);
		}
	}

	/**
	 * Remove this {@link IPuppet} if it is among the puppets.
	 */
	@Override
	public void removePuppet(IPuppet puppet) {
		this.puppets.remove(puppet);
		puppet.setContainingScene(IScene.NULL_OBJECT);
	}
}
