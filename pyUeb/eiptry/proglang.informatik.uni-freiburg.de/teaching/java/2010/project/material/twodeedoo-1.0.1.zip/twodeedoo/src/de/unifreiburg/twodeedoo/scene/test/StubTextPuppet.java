package de.unifreiburg.twodeedoo.scene.test;

import java.awt.Graphics;

import de.unifreiburg.twodeedoo.scene.IScene;
import de.unifreiburg.twodeedoo.scene.ITextPuppet;
import de.unifreiburg.twodeedoo.test.UnimplementedStubCalledException;

/**
 * Stub impl of {@link ITextPuppet}.
 * @author anton
 *
 */
public class StubTextPuppet implements ITextPuppet {

	private String lastText = "";

	@Override
	public void setText(String text) {
		this.lastText  = text;
	}

	/**
	 * @return the lastText
	 */
	public String getLastText() {
		return lastText;
	}

	@Override
	public int getX() {
		throw new UnimplementedStubCalledException();
	}

	@Override
	public int getY() {
		throw new UnimplementedStubCalledException();
	}

	@Override
	public void moveAbs(int x, int y) {
		throw new UnimplementedStubCalledException();
	}

	@Override
	public void paint(Graphics g) {
		throw new UnimplementedStubCalledException();
	}

	/** Not implemented.
	 * @see de.unifreiburg.twodeedoo.scene.IPuppet#removeFromScene()
	 */
	@Override
	public void removeFromScene() {
	}

	/** Not implemented.
	 * @see de.unifreiburg.twodeedoo.scene.IPuppet#setContainingScene(de.unifreiburg.twodeedoo.scene.IScene)
	 */
	@Override
	public void setContainingScene(IScene scene) {
	}

}
