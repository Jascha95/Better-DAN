package de.unifreiburg.twodeedoo.model;

import de.unifreiburg.twodeedoo.view.IKeyHandler;
import de.unifreiburg.twodeedoo.view.ISchedulable;

/**
 * A company contains actors and runs them.
 * @author konrad
 *
 */
public interface IActivity extends ISchedulable, IKeyHandler {
	/**
	 * Add an actor
	 * @param a an actor that isn't yet in this {@link IActivity}.
	 */
	void addActor(IActor a);

	/**
	 * Remove that actor from the actors of this activity.
	 * <p>
	 * (But note that excessive use of this method is a design smell)
	 * This will also reset the container of the actor.
	 * 
	 * @param a an actor to remove. If not among my actors, I will do nothing.
	 */
	void removeActor(IActor a);
	
	/**
	 * Replace this activity with another activity. Does not necessarily replace the Scene.
	 * @param otherActivity another IActivity.
	 */
	void switchToActivity(IActivity otherActivity);
	
}
