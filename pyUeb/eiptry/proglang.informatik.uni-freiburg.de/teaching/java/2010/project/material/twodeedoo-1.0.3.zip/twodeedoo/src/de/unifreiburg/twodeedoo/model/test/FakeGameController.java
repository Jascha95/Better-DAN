package de.unifreiburg.twodeedoo.model.test;

import de.unifreiburg.twodeedoo.view.IGameController;
import de.unifreiburg.twodeedoo.view.IKeyHandler;
import de.unifreiburg.twodeedoo.view.ISchedulable;

/**
 * {@link IGameController} fake for testing.
 * 
 * @author anton
 *
 */
public class FakeGameController implements IGameController {

	private IKeyHandler keyHandler = null;
	private ISchedulable mainSchedulable = null;
	/**
	 * @return the keyHandler
	 */
	public IKeyHandler getKeyHandler() {
		return keyHandler;
	}
	/**
	 * @param keyHandler the keyHandler to set
	 */
	public void setKeyHandler(IKeyHandler keyHandler) {
		this.keyHandler = keyHandler;
	}
	/**
	 * @return the mainSchedulable
	 */
	public ISchedulable getMainSchedulable() {
		return mainSchedulable;
	}
	/**
	 * @param mainSchedulable the mainSchedulable to set
	 */
	public void setMainSchedulable(ISchedulable mainSchedulable) {
		this.mainSchedulable = mainSchedulable;
	}
	

}
