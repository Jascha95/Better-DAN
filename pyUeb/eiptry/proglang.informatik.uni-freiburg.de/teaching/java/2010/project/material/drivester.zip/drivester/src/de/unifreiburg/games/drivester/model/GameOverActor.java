package de.unifreiburg.games.drivester.model;

import java.awt.event.KeyEvent;

import de.unifreiburg.twodeedoo.model.BaseActor;
import de.unifreiburg.twodeedoo.scene.IPuppet;
import de.unifreiburg.twodeedoo.scene.IScene;
import de.unifreiburg.twodeedoo.view.IGame;
/**
 * Display a Game Over message and switch to another activity. 
 * @author anton
 *
 */
public class GameOverActor extends BaseActor {

	private IPuppet messagePuppet;
	private boolean puppetVisible;
	private final IGame game;
	
	public GameOverActor(IScene scene, IPuppet messagePuppet, IGame game) {
		super(scene);
		this.messagePuppet = messagePuppet;
		this.game = game;
		this.puppetVisible = false;
	}

	@Override
	public boolean run(int elapsedTimeMillis) {
		if(!puppetVisible){
			scene.addPuppet(messagePuppet);
			puppetVisible = true;
		}
		return true;
	}

	/**
	 * Restart or quit the game.
	 * @see de.unifreiburg.twodeedoo.model.BaseActor#keyReleased(int)
	 */
	@Override
	public void keyReleased(int keyCode) {
		switch(keyCode){
		case KeyEvent.VK_ESCAPE:
			quitGame();
			break;
		default:
			restartGame();
		}
	}

	/**
	 * Restart the game.
	 */
	private void restartGame() {
		game.restart();
	}

	/**
	 * Quit the game.
	 */
	private void quitGame() {
		game.quit();
	}

	
}
