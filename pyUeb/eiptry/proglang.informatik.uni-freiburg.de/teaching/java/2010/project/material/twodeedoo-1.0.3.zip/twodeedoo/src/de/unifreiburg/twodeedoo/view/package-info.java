/**
 * Swing component to display scenes, schedule activities and dispatch keys.
 * <p>
 * {@link SceneView} is the Swing widget which displays a {@link IPainter},
 * schedules an {@link ISchedulable} and forwards key presses to an {@link IKeyHandler}.
 * <p>
 * This package also contains Swing-dependent classes like {@link ImagePart} 
 * (a rectangular part of a {@link java.awt.image.BufferedImage}).
 */
package de.unifreiburg.twodeedoo.view;

