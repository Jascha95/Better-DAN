/**
 * Test helpers for the model layer.
 */
package de.unifreiburg.twodeedoo.model.test;

