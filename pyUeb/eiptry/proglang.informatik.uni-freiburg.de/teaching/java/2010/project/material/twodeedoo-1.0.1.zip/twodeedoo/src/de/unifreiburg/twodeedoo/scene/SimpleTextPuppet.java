package de.unifreiburg.twodeedoo.scene;

import java.awt.Graphics;	

import de.unifreiburg.twodeedoo.view.IPainter;

/**
 * {@link IPuppet} which displays a string of text in default font and color.
 * 
 * The reference point is the leftmost end of the text baseline.
 * @author anton
 *
 */
public class SimpleTextPuppet extends AbstractPuppet implements ITextPuppet, IPainter{
	
	/**
	 * The text to show
	 */
	private String text;
	
	/**
	 * Init with coordinates and empty text.
	 * @param x x coordinate of left end of text baseline
	 * @param y y coordinate of left end of text baseline
	 */
	public SimpleTextPuppet(int x, int y){
		super(x,y);
		this.text = "";
	}
	
	/**
	 * Set the text.
	 */
	public void setText(String text){
		this.text = text;
	}
	
	/**
	 * Paint the text.
	 */
	@Override
	public void paint(Graphics g) {
		// assumption: screen coordinates = scene coordinates.
		g.drawString(text, x , y);
	}

}
