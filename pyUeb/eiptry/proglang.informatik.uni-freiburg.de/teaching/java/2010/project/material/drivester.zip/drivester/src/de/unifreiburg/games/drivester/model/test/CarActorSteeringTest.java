package de.unifreiburg.games.drivester.model.test;


import static org.junit.Assert.assertEquals;

import java.awt.event.KeyEvent;

import org.junit.Before;
import org.junit.Test;

import de.unifreiburg.games.drivester.model.CarActor;
import de.unifreiburg.twodeedoo.model.LinearMotionActor;
import de.unifreiburg.twodeedoo.model.test.ErrorActivity;
import de.unifreiburg.twodeedoo.scene.IScene;
import de.unifreiburg.twodeedoo.scene.test.StubPhasedPuppet;

/**
 * Test the steering of the CarActor: flip the puppet and turn the 
 * linear motion by 90 degrees.
 * 
 * @author anton
 *
 */
public class CarActorSteeringTest {

	/**
	 * Velocity in our example.
	 */
	private static final double VELOCITY = 42;
	/**
	 * Instance of class under test
	 */
	private CarActor carActor;
	/**
	 * The puppet stub
	 */
	private StubPhasedPuppet carPuppet;
	/**
	 * A substitute {@link LinearMotionActor} to read back the direction of movement
	 */
	private LinearMotionActor linearMotion;

	/**
	 * Create a {@link CarActor} and test stubs.
	 */
	@Before
	public void setUp() throws Exception {
		this.carPuppet = new StubPhasedPuppet(4); 
		this.carActor = new CarActor(IScene.NULL_OBJECT, 
				this.carPuppet, 100, 100, VELOCITY, new ErrorActivity());
		this.linearMotion = new LinearMotionActor(IScene.NULL_OBJECT, carPuppet, 100, 100,  9999, 0);
		carActor.setLinearMotionActor(linearMotion);
	}

	@Test
	public void testTurnLeft(){
		carActor.keyPressed(KeyEvent.VK_LEFT);
		carActor.keyReleased(KeyEvent.VK_LEFT);
		assertEquals(3, carPuppet.getCurrentPhase());
		assertEquals(-VELOCITY, linearMotion.getVelocityY(), 0.001);
		assertEquals(0, linearMotion.getVelocityX(), 0.001);
	}

	@Test
	public void testTurnLeftLeft(){
		carActor.keyPressed(KeyEvent.VK_LEFT);
		carActor.keyReleased(KeyEvent.VK_LEFT);
		carActor.keyPressed(KeyEvent.VK_LEFT);
		carActor.keyReleased(KeyEvent.VK_LEFT);
		assertEquals(2, carPuppet.getCurrentPhase());
		assertEquals(-VELOCITY, linearMotion.getVelocityX(), 0.001);
		assertEquals(0, linearMotion.getVelocityY(), 0.001);
	}

	@Test
	public void testTurnLeftLeftLeft(){
		carActor.keyPressed(KeyEvent.VK_LEFT);
		carActor.keyReleased(KeyEvent.VK_LEFT);
		carActor.keyPressed(KeyEvent.VK_LEFT);
		carActor.keyReleased(KeyEvent.VK_LEFT);
		carActor.keyPressed(KeyEvent.VK_LEFT);
		carActor.keyReleased(KeyEvent.VK_LEFT);
		assertEquals(1, carPuppet.getCurrentPhase());
		assertEquals(VELOCITY, linearMotion.getVelocityY(), 0.001);
		assertEquals(0, linearMotion.getVelocityX(), 0.001);
	}

	@Test
	public void testTurnLeftLeftLeftLeft(){
		carActor.keyPressed(KeyEvent.VK_LEFT);
		carActor.keyReleased(KeyEvent.VK_LEFT);
		carActor.keyPressed(KeyEvent.VK_LEFT);
		carActor.keyReleased(KeyEvent.VK_LEFT);
		carActor.keyPressed(KeyEvent.VK_LEFT);
		carActor.keyReleased(KeyEvent.VK_LEFT);
		carActor.keyPressed(KeyEvent.VK_LEFT);
		carActor.keyReleased(KeyEvent.VK_LEFT);
		assertEquals(0, carPuppet.getCurrentPhase());
		assertEquals(VELOCITY, linearMotion.getVelocityX(), 0.001);
		assertEquals(0, linearMotion.getVelocityY(), 0.001);
	}

	@Test
	public void testTurnRight(){
		carActor.keyPressed(KeyEvent.VK_RIGHT);
		carActor.keyReleased(KeyEvent.VK_RIGHT);
		assertEquals(1, carPuppet.getCurrentPhase());
		assertEquals(VELOCITY, linearMotion.getVelocityY(), 0.001);
		assertEquals(0, linearMotion.getVelocityX(), 0.001);
	}

	@Test
	public void testTurnRightRight(){
		carActor.keyPressed(KeyEvent.VK_RIGHT);
		carActor.keyReleased(KeyEvent.VK_RIGHT);
		carActor.keyPressed(KeyEvent.VK_RIGHT);
		carActor.keyReleased(KeyEvent.VK_RIGHT);
		assertEquals(2, carPuppet.getCurrentPhase());
		assertEquals(-VELOCITY, linearMotion.getVelocityX(), 0.001);
		assertEquals(0, linearMotion.getVelocityY(), 0.001);
	}

	@Test
	public void testTurnRightRightRight(){
		carActor.keyPressed(KeyEvent.VK_RIGHT);
		carActor.keyReleased(KeyEvent.VK_RIGHT);
		carActor.keyPressed(KeyEvent.VK_RIGHT);
		carActor.keyReleased(KeyEvent.VK_RIGHT);
		carActor.keyPressed(KeyEvent.VK_RIGHT);
		carActor.keyReleased(KeyEvent.VK_RIGHT);
		assertEquals(3, carPuppet.getCurrentPhase());
		assertEquals(-VELOCITY, linearMotion.getVelocityY(), 0.001);
		assertEquals(0, linearMotion.getVelocityX(), 0.001);
	}

	@Test
	public void testTurnRightRightRightRight(){
		carActor.keyPressed(KeyEvent.VK_RIGHT);
		carActor.keyReleased(KeyEvent.VK_RIGHT);
		carActor.keyPressed(KeyEvent.VK_RIGHT);
		carActor.keyReleased(KeyEvent.VK_RIGHT);
		carActor.keyPressed(KeyEvent.VK_RIGHT);
		carActor.keyReleased(KeyEvent.VK_RIGHT);
		carActor.keyPressed(KeyEvent.VK_RIGHT);
		carActor.keyReleased(KeyEvent.VK_RIGHT);
		assertEquals(0, carPuppet.getCurrentPhase());
		assertEquals(VELOCITY, linearMotion.getVelocityX(), 0.001);
		assertEquals(0, linearMotion.getVelocityY(), 0.001);
	}
}
