package de.unifreiburg.twodeedoo.scene;

import java.awt.Graphics;

import de.unifreiburg.twodeedoo.view.IPainter;

/**
 * I contain a collection of puppets and manage their painting.
 * 
 * @author anton
 *
 */
public interface IScene extends IPainter {
	/**
	 * add a {@link IPuppet} so that will paint above all others.
	 * @param puppet some puppet not yet in this scene.
	 */
	void addPuppet(IPuppet puppet);
	/**
	 * Remove the {@link IPuppet} from this scene. 
	 * @param puppet some puppet in this {@link IScene}.
	 */
	void removePuppet(IPuppet puppet);

	/**
	 * {@link IScene} which does nothing in a safe way.
	 */
	IScene NULL_OBJECT = new IScene() {
		@Override
		public void paint(Graphics g) {		}
		@Override
		public void removePuppet(IPuppet puppet) {		}
		@Override
		public void addPuppet(IPuppet puppet) {		}
	};
}
