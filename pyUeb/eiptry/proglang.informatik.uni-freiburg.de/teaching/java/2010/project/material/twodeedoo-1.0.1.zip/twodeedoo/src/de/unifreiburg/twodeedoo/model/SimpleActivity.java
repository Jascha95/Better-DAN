package de.unifreiburg.twodeedoo.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import de.unifreiburg.twodeedoo.scene.IScene;
import de.unifreiburg.twodeedoo.view.IGameController;

/**
 * Simple Composite of {@link IActor}s.
 * @author konrad
 *
 */
public class SimpleActivity implements IActivity{
	/**
	 * The contained {@link IActor}s.
	 */
	private List<IActor> actors = new LinkedList<IActor>();
	/**
	 * Our scene
	 */
	private IScene scene;
	/**
	 * Schedules me and receives suggestions for replacement activities.
	 */
	private IGameController gameController;
	
	/**
	 * Create instance
	 * @param scene the scene for new puppets
	 */
	public SimpleActivity(IScene scene, IGameController gameController){
		this.gameController = gameController;
		this.setScene(scene);
	}
	
	/**
	 * Let all the contained actors run. Follow their wishes for removal. 
	 * @param elapsedTimeMillis elapsed time since last run in ms
	 */
	@Override
	public boolean run(int elapsedTimeMillis) {
		List<IActor> actorsCopy = copyActorsList();
		Iterator<IActor> iactors = actorsCopy.iterator();
		while(iactors.hasNext()){
			IActor a = iactors.next();
			boolean stillAlive = a.run(elapsedTimeMillis);
			if(!stillAlive){
				actors.remove(a);
			}
		}
		return !actors.isEmpty();
	}

	/**
	 * Add an actor, becoming its container.
	 * @param actor an actor 
	 */
	public void addActor(IActor actor){
		this.actors.add(actor);
		actor.setContainer(this);
	}

	/**
	 * Setter for scene.
	 * @param scene a scene, non-null.
	 */
	public void setScene(IScene scene) {
		this.scene = scene;
	}

	/**
	 * Getter for scene.
	 * @return the scene.
	 */
	public IScene getScene() {
		return scene;
	}

	/**
	 * Dispatch to the actor which likes that key
	 */
	@Override
	public void keyPressed(int keyCode) {
		// copy the list so that key handlers can remove actors.
		ArrayList<IActor> actorsCopy = copyActorsList();
		for(IActor actor: actorsCopy){
			actor.keyPressed(keyCode); 
		}
	}

	/**
	 * @return
	 */
	private ArrayList<IActor> copyActorsList() {
		ArrayList<IActor> actorsCopy = new ArrayList<IActor>(actors.size());
		actorsCopy.addAll(actors);
		return actorsCopy;
	}

	/**
	 * Dispatch to the actor which likes that key
	 */
	@Override
	public void keyReleased(int keyCode) {
		// copy the list so that key handlers can remove actors.
		ArrayList<IActor> actorsCopy = copyActorsList();
		for(IActor actor: actorsCopy){
			actor.keyReleased(keyCode);
		}
	}

	/**
	 * Tell the {@link IGameController} that a different {@link IActivity} should be run.
	 */
	@Override
	public void switchToActivity(IActivity otherActivity) {
		gameController.setKeyHandler(otherActivity);
		gameController.setMainSchedulable(otherActivity);
	}
	
	
}
