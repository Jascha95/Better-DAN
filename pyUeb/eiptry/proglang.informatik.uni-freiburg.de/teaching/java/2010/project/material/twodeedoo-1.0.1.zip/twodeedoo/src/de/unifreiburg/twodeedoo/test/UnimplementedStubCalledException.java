package de.unifreiburg.twodeedoo.test;

/**
 * A deliberately unimplemented method of a stub has been called.
 * @author anton
 *
 */
public class UnimplementedStubCalledException extends RuntimeException {

	/**
	 * avoid warnings.
	 */
	private static final long serialVersionUID = 1L;

	public UnimplementedStubCalledException() {
		super();
	}

	public UnimplementedStubCalledException(String message, Throwable cause) {
		super(message, cause);
	}

	public UnimplementedStubCalledException(String message) {
		super(message);
	}

	public UnimplementedStubCalledException(Throwable cause) {
		super(cause);
	}

}
