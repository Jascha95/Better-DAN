package de.unifreiburg.games.drivester.model.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import de.unifreiburg.games.drivester.model.FPSDisplayActor;
import de.unifreiburg.twodeedoo.scene.IScene;
import de.unifreiburg.twodeedoo.scene.test.StubTextPuppet;

/**
 * Test {@link FPSDisplayActor} against several elapsed times.
 * @author anton
 *
 */
public class FPSDisplayActorTest {

	private StubTextPuppet textPuppet;
	private FPSDisplayActor testee;

	/**
	 * Set up the text puppet and the FPS actor.
	 */
	@Before
	public void setUp(){
		this.textPuppet = new StubTextPuppet();
		this.testee = new FPSDisplayActor(IScene.NULL_OBJECT, this.textPuppet);
	}
	
	@Test
	public void testFPScomputation10ms() {
		this.testee.run(10);
		assertEquals("100 fps", textPuppet.getLastText());
	}

	/**
	 * Expect the default string when less than 1 FPS.
	 */
	@Test
	public void testFPScomputation2000ms() {
		this.testee.run(2000);
		assertEquals("  0 fps", textPuppet.getLastText());
	}

	/**
	 * Expect the default string when 0ms have elapsed.
	 */
	@Test
	public void testFPScomputation0ms() {
		this.testee.run(0);
		assertEquals("  0 fps", textPuppet.getLastText());
	}
}
