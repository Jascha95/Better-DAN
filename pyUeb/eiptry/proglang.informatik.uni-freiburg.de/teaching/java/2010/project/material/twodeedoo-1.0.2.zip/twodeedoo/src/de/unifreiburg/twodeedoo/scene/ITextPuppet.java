package de.unifreiburg.twodeedoo.scene;


/**
 * I display text on a scene.
 * @author anton
 *
 */
public interface ITextPuppet extends IPuppet {
	/**
	 * Change the text to display.
	 * @param text new text.
	 */
	void setText(String text);
}
