package de.unifreiburg.games.drivester;

import java.awt.image.	BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import de.unifreiburg.games.drivester.model.CarActor;
import de.unifreiburg.games.drivester.model.FPSDisplayActor;
import de.unifreiburg.games.drivester.model.GameOverActor;
import de.unifreiburg.twodeedoo.model.IActor;
import de.unifreiburg.twodeedoo.model.SimpleActivity;
import de.unifreiburg.twodeedoo.scene.IScene;
import de.unifreiburg.twodeedoo.scene.ITextPuppet;
import de.unifreiburg.twodeedoo.scene.MultiImagePartPuppet;
import de.unifreiburg.twodeedoo.scene.SimpleScene;
import de.unifreiburg.twodeedoo.scene.SimpleTextPuppet;
import de.unifreiburg.twodeedoo.view.IBrush;
import de.unifreiburg.twodeedoo.view.IGame;
import de.unifreiburg.twodeedoo.view.ImagePart;
import de.unifreiburg.twodeedoo.view.SceneView;

/**
 * Main class, keeps track of all resources and starts the reactor
 * @author anton
 *
 */
public class DrivesterGameApp implements IGame, Runnable{
	/**
	 * The main window. 
	 */
	private JFrame mainWindow;
	/**
	 * the UI component which displays the scene.
	 */
	private SceneView sceneView;
	
	/**
	 * puppet for the car. Reusable between game restarts
	 */
	private MultiImagePartPuppet carPuppet;
	/**
	 * Puppet for the background. Reusable between game restarts.
	 */
	private MultiImagePartPuppet backgroundPuppet;	
	/**
	 * Puppet for the GAME OVER message. Reusable between game restarts.
	 */
	private MultiImagePartPuppet messagePuppet;
	/**
	 * The scene. Recreate at game restart.
	 */
	private IScene scene;
	/**
	 * The activity of displaying the GameOver message. Recreate at game restart.
	 */
	private SimpleActivity gameOverActivity;
	/**
	 * The activity of racing a car around. Recreate at game restart.
	 */
	private SimpleActivity gameActivity;
	/**
	 * Steer the car. Recreate at game restart.
	 */
	private IActor carActor;
	/**
	 * A bitmap of a car in several directions
	 */
	private BufferedImage carImage;
	/**
	 * The background bitmap
	 */
	private BufferedImage backgroundImage;
	/**
	 * A bitmap with a transparent ``GAME OVER'' message
	 */
	private BufferedImage gameOverImage;
	/**
	 * The text puppet which displays FPS.
	 */
	private ITextPuppet fpsTextPuppet;
	/**
	 * The actor which measures FPS and displays it on {@link #fpsTextPuppet}.
	 */
	private FPSDisplayActor fpsDisplayActor;
	/**
	 * All one-time initializations, all begin-of-game initializations
	 * @throws IOException picture loading failure.
	 */
	public void init() throws IOException{
		initUI();
		loadImages();
		restart();
	}

	/**
	 * Load all images. one-time initialization. 		
	 * @throws IOException if image loading fails.
	 */
	private void loadImages() throws IOException {
		loadCarImage();
		loadBackgroundImage();
		loadGameOverImage();
	}


	/**
	 * Init the user interface (do that once) 
	 */
	private void initUI() {
		initSceneView();
		initWindow();
	}


	/**
	 * Create a Swing window to contain the scene view.
	 */
	private void initWindow() {
		mainWindow = new JFrame("The game");
		mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainWindow.add(sceneView);
		mainWindow.pack();
	}


	/**
	 * Create the {@link #sceneView}. Leave it invisible and with the timer not running.
	 */
	private void initSceneView() {
		sceneView = new SceneView(800,600);
	}


	/**
	 * create puppets from images.
	 */
	private void initPuppets()  {
		initCarPuppet();
		initBackgroundPuppet();
		initGameOverMessagePuppet();
		initFPSTextPuppet();
	}


	/**
	 * Load car images, creating {@link #carPuppet}.
	 * @throws IOException image loading failure.
	 */
	private void initCarPuppet() {
		ImagePart car1 = new ImagePart(carImage, 0, 256, 96, 64);
		ImagePart car2= new ImagePart(carImage, 96, 256, 64, 64);
		ImagePart car3= new ImagePart(carImage, 0, 256+64, 96, 64);
		ImagePart car4= new ImagePart(carImage,0+96, 256+64, 64, 64);
		this.carPuppet = new MultiImagePartPuppet(car1);
		carPuppet.addImagePart(car2);
		carPuppet.addImagePart(car3);
		carPuppet.addImagePart(car4);
	}


	/**
	 * Read the car image into {@link #carImage}.
	 * @throws IOException if loading fails
	 */
	private void loadCarImage() throws IOException {
		this.carImage = ImageIO.read(new File("img/carsprites.png"));
	}


	/**
	 * create {@link #backgroundPuppet} from {@link #backgroundImage}
	 */
	private void initBackgroundPuppet()  {
		ImagePart backgroundPart = new ImagePart(backgroundImage);
		backgroundPuppet = new MultiImagePartPuppet(backgroundPart);
	}


	/**
	 * Load background picture {@link #backgroundImage}
	 * @throws IOException if loading fails
	 */
	private void loadBackgroundImage() throws IOException {
		this.backgroundImage = ImageIO.read(new File("img/back.jpg"));
	}


	/**
	 * Create {@link #messagePuppet} for game over message from {@link #gameOverImage}
	 */
	private void initGameOverMessagePuppet() {
		IBrush gameOverImagePart = new ImagePart(gameOverImage );
		this.messagePuppet = new MultiImagePartPuppet(gameOverImagePart );
	}


	/**
	 * Load the Game Over message picture into {@link #gameOverImage}.
	 * @throws IOException if image loading fails
	 */
	private void loadGameOverImage() throws IOException {
		this.gameOverImage = ImageIO.read(new File("img/gameover.png"));
	}

	/**
	 * Init {@link #fpsTextPuppet} with a text puppet.
	 */
	private void initFPSTextPuppet() {
		this.fpsTextPuppet = new SimpleTextPuppet(10, 20);		
	}
	

	/**
	 * Init scene and actors (can be called again to reset the game state)
	 */
	@Override
	public void restart() {
		initScene();
		initPuppets();
		initGameOverActivity();
		initGameActivity();
	}


	
	/**
	 * @see de.unifreiburg.twodeedoo.view.IGame#quit()
	 */
	@Override
	public void quit() {
		sceneView.stop();
		mainWindow.dispose();
	}


	/**
	 * Init the {@link #scene}. Requires {@link #sceneView}.
	 */
	private void initScene() {
		scene = new SimpleScene();
		sceneView.setScene(scene);
	}


	/**
	 * init the {@link #gameActivity}. Requires {@link #gameOverActivity} and {@link #sceneView}. 
	 */
	private void initGameActivity() {
		this.gameActivity = new SimpleActivity(scene, sceneView);
		sceneView.setMainSchedulable(gameActivity);
		sceneView.setKeyHandler(gameActivity);
		initBackground();
		initCar();
		initFPSDisplay();
	}


	/**
	 * init {@link #carActor}. Requires {@link #gameActivity}, {@link #gameOverActivity},
	 * puppets and scene.
	 */
	private void initCar() {
		this.carActor = new CarActor(scene, carPuppet , 0, 100, 0.07, gameOverActivity );
		gameActivity.addActor(carActor);

		scene.addPuppet(carPuppet);
	}


	/**
	 * Set up the background image (no actor)
	 */
	private void initBackground()  {
		scene.addPuppet(backgroundPuppet);
	}

	/**
	 * Init the FPS display actor.
	 */
	private void initFPSDisplay(){
		this.fpsDisplayActor = new FPSDisplayActor(scene, fpsTextPuppet);
		this.gameActivity.addActor(fpsDisplayActor);
		scene.addPuppet(fpsTextPuppet);
	}

	/**
	 * Init {@link #gameOverActivity}. Requires {@link #sceneView}, scene, puppets.
	 */
	private void initGameOverActivity()  {
		this.gameOverActivity = new SimpleActivity(scene, sceneView);
		
		GameOverActor gameOverActor = new GameOverActor(scene, messagePuppet, this);
		gameOverActivity.addActor(gameOverActor);
	}


	/**
	 * Start interacting with the game. Requires full initialization.
	 */
	public void startPlaying() {
		mainWindow.setVisible(true);
		sceneView.initTimer();
		sceneView.initKey();
	}

	/**
	 * This will be the first method to be run. Call this on the GUI thread, not 
	 * on the main thread!
	 */
	@Override
	public void run() {
		try {
			init();
			startPlaying();
		} catch (IOException e) {
			e.printStackTrace(); // being lazy!
		}
	}
}
