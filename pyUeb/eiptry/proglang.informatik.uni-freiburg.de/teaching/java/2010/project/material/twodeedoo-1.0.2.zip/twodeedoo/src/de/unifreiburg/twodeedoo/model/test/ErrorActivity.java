package de.unifreiburg.twodeedoo.model.test;

import de.unifreiburg.twodeedoo.model.IActivity;
import de.unifreiburg.twodeedoo.model.IActor;
import de.unifreiburg.twodeedoo.test.UnimplementedStubCalledException;

/**
 * Implementation of {@link IActivity} which raises {@link UnimplementedStubCalledException} 
 * for each method call.
 * 
 * @author anton
 *
 */
public class ErrorActivity implements IActivity {

	@Override
	public void addActor(IActor a) {
		throw new UnimplementedStubCalledException();
	}

	@Override
	public void switchToActivity(IActivity otherActivity) {
		throw new UnimplementedStubCalledException();
	}

	@Override
	public boolean run(int elapsedTimeMillis) {
		throw new UnimplementedStubCalledException();
	}

	@Override
	public void keyPressed(int keyCode) {
		throw new UnimplementedStubCalledException();
	}

	@Override
	public void keyReleased(int keyCode) {
		throw new UnimplementedStubCalledException();
	}

}
