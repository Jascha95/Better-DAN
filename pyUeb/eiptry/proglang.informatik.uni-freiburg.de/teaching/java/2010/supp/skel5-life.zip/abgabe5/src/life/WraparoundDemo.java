package life;

/**
 * Demo for wrapping array indices.
 * 
 * @author anton
 *
 */
public class WraparoundDemo {

	/**
	 * Demonstrate wraparound computation
	 * @param args ignored
	 */
	public static void main(String[] args) {
		System.out.println("Grid of 7.");
		System.out.print("3 has neighbours: ");
		System.out.print(wrap(7, 3-1));
		System.out.print(" and ");
		System.out.println(wrap(7, 3+1));
		System.out.print("0 has neighbours: ");
		System.out.print(wrap(7, 0-1));
		System.out.print(" and ");
		System.out.println(wrap(7, 0+1));
		System.out.print("6 has neighbours: ");
		System.out.print(wrap(7, 6-1));
		System.out.print(" and ");
		System.out.println(wrap(7, 6+1));
	}

	/**
	 * Wrap indices around array borders. 
	 * @param numRows number of array elements
	 * @param rowIndex an index (at least -numRows; at most maxint-numRows)
	 * @return an index congruent to rowIndex modulo numRows. 
	 */
	private static int wrap(int numRows, int rowIndex){
		// % computes remainder (but negative left-hand-side gives negative remainder,
		// so we add numRows first.
		return (rowIndex + numRows)%numRows;
	}
}
