package life;

/**
 * Model of a rectangular grid with a fixed number of rows and columns,
 * numbered starting at 0. Each cell contains a boolean.
 * 
 * The model also has a way of updating itself.
 * 
 * @author anton
 *
 */
public interface IGridModel {
	/**
	 * Read the given cell.
	 * @param row 0-based row index, must be less than {@link #getRows()}
	 * @param col 0-based column index, must be less than {@link #getColumns()}
	 * @return cell contents
	 */
	boolean getCell(int row, int col);
	
	/**
	 * Modify the given cell.
	 * @param row 0-based row index, must be less than {@link #getRows()}
	 * @param col 0-based column index, must be less than {@link #getColumns()}
	 * @param contents the new cell contents
	 */
	void setCell(int row, int col, boolean contents);
	
	/**
	 * Get number of rows. You can assume this to be constant during
	 * the grid's lifetime.
	 * @return number of rows
	 */
	int getRows();
	
	/**
	 * Get number of columns. You can assume this to be constant during
	 * the grid's lifetime.
	 * @return number of columns
	 */
	int getColumns();
	
	/**
	 * Update the grid according to the model-specific rules.  
	 */
	void computeNextGeneration();
}
