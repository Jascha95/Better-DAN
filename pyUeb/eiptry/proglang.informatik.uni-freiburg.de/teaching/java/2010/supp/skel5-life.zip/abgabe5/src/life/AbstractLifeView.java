package life;

import java.awt.Dimension;
import java.awt.Graphics;
import java.io.Serializable;

import javax.swing.JComponent;

/**
 * A view to display {@link IGridModel}s with colored rectangles. 
 * 
 * @author anton
 *
 */
abstract public class AbstractLifeView extends JComponent implements IView{
	
	/**
	 * Size of each cell in pixels
	 */
	protected int cellWidth, cellHeight;
	
	/**
	 * The model to be displayed
	 */
	protected IGridModel model;
	
	/**
	 * Create a new view
	 * @param model the grid to display
	 * @param cellWidth how wide to paint each cell, in pixels  
	 * @param cellHeight how high to paint each cell, in pixels
	 */
	public AbstractLifeView(IGridModel model, int cellWidth, int cellHeight) {
		super();
		this.model = model;
		this.cellWidth = cellWidth;
		this.cellHeight = cellHeight;
	}

	/**
	 * We inherit {@link Serializable}, so we need a version ID, or we get a warning.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * How big do we want to be on screen?
	 */
	@Override
	public Dimension getPreferredSize() {
		return new Dimension(model.getColumns() * cellWidth,
				model.getRows()* cellHeight);
	}

	/**
	 * Paint the cells.
	 * This will be called by Swing when the time has come for repainting. 
	 */
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		this.paintCells(g);
		//g.setColor( aliveColor );
		//g.drawString("TODO: paint something", 40, 50);
		// g.fillRect(x, y, width, height);
	}
	/**
	 * Paint the cells of {@link #model}. 
	 * @param g a graphics context.
	 */
	abstract protected void paintCells(Graphics g);
	
	/**
	 * Whenever the model changes, tell Swing that we'd like to repaint
	 * some time soon.
	 */
	public void modelChanged() {
		repaint();
	}
	
}
