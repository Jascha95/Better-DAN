package life;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.Timer;

/**
 * Abstract base to connect a {@link IGridModel} with 
 * a {@link LifeView} in a window and manage periodical updates.
 * <p>
 * What subclasses must fill in: one factory method for models and
 * one for views.
 * 
 * @author anton
 *
 */
abstract public class AbstractLifeApp implements ActionListener {
	/**
	 * My main window.
	 */
	private JFrame mainWindow;
	
	/**
	 * The visual representation of the grid.
	 */
	private AbstractLifeView view;
	
	/**
	 * The grid.
	 */
	private IGridModel model;
	
	/**
	 * Periodic timer to kick off updates
	 */
	private Timer repaintTimer;
	
	/**
	 * Init the model and the view, but don't start updating yet.
	 * @param rows number of rows in the model (and the view)
	 * @param columns number of columns in the model (and the view)
	 * @param cycleTimeMillis time between two updates in ms
	 */
	public AbstractLifeApp(int rows, int columns, int cycleTimeMillis){
		this.mainWindow = new JFrame();
		mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.model = createModel(rows, columns);
		this.view = createView(this.model);
		
		mainWindow.add(view);
		mainWindow.pack();
		
		repaintTimer = new Timer(cycleTimeMillis, this);
	}

	/**
	 * Create a model with the given number of rows and columns.
	 * @param rows number of rows, at least 1
	 * @param columns number of columns, at least 1
	 */
	abstract protected IGridModel createModel(int rows, int columns);

	/**
	 * Create a view which displays the given model
	 * @param model some {@link IGridModel}
	 * @return a fresh LifeView
	 */
	abstract protected AbstractLifeView createView(IGridModel model);

	/**
	 * Show the window and begin updating
	 */
	public void start(){
		mainWindow.setVisible(true);
		repaintTimer.setRepeats(true);
		repaintTimer.start();
	}
	
	/**
	 * {@link ActionListener} method which is called by the timer for each tick.
	 * Update the model and force the view to refresh.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		model.computeNextGeneration();
		view.modelChanged();		
	}

}
