package life;

/**
 * Container for the GUI main method
 * @author anton
 *
 */
public class GuiRunner {
	/**
	 * Run a {@link LifeApp}
	 * @param args command line args to be ignored
	 */
	public static void main(String[] args){
		//LifeApp app = new LifeApp(50, 50, 80);
		//app.start();
	}
}
