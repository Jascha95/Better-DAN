package life;

/**
 * I display something. You can notify me when the model has changed so
 * that I update my visual representation. 
 * 
 * @author anton
 *
 */
public interface IView {
	/**
	 * Call this when the model which I display has changed.
	 */
	void modelChanged();
}
