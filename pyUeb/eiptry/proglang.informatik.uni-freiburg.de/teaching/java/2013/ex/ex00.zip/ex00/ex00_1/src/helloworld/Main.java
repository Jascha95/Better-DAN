package helloworld;
/**
 * Simple main class.
 */
class Main   {
	/**
	 * Initial main method which prints the famous "Hello World" string.
	 */
    public void main() {
        System.out.println("Hello World!");
    }
}
