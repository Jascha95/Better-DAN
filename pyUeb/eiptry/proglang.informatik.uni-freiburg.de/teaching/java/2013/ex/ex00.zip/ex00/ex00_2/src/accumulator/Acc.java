package accumulator;

public class Acc {
    private int i;
    public int add(int i) {
        this.i += i;
        return i;
    }

    public int GetResult() {
        return this.i;
    }
}
