package simplechess;

public enum PieceKind {
        QUEEN,
        KNIGHT,
        BISHOP,
        ROOK
}
