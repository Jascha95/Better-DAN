package subsequence;

public enum PartialOrdering {
    LESS,
    EQUAL,
    GREATER,
    INCOMPARABLE
}
