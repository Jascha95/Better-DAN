package formatsi;

import org.junit.Test;

import static org.junit.Assert.*;

public class FormatTest {
    @Test
    public void formatSI() throws Exception {
    }

    @Test
    public void formatSIFailing() throws Exception {
    }

}
