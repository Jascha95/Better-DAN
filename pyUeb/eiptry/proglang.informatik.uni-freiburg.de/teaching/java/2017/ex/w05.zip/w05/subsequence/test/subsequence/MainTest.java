package subsequence;


import org.junit.Test;

import static org.junit.Assert.*;
import static subsequence.PartialOrdering.*;

/**
 * Created by thiemann on 21.05.17.
 */
public class MainTest {
    @Test
    public void subsequenceCompare() {
    }

}
