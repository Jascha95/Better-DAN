package lineintersection;

import org.junit.Test;

import static org.junit.Assert.*;

public class GeometryTest {
    @Test
    public void lineIntersection() throws Exception {
    }


}
