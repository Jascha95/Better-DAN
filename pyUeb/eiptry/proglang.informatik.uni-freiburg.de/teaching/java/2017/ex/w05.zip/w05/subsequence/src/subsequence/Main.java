package subsequence;

/**
 * Created by thiemann on 21.05.17.
 */
public class Main {
    public static PartialOrdering subsequenceCompare(String s1, String s2) {
        return PartialOrdering.LESS;
    }
}

