package stdin;


import java.util.Scanner;

// read  3 ints from sdtin and print each on a new line
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        // please put your code here ...
    }
}
