package addtwoints;

import java.util.Scanner;

// read two ints from stdin, add them and print out the result.
public class Main {

    public static void main(String[] args) {

        // please put your code here ...
    }
}
