package sessions2;

/**
 * Message kind: a message can either be a command, or data.
 * Created by thiemann on 18.06.17.
 */
public enum MessageKind {
    DATA, COMMAND
}
