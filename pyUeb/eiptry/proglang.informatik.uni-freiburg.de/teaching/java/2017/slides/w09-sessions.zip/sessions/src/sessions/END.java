package sessions;

import java.util.Queue;

/**
 * Created by thiemann on 17.07.17.
 */
public class END implements Session {
    @Override
    public boolean check(Queue<Message> trace) {
        return trace.isEmpty();
    }

    @Override
    public Session dual() {
        return new END();
    }
}
