package sessions;

import java.util.Queue;

/**
 * Created by thiemann on 17.07.17.
 */
public class Receive implements Session {
    private final Session next;
    public Receive(Session next) {
        this.next = next;
    }

    @Override
    public boolean check(Queue<Message> trace) {
        if (trace.isEmpty()) {
            return false; // want to receive, but no message left
        }
        Message m = trace.poll();
        if (m.getKind() == MessageKind.DATA &&
                m.getMode() == MessageMode.RECEIVE) {
            return next.check(trace);
        }
        return false;
    }

    @Override
    public Session dual() {
        return new Send(next.dual());
    }
}
