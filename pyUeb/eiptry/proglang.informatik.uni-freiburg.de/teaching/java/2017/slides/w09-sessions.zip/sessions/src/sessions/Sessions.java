package sessions;

import java.util.Map;

/**
 * Created by thiemann on 17.07.17.
 */
public class Sessions {
    public static Session send(Session next) {
        return new Send(next);
    }
    public static Session receive(Session next) {
        return new Receive(next);
    }
    public static Session end() {
        return new END();
    }
    public static Session select(Map<String,Session> selectMap) {
        return new Choice(MessageMode.SEND, selectMap);
    }
    public static Session branch(Map<String, Session> clauses) {
        return new Choice(MessageMode.RECEIVE, clauses);
    }
}
