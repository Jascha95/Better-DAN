package sessions;

import java.util.HashMap;
import java.util.Map;
import java.util.Queue;

/**
 * Created by thiemann on 17.07.17.
 */
public class Choice implements Session {
    private final MessageMode mode;
    private final Map<String, Session> clauses;

    public Choice(MessageMode mode, Map<String, Session> clauses) {
        this.mode = mode;
        this.clauses = clauses;
    }

    @Override
    public boolean check(Queue<Message> trace) {
        if (trace.isEmpty()) {
            return false;
        }
        Message m = trace.poll();
        String pld = m.getPayLoad();
        if (m.getKind() == MessageKind.COMMAND &&
                m.getMode() == this.mode &&
                clauses.keySet().contains(pld)) {
            return clauses.get(pld).check(trace);
        }
        return false;
    }

    @Override
    public Session dual() {
        Map<String, Session> newClauses = new HashMap<>();
        for (String key : clauses.keySet()) {
            newClauses.put(key, clauses.get(key).dual());
        }
        return new Choice(mode.dual(), newClauses);
    }

    @Override
    public String toString() {
        return "Choice{" +
                "mode=" + mode +
                ", clauses=" + clauses +
                '}';
    }
}
