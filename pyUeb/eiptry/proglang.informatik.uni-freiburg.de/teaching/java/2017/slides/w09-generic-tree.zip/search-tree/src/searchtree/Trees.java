package searchtree;

/**
 * Created by thiemann on 03.07.17.
 */
public class Trees {
    public static Tree makeTree(int[] elements) {
        Tree result = new Leaf();
        for( int i : elements) {
            result = result.add(i);
        }
        return result;
    }
}
