package searchtree;

/**
 * Created by thiemann on 03.07.17.
 */
public class Leaf implements Tree {
    @Override
    public Tree add(int i) {
        return new Node(new Leaf(), i, new Leaf());
    }

    @Override
    public boolean contains(int i) {
        return false;
    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public String elementsAsString() {
        return "";
    }
}
