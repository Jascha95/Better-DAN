package generictree;

import org.junit.Test;

import static org.junit.Assert.*;

public class TestExamples {

    @Test
    public void exampleTests() {
        Tree<Integer> t = Trees.makeTree(new Integer[]{2, 3, 4, 4, 1});
        assertTrue(t.contains(4));
        assertFalse(t.contains(6));
        assertEquals(4, t.size());

        Tree<Integer> t2 = t.add(6).add(7).add(6);
        assertFalse(t.contains(6));
        assertTrue(t2.contains(6));
        assertEquals(6, t2.size());
        assertEquals(4, t.size());

        assertEquals("1, 2, 3, 4, 6, 7", t2.elementsAsString());
        assertEquals("1, 2, 3, 4", t.elementsAsString());

    }

    @Test
    public void testOneNode() {
        Tree<Integer> oneNode = Trees.makeTree(new Integer[]{42});
        assertEquals(1, oneNode.size());
        assertEquals("42", oneNode.elementsAsString());
        assertTrue(oneNode.contains(42));
        assertFalse(oneNode.contains(4711));
    }

    @Test
    public void testEmpty() {
        Tree<Integer> empty = Trees.makeTree(new Integer[]{});
        assertEquals(0, empty.size());
        assertEquals("", empty.elementsAsString());
        assertFalse(empty.contains(0));
    }

    @Test
    public void exampleStringTests() {
        Tree<String> t = Trees.makeTree(new String[]{"2", "3", "4", "4", "1"});
        assertTrue(t.contains("4"));
        assertFalse(t.contains("6"));
        assertEquals(4, t.size());

        Tree<String> t2 = t.add("6").add("7").add("6");
        assertFalse(t.contains("6"));
        assertTrue(t2.contains("6"));
        assertEquals(6, t2.size());
        assertEquals(4, t.size());

        assertEquals("1, 2, 3, 4, 6, 7", t2.elementsAsString());
        assertEquals("1, 2, 3, 4", t.elementsAsString());

    }


    @Test
    public void testOneStringNode() {
        Tree<String> oneNode = Trees.makeTree(new String[]{"Hello"});
        assertEquals(1, oneNode.size());
        assertEquals("Hello", oneNode.elementsAsString());
        assertTrue(oneNode.contains("Hello"));
        assertFalse(oneNode.contains("Fifi"));
    }

}