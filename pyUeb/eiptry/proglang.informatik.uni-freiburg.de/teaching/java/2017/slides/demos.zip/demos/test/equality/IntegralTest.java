package equality;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by thiemann on 13.06.17.
 */
public class IntegralTest {

    private Integral zero;
    private Integral one;

    @Before
    public void setUp() {
        zero = new Integral(0, 0);
        one = new Integral(44, 43);
    }

    @Test
    public void add() {
        assertEquals(zero, zero.add(zero));
        assertEquals(one, zero.add(one));
        assertEquals(new Integral(1002, 1000), one.add(one));
        assertEquals(new Integral(0,10),
                new Integral(15, 10).add(new Integral(5, 20)));
    }

    @Test
    public void sub() throws Exception {
    }

    @Test
    public void toInt() {
        assertEquals(0, zero.toInt());
        assertEquals(1, one.toInt());
        assertEquals(-15, new Integral(5, 20).toInt());
    }

    @Test
    public void testEquals() {
        assertTrue(zero.equals(new Integral(52, 52)));
        assertTrue(zero.equals(new Integral(4711, 4711)));
        assertFalse(zero.equals(one));
        assertTrue(one.equals(new Integral(11, 10)));
    }

    @Test
    public void testHashCode() throws Exception {
    }

}