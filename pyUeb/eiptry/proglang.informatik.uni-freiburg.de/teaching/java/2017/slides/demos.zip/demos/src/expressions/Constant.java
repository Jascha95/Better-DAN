package expressions;

/**
 * Created by thiemann on 19.06.17.
 */
public class Constant implements Expression {
    private final int value;

    public Constant(int value) {
        this.value = value;
    }

    @Override
    public int eval(State state) {
        return value;
    }
}
