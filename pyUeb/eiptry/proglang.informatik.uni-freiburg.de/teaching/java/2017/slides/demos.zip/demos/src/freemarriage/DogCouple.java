package freemarriage;

/**
 * Created by thiemann on 03.07.17.
 */
public class DogCouple extends Couple<Dog, Dog> {
    public DogCouple(Dog dog, Dog dog2) {
        super(dog, dog2);
    }
}
