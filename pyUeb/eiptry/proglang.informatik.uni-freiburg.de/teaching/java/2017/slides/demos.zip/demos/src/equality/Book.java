package equality;

/**
 * Created by thiemann on 13.06.17.
 */
public class Book {
    private final String lastName; // of author
    private final String firstName; // of author
    private final String title;
    private final String city;
    private final String publisher;
    private final int year;

    public Book(String lastName, String firstName, String title, String city, String publisher, int year) {
        // make sure that all string != null
        if (lastName == null
                || firstName == null
                || title == null
                || city == null
                || publisher == null) {
            throw new IllegalArgumentException("null string argument detected");
        }
        this.lastName = lastName;
        this.firstName = firstName;
        this.title = title;
        this.city = city;
        this.publisher = publisher;
        this.year = year;
    }

    @Override
    public String toString() {
        return "Book{" +
                "lastName='" + lastName + '\'' +
                ", firstName='" + firstName + '\'' +
                ", title='" + title + '\'' +
                ", city='" + city + '\'' +
                ", publisher='" + publisher + '\'' +
                ", year=" + year +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Book book = (Book) o;

        if (year != book.year) return false;
        if (!lastName.equals(book.lastName)) return false;
        if (!firstName.equals(book.firstName)) return false;
        if (!title.equals(book.title)) return false;
        // if (!city.equals(book.city)) return false;
        return publisher.equals(book.publisher);
    }

    @Override
    public int hashCode() {
        int result = lastName.hashCode();
        result = 31 * result + firstName.hashCode();
        result = 31 * result + title.hashCode();
        // result = 31 * result + city.hashCode();
        result = 31 * result + publisher.hashCode();
        result = 31 * result + year;
        return result;
    }
}
