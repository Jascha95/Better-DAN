package deepcopy;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by thiemann on 19.06.17.
 */
public class BouquetTest {
    private Flower rose;
    private Flower tulip;
    private Flower violet;
    private List<Flower> flowers;

    @Before
    public void setup() {
        rose = new Flower("Rose");
        tulip = new Flower("Tulip");
        violet = new Flower("Violet");
        flowers = new ArrayList<>();
        flowers.add(rose);
        flowers.add(tulip);
        flowers.add(violet);
    }

    @Test
    public void test0() {
        Bouquet b = new Bouquet("For Mary", flowers);
        String originalBouquet = b.toString();
        System.out.println(originalBouquet);

        // Mary:
        List<Flower> myflowers = b.getContent();
        String originalContent = myflowers.toString();
        System.out.println(originalContent);

        myflowers.remove(new Flower("Rose"));
        flowers.remove(new Flower("Tulip"));

        String afterBouquet = b.toString();
        String afterMyflowers = myflowers.toString();
        System.out.println(afterBouquet);
        System.out.println(afterMyflowers);

        assertFalse(originalBouquet.equals(afterBouquet));
        assertFalse(originalContent.equals(afterMyflowers));
        assertTrue(myflowers.equals(b.getContent()));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void test1() {
        Bouquet b = new Bouquet("For Mary",
                flowers);
        System.out.println(b.toString());

        // Mary:
        List<Flower> myflowers = b.unmodifiableContent();
        System.out.println(myflowers.toString());

        myflowers.remove(new Flower("Rose"));   // exception
        flowers.remove(new Flower("Tulip"));

        System.out.println(b.toString());
        System.out.println(myflowers.toString());
    }

    @Test
    public void test1b() {
        Bouquet b = new Bouquet("For Mary",
                flowers);
        System.out.println(b.toString());

        // Mary:
        List<Flower> myflowers = b.unmodifiableContent();
        System.out.println(myflowers.toString());

        //myflowers.remove(new Flower("Rose"));   // exception
        flowers.remove(new Flower("Tulip"));

        System.out.println(b.toString());
        System.out.println(myflowers.toString());

        assertTrue(myflowers.equals(b.getContent()));
    }

    @Test
    public void test2() {
        Bouquet b = new Bouquet("For Cathy", flowers);
        System.out.println(b.toString());

        // Cathy
        List<Flower> myflowers = b.shallowCopyContent();
        System.out.println(myflowers.toString());

        myflowers.remove(new Flower("Violet"));
        System.out.println(myflowers.toString());
        System.out.println(b.toString());

        Flower f = myflowers.get(0);
        f.setState(FlowerState.FULL_BLOSSOM);
        System.out.println(f.toString());
        System.out.println(myflowers.toString());
        System.out.println(b.toString());
    }

    @Test
    public void test3() {
        Bouquet b = new Bouquet("For John", flowers);
        System.out.println(b.toString());

        // John
        List<Flower> myflowers = b.deepCopyContent();
        System.out.println(myflowers.toString());

        myflowers.remove(new Flower("Violet"));
        System.out.println(myflowers.toString());
        System.out.println(b.toString());

        Flower f = myflowers.get(0);
        f.setState(FlowerState.FULL_BLOSSOM);
        System.out.println(f.toString());
        System.out.println(myflowers.toString());
        System.out.println(b.toString());

    }

}