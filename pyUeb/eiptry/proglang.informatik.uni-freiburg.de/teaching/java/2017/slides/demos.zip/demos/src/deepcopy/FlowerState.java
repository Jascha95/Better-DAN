package deepcopy;

/**
 * Created by thiemann on 19.06.17.
 */
public enum FlowerState {
    FRESH, FULL_BLOSSOM, WITHERING, ROTTEN
}
