package deepcopy;

/**
 * Created by thiemann on 19.06.17.
 */
public class Flower {
    private final String name;
    private FlowerState state;

    public Flower(String name) {
        this.name = name;
        this.state = FlowerState.FRESH;
    }

    private Flower(String name, FlowerState state) {
        this.name = name;
        this.state = state;
   }

    public FlowerState getState() {
        return state;
    }

    public void setState(FlowerState state) {
        this.state = state;
    }

    public Flower copy() {
        return new Flower(name, state);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Flower flower = (Flower) o;

        return name != null ? name.equals(flower.name) : flower.name == null;
    }

    @Override
    public int hashCode() {
        return name != null ? name.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Flower{" +
                "name='" + name + '\'' +
                ", state=" + state +
                '}';
    }
}
