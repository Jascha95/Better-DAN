package expressions;

/**
 * Created by thiemann on 19.06.17.
 */
public interface Expression {
    public int eval(State state);
}
