package freemarriage;

/**
 * Created by thiemann on 03.07.17.
 */
public class Couple<CRIS, CROS> {
    private final CRIS cris;
    private final CROS cros;

    public Couple(CRIS cris, CROS cros) {
        this.cris = cris;
        this.cros = cros;
    }

    /**
     * Swap roles in this partnership.
     * @return the new partnership.
     */
    public Couple<CROS, CRIS> swapRoles() {
        return new Couple<CROS, CRIS>(cros, cris);
    }

    /**
     * Replace the cros partner by a fresh one.
     * @param newCros
     * @return the new partnership.
     */
    public Couple<CRIS, CROS> replace(CROS newCros) {
        return new Couple<CRIS, CROS> (cris, newCros);
    }

    @Override
    public String toString() {
        return "Couple{" +
                "cris=" + cris +
                ", cros=" + cros +
                '}';
    }
}
