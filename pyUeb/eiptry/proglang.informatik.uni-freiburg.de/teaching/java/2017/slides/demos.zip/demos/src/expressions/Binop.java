package expressions;

/**
 * Created by thiemann on 19.06.17.
 */
public enum Binop {
    ADD, SUB, MUL, DIV, EQUALS, LESSTHAN
}
