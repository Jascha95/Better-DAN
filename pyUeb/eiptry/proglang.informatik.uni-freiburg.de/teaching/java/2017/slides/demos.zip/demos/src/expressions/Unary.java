package expressions;

/**
 * Created by thiemann on 19.06.17.
 */
public class Unary implements Expression {
    private final Unop op;
    private final Expression exp;

    public Unary(Unop op, Expression exp) {
        this.op = op;
        this.exp = exp;
    }

    @Override
    public int eval(State state) {
        int result = exp.eval(state);
        switch (op) {
            case NOT:
                return (result == 0 ? 1 : 0);
            case NEGATE:
                return -result;
            default:
                throw new IllegalStateException();
        }
    }
}
