package freemarriage;

/**
 * Created by thiemann on 03.07.17.
 */
public class Cat {
    private final String name;

    public Cat(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Cat{" + name +
                '}';
    }
}
