package equality;

/**
 * Represent integer number as pairs von natural numbers.
 * We let (m, n) represent (m - n).
 * There many representation for the same integer:
 * (0,1), (1, 2), (2, 3), ... == -1
 * (1,0), (2, 1), (3, 2), ... == 1
 * (0,0), (1,1), ... == 0
 * Created by thiemann on 13.06.17.
 */
public class Integral {
    /**
     * (pos, neg) represents (pos - neg) where pos, neg >= 0.
     */
    private final int pos;
    private final int neg;

    public Integral(int pos, int neg) {
        if (pos < 0 || neg < 0) {
            throw new IllegalArgumentException();
        }
        this.pos = pos;
        this.neg = neg;
    }

    @Override
    public String toString() {
        return "Integral{" +
                "pos=" + pos +
                ", neg=" + neg +
                '}';
    }

    /**
     * Construct new integral representing the sum of this number and the other.
     * @param other
     * @return the sum.
     */
    public Integral add(Integral other) {
        // (m1 - n1) + (m2 - n2) = (m1 + m2) - (n1 + n2)
        return new Integral(this.pos + other.pos, this.neg + other.neg);
    }

    public Integral sub(Integral other) {
        // (m1 - n1) - (m2 - n2) = (m1 + n2) - (n1 - m2)
        return new Integral(this.pos + other.neg, this.neg + other.pos);
    }

    public int toInt() {
        return this.pos - this.neg;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || this.getClass() != other.getClass()) {
            return false;
        }
        Integral that = (Integral) other;

        // (m1 - n1) == (m2 - n2) <==> m1 + n2 == m2 + n1
        return this.pos + that.neg == that.pos + this.neg;
    }

    @Override
    public int hashCode() {
        return toInt();
    }
}
