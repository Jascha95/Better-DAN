package freemarriage;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by thiemann on 03.07.17.
 */
public class DogCoupleTest {
    @Test
    public void makeDogCouple() {
        DogCouple dd =
                new DogCouple(new Dog ("Bello"),
                        new Dog("Hasso"));
        Couple<Dog, Dog> swapped =
                dd.swapRoles();
        Couple<Dog, Dog> woBello =
                swapped.replace(new Dog("Fifi"));
        assertEquals(
                "Couple{cris=Dog{Hasso}, cros=Dog{Fifi}}",
                woBello.toString());
    }
}