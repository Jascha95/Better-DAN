package btree;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by thiemann on 19.06.17.
 */
public class BTreeTest {

    private BTree b0, b1, b2;

    @Before
    public void setup() {
        b0 = new Leaf(42);
        b1 = new Branch(b0, b0);
        b2 = new Branch(b0, b1);
    }

    @Test
    public void testCount() {
        assertEquals(1, b0.count());
        assertEquals(2, b1.count());
        assertEquals(3, b2.count());
    }

    @Test
    public void testHeight() {
        assertEquals(0, b0.height());
        assertEquals(1, b1.height());
        assertEquals(2, b2.height());
    }

    @Test
    public void testMirror() {
        assertEquals(b0, b0.mirror());
        assertEquals(b1, b1.mirror());
        assertEquals(new Branch(b1, b0), b2.mirror());
    }

    @Test
    public void testFull() {
        assertTrue(b0.full() >= 0);
        assertTrue(b1.full() >= 0);
        assertFalse(b2.full() >= 0);
    }

}