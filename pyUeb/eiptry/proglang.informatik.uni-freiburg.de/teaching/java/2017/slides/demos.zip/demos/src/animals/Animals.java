package animals;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by thiemann on 19.06.17.
 */
public class Animals {
    public void test() {
        Animal doggy = new Dog();
        Animal kitty = new Cat();
        Animal fishy = new Fish();

        System.out.println(doggy.makeSound());
        System.out.println(kitty.makeSound());
        System.out.println(fishy.makeSound());

        List<Animal> animals = new ArrayList<>();
        animals.add(doggy);
        animals.add(kitty);

    }
}
