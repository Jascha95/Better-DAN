package animals;

/**
 * Created by thiemann on 19.06.17.
 */
public class Fish implements Animal {
    @Override
    public String makeSound() {
        return "";
    }

    @Override
    public String move() {
        return "schwimmt";
    }

    @Override
    public int getPrice() {
        return 1000;
    }
}
