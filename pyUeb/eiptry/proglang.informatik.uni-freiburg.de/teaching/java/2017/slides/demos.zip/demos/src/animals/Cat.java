package animals;

/**
 * Created by thiemann on 19.06.17.
 */
public class Cat implements Animal {
    @Override
    public String makeSound() {
        return "Miau";
    }

    @Override
    public String move() {
        return "schleichen";
    }

    @Override
    public int getPrice() {
        return 70;
    }
}
