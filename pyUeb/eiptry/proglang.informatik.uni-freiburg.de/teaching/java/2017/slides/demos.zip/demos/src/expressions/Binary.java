package expressions;

import com.sun.javafx.applet.ExperimentalExtensions;

/**
 * Created by thiemann on 19.06.17.
 */
public class Binary implements Expression {
    private final Binop op;
    private final Expression exp1;
    private final Expression exp2;

    public Binary(Binop op, Expression exp1, Expression exp2) {
        this.op = op;
        this.exp1 = exp1;
        this.exp2 = exp2;
    }

    @Override
    public int eval(State state) {
        int result1 = exp1.eval(state);
        int result2 = exp2.eval(state);
        switch (op) {
            case ADD:
                return result1 + result2;
            case SUB:
                return result1 - result2;
            case MUL:
                return result1 * result2;
            case DIV:
                return result1 / result2;
            case EQUALS:
                return (result1 == result2 ? 1 : 0);
            case LESSTHAN:
                return (result1 < result2 ? 1 : 0);
            default:
                throw new IllegalStateException();
        }
    }
}
