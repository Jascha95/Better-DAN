package animals;

/**
 * Created by thiemann on 19.06.17.
 */
public interface Animal {
    public String makeSound();
    public String move();
    public int getPrice();
}
