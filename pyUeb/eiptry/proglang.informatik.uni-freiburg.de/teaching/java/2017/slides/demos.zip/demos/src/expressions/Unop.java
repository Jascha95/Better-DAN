package expressions;

/**
 * Created by thiemann on 19.06.17.
 */
public enum Unop {
    NOT, NEGATE
}
