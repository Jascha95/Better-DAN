package expressions;

import java.util.HashMap;

/**
 * Created by thiemann on 19.06.17.
 */
public class State extends HashMap<String, Integer> {
}
