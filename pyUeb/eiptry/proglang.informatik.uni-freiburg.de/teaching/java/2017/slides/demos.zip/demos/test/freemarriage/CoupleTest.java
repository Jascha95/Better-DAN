package freemarriage;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by thiemann on 03.07.17.
 */
public class CoupleTest {
    @Test
    public void testCouples() {
        Couple<Cat, Dog> cd =
                new Couple<Cat, Dog> (
                        new Cat("Pussy"),
                        new Dog("Bello"));
        assertEquals(
                "Couple{cris=Cat{Pussy}, cros=Dog{Bello}}",
                cd.toString());
        Couple<Dog, Cat> dc = cd.swapRoles();
        assertEquals(
                "Couple{cris=Dog{Bello}, cros=Cat{Pussy}}",
                dc.toString()
        );
        Cat kitty = new Cat("Kitty");
        Couple<Dog, Cat> newdc = dc.replace(kitty);
        assertEquals(
                "Couple{cris=Dog{Bello}, cros=Cat{Kitty}}",
                newdc.toString()
        );
    }
}