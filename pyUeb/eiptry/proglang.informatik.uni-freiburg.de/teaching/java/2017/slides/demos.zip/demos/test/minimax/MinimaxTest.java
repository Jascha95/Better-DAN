package minimax;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by thiemann on 03.07.17.
 */
public class MinimaxTest {
    @Test
    public void testComparableIntString() {
        Integer i1 = new Integer(42);
        Integer i2 = new Integer( 4711);
        int result = i1.compareTo(i2);
        assertTrue(result < 0);

        String s1 = "Affe";
        String s2 = "Banane";
        result = s1.compareTo(s2);
        assertTrue(result < 0);

        assertEquals(0,
                "Birne".compareTo("Birne"));
    }

    @Test
    public void testComparableString () {
        Minimax<String> mm = new Minimax<>("M", "M");
        mm.measured ("Q");
        mm.measured ("L");
        mm.measured ("O");
        mm.measured ("A");
        assertEquals("A", mm.getMinVal());
        assertEquals("Q", mm.getMaxVal());
    }

    @Test
    public void testComparableInteger () {
        Minimax<Integer> mi = new Minimax<> (100,100);
        mi.measured(1000);
        mi.measured(-1);
        mi.measured(4711);
        mi.measured(42);
        assertEquals(new Integer(-1), mi.getMinVal());
        assertEquals(new Integer(4711), mi.getMaxVal());

        assertEquals(-1, (int)mi.getMinVal());
        assertEquals(4711, (int)mi.getMaxVal());
    }
}