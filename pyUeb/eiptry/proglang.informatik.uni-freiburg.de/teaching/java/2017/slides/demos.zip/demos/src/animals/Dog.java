package animals;

/**
 * Created by thiemann on 19.06.17.
 */
public class Dog implements Animal {
    @Override
    public String makeSound() {
        return "Wau";
    }

    @Override
    public String move() {
        return "laufen";
    }

    @Override
    public int getPrice() {
        return 150;
    }
}
