package expressions;

/**
 * Created by thiemann on 19.06.17.
 */
public class Var implements Expression {
    private final String name;

    public Var(String name) {
        this.name = name;
    }

    @Override
    public int eval(State state) {
        return state.get(name);
    }
}
