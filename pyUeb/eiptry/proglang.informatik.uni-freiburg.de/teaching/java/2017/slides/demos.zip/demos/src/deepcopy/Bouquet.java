package deepcopy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by thiemann on 19.06.17.
 */
public class Bouquet {
    private final String name;
    private final List<Flower> content;

    @Override
    public String toString() {
        return "Bouquet{" +
                "name='" + name + '\'' +
                ", content=" + content +
                '}';
    }

    public Bouquet(String name, List<Flower> content) {
        this.name = name;
        this.content = content;
    }
    
    public boolean add(Flower item) {
        return content.add(item);
    }

    public String getName() {
        return name;
    }

    /**
     * Getter for content.
     * @return a shared point to this bouquet's content.
     */
    public List<Flower> getContent() {
        return content;
    }

    public List<Flower> unmodifiableContent() {
        return Collections.unmodifiableList(content);
    }

    public List<Flower> shallowCopyContent() {
        List<Flower> result = new ArrayList<>(content);
        return result;
    }

    public List<Flower> deepCopyContent() {
        List<Flower> result = new ArrayList<>();
        for(Flower f : content) {
            result.add(f.copy());
        }
        return result;
    }
}
