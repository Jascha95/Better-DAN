package minimax;

/**
 * Created by thiemann on 03.07.17.
 */
public class Minimax<V extends Comparable<V>> {
        private V minVal;
        private V maxVal;

    public Minimax(V minVal, V maxVal) {
        this.minVal = minVal;
        this.maxVal = maxVal;
    }

    public V getMinVal() {
        return minVal;
    }

    public V getMaxVal() {
        return maxVal;
    }

    public void measured(V value) {
            if (value.compareTo(minVal) < 0) { minVal = value; }
            if (value.compareTo(maxVal) > 0) { maxVal = value; }
        }
        public void reset (V value) {
            minVal = value;
            maxVal = value;
        }
}
