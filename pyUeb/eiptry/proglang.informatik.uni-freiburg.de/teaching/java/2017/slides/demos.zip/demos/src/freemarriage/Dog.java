package freemarriage;

/**
 * Created by thiemann on 03.07.17.
 */
public class Dog {
    private final String name;

    public Dog(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Dog{" + name  +
                '}';
    }
}
