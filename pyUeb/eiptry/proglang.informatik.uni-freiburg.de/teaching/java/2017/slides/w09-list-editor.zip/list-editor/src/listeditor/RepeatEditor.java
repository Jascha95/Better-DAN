package listeditor;

import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Created by thiemann on 17.07.17.
 */
public class RepeatEditor extends ListEditor {
    public RepeatEditor(PrintWriter out) {
        super(out);
    }

    @Override
    protected void executeMissing(String cmd, Scanner restOfLine) {
        if ("repeat".equals(cmd)) {
            // extension active
            if (restOfLine.hasNextInt()) {
                int n = restOfLine.nextInt();
                String line = restOfLine.nextLine();
                while (n > 0) {
                    pushBack(line);
                    n--;
                }
            } else {
                // illegal command format
            }
        } else {
            throw new InputMismatchException();
        }

    }
}
