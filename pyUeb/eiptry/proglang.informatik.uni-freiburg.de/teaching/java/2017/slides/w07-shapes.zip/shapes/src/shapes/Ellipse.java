package shapes;

/**
 * Created by thiemann on 26.06.17.
 */
public class Ellipse implements Shape {
    private final V2 center;
    private final V2 radii;

    /**
     * Represent an ellipsis.
     * @param center coordinates
     * @param radii horizontal and vertical, must be > 0.
     */
    public Ellipse(V2 center, V2 radii) {
        if (radii.getX() <= 0 || radii.getY() <= 0) {
            throw new IllegalArgumentException();
        }
        this.center = center;
        this.radii = radii;
    }

    @Override
    public boolean contains(V2 point) {
        double dx = point.getX() - center.getX();
        double dy = point.getY() - center.getY();
        double a = radii.getX();
        double b = radii.getY();
        return (dx * dx / a / a + dy * dy / b / b <= 1);
    }

    @Override
    public Shape move(V2 displacement) {
        return new Ellipse(center.move(displacement), radii);
    }

    @Override
    public Box boundingBox() {
        V2 lowerRightCorner =
                new V2( center.getX() - radii.getX(),
                        center.getY() - radii.getY());
        V2 dimension =
                new V2( 2 * radii.getX(),
                        2 * radii.getY());
        return new Box(lowerRightCorner, dimension);
    }
}
