package shapes;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by thiemann on 26.06.17.
 */
public class Picture implements Shape {
    private final List<Shape> shapes;

    public Picture(List<Shape> shapes) {
        this.shapes = shapes;
    }

    @Override
    public boolean contains(V2 point) {
        for(Shape s : shapes) {
            if (s.contains(point)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public Shape move(V2 displacement) {
        List<Shape> result = new ArrayList<>();
        for(Shape s : shapes) {
            result.add(s.move(displacement));
        }
        return new Picture(result);
    }

    @Override
    public Box boundingBox() {
        if (shapes.isEmpty()) {
            return new Box(new V2(0,0), new V2(0,0));
        }
        double llx = 0;
        double lly = 0;
        double urx = 0;
        double ury = 0;
        boolean first = true;
        for (Shape s : shapes) {
            Box bb = s.boundingBox();
            V2 llc = bb.getLowerLeftCorner();
            V2 dim = bb.getDimensions();
            // coordinates of ll and ur corner for current shape s
            double myllx = llc.getX();
            double mylly = llc.getY();
            double myurx = myllx + dim.getX();
            double myury = mylly + dim.getY();
            if (first) {
                // just copy for the first shape in list
                llx = myllx;
                lly = mylly;
                urx = myurx;
                ury = myury;
                first = false;
            } else {
                // push boundaries by taking max and min as appropriate
                llx = Math.min(llx, myllx);
                lly = Math.min(lly, mylly);
                urx = Math.max(urx, myurx);
                ury = Math.max(ury, myury);
            }
        }
        // calculate box dimensions from corners
        V2 bbLowerLeft = new V2(llx, lly);
        V2 bbDimension = new V2(urx-llx, ury-lly);
        return new Box(bbLowerLeft, bbDimension);
    }
}
