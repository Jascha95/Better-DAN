package shapes;

import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;

public class ExampleTests {

    @org.junit.Test
    public void testEllipse() {
        Shape e = Shapes.makeEllipse(new V2(0, 0), new V2(1, 2));
        V2 p1 = new V2(0.5, 1);
        V2 p2 = new V2(1,1);
        assertTrue(e.contains(p1));
        assertFalse(e.contains(p2));

        assertFalse(e.move(new V2(-2, 0))
                     .contains(p1));
    }

    @Test
    public void testRectangle() {
        Shape r = Shapes.makeRectangle(new V2(0,2), new V2(1, 2));
        V2 p1 = new V2(0.5, 1);
        V2 p2 = new V2(1,1);
        assertFalse(r.contains(p1));
        assertFalse(r.contains(p2));

        assertEquals(new Box(new V2(0,2), new V2(1, 2)),
                r.boundingBox());
    }

    @org.junit.Test
    public void testPicture() {
        Shape e = Shapes.makeEllipse(new V2(0, 0), new V2(2, 1));
        // bb: (-2, -1) (4, 2) ur (2,1)
        assertEquals(new Box(new V2(-2, -1), new V2(4,2)),
                e.boundingBox());
        Shape r = Shapes.makeRectangle(new V2(0,2), new V2(1, 2));
        // bb: (0,2) (1, 2) ur (1, 4)
        assertEquals(new Box (new V2(0,2), new V2(1, 2)),
                r.boundingBox());
        V2 p1 = new V2(0.5, 1);
        V2 p2 = new V2(1,1);

        Shape pict = Shapes.makePicture(Arrays.asList(e, r));

        assertFalse(pict.contains(p1));
        assertFalse(pict.contains(p2));
        assertTrue(pict.contains(new V2(1, 0.5)));

        assertEquals(new Box(new V2(-2, -1), new V2(4, 5)),
                pict.boundingBox());
    }
//
//    @Test
//    public void testLarger() {
//        V2 origin = new V2 (0,0);
//        Shape e1 =
//                Shapes.makeEllipse(origin,
//                        new V2(1, 1));
//        Shape e2 =
//                Shapes.makeEllipse(origin,
//                        new V2(1, 2));
//        assertTrue(e2.larger(e1));
//    }

}