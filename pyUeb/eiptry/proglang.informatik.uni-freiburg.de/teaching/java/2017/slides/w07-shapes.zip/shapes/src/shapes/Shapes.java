package shapes;

import java.util.List;

/**
 * Created by thiemann on 26.06.17.
 */
public class Shapes {
    public static Shape makeEllipse(V2 center, V2 radii) {
        return new Ellipse(center, radii);
    }

    public static Shape makeRectangle(V2 upperleftCorner, V2 dimension) {
        return new Rectangle(upperleftCorner, dimension);
    }

    public static Shape makePicture(List<Shape> shapes) {
        return new Picture(shapes);
    }
}
