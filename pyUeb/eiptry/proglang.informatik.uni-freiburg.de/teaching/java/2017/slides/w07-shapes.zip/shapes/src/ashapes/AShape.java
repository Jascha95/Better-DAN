package ashapes;

/**
 * Created by thiemann on 26.06.17.
 */
public abstract class AShape implements Shape {
    public boolean larger(Shape other) {
        return area() >= other.area();
    }
}
