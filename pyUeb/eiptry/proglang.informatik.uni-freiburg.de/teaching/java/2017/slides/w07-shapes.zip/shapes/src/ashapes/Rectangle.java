package ashapes;

/**
 * Created by thiemann on 26.06.17.
 */
public class Rectangle extends AShape {
    private final V2 leftUpperCorner;
    private final V2 dimension;

    public Rectangle(V2 leftUpperCorner, V2 dimension) {
        this.leftUpperCorner = leftUpperCorner;
        this.dimension = dimension;
    }

    @Override
    public boolean contains(V2 point) {
        return false;
    }

    @Override
    public Shape move(V2 displacement) {
        return null;
    }

    @Override
    public Box boundingBox() {
        return null;
    }

    @Override
    public double area() {
        return dimension.getX() * dimension.getY();
    }
}
