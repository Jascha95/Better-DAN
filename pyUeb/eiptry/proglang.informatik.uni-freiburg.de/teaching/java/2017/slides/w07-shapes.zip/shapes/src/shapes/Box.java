package shapes;

/**
 * A class for a box in a cartesian coordinate system.
 */
public class Box {
    private final V2 lowerLeftCorner;
    private final V2 dimensions;

    /**
     * A box is defined by its lower right corner and its dimensions.
     * Dimensions have to be positive.
     */
    public Box(V2 lowerLeftCorner, V2 dimensions) {
        if (dimensions.getX() < 0 || dimensions.getY() < 0) {
            throw new IllegalArgumentException("Bad dimensions: " + dimensions);
        }
        this.lowerLeftCorner = lowerLeftCorner;
        this.dimensions = dimensions;
    }

    public V2 getLowerLeftCorner() {
        return lowerLeftCorner;
    }

    public V2 getDimensions() {
        return dimensions;
    }

    @Override
    public String toString() {
        return "Box{" +
                "lowerLeftCorner=" + lowerLeftCorner +
                ", dimensions=" + dimensions +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Box box = (Box) o;

        if (lowerLeftCorner != null ? !lowerLeftCorner.equals(box.lowerLeftCorner) : box.lowerLeftCorner != null)
            return false;
        return dimensions != null ? dimensions.equals(box.dimensions) : box.dimensions == null;
    }

    @Override
    public int hashCode() {
        int result = lowerLeftCorner != null ? lowerLeftCorner.hashCode() : 0;
        result = 31 * result + (dimensions != null ? dimensions.hashCode() : 0);
        return result;
    }
}
