package ashapes;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by thiemann on 26.06.17.
 */
public class Picture extends AShape {
    private final List<Shape> shapes;

    public Picture(List<Shape> shapes) {
        this.shapes = shapes;
    }

    @Override
    public boolean contains(V2 point) {
        for(Shape s : shapes) {
            if (s.contains(point)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public Shape move(V2 displacement) {
        List<Shape> result = new ArrayList<>();
        for(Shape s : shapes) {
            result.add(s.move(displacement));
        }
        return new Picture(result);
    }

    @Override
    public Box boundingBox() {
        return null;
    }

    @Override
    public double area() {
        double sum = 0;
        for (Shape s : shapes) {
            sum += s.area();
        }
        return sum;
    }
}
