package shapes;

/**
 * Created by thiemann on 26.06.17.
 */
public class Rectangle implements Shape {
    private final V2 lowerLeftCorner;
    private final V2 dimension;

    public Rectangle(V2 lowerLeftCorner, V2 dimension) {
        this.lowerLeftCorner = lowerLeftCorner;
        this.dimension = dimension;
    }

    @Override
    public boolean contains(V2 point) {
        double deltax = point.getX() - lowerLeftCorner.getX();
        double deltay = point.getY() - lowerLeftCorner.getY();
        return (deltax >= 0 && deltax <= dimension.getX()) &&
                (deltay >= 0 && deltay <= dimension.getY());
    }

    @Override
    public Shape move(V2 displacement) {
        return new Rectangle(lowerLeftCorner.move(displacement), dimension);
    }

    @Override
    public Box boundingBox() {
        return new Box(lowerLeftCorner, dimension);
    }
}
