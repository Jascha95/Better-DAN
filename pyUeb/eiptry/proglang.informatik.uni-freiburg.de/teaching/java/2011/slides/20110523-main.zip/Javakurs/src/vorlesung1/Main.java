/**
 * 
 */
package vorlesung1;

/**
 * @author progpult
 * Example class for executing code in Eclipse.
 */
public class Main {

	/**
	 * @param args command line parameters
	 */
	public static void main(String[] args) {
		System.out.println("Hallo Studenten!");

	}

}
