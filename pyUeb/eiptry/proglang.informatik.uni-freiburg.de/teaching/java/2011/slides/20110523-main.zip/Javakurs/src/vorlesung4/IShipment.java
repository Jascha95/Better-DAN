package vorlesung4;


/**
 * A list of Shipment items for one particular shipment.
 * 
 * @author progpult
 *
 */
public interface IShipment {

	/**
	 * @return the total price of this shipment in cent
	 */
	int totalPrice();
}
