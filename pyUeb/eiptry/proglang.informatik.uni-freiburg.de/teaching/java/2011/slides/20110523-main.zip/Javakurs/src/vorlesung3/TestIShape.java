/**
 * 
 */
package vorlesung3;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author progpult
 *
 */
public class TestIShape {
	
	static final double DELTA = 1e-5;
	
	CartPt p0 = new CartPt (0,0);
	CartPt p1 = new CartPt (50,50);
	CartPt p2 = new CartPt (80,80);
	Square s = new Square (p0, 50);
	Circle c = new Circle (p1, 30);
	Dot d = new Dot (p2);
	
	IShape sh1 = new Square (p0, 50);
	IShape sh2 = new Circle (p1, 30);
	IShape sh3 = new Dot (p2);
	IShape sh4 = s;
	IShape sh5 = c;
	IShape sh6 = d;
	

	/**
	 * Test method for {@link vorlesung3.IShape#area()}.
	 */
	@Test
	public void testArea() {
		assertEquals(0, sh3.area(), DELTA);
		assertEquals(2500, sh1.area(), DELTA);
		assertEquals(900*Math.PI, sh2.area(), DELTA);
	}

	/**
	 * Test method for {@link vorlesung3.IShape#distTo0()}.
	 */
	@Test
	public void testDistTo0() {
		fail("Not yet implemented");
	}

}
