/**
 * 
 */
package vorlesung2;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author progpult
 *
 */
public class TestShipmentItem {
	
	private final double DELTA = 1e-5;

	/**
	 * Test method for {@link vorlesung2.ShipmentItem#totalCost()}.
	 */
	@Test
	public void testTotalCost() {
		Resource copper = new Resource("Copper", 12.22, 800, 2000, 20000);
		ShipmentItem si_copper = new ShipmentItem(copper, 10000);
		ShipmentItem si_copper2 = new ShipmentItem(copper, 100000);
		ShipmentItem si_copper3 = new ShipmentItem(copper, 250000);
		assertEquals(200000, si_copper.totalCost(), DELTA);
		assertEquals(1900000, si_copper2.totalCost(), DELTA);
		assertEquals(4500000, si_copper3.totalCost(), DELTA);
	}

}
