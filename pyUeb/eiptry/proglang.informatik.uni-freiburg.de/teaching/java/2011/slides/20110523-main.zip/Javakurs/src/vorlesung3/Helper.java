package vorlesung3;

public class Helper {
	CartPt p0 = new CartPt (0,0);
	CartPt p1 = new CartPt (50,50);
	CartPt p2 = new CartPt (80,80);
	Square s = new Square (p0, 50);
	Circle c = new Circle (p1, 30);
	Dot d = new Dot (p2);
	
	IShape sh1 = new Square (p0, 50);
	IShape sh2 = new Circle (p1, 30);
	IShape sh3 = new Dot (p2);
	IShape sh4 = s;
	IShape sh5 = c;
	IShape sh6 = d;
	
	IShape ss = d;

}
