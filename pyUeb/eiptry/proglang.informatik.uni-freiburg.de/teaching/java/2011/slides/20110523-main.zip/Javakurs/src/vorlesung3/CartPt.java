/**
 * 
 */
package vorlesung3;

/**
 * @author progpult
 * Cartesian point.
 */
public class CartPt {
	private int x;
	private int y;
	
	public CartPt(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public double distTo0() {
		return Math.sqrt(this.x*this.x + this.y*this.y);
	}

	public boolean isSame(CartPt p) {
		return this.x == p.x && this.y == p.y;
	}

}
