/**
 * 
 */
package vorlesung2;

/**
 * @author progpult
 *
 */
public class Resource {
	/** of resource */
	private String name;
	/** physical property */
	private double density;
	/** physical property */
	private double meltingPoint;
	/** physical property */
	private double boilingPoint;
	
	/**
	 * Constructor
	 * @param name of resource
	 * @param density in kg / m�
	 * @param meltingPoint in K
	 * @param boilingPoint in K
	 */
	public Resource(
			String name,
			double density,
			double meltingPoint,
			double boilingPoint) {
		this.name = name;
		this.density = density;
		this.meltingPoint = meltingPoint;
		this.boilingPoint = boilingPoint;
	}
	
	/**
	 * Getter for density.
	 * @return density in kg/m�
	 */
	public double getDensity() {
		return this.density;
	}
	
	/**
	 * Checks if resource is solid.
	 * @param temp of surroundings in K
	 * @return true if resource solid.
	 */
	public boolean isSolid(double temp) {
		return temp <= this.meltingPoint;
	}

}
