/**
 * 
 */
package vorlesung2;

/**
 * @author progpult
 *
 */
public class ShipmentItem {
	/** the resource */
	private Resource item;
	/** in kg */
	private double weight;
	/** in EUR/ton */
	private double price;
	
	/**
	 * Constructor.
	 * @param item 
	 * @param weight in kg
	 * @param price in EUR / ton
	 */
	public ShipmentItem(Resource item, double weight, double price) {
		this.item = item;
		this.weight = weight;
		this.price = price;
	}
	
	/**
	 * computes the volume of shipment.
	 * @return the volume in m�.
	 */
	public double totalVolume() {
		return weight / this.item.getDensity();
	}
	
	/**
	 * Checks if shipment is solid at temperature.
	 * @param temp in K
	 * @return true if solid
	 */
	public boolean isSolid(double temp) {
		return this.item.isSolid(temp);
	}
	
	/**
	 * Compute overall cost of shipment.
	 * @return the cost in EUR.
	 */
	public double totalCost() {
		return this.weight / 1000 * this.price;
	}

}
