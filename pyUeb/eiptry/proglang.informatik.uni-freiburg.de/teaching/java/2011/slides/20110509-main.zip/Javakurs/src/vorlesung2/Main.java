/**
 * 
 */
package vorlesung2;

/**
 * @author progpult
 *
 */
public class Main {

	/**
	 * @param args command line
	 */
	public static void main(String[] args) {
		ResourceShipment rs = new ResourceShipment("Eisenerz", 20000, 450);
		ResourceShipment rs2 = new ResourceShipment("Kupfer", 4000, 780);
		
		System.out.println(
				"Gesamtpreis von " + rs.describe() + " ist " +
				rs.totalPrice() + " EUR");
		
		if(rs.isLighterThan(rs2)) {
			System.out.println("Eisenerz ist leichter");
		} else {
			System.out.println("Kupfer ist leichter");
		}
	}

}
