package ballworld;

import de.unifreiburg.twodeedoo.world.ICanvas;
import de.unifreiburg.twodeedoo.world.ISimulationController;
import de.unifreiburg.twodeedoo.world.IWorld;


/**
 * One part of the simulation
 * 
 * @author progpult
 *
 */
public interface ISimMember {

	/**
	 * Time has passed. Simulate.
	 * @param ctrl to quit the simulation etc
	 */
	void onTick(ISimulationController ctrl);
	
	
	/**
	 * A key has been pressed.
	 * @param code Keycode as in {@link IWorld}
	 * @param ctrl to quit the simulation etc
	 */
	void keyPressed(int code, ISimulationController ctrl);
	
	/**
	 * A key has been released.
	 * @param code Keycode as in {@link IWorld}
	 * @param ctrl to quit the simulation etc
	 */
	void keyReleased(int code, ISimulationController ctrl);

	/**
	 * Paint this part of the simulation onto the canvas.
	 * @param canvas a canvas.
	 */
	void paint(ICanvas canvas);
}
