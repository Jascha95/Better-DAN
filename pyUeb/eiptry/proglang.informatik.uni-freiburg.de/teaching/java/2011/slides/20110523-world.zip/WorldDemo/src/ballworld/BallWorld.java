/**
 * 
 */
package ballworld;

import java.awt.Color;
import java.awt.event.KeyEvent;

import de.unifreiburg.twodeedoo.world.ICanvas;
import de.unifreiburg.twodeedoo.world.ISimulationController;
import de.unifreiburg.twodeedoo.world.IWorld;

/**
 * @author progpult
 *
 */
public class BallWorld implements IWorld {

	
	/**
	 * Floor level, y coordinate, in pixels
	 */
	private static final double FLOOR_Y = 400;
	/**
	 * Acceleration due to gravity in centimeters per timeslice squared
	 */
	private static final double GRAVITY = -0.1;
	
	/**
	 * acceleration when the wind hits the ball, 
	 * in centimeters per timeslice squared
	 */
	private static final double WIND_ACCELERATION = 0.05;
	/**
	 * Height above the ground in centimeters
	 */
	private double height;
	
	/**
	 * velocity in centimeters per timeslice, positive means up
	 */
	private double velocity;
	
	
	/**
	 * is the fan blowing right now?
	 */
	private boolean blowing;
	
	
	
	
	/**
	 * 
	 * Create a ball world.
	 */
	public BallWorld() {
		height = 160;
		blowing = false;
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#getTitle()
	 */
	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return "Ballwelt";
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#getWidth()
	 */
	@Override
	public int getWidth() {
		// TODO Auto-generated method stub
		return 640;
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#getHeight()
	 */
	@Override
	public int getHeight() {
		// TODO Auto-generated method stub
		return 480;
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#getCycleTimeMs()
	 */
	@Override
	public int getCycleTimeMs() {
		return 20;
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#onTick(de.unifreiburg.twodeedoo.world.ISimulationController)
	 */
	@Override
	public void onTick(ISimulationController controller) {
		height = height + velocity;
		double acceleration;
		if(blowing) {
			acceleration = WIND_ACCELERATION; 
		} else {
			acceleration = GRAVITY;
		}
		velocity = velocity + acceleration;
		if(height <= 0) {
			velocity = - 0.7 * velocity;
			height = 0;
		}
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#onKeyPressed(int, de.unifreiburg.twodeedoo.world.ISimulationController)
	 */
	@Override
	public void onKeyPressed(int keyCode, ISimulationController controller) {
		if(keyCode == KeyEvent.VK_UP) {
			this.blowing = true;
			
		}
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#onKeyReleased(int, de.unifreiburg.twodeedoo.world.ISimulationController)
	 */
	@Override
	public void onKeyReleased(int keyCode, ISimulationController controller) {
		if(keyCode == KeyEvent.VK_UP) {
			this.blowing = false;
			
		}
		else if(keyCode==KeyEvent.VK_ESCAPE) {
			controller.quit();
		}
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#paint(de.unifreiburg.twodeedoo.world.ICanvas)
	 */
	@Override
	public void paint(ICanvas canvas) {
		int ballCenterY = (int) (FLOOR_Y - height - 10);
		canvas.drawFilledCircle(300, ballCenterY, 10, Color.BLACK);
		canvas.drawFilledRect(0, 400, 640, 480, Color.PINK);	
	}

}
