package ballworld;

import de.unifreiburg.twodeedoo.world.ICanvas;
import de.unifreiburg.twodeedoo.world.ISimulationController;

/**
 * Composite simulation member consisting of two members.
 * You can construct a tree of members this way.
 * @author anton
 *
 */
public class ConsMember implements ISimMember {

	/**
	 * One member.
	 */
	private ISimMember first;
	/**
	 * Another member.
	 */
	private ISimMember second;
	
	/**
	 * @param first one member
	 * @param second another member
	 */
	public ConsMember(ISimMember first, ISimMember second) {
		this.first = first;
		this.second = second;
	}

	@Override
	public void onTick(ISimulationController ctrl) {
		first.onTick(ctrl);
		second.onTick(ctrl);
		
	}

	@Override
	public void keyPressed(int code, ISimulationController ctrl) {
		first.keyPressed(code, ctrl);
		second.keyPressed(code, ctrl);
	}

	@Override
	public void keyReleased(int code, ISimulationController ctrl) {
		first.keyReleased(code, ctrl);
		second.keyReleased(code, ctrl);
		
	}

	@Override
	public void paint(ICanvas canvas) {
		first.paint(canvas);
		second.paint(canvas);
	}

}
