package ballworld;

import de.unifreiburg.twodeedoo.world.WorldApplication;

/**
 * Main class to run the world.
 * @author anton
 *
 */
public class Main {

	/**
	 * Main method for the jvm.
	 * @param args command line args, ignored.
	 */
	public static void main(String[] args) {
		//WorldApplication.runWorld(new BallWorld());
		WorldApplication.runWorld(new ComplexWorld(
				new ConsMember(
						new BallMember(), 
						new EmptyMember())));
	}

}
