/**
 * 
 */
package ballworld;

import de.unifreiburg.twodeedoo.world.ICanvas;
import de.unifreiburg.twodeedoo.world.ISimulationController;

/**
 * @author progpult
 *
 */
public class EmptyMember implements ISimMember {

	/* (non-Javadoc)
	 * @see ballworld.ISimMember#onTick(de.unifreiburg.twodeedoo.world.ISimulationController)
	 */
	@Override
	public void onTick(ISimulationController ctrl) {
		
	}

	/* (non-Javadoc)
	 * @see ballworld.ISimMember#keyPressed(int, de.unifreiburg.twodeedoo.world.ISimulationController)
	 */
	@Override
	public void keyPressed(int code, ISimulationController ctrl) {
		
	}

	/* (non-Javadoc)
	 * @see ballworld.ISimMember#keyReleased(int, de.unifreiburg.twodeedoo.world.ISimulationController)
	 */
	@Override
	public void keyReleased(int code, ISimulationController ctrl) {
		
	}

	/* (non-Javadoc)
	 * @see ballworld.ISimMember#paint(de.unifreiburg.twodeedoo.world.ICanvas)
	 */
	@Override
	public void paint(ICanvas canvas) {
	}

}
