/**
 * 
 */
package ballworld;

import de.unifreiburg.twodeedoo.world.ICanvas;
import de.unifreiburg.twodeedoo.world.ISimulationController;
import de.unifreiburg.twodeedoo.world.IWorld;

/**
 * World which is inhabited by {@link ISimMember}s. 
 * 
 * @author progpult
 *
 */
public class ComplexWorld implements IWorld {

	/**
	 * The entire membership as one (composite) {@link ISimMember}.
	 */
	private ISimMember members;
	
	
	
	/**
	 * Create a world around inhabitants.
	 * @param members all the inhabitants
	 */
	public ComplexWorld(ISimMember members) {
		this.members = members;
	
	}

	@Override
	public String getTitle() {
		return "Ballwelt";
	}

	@Override
	public int getWidth() {
		return 640;
	}

	@Override
	public int getHeight() {
		return 480;
	}

	@Override
	public int getCycleTimeMs() {
		return 20;
	}

	@Override
	public void onTick(ISimulationController controller) {
		members.onTick(controller);
	}

	@Override
	public void onKeyPressed(int keyCode, ISimulationController controller) {
		members.keyPressed(keyCode, controller);
	}

	@Override
	public void onKeyReleased(int keyCode, ISimulationController controller) {
		members.keyReleased(keyCode, controller);
	}

	@Override
	public void paint(ICanvas canvas) {
		members.paint(canvas);
	}

}
