/**
 * 
 */
package vorlesung2;

/**
 * @author progpult
 *
 */
public class Resource {
	/** of resource */
	private String name;
	/** physical property */
	private double density;
	/** physical property */
	private double meltingPoint;
	/** physical property */
	private double boilingPoint;
	/** base price of resource in EUR cent */
	private double basePrice;
	
	/**
	 * Constructor
	 * @param name of resource
	 * @param density in kg / m�
	 * @param meltingPoint in K
	 * @param boilingPoint in K
	 * @param basePrice in EUR cent
	 */
	public Resource(
			String name,
			double density,
			double meltingPoint,
			double boilingPoint,
			double basePrice) {
		this.name = name;
		this.density = density;
		this.meltingPoint = meltingPoint;
		this.boilingPoint = boilingPoint;
		this.basePrice = basePrice;
	}
	
	/**
	 * Getter for density.
	 * @return density in kg/m�
	 */
	public double getDensity() {
		return this.density;
	}
	
	/**
	 * Checks if resource is solid.
	 * @param temp of surroundings in K
	 * @return true if resource solid.
	 */
	public boolean isSolid(double temp) {
		return temp <= this.meltingPoint;
	}
	
	/**
	 * Check if resource is liquid.
	 * @param temp of surroundings in K
	 * @return true is liquid
	 */
	public boolean isLiquid(double temp) {
		return false;
	}

	/**
	 * Getter for basePrice.
	 * @return basePrice in EUR cent / t
	 */
	public double getBasePrice() {
		return this.basePrice;
	}

}
