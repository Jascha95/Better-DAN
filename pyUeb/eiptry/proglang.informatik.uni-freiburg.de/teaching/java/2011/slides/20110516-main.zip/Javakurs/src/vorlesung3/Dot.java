/**
 * 
 */
package vorlesung3;

/**
 * @author progpult
 * Represent a single dot.
 */
public class Dot implements IShape {
	/** coordinate of dot */
	private CartPt loc;
	
	public Dot(CartPt coordinate) {
		this.loc = coordinate;
	}

	@Override
	public double area() {
		return 0;
	}

	@Override
	public double distTo0() {
		return this.loc.distTo0();
	}

	@Override
	public boolean in(CartPt p) {
		return this.loc.isSame(p);
	}

	@Override
	public Square bb() {
		return null;
	}

}
