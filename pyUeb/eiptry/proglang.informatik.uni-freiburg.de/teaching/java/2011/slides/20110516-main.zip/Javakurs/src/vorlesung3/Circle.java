/**
 * 
 */
package vorlesung3;

/**
 * @author progpult
 *
 */
public class Circle implements IShape {
	/** reference point */
	private CartPt loc;
	/** radius in pix */
	private int radius;
	
	public Circle (CartPt reference, int radius) {
		this.loc = reference;
		this.radius = radius;
	}

	@Override
	public double area() {
		return Math.PI * this.radius * this.radius;
	}

	@Override
	public double distTo0() {
		double locDist = this.loc.distTo0();
		if (locDist>=this.radius) {
			return locDist-this.radius;
		} else {
			return 0;
		}
	}

	@Override
	public boolean in(CartPt p) {
		return false;  // cheating
	}

	@Override
	public Square bb() {
		return null;   // to be completed
	}

}
