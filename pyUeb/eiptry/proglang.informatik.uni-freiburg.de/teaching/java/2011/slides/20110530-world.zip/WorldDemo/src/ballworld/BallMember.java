package ballworld;

import java.awt.Color;
import java.awt.event.KeyEvent;

import de.unifreiburg.twodeedoo.world.ICanvas;
import de.unifreiburg.twodeedoo.world.ISimulationController;

public class BallMember implements ISimMember {
	/**
	 * Floor level, y coordinate, in pixels
	 */
	private static final double FLOOR_Y = 400;
	/**
	 * Acceleration due to gravity in centimeters per timeslice squared
	 */
	private static final double GRAVITY = -0.1;
	
	/**
	 * acceleration when the wind hits the ball, 
	 * in centimeters per timeslice squared
	 */
	private static final double WIND_ACCELERATION = 0.05;
	/**
	 * Height above the ground in centimeters
	 */
	private double height;
	
	/**
	 * velocity in centimeters per timeslice, positive means up
	 */
	private double velocity;
	
	
	/**
	 * is the fan blowing right now?
	 */
	private boolean blowing;
	
	
	/**
	 * 
	 */
	public BallMember() {
		height = 160;
		blowing = false;
	}

	@Override
	public void onTick(ISimulationController ctrl) {
		// TODO Auto-generated method stub
		height = height + velocity;
		double acceleration;
		if(blowing) {
			acceleration = WIND_ACCELERATION; 
		} else {
			acceleration = GRAVITY;
		}
		velocity = velocity + acceleration;
		if(height <= 0) {
			velocity = - 0.7 * velocity;
			height = 0;
		}
	}

	@Override
	public void keyPressed(int code, ISimulationController ctrl) {
		// TODO Auto-generated method stub
		if(code == KeyEvent.VK_UP) {
			this.blowing = true;
			
		}
	}

	@Override
	public void keyReleased(int code, ISimulationController ctrl) {
		// TODO Auto-generated method stub
		if(code == KeyEvent.VK_UP) {
			this.blowing = false;
			
		}
		else if(code==KeyEvent.VK_ESCAPE) {
			ctrl.quit();
		}
	}

	@Override
	public void paint(ICanvas canvas) {
		// TODO Auto-generated method stub
		
		int ballCenterY = (int) (FLOOR_Y - height - 10);
		canvas.drawFilledCircle(300, ballCenterY, 10, Color.BLACK);
		canvas.drawFilledRect(0, 400, 640, 480, Color.PINK);	
	}

}
