package ballworld;

import de.unifreiburg.twodeedoo.world.ICanvas;
import de.unifreiburg.twodeedoo.world.ISimulationController;

public class ConsMember implements ISimMember {

	private ISimMember first;
	private ISimMember second;
	
	/**
	 * @param first
	 * @param second
	 */
	public ConsMember(ISimMember first, ISimMember second) {
		this.first = first;
		this.second = second;
	}

	@Override
	public void onTick(ISimulationController ctrl) {
		first.onTick(ctrl);
		second.onTick(ctrl);
		
	}

	@Override
	public void keyPressed(int code, ISimulationController ctrl) {
		first.keyPressed(code, ctrl);
		second.keyPressed(code, ctrl);
	}

	@Override
	public void keyReleased(int code, ISimulationController ctrl) {
		first.keyReleased(code, ctrl);
		second.keyReleased(code, ctrl);
		
	}

	@Override
	public void paint(ICanvas canvas) {
		first.paint(canvas);
		second.paint(canvas);
	}

}
