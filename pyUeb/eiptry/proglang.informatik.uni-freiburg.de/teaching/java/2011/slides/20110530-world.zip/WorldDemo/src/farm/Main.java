package farm;

import de.unifreiburg.twodeedoo.world.WorldApplication;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//WorldApplication.runWorld(new BallWorld());
		WorldApplication.runWorld(new FarmWorld());
	}

}
