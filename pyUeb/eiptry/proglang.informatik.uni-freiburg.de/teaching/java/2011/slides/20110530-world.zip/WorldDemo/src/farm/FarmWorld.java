package farm;

import java.awt.Color;
import java.awt.event.KeyEvent;

import de.unifreiburg.twodeedoo.world.ICanvas;
import de.unifreiburg.twodeedoo.world.ISimulationController;
import de.unifreiburg.twodeedoo.world.IWorld;

/**
 * Partial solution for an improperly-remembered ex04_2, live-coded 2011-05-30. 
 * 
 * TODO: Cabbage state is becoming too complex; create a cabbage class.
 *       CabbagePatch represents the place where one plant of cabbage grows.
 *       It has fields for size and ripeness. It has a method plant() where
 *       a tractor can plant a seed. It has a method harvest() which resets
 *       the size and returns the market value. It has a method draw(...) which,
 *       given coordinates of the grid square, paints the cabbage. It has a 
 *       method tick(...) which computes growth. It doesn't know its position.
 *       Then we keep an array of CabbagePatch in FarmWorld. 
 *       
 * TODO: Tractor state is becoming too complex; create a tractor class.
 *       It knows its position. It can move right,left,up,down. It has a flag
 *       for harvesting state. It has a method visitCabbage(CabbagePatch)
 *       which does something to that cabbage. It has a draw-method.
 *       
 * TODO: Hide the cabbage array behind a cabbage field interface: knows its
 *       size, and you can ask it for the cabbage at coordinates. Then the tractor would
 *       know that cabbage field. Better than knowing the array, which is an implementation
 *       detail.
 *       
 * Then the world would only be responsible for delegating events to the cabbages and
 * the tractor.  
 * 
 * @author anton
 *
 */
public class FarmWorld implements IWorld {

	private static final int SCREEN_HEIGHT = 480;
	private static final int SCREEN_WIDTH = 640;
	private static final int WIDTH = 20;
	private static final int HEIGHT = 20;
	private static final int CELL_WIDTH = SCREEN_WIDTH / WIDTH;
	private static final int CELL_HEIGHT = SCREEN_HEIGHT / HEIGHT;
	private int[][] cabbageGrowth;
	private int tracX, tracY;
	private boolean harvesting;
	private int score;

	public FarmWorld() {
		cabbageGrowth = new int[WIDTH][HEIGHT];
		tracX = 10;
		tracY = 4;
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return "farm";
	}

	@Override
	public int getWidth() {
		// TODO Auto-generated method stub
		return SCREEN_WIDTH;
	}

	@Override
	public int getHeight() {
		// TODO Auto-generated method stub
		return SCREEN_HEIGHT;
	}

	@Override
	public int getCycleTimeMs() {
		// TODO Auto-generated method stub
		return 50;
	}

	@Override
	public void onTick(ISimulationController controller) {
		// TODO Auto-generated method stub
		for (int i = 0; i < WIDTH; i = i + 1) {
			for (int j = 0; j < HEIGHT; j = j + 1) {
				int size = cabbageGrowth[i][j];
				if (size < 10) {
					cabbageGrowth[i][j] = size + 1;
				}
			}
		}

	}

	@Override
	public void onKeyPressed(int keyCode, ISimulationController controller) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onKeyReleased(int keyCode, ISimulationController controller) {
		if (keyCode == KeyEvent.VK_RIGHT) {
			if (tracX < WIDTH - 1)
				tracX = tracX + 1;
		} else if (keyCode == KeyEvent.VK_DOWN) {
			if (tracY < HEIGHT - 1)
				tracY = tracY + 1;
		} else if (keyCode == KeyEvent.VK_LEFT) {
			if (tracX > 0)
				tracX = tracX - 1;
		} else if (keyCode == KeyEvent.VK_UP) {
			if (tracY > 0)
				tracY = tracY - 1;
		} else if (keyCode == KeyEvent.VK_H) {
			harvesting = !harvesting;
		}
		maybeHarvest();
	}

	private void maybeHarvest() {
		if (harvesting) {
			int size = cabbageGrowth[tracX][tracY];
			cabbageGrowth[tracX][tracY] = 0;
			score = score + size;
		}
	}

	@Override
	public void paint(ICanvas canvas) {
		drawCabbage(canvas);
		drawTractor(canvas);
		drawScore(canvas);
	}

	private void drawScore(ICanvas canvas) {
		canvas.drawText(200, 30, String.valueOf(score), Color.BLACK);
	}

	private void drawTractor(ICanvas canvas) {
		canvas.drawFilledRect(tracX * CELL_WIDTH, tracY * CELL_HEIGHT,
				CELL_WIDTH, CELL_HEIGHT, Color.MAGENTA);
	}

	private void drawCabbage(ICanvas canvas) {
		for (int i = 0; i < WIDTH; i = i + 1) {
			for (int j = 0; j < HEIGHT; j = j + 1) {
				int size = cabbageGrowth[i][j];
				drawCabbage(canvas, size, i, j);
			}
		}
	}

	private void drawCabbage(ICanvas canvas, int size, int i, int j) {
		int x = CELL_WIDTH * i;
		int y = CELL_HEIGHT * j;

		canvas.drawFilledCircle(x + CELL_WIDTH / 2, y + CELL_WIDTH / 2, size,
				Color.BLUE);
	}

}
