/**
 * 
 */
package vorlesung5;

/**
 * @author progpult
 * Represent a single dot.
 */
public class Dot extends AShape {
	
	/**
	 * Create a dot.
	 * @param coordinate the dot.
	 */
	public Dot(CartPt coordinate) {
		super(coordinate);
	}

	@Override
	public double area() {
		return 0;
	}

	@Override
	public boolean in(CartPt p) {
		return this.loc.isSame(p);
	}

	@Override
	public Square bb() {
		return null;
	}

}
