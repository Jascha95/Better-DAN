/**
 * 
 */
package vorlesung2;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author progpult
 *
 */
public class TestResourceShipment {
	/** test object */
	private ResourceShipment rs1 = new ResourceShipment("Eisenerz", 20000, 450);
	/** test object */
	private ResourceShipment rs2 = new ResourceShipment("Kupfer", 4000, 780);

	/**
	 * Test method for {@link vorlesung2.ResourceShipment#totalPrice()}.
	 */
	@Test
	public void testTotalPrice() {
		assertEquals(9000.0, rs1.totalPrice(), 0.001);
		assertEquals(3120, rs2.totalPrice(), 0.001);
	}

	/**
	 * Test method for {@link vorlesung2.ResourceShipment#isLighterThan(vorlesung2.ResourceShipment)}.
	 */
	@Test
	public void testIsLighterThan() {
		assertTrue(rs2.isLighterThan(rs1));
		assertFalse(rs1.isLighterThan(rs2));
	}

}
