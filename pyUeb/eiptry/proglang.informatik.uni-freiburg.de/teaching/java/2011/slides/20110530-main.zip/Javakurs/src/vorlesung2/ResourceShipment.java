/**
 * 
 */
package vorlesung2;

/**
 * @author progpult
 *
 */
public class ResourceShipment {
	/** name of resource */
	private String name;
	/** weight in kg */
	private double weight;
	/** price in EUR per ton */
	private double price;
	
	/**
	 * Constructor.
	 * @param name of resource
	 * @param weight in kg
	 * @param price in EUR per ton
	 */
	public ResourceShipment(String name, double weight, double price) {
		this.name = name;
		this.weight = weight;
		this.price = price;
	}
	
	/**
	 * Compute total price of shipment.
	 * @return the price in EUR
	 */
	public double totalPrice() {
		return this.weight / 1000 * this.price;
	}
	
	/**
	 * Textual description of shipment.
	 * @return a descriptive string.
	 */
	public String describe() {
		return 
			this.weight + " kg " +
			this.name + " zum Preis von " + this.price + "EUR / Tonne";
	}
	
	/**
	 * Tests if this object is lighter than other object.
	 * @param other shipment
	 * @return true if this object is lighter.
	 */
	public boolean isLighterThan(ResourceShipment other) {
		return this.weight < other.weight;
	}

}
