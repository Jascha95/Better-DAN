/**
 * 
 */
package vorlesung3;

/**
 * @author progpult
 *
 */
public class Square implements IShape {
	/** reference point */
	private CartPt loc;
	/** length */
	private int size;
	
	public Square (CartPt reference, int size) {
		this.loc = reference;
		this.size = size;
	}

	@Override
	public double area() {
		return this.size*this.size;
	}

	@Override
	public double distTo0() {
		return this.loc.distTo0();
	}

	@Override
	public boolean in(CartPt p) {
		return false;  // to be completed
	}

	@Override
	public Square bb() {
		return new Square(this.loc, this.size);
	}

}

