package ballworld;

import de.unifreiburg.twodeedoo.world.ICanvas;
import de.unifreiburg.twodeedoo.world.ISimulationController;


/**
 * One part of the simulation
 * 
 * @author progpult
 *
 */
public interface ISimMember {

	void onTick(ISimulationController ctrl);
	
	void keyPressed(int code, ISimulationController ctrl);
	
	void keyReleased(int code, ISimulationController ctrl);

	void paint(ICanvas canvas);
}
