/**
 * 
 */
package ballworld;

import java.awt.Color;
import java.awt.event.KeyEvent;

import de.unifreiburg.twodeedoo.world.ICanvas;
import de.unifreiburg.twodeedoo.world.ISimulationController;
import de.unifreiburg.twodeedoo.world.IWorld;

/**
 * @author progpult
 *
 */
public class ComplexWorld implements IWorld {

	private ISimMember members;
	
	
	
	/**
	 * 
	 * Create a ball world.
	 */
	public ComplexWorld(ISimMember members) {
		this.members = members;
	
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#getTitle()
	 */
	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return "Ballwelt";
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#getWidth()
	 */
	@Override
	public int getWidth() {
		// TODO Auto-generated method stub
		return 640;
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#getHeight()
	 */
	@Override
	public int getHeight() {
		// TODO Auto-generated method stub
		return 480;
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#getCycleTimeMs()
	 */
	@Override
	public int getCycleTimeMs() {
		return 20;
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#onTick(de.unifreiburg.twodeedoo.world.ISimulationController)
	 */
	@Override
	public void onTick(ISimulationController controller) {
		members.onTick(controller);
		
		
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#onKeyPressed(int, de.unifreiburg.twodeedoo.world.ISimulationController)
	 */
	@Override
	public void onKeyPressed(int keyCode, ISimulationController controller) {
		members.keyPressed(keyCode, controller);
		
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#onKeyReleased(int, de.unifreiburg.twodeedoo.world.ISimulationController)
	 */
	@Override
	public void onKeyReleased(int keyCode, ISimulationController controller) {
		members.keyReleased(keyCode, controller);
		
	}

	/* (non-Javadoc)
	 * @see de.unifreiburg.twodeedoo.world.IWorld#paint(de.unifreiburg.twodeedoo.world.ICanvas)
	 */
	@Override
	public void paint(ICanvas canvas) {
		
		members.paint(canvas);
	
	}

}
