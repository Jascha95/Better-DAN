/**
 * 
 */
package vorlesung4;

/**. 
 * One item in a shipment: quantity, price per unit.
 * 
 * @author progpult
 *
 */
public class ShipmentItem {

	/**
	 * number of things
	 */
	private int count;
	/**
	 * price per thing in Cent
	 */
	private int pricePerItem;
	/**
	 * @param count number of things
	 * @param pricePerItem price per thing in cent
	 */
	public ShipmentItem(int count, int pricePerItem) {
		super();
		this.count = count;
		this.pricePerItem = pricePerItem;
	}
	
	/**
	 * @return price of this shipment item in cent
	 */
	public int price(){
		return count * pricePerItem;
	}

}
