/**
 * 
 */
package vorlesung5;

/**
 * A circle.
 * 
 * @author progpult
 *
 */
public class Circle extends AShape{
	/** radius in pix */
	private int radius;
	
	/**
	 * Create a circle.
	 * @param reference center
	 * @param radius radius.
	 */
	public Circle (CartPt reference, int radius) {
		super(reference);
		this.radius = radius;
	}

	@Override
	public double area() {
		return Math.PI * this.radius * this.radius;
	}

	@Override
	public double distTo0() {
		double locDist = super.distTo0();
		if (locDist>=this.radius) {
			return locDist-this.radius;
		} else {
			return 0;
		}
	}

	@Override
	public boolean in(CartPt p) {
		return false;  // cheating
	}

	@Override
	public Square bb() {
		return null;   // to be completed
	}

}
