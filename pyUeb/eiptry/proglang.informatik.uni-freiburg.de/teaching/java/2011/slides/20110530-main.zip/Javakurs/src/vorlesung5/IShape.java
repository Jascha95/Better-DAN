/**
 * 
 */
package vorlesung5;

/**
 * @author progpult
 *
 */
public interface IShape {
	/**
	 * Computes area of figure
	 * @return the area
	 */
	public double area();
	/**
	 * Computes distance to origin
	 * @return distance
	 */
	public double distTo0();
	/**
	 * Checks if point in figure
	 * @param p the point
	 * @return true if point in figure
	 */
	public boolean in(CartPt p);
	/**
	 * Computes bounding box of figure
	 * @return the bounding square
	 */
	public Square bb();

}
