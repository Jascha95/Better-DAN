/**
 * 
 */
package vorlesung2;

/**
 * @author progpult
 *
 */
public class Shipment {
	/** particular item */
	private ShipmentItem item;
	/** receiver of shipment */
	private String receiver;
	/** logistics information */
	private Transporter transporter;
	
	/**
	 * Computes overall cost of shipment including logistics.
	 * @return cost in EUR.
	 */
	public double totalCost() {
		return item.totalCost() + transporter.totalCost();
	}

}
