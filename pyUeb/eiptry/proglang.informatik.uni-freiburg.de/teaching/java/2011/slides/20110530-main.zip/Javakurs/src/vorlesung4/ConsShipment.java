/**
 * 
 */
package vorlesung4;

/**
 * Shipment containing a shipment item and a remaining shipment.
 * 
 * @author progpult
 *
 */
public class ConsShipment implements IShipment {

	/**
	 * Head of the list.
	 */
	private final ShipmentItem shipmentItem;
	/**
	 * Tail of the list.
	 */
	private final IShipment rest;

	/**
	 * Create a new list node.
	 * @param shipmentItem head of the list
	 * @param consShipment tail of the list.
	 */
	public ConsShipment(ShipmentItem shipmentItem, IShipment consShipment) {
		this.shipmentItem = shipmentItem;
		this.rest = consShipment;
	}

	@Override
	public int totalPrice() {
		return shipmentItem.price() + rest.totalPrice();
	}

}
