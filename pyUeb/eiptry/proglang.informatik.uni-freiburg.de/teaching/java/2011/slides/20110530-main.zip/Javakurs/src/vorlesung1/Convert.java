/**
 * 
 */
package vorlesung1;

/**
 * @author progpult
 * Conversion of Celsius degrees to Fahrenheit (and back).
 */
public class Convert {

	/**
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		if (args.length != 2) {
			usage();
		} else {
			double dvalue = new Double(args[0]);
			String command = args[1];
			double result;
			if (command.equals("C")) {
				result = celsius2fahrenheit(dvalue);
				System.out.println(dvalue + " Celsius = " + result + " Fahrenheit");
			} else if (command.equals("F")) {
				result = fahrenheit2celsius(dvalue);
				System.out.println(dvalue + " Fahrenheit = " + result + " Celsius");
			} else {
				usage();
			}
		}

	}
	
	/**
	 * 
	 * @param dvalue temperature in F
	 * @return temperature in C
	 */
	private static double fahrenheit2celsius(double dvalue) {
		return (dvalue -32.0) * 5.0 / 9.0;
	}
	
	/**
	 * Convert Celsius degrees to Fahrenheit.
	 * @param dvalue a double representing a temperature in deg Celsius
	 * @return a double rep the temperature in Fahrenheit.
	 */
	private static double celsius2fahrenheit(double dvalue) {
		return (dvalue) * 9.0 / 5.0 + 32.0;
	}

	/**
	 * print a usage message.
	 */
	private static void usage() {
		System.out.println("Usage: <number> [CF]");
		System.out.println("Convert <number> to Celius or Fahrenheit");
	}

}
