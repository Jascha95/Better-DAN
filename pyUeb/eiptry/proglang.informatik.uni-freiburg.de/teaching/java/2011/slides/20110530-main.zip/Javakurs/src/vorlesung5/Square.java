/**
 * 
 */
package vorlesung5;

/**
 * @author progpult
 *
 */
public class Square extends AShape {
	/** length */
	private int size;
	
	/**
	 * Create a square
	 * @param reference The corner closest to 0,0
	 * @param size length of each side.
	 */
	public Square (CartPt reference, int size) {
		super(reference);
		this.size = size;
	}

	@Override
	public double area() {
		return this.size*this.size;
	}

	@Override
	public boolean in(CartPt p) {
		return false;  // to be completed
	}

	@Override
	public Square bb() {
		return new Square(this.loc, this.size);
	}

}

