/**
 * 
 */
package vorlesung4;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * Unit test for {@link ConsShipment} and {@link EmptyShipment}
 * @author progpult
 *
 */
public class ShipmentTest {

	/**
	 * Test price computation on empty shipments.
	 */
	@Test
	public void testEmpty(){
		IShipment shipm = new EmptyShipment();
		assertEquals(0, shipm.totalPrice());
	}
	
	/**
	 * Test price computation on nonempty shipments.
	 */
	@Test
	public void testNonempty() {
		IShipment shipm = new ConsShipment(new ShipmentItem(11, 9),
				new ConsShipment(new ShipmentItem(3, 7),
						new EmptyShipment()));
		assertEquals(120, shipm.totalPrice());
	}
}
