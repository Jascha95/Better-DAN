/**
 * 
 */
package vorlesung4;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * @author progpult
 *
 */
public class ShipmentItemTest {

	/**
	 * Test that a {@link ShipmentItem} computes its price correctly.
	 */
	@Test 
	public void testPriceComputation (){
		ShipmentItem si = new ShipmentItem(2, 16);
		assertEquals(32, si.price());
	}
}
