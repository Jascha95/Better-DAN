/**
 * 
 */
package vorlesung2;

/**
 * @author progpult
 *
 */
public class ShipmentItem {
	/** the resource */
	private Resource item;
	/** in kg */
	private double weight;
	
	/**
	 * Constructor.
	 * @param item 
	 * @param weight in kg
	 */
	public ShipmentItem(Resource item, double weight) {
		this.item = item;
		this.weight = weight;
	}
	
	/**
	 * computes the volume of shipment.
	 * @return the volume in m�.
	 */
	public double totalVolume() {
		return weight / this.item.getDensity();
	}
	
	/**
	 * Checks if shipment is solid at temperature.
	 * @param temp in K
	 * @return true if solid
	 */
	public boolean isSolid(double temp) {
		return this.item.isSolid(temp);
	}
	
	/**
	 * Implements business rule for discounts.
	 * @return discount percentage dependent on weight. (0<= discount <= 100)
	 */
	private double discount() {
		if (this.weight < 50000) {
			return 0;
		} else if (this.weight < 200000) {
			return 5;
		} else {
			return 10;
		}
	}
	
	/**
	 * Compute overall cost of shipment.
	 * Incorporates business rule.
	 * @return the cost in EUR.
	 */
	public double totalCost() {
		return this.weight / 1000 * this.item.getBasePrice()
		* (1 - this.discount()/100.0);
	}

}
