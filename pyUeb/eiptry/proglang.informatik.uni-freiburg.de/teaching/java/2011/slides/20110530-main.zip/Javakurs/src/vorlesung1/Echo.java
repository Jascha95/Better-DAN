/**
 * 
 */
package vorlesung1;

/**
 * @author progpult
 * Copy arguments to console output.
 */
public class Echo {

	/**
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		int i = 0;
		while(i < args.length) {
			System.out.println("Arg #" + i + " = " + args[i]);
			i = i+1;
		}

	}

}
