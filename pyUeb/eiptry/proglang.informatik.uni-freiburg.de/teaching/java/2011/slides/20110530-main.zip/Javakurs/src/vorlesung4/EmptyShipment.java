/**
 * 
 */
package vorlesung4;

/**
 * Empty shipment.
 * 
 * @author progpult
 *
 */
public class EmptyShipment implements IShipment {

	
	@Override
	public int totalPrice() {
		return 0;
	}

}
