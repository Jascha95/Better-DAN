/**
 * 
 */
package vorlesung2;

/**
 * @author progpult
 *
 */
public class Transporter {
	/** cost of logistics */
	private double cost;

	/**
	 * Cost.
	 * @return cost of logistics.
	 */
	public double totalCost() {
		return this.cost;
	}

}
