/**
 * 
 */
package vorlesung5;

/**
 * @author progpult
 * Cartesian point.
 */
public class CartPt {
	/**
	 * x coordinate
	 */
	private int x;
	/**
	 * y coordinate
	 */
	private int y;
	
	/**
	 * Create a point
	 * @param x x coordinate
	 * @param y y coordinate
	 */
	public CartPt(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * Distance to (0,0).
	 * @return a distance, nonnegative.
	 */
	public double distTo0() {
		return Math.sqrt(this.x*this.x + this.y*this.y);
	}

	/**
	 * Is this the same point as the other point?
	 * @param p other point
	 * @return true if same point.
	 */
	public boolean isSame(CartPt p) {
		return this.x == p.x && this.y == p.y;
	}

}
