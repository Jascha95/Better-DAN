package vorlesung5;

/**
 * Abstract base class for IShape implementations.
 * 
 * @author anton
 *
 */
public abstract class AShape implements IShape {

	/**
	 * The point of reference.
	 */
	protected CartPt loc;

	/**
	 * Ctor.
	 * @param reference the point of reference.
	 */
	public AShape(CartPt reference) {
		this.loc = reference;
	}

	@Override
	abstract public double area(); // subclasses must override this!

	@Override
	public double distTo0() {
		// this is the same for most subclasses...
		return loc.distTo0();
	}

	@Override
	abstract public boolean in(CartPt p) ;

	@Override
	abstract public Square bb();

}
