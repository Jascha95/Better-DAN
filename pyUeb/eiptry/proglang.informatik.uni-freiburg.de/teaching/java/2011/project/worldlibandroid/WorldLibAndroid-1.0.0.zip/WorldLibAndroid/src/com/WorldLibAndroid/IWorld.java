package com.WorldLibAndroid;

/**
 * An interface which provides methods to let the user manipulate objects in the
 * canvas.
 * 
 * @author Christian Herrera
 */
public interface IWorld {

	/**
	 * Performs an action on ever tick of the world's clock.
	 */
	public void onTick();

	/**
	 * Performs an action when touching the screen of the device.
	 * 
	 * @param x
	 *            coordinate of the touched area.
	 * @param y
	 *            coordinate of the touched area.
	 */
	public void onTouchEvent(int x, int y);

	/**
	 * Performs an action when tilting the device by using the accelerometer.
	 * 
	 * @param mAccelX
	 *            Acceleration minus Gx on the x-axis.
	 * @param mAccelY
	 *            Acceleration minus Gy on the y-axis.
	 * @param mAccelZ
	 *            Acceleration minus Gz on the z-axis. Note: Get more
	 *            information on <a href=
	 *            "http://developer.android.com/reference/android/hardware/SensorEvent.html"
	 *            > Android's Sensors</a>
	 */
	public void onTiltEvent(float mAccelX, float mAccelY, float mAccelZ);

	/**
	 * Performs an action when tilting the device by using the gyroscope.
	 * 
	 * @param mGyroX
	 *            Angular speed around the x-axis.
	 * @param mGyroY
	 *            Angular speed around the y-axis.
	 * @param mGyroZ
	 *            Angular speed around the z-axis. Note: Get more information on
	 *            <a href=
	 *            "http://developer.android.com/reference/android/hardware/SensorEvent.html"
	 *            > Android's Sensors</a>
	 */

	public void onGyroscopeEvent(float mGyroX, float mGyroY, float mGyroZ);

	/**
	 * Performs an action when pressing a key on the keyboard.
	 * 
	 * @param keyCode
	 *            The key code that represents a key. Note: Get more information
	 *            on <a href=
	 *            "http://developer.android.com/reference/android/view/KeyEvent.html"
	 *            > KeyEvents</a>
	 */
	public void onKeyEvent(int keyCode);

	/**Performs an action when tilting the device by using the gyroscope.
	 * @param mOriX Azimuth, angle between the magnetic north direction and the y-axis, around the z-axis (0 to 359). 0=North, 90=East, 180=South, 270=West.
     * @param mOriY Pitch, rotation around x-axis (-180 to 180), with positive values when the z-axis moves toward the y-axis.
	 * @param mOriZ Roll, rotation around y-axis (-90 to 90), with positive values when the x-axis moves toward the z-axis. 
	 * Note: Get more information on <a href="http://developer.android.com/reference/android/hardware/SensorEvent.html"> Android's Sensors</a> */ 
	
	public void onOrientationEvent(float mOriX, float mOriY, float mOriZ);
	
	/**
	 * With this method the user can draw on the canvas.
	 * 
	 * @param c
	 *            Canvas object to insert the figures to draw in.
	 */
	public void draw(ICanvas c);

	/**
	 * With this method the user establish the initial values at bigBang.
	 * 
	 * @param init
	 *            object where we can establish the initial values.
	 */
	public void onInit(IInit init);
}
