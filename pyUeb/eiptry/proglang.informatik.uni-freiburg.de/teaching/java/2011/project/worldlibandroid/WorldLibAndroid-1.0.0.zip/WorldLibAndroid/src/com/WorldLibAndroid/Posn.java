package com.WorldLibAndroid;

/**
 * Copyright 2007, 2008 Viera K. Proulx, Matthias Felleisen
 * This program is distributed under the terms of the 
 * GNU Lesser General Public License (LGPL)
 */

/**
 * To represent a point on the drawing <CODE>CanvasX</CODE>
 * 
 * @author Viera K. Proulx
 * @since August 2, 2007
 */
public class Posn {
	/**
	 * x coordinate on the drawing canvas.
	 */
	private float x;

	/**
	 * y coordinate on the drawing canvas.
	 */
	private float y;

	/**
	 * Constructor
	 * 
	 * @param x
	 *            coordinate on the drawing canvas.
	 * @param y
	 *            coordinate on the drawing canvas.
	 */
	public Posn(float x, float y) {
		this.x = x;
		this.y = y;
	}
	
	/**Method to get the variable x.
	 * @return x coordinate in the canvas.*/
	public float getX()
	{
		return x;
	}
	
	/**Method to get the variable y.
	 * @return y coordinate in the canvas.*/
	public float getY()
	{
		return y;
	}
	
	/**Method to set the variable x.
	 * @param x coordinate in the canvas.*/
	public void setX(float x)
	{
		this.x = x;
	}
	
	/**Method to set the variable y.
	 * @param y coordinate in the canvas.*/
	public void setY(float y)
	{
		this.y = y;
	}
}