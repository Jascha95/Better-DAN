package com.WorldLibAndroid;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;

/**
 * Defines the methods to draw the possible objects.
 * 
 * @author Christian Herrera
 */
public interface ICanvas {

	/**
	 * Draws a line.
	 * 
	 * @param x1
	 *            coordinate of the beginning of the line.
	 * @param y1
	 *            coordinate of the beginning of the line.
	 * @param x2
	 *            coordinate of the end of the line.
	 * @param y2
	 *            coordinate of the end of the line.
	 * @param p
	 *            object that holds the color of the line.
	 */
	public void drawLine(float x1, float y1, float x2, float y2, IColor p);

	/**
	 * Draws a filled rectangle.
	 * 
	 * @param x1
	 *            The left side of the rectangle to be drawn.
	 * @param y1
	 *            The top side of the rectangle to be drawn.
	 * @param x2
	 *            The right side of the rectangle to be drawn.
	 * @param y2
	 *            The bottom side of the rectangle to be drawn.
	 * @param p
	 *            object that holds the color of the rectangle.
	 */
	public void drawRect(float x1, float y1, float x2, float y2, IColor p);

	/**
	 * Draws a filled circle.
	 * 
	 * @param x
	 *            coordinate of the canvas panel.
	 * @param y
	 *            coordinate of the canvas panel.
	 * @param radius
	 *            of the circle.
	 * @param p
	 *            object that holds the color of the circle.
	 */
	public void drawCircle(float x, float y, float radius, IColor p);

	/**
	 * Draws a text.
	 * 
	 * @param m
	 *            The text to be drawn.
	 * @param x
	 *            The x-coordinate of the origin of the text being drawn.
	 * @param y
	 *            The y-coordinate of the origin of the text being drawn.
	 * @param p
	 *            object that holds the color of the text.
	 */
	public void drawText(String m, float x, float y, IColor p);

	/**
	 * Treat the specified array of colors as a bitmap, and draw it. This gives
	 * the same result as first creating a bitmap from the array, and then
	 * drawing it, but this method avoids explicitly creating a bitmap object
	 * which can be more efficient if the colors are changing often.
	 * 
	 * @param colors
	 *            Array of colors representing the pixels of the bitmap.
	 * @param offset
	 *            into the array of colors for the first pixel.
	 * @param stride
	 *            The number of colors in the array between rows (must be >=
	 *            width or <= -width).
	 * @param x
	 *            The X coordinate for where to draw the bitmap.
	 * @param y
	 *            The Y coordinate for where to draw the bitmap.
	 * @param width
	 *            The width of the bitmap.
	 * @param height
	 *            The height of the bitmap.
	 * @param hasAlpha
	 *            True if the alpha channel of the colors contains valid values.
	 *            If false, the alpha byte is ignored (assumed to be 0xFF for
	 *            every pixel).
	 * */
	public void drawBitmap(int[] colors, int offset, int stride, float x,
			float y, int width, int height, boolean hasAlpha);

	/**
	 * Draws the specified drawable image.
	 * 
	 * @param image
	 *            the {@link Drawable} to be drawn
	 */
	public void drawDrawable(Drawable image);

	/** Clears the canvas. */
	public void cleanCanvas();

	/**
	 * Get the inner {@link Canvas}; can be used to draw complicated shapes
	 * beyond what this interface offers.
	 * 
	 * @return the inner {@link Canvas} object
	 */
	public Canvas getAndroidCanvas();

}
