package com.WorldLibAndroid.Demo;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;

import com.WorldLibAndroid.*;

/**BlobWorld Class*/
public class BlobWorld implements IWorld {
    /** The width of the canvas.
     * */
	static final int WIDTH = 600;
    /** The height of the canvas.
     * */
	static final int HEIGHT = 800;
    /** The threshold to react to acceleration data.
     * */
	private static float accelThreshold = 2;
    /** The threshold to react to orientation data.
     * */
	private static float orientThreshold = 65;

	/** IColor objects*/
	private IColor iRed, iWhite, iGreen, iYellow;
	/** Posn objects*/
	private Posn p1, p3, p4, p5, p6, p7;
	/** Radius of the objects*/
	private int radius1, radius2;
	
	/** blob object*/
	private ShapeObj blob;

	/** IInit object*/
	private IInit iinit;

	/** Objects to indicate if the blob is out of canvas or eaten*/
	private boolean blobOut = false, blobEaten = false;
    
	/**Contructor*/
	public BlobWorld() {

		// Creating an circle
		p1 = new Posn(10, 10);
		radius1 = 30;
		iRed = new Color(android.graphics.Color.RED);

		// Creating a disk
		p3 = new Posn(100, 100);
		radius2 = 15;
		iWhite = new Color(android.graphics.Color.WHITE);

		// Creating a line
		p4 = new Posn(20, 20);
		p5 = new Posn(40, 40);
		iYellow = new Color(android.graphics.Color.YELLOW);

		// Creating a rectangle
		p6 = new Posn(40, 40);
		p7 = new Posn(60, 60);
		iGreen = new Color(android.graphics.Color.GREEN);

	}

	@Override
	public void draw(ICanvas c) {
		c.cleanCanvas();
		blob = new ShapeObj(p1, iRed, radius1);
		blob.draw(c);

		c.drawCircle(p3.getX(), p3.getY(), radius2, iWhite);
		c.drawRect(p6.getX(), p6.getY(), p7.getX(), p7.getY(), iGreen);
		c.drawLine(p4.getX(), p4.getY(), p5.getX(), p5.getY(), iYellow);

		int width = 10;
		int height = 10;
		int[] colors = new int[width * height];
		int offset = 0;
		int stride = width;
		float x = 15;
		float y = 15;
		boolean hasAlpha = false;

		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				colors[j + i * width] ^= 0x0000005F + j * 0xF; // filling the array in
														// blue color
			}
		}
		c.drawBitmap(colors, offset, stride, x, y, width, height, hasAlpha);
		Resources res = iinit.context().getResources();
		Drawable image = res.getDrawable(R.drawable.icon);
		image.setBounds(100, 40, 148, 88);
		c.drawDrawable(image);

		if (blobOut)
			c.drawText("Blob out of bounds", 20, 20, iWhite);

		if (blobEaten)
			c.drawText("Blob eaten", 20, 20, iWhite);
	}

	/** Move the Blob when the player presses a key 
	 * @param s the key pressed*/
	@Override
	public void onKeyEvent(int s) {
		blob.moveBlob(s);
	}

	/**
	 * On tick check whether the Blob is out of bounds, or fell into the black
	 * hole in the middle. If all is well, move the Blob in a random direction.
	 */
	@Override
	public void onTick() {
		// if the blob is outside the canvas, stop
		if (blob.outsideBounds(WIDTH, HEIGHT)) {
			blobOut = true;
			iinit.endOfWorld();
		}

		// time ends is the blob falls into the black hole in the middle
		if (blob.nearCenter(WIDTH, HEIGHT)) {
			blobEaten = true;
			iinit.endOfWorld();
		}

		// else move the blob randomly at most 5 pixels in any direction
		else {
			blob.randomMove(5);
		}
	}

	@Override
	public void onTouchEvent(int x, int y) {
		blob.moveAtTouch(x, y);
	}

	@Override
	public void onTiltEvent(float x, float y, float z) {
		if (Math.abs(x) > Math.abs(y)) {
			if (x < -accelThreshold)
				blob.moveAtTilt(8, 0);
			if (x > accelThreshold)
				blob.moveAtTilt(-8, 0);
		} else {
			if (y < -accelThreshold)
				blob.moveAtTilt(0, -8);
			if (y > accelThreshold)
				blob.moveAtTilt(0, 8);
		}
	}

	@Override
	public void onGyroscopeEvent(float x, float y, float z) {

	}
	
	@Override
	public void onOrientationEvent(float x, float y, float z) {
	
		if (Math.abs(x) > Math.abs(y)) {
			if (x < orientThreshold) blob.moveAtOrient(-5, 0);
			if (x >  orientThreshold) blob.moveAtOrient(5, 0);
		}
		else {
			if (x < orientThreshold) blob.moveAtOrient(0, -5);
			if (y >  orientThreshold) blob.moveAtOrient(0, 5);
		}
	}
	@Override
	public void onInit(IInit ii) {
		iinit = ii;
		iinit.bigBang(WIDTH, HEIGHT, 60000, 1000);
	}

}