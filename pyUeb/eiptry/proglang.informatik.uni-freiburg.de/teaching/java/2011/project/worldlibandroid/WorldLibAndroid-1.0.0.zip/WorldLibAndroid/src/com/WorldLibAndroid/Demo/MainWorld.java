/**
 * 
 */
package com.WorldLibAndroid.Demo;

import android.os.Bundle;
import com.WorldLibAndroid.*;

/**
 * Main class to the activity is created.
 * 
 * @author Christian Herrera
 */
public class MainWorld extends World {

	/**
	 * Called when the activity is starting.
	 * 
	 * @param savedInstanceState
	 *            If the activity is being re-initialized after previously being
	 *            shut down then this Bundle contains the data it most recently
	 *            supplied in onSaveInstanceState(Bundle). Note: Otherwise it is
	 *            null.
	 */
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		myModel = new BlobWorld();
		myModel.onInit(this);
	}

}
