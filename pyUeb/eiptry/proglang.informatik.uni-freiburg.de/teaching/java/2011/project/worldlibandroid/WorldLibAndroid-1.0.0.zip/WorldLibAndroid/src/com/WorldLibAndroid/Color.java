package com.WorldLibAndroid;

/**
 * Color class to hold the color of an object.
 * 
 * @author Christian Herrera
 */
public class Color implements IColor {

	/**
	 * color to hold the color constant for an object.
	 */
	private int color;

	/**
	 * Constructor
	 * 
	 * @param color
	 *            to fill the object with.
	 */
	public Color(int color) {
		this.color = color;
	}

	/**
	 * Returns the integer representing a color.
	 * 
	 * @return color representation of the color.
	 */
	@Override
	public int thisColor() {
		return this.color;
	}

}
