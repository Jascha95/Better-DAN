package com.WorldLibAndroid;

/**
 * Copyright 2008 Viera K. Proulx
 * This program is distributed under the terms of the 
 * GNU Lesser General Public License (LGPL)
 */

/**
 * An interface to create a union of six basic colors used in ProfessorJ draw
 * teachpack.
 * 
 * @author Viera K. Proulx
 * @since 12 March 2008
 * 
 */
public interface IColor {

	/**
	 * Provides the color represented by this class.
	 * @return int representation of the color.
	 */
	public int thisColor();
}