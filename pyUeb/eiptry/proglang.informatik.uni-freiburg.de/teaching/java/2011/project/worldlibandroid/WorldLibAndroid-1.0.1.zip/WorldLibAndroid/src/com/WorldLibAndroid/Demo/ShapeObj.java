package com.WorldLibAndroid.Demo;

import java.util.Random;

import com.WorldLibAndroid.*;

import android.view.KeyEvent;

/**
 * The class that will hold the type of figure.
 * 
 * @author Christian Herrera
 * @since April 21, 2011
 */
public class ShapeObj {
	/** The Posn object to hold the coordinates of the blob.*/
	private Posn p1;
	/** The IColor object to hold the color of the figure.*/
	private IColor pn;
	/** The radius the radius of the blob.*/
	private int radius;
	
	/**
	 * @param p1 the Posn object to hold the coordinates of the blob.
	 * @param p the color of the figure.
	 * @param radius the radius of the blob.
	 * */
	ShapeObj(Posn p1, IColor p, int radius) {
		this.p1 = p1;
		this.pn = p;
		this.radius = radius;
	}

	/**
	 * Places the blob certain amount of pixels to the left, right, up or down.
	 * Changes the color of the blob.
	 * @param ke the integer representing the key pressed.
	 */
	public void moveBlob(int ke) {
		if (ke == KeyEvent.KEYCODE_DPAD_RIGHT) {
			this.p1.setX(this.p1.getX() + 5);
		} else if (ke == KeyEvent.KEYCODE_DPAD_LEFT) {
			this.p1.setX(this.p1.getX() - 5);
		} else if (ke == KeyEvent.KEYCODE_DPAD_UP) {
			this.p1.setY(this.p1.getY() - 5);
		} else if (ke == KeyEvent.KEYCODE_DPAD_DOWN) {
			this.p1.setY(this.p1.getY() + 5);
		}
		// change the color to Y, G, R
		else if (ke == KeyEvent.KEYCODE_Y) {
			this.pn = new Color(android.graphics.Color.YELLOW);
		} else if (ke == KeyEvent.KEYCODE_G) {
			Color green = new Color(android.graphics.Color.GREEN);
			this.pn = green;
		} else if (ke == KeyEvent.KEYCODE_R) {
			this.pn = new Color(android.graphics.Color.RED);
		}
	}

	/** Moves the blob when touching the screen. 
	 * @param x coordinate to move the object to.
	 * @param y coordinate to move the object to.*/
	public void moveAtTouch(int x, int y) {
		this.p1.setX(x);
		this.p1.setY(y);
	}
	
	/** Moves the blob using the acceleration sensor (when tilting the device). 
	 * @param x coordinate to move the object to.
	 * @param y coordinate to move the object to.*/
	public void moveAtTilt(int x, int y) {
		this.p1.setX(this.p1.getX() + x);
		this.p1.setY(this.p1.getY() + y);
	}

	/** Moves the blob using the orientation sensor. 
	 * @param x coordinate to move the object to.
	 * @param y coordinate to move the object to.*/
	public void moveAtOrient(int x, int y){
		this.p1.setX(this.p1.getX() + x);
		this.p1.setY(this.p1.getY() + y);
	}
	/** produce a new blob moved by a random distance < n pixels 
	 * @param n number of pixels to move randomly*/
	void randomMove(int n) {
		this.p1.setX(this.p1.getX() + this.randomInt(n));
		this.p1.setY(this.p1.getY() + this.randomInt(n));
	}

	/** helper method to generate a random number in the range -n to n 
	 * @param n number of pixels to move randomly
	 * @return integer calculated.
	 * */
	int randomInt(int n) {
		return -n + (new Random().nextInt(2 * n + 1));
	}

	/** is the blob outside the bounds given by the WIDTH and HEIGHT 
	 * @param width of the canvas considered to be out.
	 * @param height of the canvas considered to be out.
	 * @return true if out of the boundaries.
	 * */
	boolean outsideBounds(int width, int height) {
		return this.p1.getX() < 0 || this.p1.getX() > width || this.p1.getY() < 0
				|| this.p1.getY() > height;
	}

	/** is the blob near the center of area given by the WIDTH and HEIGHT 
	 * @param width of the canvas considered to be close to the center.
	 * @param height of the canvas considered to be close to the center.
	 * @return true if close to the center.
	 * */
	boolean nearCenter(int width, int height) {
		return this.p1.getX() > width / 2 - 10 && this.p1.getX() < width / 2 + 10
				&& this.p1.getY() > height / 2 - 10 && this.p1.getY() < height / 2 + 10;
	}
	
	/** is the blob near the center of area given by the WIDTH and HEIGHT 
	 * @param c object canvas.
	 * */
	public void draw(ICanvas c) {
		c.drawCircle(p1.getX(), p1.getY(), radius, pn);
	}

}
