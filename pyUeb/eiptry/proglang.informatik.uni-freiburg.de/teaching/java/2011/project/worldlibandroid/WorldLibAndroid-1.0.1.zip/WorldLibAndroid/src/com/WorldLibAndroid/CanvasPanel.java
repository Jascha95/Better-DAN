package com.WorldLibAndroid;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Bitmap.Config;
import android.graphics.drawable.Drawable;
import android.view.View;

/**
 * Copyright 2007, 2008 Viera K. Proulx
 * This program is distributed under the terms of the 
 * GNU Lesser General Public License (LGPL)
 */

/**
 * A panel to hold the drawings.
 * 
 */
public class CanvasPanel extends View implements ICanvas {
	/**
	 * c host the draw calls (writing into the bitmap).
	 */
	private Canvas c;
	/**
	 * b hold the pixels.
	 */
	private Bitmap b;
	/**
	 * width of the canvas.
	 */
	private int width = 0;
	/**
	 * height of the canvas.
	 */
	private int height = 0;

	/**
	 * The constructor to create an object with a specific width and height.
	 * 
	 * @param context
	 *            allows access to application-specific resources and classes,
	 *            as well as up-calls for application-level operations such as
	 *            launching activities, broadcasting and receiving intents, etc.
	 * @param width
	 *            of the canvas.
	 * @param height
	 *            of the canvas.
	 */
	public CanvasPanel(Context context, int width, int height) {
		super(context);
		this.height = height;
		this.width = width;
		b = Bitmap.createBitmap(width, height, Config.RGB_565);
		c = new Canvas(b);
	}

	/**
	 * Method to draw the figures on the canvas panel.
	 * 
	 * @param canvas
	 *            host the draw calls (writing into the bitmap).
	 */

	public void onDraw(Canvas canvas) {
		canvas.drawBitmap(b, new Matrix(), null);
	}

	/**
	 * Sets the color of the figure.
	 * 
	 * @param p
	 *            the interface that holds the color of the figure to draw.
	 * @return paint parsed object that holds the color.
	 */
	private Paint paintFromColor(IColor p) {
		Paint pnt = new Paint();
		pnt.setColor(p.thisColor());
		return pnt;
	}

	/**
	 * Draws a filled circle.
	 * 
	 * @param x
	 *            coordinate of the canvas panel.
	 * @param y
	 *            coordinate of the canvas panel.
	 * @param radius
	 *            of the circle.
	 * @param p
	 *            object that holds the color of the circle.
	 */
	@Override
	public void drawCircle(float x, float y, float radius, IColor p) {
		c.drawCircle(x, y, radius, paintFromColor(p));
	}

	/**
	 * Draws a line.
	 * 
	 * @param x1
	 *            coordinate of the beginning of the line.
	 * @param y1
	 *            coordinate of the beginning of the line.
	 * @param x2
	 *            coordinate of the end of the line.
	 * @param y2
	 *            coordinate of the end of the line.
	 * @param p
	 *            object that holds the color of the line.
	 */
	@Override
	public void drawLine(float x1, float y1, float x2, float y2, IColor p) {
		c.drawLine(x1, y1, x2, y2, paintFromColor(p));

	}

	/**
	 * Draws a filled rectangle.
	 * 
	 * @param x1
	 *            The left side of the rectangle to be drawn.
	 * @param y1
	 *            The top side of the rectangle to be drawn.
	 * @param x2
	 *            The right side of the rectangle to be drawn.
	 * @param y2
	 *            The bottom side of the rectangle to be drawn.
	 * @param p
	 *            object that holds the color of the rectangle.
	 */
	@Override
	public void drawRect(float x1, float y1, float x2, float y2, IColor p) {
		c.drawRect(x1, y1, x2, y2, paintFromColor(p));

	}

	/**
	 * Draws a text.
	 * 
	 * @param m
	 *            The text to be drawn.
	 * @param x
	 *            The x-coordinate of the origin of the text being drawn.
	 * @param y
	 *            The y-coordinate of the origin of the text being drawn.
	 * @param p
	 *            object that holds the color of the text.
	 */
	@Override
	public void drawText(String m, float x, float y, IColor p) {
		c.drawText(m, x, y, paintFromColor(p));

	}

	/** Clears the canvas. */
	@Override
	public void cleanCanvas() {
		b = Bitmap.createBitmap(width, height, Config.RGB_565);
		c = new Canvas(b);

	}

	/**
	 * Treat the specified array of colors as a bitmap, and draw it. This gives
	 * the same result as first creating a bitmap from the array, and then
	 * drawing it, but this method avoids explicitly creating a bitmap object
	 * which can be more efficient if the colors are changing often.
	 * 
	 * @param colors
	 *            Array of colors representing the pixels of the bitmap.
	 * @param offset
	 *            into the array of colors for the first pixel.
	 * @param stride
	 *            The number of colors in the array between rows (must be >=
	 *            width or <= -width).
	 * @param x
	 *            The X coordinate for where to draw the bitmap.
	 * @param y
	 *            The Y coordinate for where to draw the bitmap.
	 * @param width
	 *            The width of the bitmap.
	 * @param height
	 *            The height of the bitmap.
	 * @param hasAlpha
	 *            True if the alpha channel of the colors contains valid values.
	 *            If false, the alpha byte is ignored (assumed to be 0xFF for
	 *            every pixel).
	 * */
	@Override
	public void drawBitmap(int[] colors, int offset, int stride, float x,
			float y, int width, int height, boolean hasAlpha) {
		c.drawBitmap(colors, offset, stride, x, y, width, height, hasAlpha,
				null);

	}
	
	@Override
	public void drawDrawable(Drawable image) {
		image.draw(c);
	}
	
	/** Get the canvas. 
	 * @return c canvas object*/
	@Override
	public Canvas getAndroidCanvas() {
		return c;
	}

}
