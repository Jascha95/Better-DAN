package com.WorldLibAndroid;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.CountDownTimer;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

/**
 * Copyright 2007, 2008 Viera K. Proulx
 * This program is distributed under the terms of the 
 * GNU Lesser General Public License (LGPL)
 */


/**
 * World for programming interactive games - with graphics, key events,
 * mouse events and a timer. Designed to implement the same interface as
 * DrScheme/ProfessorJ world teachpack library.
 * 
 * @author Viera K. Proulx
 * @since November 15, 2007
 */

  public class World extends Activity implements IInit {

  /** theCanvas The canvas that displays the current world. */
  private  CanvasPanel theCanvas;
  
  /** worldExists True if 'bigBang' started the world and it did not end, did not stop. */
  protected boolean worldExists = true;

  /** myTime The timer for this world. */
  protected MyTimer myTime;
 
  /** myAdapter The key adapter for this world.*/
  protected MyKeyAdapter myAdapter;
 
  /** myTouchAdapter The touch adapter for this world.*/
  protected MyTouchAdapter myTouchAdapter;
  
  /** myTiltAdapter The tilt adapter for this world.*/
  protected MyTiltAdapter myTiltAdapter;
  
  /** myGyroscopeAdapter The gyroscope adapter for this world.*/
  protected MyGyroscopeAdapter myGyroscopeAdapter;
  
  /** myOriAdapter The orientation adapter for this world.*/
  protected MyOrientationAdapter myOriAdapter;
  
  /** myModel The model of this world.*/
  protected IWorld myModel;
  
  
  /////////////////////////////////////////////////////////////////////////
  // Methods for interacting with the World                              //
  /////////////////////////////////////////////////////////////////////////
  
  /**
   * Start the world by creating a canvas of the given size, creating
   * and adding the key and mouse adapters, and starting the timer at the
   * given speed.
   * @param width the Canvas of the <code>{@link CanvasPanel CanvasPanel}</code>
   * @param height the Canvas of the <code>{@link CanvasPanel CanvasPanel}</code>
   * @param mili The number of millis in the future from the call to start() until the countdown is done and onFinish() is called.
   * @param interval the The interval along the way to receive onTick(long) callbacks. 
   */

  public void bigBang(int width, int height, long mili, long interval ){
	  
	  theCanvas = new CanvasPanel(this, width, height);
	  
	  // make sure the canvas responds to events
	  theCanvas.setFocusable(true);
	  
      //Setting the canvas
      setContentView(theCanvas);
	  
	  // add the timer -- 
	  myTime = new MyTimer(this, mili,interval);
	  // add the key listener to the frame for our canvas
	  myAdapter = new MyKeyAdapter(this, theCanvas, this);
	  // add the touch listener to the frame for our canvas
	  myTouchAdapter = new MyTouchAdapter(this, theCanvas, this);
	  // add the tilt listener to the frame for our canvas
	  myTiltAdapter= new MyTiltAdapter(this, this);
	  // add the gyroscope listener to the frame for our canvas
	  myGyroscopeAdapter= new MyGyroscopeAdapter(this, this);
	  // add the orientation listener to the frame for our canvas
	  myOriAdapter= new MyOrientationAdapter(this, this);
	  
	  this.drawWorld();
  }

  /**
   * End the world interactions - leave the canvas open, 
   * write the end of world message onto the canvas
   */
  public void endOfWorld( ){  
	  // remove listeners and set worldExists to false
	  myTime.cancel();
	  // draw the final scene of the world with the end of world message
	  
	  //unregistering sensors
	  myTiltAdapter.unregisterAccelSensor();
	  myGyroscopeAdapter.unRegisterGyroSensor();
	  myOriAdapter.unRegisterOriSensor();
	  this.drawWorld();
	  
	  this.worldExists = false;  
	  System.out.println("The end of the world: ");
  }
  
  /**
   * The method invoked by the timer on each tick.
   * Delegates to the user to define a new state of the world,
   * then resets the canvas and event handlers for the new world
   * to those currently used.
   */
  protected void processTick(){
    try{
      if (worldExists){
        myModel.onTick();
        this.drawWorld();
      }
    } 
    catch(RuntimeException re){
      re.printStackTrace();
      //throw re;
      Runtime.getRuntime().halt(1);
    }
  }  
  
  /**
   * The method invoked by the key adapter on selected key events.
   * Delegates to the user to define a new state of the world,
   * then resets the canvas and event handlers for the new world
   * to those currently used.
   * @param keyCode integer representing the key pressed.
   */
  protected void processKeyEvent(int keyCode){
	  try{
		  if (worldExists){
	        myModel.onKeyEvent(keyCode);
	        this.drawWorld();
		  }
	  }
	  catch(RuntimeException re){
	    re.printStackTrace();
	    //throw re;
	    Runtime.getRuntime().halt(1);
	  }
  }
  
  /**
   * The method invoked by the touch adapter when touching the screen.
   * Delegates to the user to define a new state of the world,
   * then resets the canvas and event handlers for the new world
   * to those currently used.
   * @param x integer representing the x coordinate when touching the screen.
   * @param y integer representing the y coordinate when touching the screen.
   */
  protected void processTouchEvent(int x, int y){
	  try{
		  if (worldExists){
	        myModel.onTouchEvent(x, y);
	        this.drawWorld();
		  }
	  }
	  catch(RuntimeException re){
	    re.printStackTrace();
	    //throw re;
	    Runtime.getRuntime().halt(1);
	  }
  }
  
  /**
   * The method invoked by the tilt adapter when tilting the device.
   * Delegates to the user to define a new state of the world,
   * then resets the canvas and event handlers for the new world
   * to those currently used.
   * @param mAccelX Acceleration minus Gx on the x-axis 	
   * @param mAccelY Acceleration minus Gy on the y-axis 
   * @param mAccelZ Acceleration minus Gz on the z-axis 
   */
  protected void processTiltEvent(float mAccelX, float mAccelY, float mAccelZ){
	  try{
		  if (worldExists){
	        myModel.onTiltEvent(mAccelX, mAccelY, mAccelZ);
	        this.drawWorld();
		  }
	  }
	  catch(RuntimeException re){
	    re.printStackTrace();
	    //throw re;
	    Runtime.getRuntime().halt(1);
	  }
  }
  
  /**
   * The method invoked by the gyroscope adapter when moving the device.
   * Delegates to the user to define a new state of the world,
   * then resets the canvas and event handlers for the new world
   * to those currently used.
   * @param mGyroX Angular speed around the x-axis 
   * @param mGyroY Angular speed around the y-axis 
   * @param mGyroZ Angular speed around the z-axis 
   */
  protected void processGyroscopeEvent(float mGyroX, float mGyroY, float mGyroZ){
	  try{
		  if (worldExists){
	        myModel.onGyroscopeEvent(mGyroX, mGyroY, mGyroZ);
	        this.drawWorld();
		  }
	  }
	  catch(RuntimeException re){
	    re.printStackTrace();
	    //throw re;
	    Runtime.getRuntime().halt(1);
	  }
  }
  
  /**
   * The method invoked by the orientation adapter when moving the device.
   * Delegates to the user to define a new state of the world,
   * then resets the canvas and event handlers for the new world
   * to those currently used.
   * @param mOriX Azimuth, angle between the magnetic north direction and the y-axis, around the z-axis (0 to 359). 0=North, 90=East, 180=South, 270=West.
   * @param mOriY Pitch, rotation around x-axis (-180 to 180), with positive values when the z-axis moves toward the y-axis.
   * @param mOriZ Roll, rotation around y-axis (-90 to 90), with positive values when the x-axis moves toward the z-axis. 
   */
  protected void processOrientationEvent(float mOriX, float mOriY, float mOriZ){
	  try{
		  if (worldExists){
	        myModel.onOrientationEvent(mOriX, mOriY, mOriZ);
	        this.drawWorld();
		  }
	  }
	  catch(RuntimeException re){
	    re.printStackTrace();
	    //throw re;
	    Runtime.getRuntime().halt(1);
	  }
  }
  
  /**
   * Invoke the user defined <code>drawWorld</code> method, if this 
   * <code>{@link World World}</code> has been initialized 
   * via <code>bigBang</code> and did not stop or end 
   * or <code>endOfWorld</code>

   */
  protected void drawWorld(){
    if (this.worldExists){
      myModel.draw(theCanvas);
      theCanvas.postInvalidate();
    }
  }

@Override
public ContextThemeWrapper context() {
	return this;
}

}

/**
 * The action listener for the timer events.
 * 
 * @author Viera K. Proulx
 * @since August 2, 2007
 */
 
class MyTimer{

	  /** currWorld that handles the timer events */
	  protected World currWorld;
	  
	  /** timer that generates the time events */
	  protected CountDownTimer timer;
	  
	  /** running evaluates if the world is still running */
	  protected boolean running = true;

	  /**
	   * Create the initial timer for the given 
	   * <code>{@link World World}</code> at the given <code>speed</code>.
	   * 
	   * @param currentWorld the given <code>{@link World World}</code>
	   * @param mili the given <code>mili</code>
	   * @param interval the given <code>interval</code>
	   */

	  protected MyTimer(World currentWorld, long mili, long interval){
		  	currWorld = currentWorld;

		  	timer = new CountDownTimer(mili, interval) {
		  		public void onTick(long millisUntilFinished) {
		  			currWorld.processTick();
		  		}

		  		public void onFinish() {
		  			///currWorld.worldExists = false;
		  			System.out.println("The world stopped");
		  		}
		  	}.start();
	  }
	/**
	  * Method call when the time expires. 
	  */
	public void cancel() {
		timer.cancel();		
	}
}


/**
 * <p>The implementation of callbacks for the key events.</p>
 * <p>Report all regular key presses and the four arrow keys</p>
 * <p>Ignore other key pressed events, key released events, 
 * special keys, etc.</p>
 * 
 * @author Viera K. Proulx
 * @since August 2, 2007
 */
class MyKeyAdapter extends View {

  /** the current <code>{@link World World}</code> 
   * that handles the key events */
  protected World theWorld;
  /**
   * cp CanvasPanel object to attach the listener to.
   */
  protected CanvasPanel cp;
  

  /** the <code>KeyAdapter</code> that handles the key events 
   * @param contex allows access to application-specific resources and classes, as well as up-calls for application-level operations such as launching activities, broadcasting and receiving intents, etc. 
   * @param c CanvasPanel object to attach the listener to.
   * @param w object World that handles the callbacks.
   * */
  protected MyKeyAdapter(Context contex, CanvasPanel c, World w){
	  super(contex);
	  cp = c;
	  theWorld = w;
	  
	  /** the <code>setOnKeyListener</code> that handles the key events occurring on the CanvasPanel*/
      cp.setOnKeyListener(new OnKeyListener () {
	  public boolean onKey(View v, int keyCode, KeyEvent event){
		 
//			String keyString ="";

		    int id = event.getAction();
	        if (id == KeyEvent.ACTION_DOWN){
	        	theWorld.processKeyEvent(keyCode); 
		    }
		return false;
  		}
  });
}
}

/** the <code>TouchAdapter</code> that handles touch events */
class MyTouchAdapter extends View {
	 /** the current <code>{@link World World}</code> 
	   * that handles the key events */
	  protected World theWorld;
	  /**
	   * cp CanvasPanel object to attach the listener to.
	   */
	  protected CanvasPanel cp;
	  /**
	   * x coordinate representing the point when touching the screen.
	   */
	  protected int x = 0;
	  /**
	   * y coordinate representing the point when touching the screen
	   */
	  protected int y = 0;
	  
	  /** the <code>TouchAdapter</code> that handles the touch events 
	   * @param contex allows access to application-specific resources and classes, as well as up-calls for application-level operations such as launching activities, broadcasting and receiving intents, etc. 
	   * @param c CanvasPanel object to attach the listener to.
	   * @param w object World that handles the callbacks.
	   * */
	  protected MyTouchAdapter(Context contex, CanvasPanel c, World w){
		  super(contex);
		  cp = c;
		  theWorld = w;
		  
		  /** the <code>setOnTouchListener</code> that handles the touch events occurring on the CanvasPanel*/
	      cp.setOnTouchListener(new OnTouchListener(){
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_DOWN)
				{
					x = (int) event.getX();
			    	y = (int) event.getY();
			    	theWorld.processTouchEvent(x,y);
				}else if (event.getAction() == MotionEvent.ACTION_MOVE)
				{
					x = (int) event.getX();
			    	y = (int) event.getY();
			    	theWorld.processTouchEvent(x,y);
				}
			    return true;
			}
	      });
	}
}

/** the TiltAdapter that handles the movements of the device */
class MyTiltAdapter  {
	 /** the current <code>{@link World World}</code> 
	   * that handles the key events */
	protected World theWorld;
	
	/** Acceleration minus Gx on the x-axis.
	 */
    private float mAccelX = 0;
    /**
    * 	Acceleration minus Gy on the y-axis.
    */
	private float mAccelY = 0;
	/**
	 *  Acceleration minus Gz on the z-axis. 
	 * */
	private float mAccelZ = 0;
	/**
	 *  object to register the acceleration sensor.
	 */
	private SensorManager mAcceSen;
	
	/**
	 *  object to handle the callback to the acceleration sensor.
	 */
    private final SensorEventListener listen = new SensorEventListener() {
		@Override
		public void onSensorChanged(SensorEvent event) {
			mAccelX = event.values[0];
			mAccelY = event.values[1];
			mAccelZ = event.values[2];
			
			theWorld.processTiltEvent(mAccelX,mAccelY,mAccelZ);
		}
		public void onAccuracyChanged(Sensor event, int res) {}
    };
    
    /** The constructor will use a context object to register itself for various inputs:
      * @param c object to retrieve the sensor service.
      * @param w object World that handles the callbacks.
     */
    protected MyTiltAdapter(Context c, World w) {
    	theWorld = w;

    	mAcceSen = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);  
        Sensor accSensor = mAcceSen.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mAcceSen.registerListener(listen, accSensor, SensorManager.SENSOR_DELAY_UI);
    	
    }
    /**
     * Method to unregister the acceleration sensor.
     */
    public void unregisterAccelSensor(){
    	mAcceSen.unregisterListener(listen);
    }
}
    /** the <code>GyroscopeAdapter</code> that handles the movements of the device */
    class MyGyroscopeAdapter  {
   	 /** the current <code>{@link World World}</code> 
  	   * that handles the key events */
    	protected World theWorld;
    	/** mGyroX Angular speed around the x-axis. */
        private float mGyroX = 0;
    	/** mGyroX Angular speed around the y-axis. */
    	private float mGyroY = 0;
    	/** mGyroZ Angular speed around the z-axis. */
    	private float mGyroZ = 0;
    	/**
    	 *  object to register the gyroscope sensor.
    	 */
    	private SensorManager mGyroSen;

    	/**
    	 *  object to handle the callback to the acceleration sensor.
    	 */
        private final SensorEventListener listen = new SensorEventListener() {
    		@Override
    		public void onSensorChanged(SensorEvent event) {
    			mGyroX = event.values[0];
    			mGyroY = event.values[1];
    			mGyroZ = event.values[2];
    			
    			theWorld.processGyroscopeEvent(mGyroX,mGyroY,mGyroZ);
    		}
    		public void onAccuracyChanged(Sensor event, int res) {}
        };
        
        /** The constructor will use a context object to register itself for various inputs:
         * @param c object to retrieve the sensor service.
         * @param w object World that handles the callbacks.
         * */
        
        protected MyGyroscopeAdapter(Context c, World w) {
        	theWorld = w;

        	mGyroSen = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);  
            Sensor accSensor = mGyroSen.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            mGyroSen.registerListener(listen, accSensor, SensorManager.SENSOR_DELAY_UI);
        }
        /**
         * Method to unregister the acceleration sensor.
         */
        public void unRegisterGyroSensor(){
        	mGyroSen.unregisterListener(listen);
        }
}

    /** the MyOrientationAdapterAdapter that handles the movements of the device */
class MyOrientationAdapter  {
	
  	   /** theWorld the current World  that handles the key events */
    	protected World theWorld;
    	/** mOriX Azimuth, angle between the magnetic north direction and the y-axis, around the z-axis (0 to 359). 0=North, 90=East, 180=South, 270=West.
    	 * */
        private float mOriX = 0;
    	/** mOriY Pitch, rotation around x-axis (-180 to 180), with positive values when the z-axis moves toward the y-axis.
    	 * */
    	private float mOriY = 0;
    	/** mOriZ Roll, rotation around y-axis (-90 to 90), with positive values when the x-axis moves toward the z-axis.
    	 * */
    	private float mOriZ = 0;
    	/**
    	 *  object to register the orientation sensor.
    	 */
    	private SensorManager mOriSen;

    	/**
    	 *  object to handle the callback to the orientation sensor.
    	 */
        private final SensorEventListener listen = new SensorEventListener() {
    		@Override
    		public void onSensorChanged(SensorEvent event) {
    			mOriX = event.values[0];
    			mOriY = event.values[1];
    			mOriZ = event.values[2];
    			
    			theWorld.processOrientationEvent(mOriX,mOriY,mOriZ);
    		}
    		public void onAccuracyChanged(Sensor event, int res) {}
        };
        
        /** The constructor will use a context object to register itself for various inputs:
         * @param c object to retrieve the sensor service.
         * @param w object World that handles the callbacks.
         * */
        protected MyOrientationAdapter(Context c, World w) {
        	theWorld = w;

        	mOriSen = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);  
            Sensor oriSensor = mOriSen.getDefaultSensor(Sensor.TYPE_ORIENTATION);
            mOriSen.registerListener(listen, oriSensor, SensorManager.SENSOR_DELAY_UI);
        }
        /**
         * Method to unregister the acceleration sensor.
         */
        public void unRegisterOriSensor(){
        	mOriSen.unregisterListener(listen);
        }
    }



