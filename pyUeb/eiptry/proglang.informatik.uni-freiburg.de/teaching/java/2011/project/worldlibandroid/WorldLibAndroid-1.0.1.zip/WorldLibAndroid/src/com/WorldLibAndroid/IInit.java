package com.WorldLibAndroid;

import android.view.ContextThemeWrapper;

/**
 * An interface to provide methods to initialize and end a given world.
 * 
 * @author Christian Herrera
 */
public interface IInit {
	/**
	 * Initializes the world.
	 * 
	 * @param width
	 *            of the canvas.
	 * @param height
	 *            of the canvas.
	 * @param millis
	 *            The number of millis in the future from the call to start()
	 *            until the countdown is done and onFinish() is called.
	 * @param interval
	 *            The interval along the way to receive onTick(long) callbacks.
	 */
	public void bigBang(int width, int height, long millis, long interval);

	/** Ends the world */
	public void endOfWorld();
	
	/**
	 * Access to the application's environment.
	 * 
	 * @return the application context
	 */
	public ContextThemeWrapper context();
}
