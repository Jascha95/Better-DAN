package adventure;

import java.io.PrintWriter;

/**
 * Application logic for a program with a line-based text interface.
 * <p>
 * A shell calls {@link #start(PrintWriter)} once at the start of a session, then
 * feeds it line after line of user input with {@link #processInput(String, PrintWriter)}
 * until the processInput call returns false.
 * <p>
 * This resembles the Servlet approach to running web servers. 
 * 
 * @author anton
 *
 */
public interface ILineHandler {

	/**
	 * The session has started. The line handler can e.g. print a
	 * welcome message. This method may only be called once, and
	 * not after a call to {@link #processInput(String, PrintWriter)}.
	 * 
	 * @param output print output here.
	 */
	void start(PrintWriter output);

	/**
	 * Process another line of input.
	 * 
	 * @param line a line of user input without the trailing newline.
	 * @param output where output should be printed.
	 * @return true if processing should continue, false to finish the session.
	 */
	boolean processInput(String line, PrintWriter output);
	
}
