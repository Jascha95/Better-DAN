package adventure;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

/**
 * Mediate between a {@link ILineHandler} and standard input/output.
 * 
 * @author anton
 *
 */
public class Shell {

	
	/**
	 * The line-based application. 
	 */
	private ILineHandler repl;
	
	/**
	 * Create a shell to run that line handler.
	 * @param repl a ILineHandler.
	 */
	public Shell(ILineHandler repl) {
		this.repl = repl;
	}

	/**
	 * Run the line handler to completion.
	 */
	public void run() {
		try {
			boolean wantsToContinue = true;
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			PrintWriter out = new PrintWriter(System.out);
			repl.start(out);
			while(wantsToContinue) {
				out.print("> ");
				out.flush();
				String s = br.readLine();
				if(s != null) {
					wantsToContinue = repl.processInput(s, out);
				}
				else {
					wantsToContinue = false;
				}
			}
			out.println("\n--END--");
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
