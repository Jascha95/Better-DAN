package adventure;

/**
 * Main class for the adventure.
 * @author anton
 *
 */
public class Main {

	/**
	 * @param args unused command-line args.
	 */
	public static void main(String[] args) {
		/*
		IStoryState happyEnd = new FinalState(
				"Sie nimmt einen Keks und lächelt Dich kurz an.\n" +
				"Zwei Stunden später packt sie ihre Notizen ein und bricht auf.\n" +
				"Du fängst sie am Kaffeeautomaten ab. Ein Wort gibt das andere.\n" +
				"Noch am selben Abend tauscht Ihr PGP-Schlüssel aus und richtet\n" +
				"einander Accounts ein.\n\n" +
				"The End.");
		IStoryState badEnd = new FinalState(
				"Sie verdreht die Augen, packt ihren Rucksack und verlässt den Pool.\n" +
				"\nDas war wohl nichts.");
		IStoryState s2 = new ChoiceState(
				"Sie kneift kurz die Augen zu und runzelt die Stirn. \n" +
				"'C-u M-|', sagt sie dann, lächelt kurz und wendet sich wieder ihrem Programm zu.\n" +
				"(1) Du sagst 'Ich wusste gar nicht, dass Mädchen Emacs verwenden können.'\n" +
				"(2) Du bietest ihr einen von Deinen Keksen an.\n",
				badEnd, happyEnd); 
		IStoryState s1 = new ChoiceState(
				"Du sitzt im Pool. Eine auf eine nerdige Weise gutaussehende Studentin\n" +
				"sitzt zwei Rechner weiter.\n" +
				"(1) Du fragst sie, ob sie auswendig weiß, wie man im Emacs\n" +
				"    eine Region durch ein Shell-Kommando peipt.\n" +
				"(2) Du fragst sie, ob ihr Vater ein Dieb ist, \n" +
				"    denn im Himmel fehlen ein paar Sterne.\n", s2, badEnd);
		AdventureLineHandler alh = new AdventureLineHandler(s1);
		new Shell(alh).run();
		*/
	}

}
