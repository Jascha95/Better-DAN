package pair;

/**
 * I say 'yes' to some objects and 'no' to other objects.
 * 
 * @author anton
 *
 * @param <T> the type of objects I have an opinion of
 */
public interface ISelect<T> {

	/**
	 * Do I say 'yes' to that particular object
	 * @param elem an object, not null
	 * @return true iff I say 'yes' to that object.
	 */
	boolean selected(T elem);
}
