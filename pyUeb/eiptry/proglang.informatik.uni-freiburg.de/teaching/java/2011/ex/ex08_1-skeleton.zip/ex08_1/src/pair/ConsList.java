package pair;

/**
 * List containing of a head value and a tail list.
 * 
 * @author anton
 *
 * @param <E> element type.
 */
public class ConsList<E> implements IList<E> {
	
	/**
	 * The first element
	 */
	private final E head;
	/**
	 * The second through nth element
	 */
	private final IList<E> tail;
	/**
	 * Make a new list by prepending an element
	 * @param head new element
	 * @param tail old list
	 */
	public ConsList(E head, IList<E> tail) {
		this.head = head;
		this.tail = tail;
	}
	@Override
	public boolean isEmpty() {
		return false;
	}
	@Override
	public E head() {
		return head;
	}
	@Override
	public IList<E> tail() {
		return tail;
	}
	@Override
	public int size() {
		return 1 + tail.size();
	}
	@Override
	public IList<E> filter(ISelect<E> filterPredicate) {
		IList<E> filteredTail = tail.filter(filterPredicate);
		if(filterPredicate.selected(head)) {
			return new ConsList<E>(head, filteredTail);
		}
		else {
			return filteredTail;
		}
	}
	
}
