package pair;

/**
 * Generic functional list.
 * 
 * @author anton
 *
 * @param <E> the type of the contained elements
 */
public interface IList<E> {
	/**
	 * Is this an empty list?
	 * @return true iff empty list.
	 */
	boolean isEmpty();
	/**
	 * The head of this list.
	 * Undefined behaviour if the list is empty.
	 * @return an E.
	 */
	E head();
	/**
	 * The rest of this list (all elements except for the first).
	 * Undefined behaviour if the list is empty.
	 * @return a list.
	 */
	IList<E> tail();
	
	/**
	 * @return size of this list.
	 */
	int size();
	
	/**
	 * Create a list of only the elements to which the filterPredicate
	 * says 'yes'.
	 * @param filterPredicate a predicate
	 * @return a sublist of this list.
	 */
	IList<E> filter(ISelect<E> filterPredicate);
}
