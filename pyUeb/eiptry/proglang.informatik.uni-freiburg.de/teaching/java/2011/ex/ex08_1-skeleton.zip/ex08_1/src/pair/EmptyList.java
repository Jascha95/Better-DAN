package pair;

/**
 * The empty list.
 * @author anton
 *
 * @param <E> Type of values which this list does not contain
 */
public class EmptyList<E> implements IList<E> {

	@Override
	public boolean isEmpty() {
		return true;
	}

	@Override
	public E head() {
		throw new UnsupportedOperationException();
	}

	@Override
	public IList<E> tail() {
		throw new UnsupportedOperationException();
	}

	@Override
	public int size() {
		return 0;
	}

	@Override
	public IList<E> filter(ISelect<E> filterPredicate) {
		return this;
	}

}
