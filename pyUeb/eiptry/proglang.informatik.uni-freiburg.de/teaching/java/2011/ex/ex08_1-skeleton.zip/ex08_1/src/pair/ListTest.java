package pair;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * Unit test for the {@link IList} implementations.
 * 
 * @author anton
 *
 */
public class ListTest {

	/**
	 * Empty list: size 0
	 */
	@Test
	public void testEmptyListSize() {
		EmptyList<String> mt = new EmptyList<String>();
		assertEquals(0, mt.size());
		assertTrue(mt.isEmpty());
	}
	
	/**
	 * Empty list, filtered, stays empty
	 */
	@Test
	public void testEmptyListFilter() {
		EmptyList<String> mt = new EmptyList<String>();
		IList<String> filtered = mt.filter(new StartsWithCapitalZ());
		assertTrue(filtered.isEmpty());
	}
	
	/**
	 * Test: three-element list has size 3
	 */
	@Test
	public void testConsListSize() {
		IList<String> abc = 
				new ConsList<String>("Zauberer", 
						new ConsList<String>("schmelzen", 
								new ConsList<String>("Zinksulfid", new EmptyList<String>())));
		assertFalse(abc.isEmpty());
		assertEquals(3, abc.size());
	}
	
	/**
	 * Test filtering of a three-element list.
	 */
	@Test
	public void testConsListFilter() {
		IList<String> abc = 
				new ConsList<String>("Zauberer", 
						new ConsList<String>("schmelzen", 
								new ConsList<String>("Zinksulfid", new EmptyList<String>())));
		IList<String> ac = abc.filter(new StartsWithCapitalZ());
		assertEquals(2, ac.size());
		assertEquals("Zauberer", ac.head());
		assertEquals("Zinksulfid", ac.tail().head());
	}
	
	/**
	 * A predicate which says 'yes' to words starting with 'Z' and no
	 * to all others.
	 * @author anton
	 *
	 */
	private static class StartsWithCapitalZ implements ISelect<String> {

		@Override
		public boolean selected(String elem) {
			return elem.startsWith("Z");
		}
		
	}
}
