package pair;

/**
 * Finite mapping, mutable
 * 
 * @author anton
 *
 * @param <K> key type
 * @param <V> value type
 */
public interface IMap<K,V> {

	/**
	 * Associate that key with that value
	 * @param key key, not null
	 * @param value value, not null
	 */
	void put(K key, V value);
	
	/**
	 * The value associated with key, or null
	 * @param key a key, not null
	 * @return a value, or null
	 */
	V get(K key);
	
}
