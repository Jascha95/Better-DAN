package testing;

/**
 * Logger for error messages. You call {@link #logError(boolean, String)}
 * to record that an error has occurred.
 * <p>
 * The logger writes to two log files (represented by {@link IOutputStream}
 * instances): the critical error log and the complete error log.
 * Log entries are always one line, starting with a 24h-timestamp in the
 * "HH:MM:SS" format, and finishing with a newline char.
 * </p>
 * <p>
 * Errors can be <em>critical</em>. 
 * All errors are written to the complete error log.
 * Only critical errors are written to the critical
 * error log. A critical error in the complete error log
 * is prefixed with "CRITICAL: ". 
 * </p>
 *  
 * @author anton
 *
 */
public class ErrorLogger {

	/**
	 * will be used for timestamps
	 */
	private final IClock clock;
	/**
	 * write all critical errors here
	 */
	private final IOutputStream criticalStream;
	/**
	 * write critical and noncritical messages here.
	 */
	private final IOutputStream completeStream;
	
	/**
	 * Create a new logger
	 * @param clock will be used for timestamps
	 * @param errorStream write critical errors here
	 * @param completeStream write all messages here
	 */
	public ErrorLogger(IClock clock, IOutputStream errorStream,
			IOutputStream completeStream) {
		super();
		this.clock = clock;
		this.criticalStream = errorStream;
		this.completeStream = completeStream;
	}

	/**
	 * Log an error.
	 * @param critical true if this is a critical error.
	 * @param message Error message
	 */
	public void logError(boolean critical, String message) {
		SimpleTime now = clock.now();
		String timeString = now.toString();
		if(critical) {
			criticalStream.write(timeString+": "+message+"\n");
			completeStream.write(timeString+": CRTICAL: "+message+"\n");
		}
		else {
			completeStream.write(timeString+": "+message);
		}
	}
	
}
