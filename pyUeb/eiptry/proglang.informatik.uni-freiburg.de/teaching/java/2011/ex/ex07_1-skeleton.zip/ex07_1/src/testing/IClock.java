package testing;


/**
 * You can ask me what time it is.
 * 
 * @author anton
 *
 */
public interface IClock {

	/**
	 * @return the current time.
	 */
	SimpleTime now();
}
