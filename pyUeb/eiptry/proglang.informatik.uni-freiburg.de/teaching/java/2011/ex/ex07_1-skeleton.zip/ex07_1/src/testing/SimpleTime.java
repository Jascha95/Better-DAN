package testing;

import java.util.GregorianCalendar;

/**
 * One second in a day. Normally, you'd use something like 
 * {@link Date} or {@link GregorianCalendar}, but in this example,
 * we just want to transport hour minute second, and don't worry
 * about calendar reforms and leap seconds.
 * 
 * @author anton
 *
 */
public class SimpleTime {

	/**
	 * The hours.
	 */
	private final int hours;
	/**
	 * The minutes.
	 */
	private final int minutes;
	/**
	 * The seconds.
	 */
	private final int seconds;

	/**
	 * Make new point in time.
	 * @param hours hours 0..23
	 * @param minutes minutes 0..59
	 * @param seconds seconds 0..59
	 */
	public SimpleTime(int hours, int minutes, int seconds) {
		this.hours = hours;
		this.minutes = minutes;
		this.seconds = seconds;
	}

	/**
	 * @return the hours
	 */
	public int getHours() {
		return hours;
	}

	/**
	 * @return the minutes
	 */
	public int getMinutes() {
		return minutes;
	}

	/**
	 * @return the seconds
	 */
	public int getSeconds() {
		return seconds;
	}
	
	@Override
	public String toString() {
		return String.format("%02d:%02d:%02d",hours,minutes,seconds);
	}
}
