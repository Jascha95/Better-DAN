package testing;

/**
 * Simplified output stream (The stream and writer classes from java.io are
 * too complex for the example).
 * 
 * @author anton
 *
 */
public interface IOutputStream {

	/**
	 * Write the text to the output. Does not add a newline or anything. 
	 * @param text some text.
	 */
	void write(String text);
	
}
