package date;

/**
 * A class representing a date.
 *
 */
public class Date {
	
	/**
	 * The date's year.
	 */
	private int year;
	
	/**
	 * The date's month.
	 */
	private int month;
	
	/**
	 * The date's day.
	 */
	private int day;
	
	/**
	 * A constant array holding the number of days per month for non leap years.
	 * After initialization the following holds true:
	 * 
	 *  DAYS_PER_MONTH_NON_LEAP_YEAR[i] is the number of days in the (i+1)th month
	 *  of the non-leap-year, (e.g. DAYS_PER_MONTH_NON_LEAP_YEAR[1] is the
	 *  length of February, i.e. 28 days)
	 */
	static final int[] DAYS_PER_MONTH_NON_LEAP_YEAR = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };  
	
	/**
	 * Constructs a new date using the specified year, month, and day values.
	 * @param year The date's year.
	 * @param month The date's month (one-based).
	 * @param day The date's day (one-based).
	 */
	public Date(int year, int month, int day) {
		this.year = year;
		this.month = month;
		this.day = day;
	}
	
	/**
	 * If you number all days of the year, in which place does this day
	 *  appear?
	 * @return The day of the year for this date (1-based, i.e. Jan 1 returns 1)
	 */
	public int dayOfTheYear() {
		int result = 0;
		
		for (int i=1; i<this.month; i++) {
			result += daysPerMonth(this.year, i);
		}
		result += this.day;
		
		return result;
	}
	
	/**
	 * Returns the number of days of the specified month in the specified year.
	 * @param year The month's year (one-based).
	 * @param month The month to return the number of days for (one-based).
	 * @return The number of days in the specified month.
	 */
	public static int daysPerMonth(int year, int month) {
		if (month == 2 && isLeapYear(year)) {
			return DAYS_PER_MONTH_NON_LEAP_YEAR[month-1] + 1;
		}
		else {
			return DAYS_PER_MONTH_NON_LEAP_YEAR[month-1];
		}
	}
	
	/**
	 * Returns whether the specified year is a leap year.
	 * @param year The year to check (one-based). 
	 * @return True, if the specified is leap year, false otherwise.
	 */
	public static boolean isLeapYear(int year) {
		return ((year % 4) == 0);
	}
	
	/**
	 * This method returns whether this date is after the specified date. 
	 * @param other The date to compare this date to.
	 * @return The method returns true, if and only if this date is after the
	 * specified date, false otherwise.
	 */
	public boolean after(Date other) {
		boolean result;
		
		if (this.year > other.year) {
			result = true;
		}
		else if (this.month > other.month) {
			result = true;
		}
    	else if (this.day > other.day) {
    		result = true;
		}
		else {
			result = false;
		}
		
		return result;
	}
	
	/**
	 * Returns a string representation of the object.
	 * 
	 * @return a string representation of this date.
	 */
	public String toString() {
		return year + "-" + month + "-" + day; 
	}
}
