package except;

/**
 * Dummy implementation for {@link IceCreamControl} in tests.
 * 
 * The fields starting with 'pretend' control whether the cone
 * dispenser, the pump or the mill, respectively,
 * will throw an error.
 * 
 * @author anton
 *
 */
public class DummyIceCreamDispenser implements IIceCreamDispenser {

	/**
	 * Pretend that the cone supply is empty?
	 */
	private boolean pretendConesEmpty;
	
	/**
	 * Pretend that the ice cream supply is empty?
	 */
	private boolean pretendIceCreamEmpty;
	/**
	 * Pretend that the pump has jammed?
	 */
	private boolean pretendPumpJammed;
	/**
	 * Pretend that the mill has blocked?
	 */
	private boolean pretendMillBlocked;
	
	@Override
	public void dropCone() {
		if(pretendConesEmpty) {
			// TODO throw an exception
		}
	}

	@Override
	public void pumpIceCream() {
		if(pretendIceCreamEmpty) {
			// TODO throw an exception
		}
		if(pretendPumpJammed) {
			// TODO throw an exception
		}
	}

	@Override
	public void grindChocolate() {
		if(pretendMillBlocked) {
			// TODO throw an exception
		}
	}

	/**
	 * @return the pretendConesEmpty
	 */
	public boolean isPretendConesEmpty() {
		return pretendConesEmpty;
	}

	/**
	 * @param pretendConesEmpty the pretendConesEmpty to set
	 */
	public void setPretendConesEmpty(boolean pretendConesEmpty) {
		this.pretendConesEmpty = pretendConesEmpty;
	}

	/**
	 * @return the pretendPumpJammed
	 */
	public boolean isPretendPumpJammed() {
		return pretendPumpJammed;
	}

	/**
	 * @param pretendPumpJammed the pretendPumpJammed to set
	 */
	public void setPretendPumpJammed(boolean pretendPumpJammed) {
		this.pretendPumpJammed = pretendPumpJammed;
	}

	/**
	 * @return the pretendMillBlocked
	 */
	public boolean isPretendMillBlocked() {
		return pretendMillBlocked;
	}

	/**
	 * @param pretendMillBlocked the pretendMillBlocked to set
	 */
	public void setPretendMillBlocked(boolean pretendMillBlocked) {
		this.pretendMillBlocked = pretendMillBlocked;
	}

	
}
