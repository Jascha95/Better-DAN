package except;

/**
 * Controller for the ice cream machine. Handles user interaction. Tells the
 * {@link IIceCreamDispenser} what to do.
 * 
 * @author anton
 * 
 */
public class IceCreamControl {

	/**
	 * My {@link IIceCreamDispenser} instance.
	 */
	private final IIceCreamDispenser dispenser;

	/**
	 * Is this machine in OK condition?
	 */
	private boolean ok;

	/**
	 * The message we're displaying on the little display.
	 */
	private String message = "";

	/**
	 * Ctor.
	 * 
	 * @param dispenser
	 *            The dispenser to use.
	 */
	public IceCreamControl(IIceCreamDispenser dispenser) {
		this.dispenser = dispenser;
		ok = true;
	}

	/**
	 * Make a small ice cone. TODO Error handling: this method lets all
	 * exceptions through to the caller
	 */
	public void makeKidCone() {
		dispenser.dropCone();
		dispenser.pumpIceCream();
		dispenser.grindChocolate();
	}

	/**
	 * Make a big ice cone. TODO Error handling: this method lets all exceptions
	 * through to the caller
	 */
	public void makeMaxiCone() {
		dispenser.dropCone();
		dispenser.pumpIceCream();
		dispenser.pumpIceCream();
		dispenser.grindChocolate();
	}

	/**
	 * Handle a key pressed on the keypad.
	 * 
	 * 'k' makes a kid cone, 'm' makes a maxi cone. If successful,
	 * we display "THANK YOU". If an invalid key is pressed, we display
	 * "???". If the dispenser reports an error, we display 
	 * "FILL CONES" if out of cones, or "FILL ICE" if out of ice cream,
	 * or "CALL SERVICE" if another error occurs.
	 * 
	 * TODO Error handling: this method handles all errors by displaying a
	 * message.
	 * 
	 * @param c
	 *            the key entered.
	 */
	public void handleKeypadInput(char c) {
		if (ok) {
			if (c == 'k') {
				makeKidCone();
				displayMessage("THANK YOU");
			} else if (c == 'm') {
				makeMaxiCone();
				displayMessage("THANK YOU");
			} else {
				// TODO the user has pressed a meaningless button
			}
			// TODO error handling!
		}
	}

	/**
	 * Display a message on the display
	 * 
	 * @param string
	 *            message
	 */
	private void displayMessage(String string) {
		message = string;
	}

	/**
	 * Is the machine operating fully OK? No disturbances?
	 * 
	 * @return the ok
	 */
	public boolean isOk() {
		return ok;
	}

	/**
	 * The message on the display.
	 * 
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

}
