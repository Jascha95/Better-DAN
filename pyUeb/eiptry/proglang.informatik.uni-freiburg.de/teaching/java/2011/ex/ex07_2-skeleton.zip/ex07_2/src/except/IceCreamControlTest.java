package except;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * Test for {@link IceCreamControl}
 * 
 */
public class IceCreamControlTest {

	/**
	 * Expect that a kid's cone is correctly produced if
	 * the dispenser does not produce errors.
	 */
	@Test
	public void testGoodKidConeFromInput() {
		DummyIceCreamDispenser dispenser = new DummyIceCreamDispenser();
		IceCreamControl c = new IceCreamControl(dispenser);
		
		c.handleKeypadInput('k');
		
		assertEquals("THANK YOU", c.getMessage());
	}
}
