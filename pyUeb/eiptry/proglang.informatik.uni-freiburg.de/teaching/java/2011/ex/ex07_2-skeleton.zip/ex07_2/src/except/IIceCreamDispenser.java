package except;

/**
 * Frontend for the pump which pumps ice cream and the mill
 * which makes chocolate flakes. 
 * 
 * @author anton
 *
 */
public interface IIceCreamDispenser {

	/**
	 * Drop an ice-cream cone under the nozzle.
	 * TODO We may have run out of cones. Handle that. 
	 */
	void dropCone();

	/**
	 * Pump one load of ice cream through the nozzle.
	 * TODO The pump may jam. Handle that.
	 */
	void pumpIceCream();
	
	/**
	 * Grind and dispense a load of freshly-ground chocolate flakes.
	 * TODO The chocolate mill may block. Handle that.
	 */
	void grindChocolate();
	
}
