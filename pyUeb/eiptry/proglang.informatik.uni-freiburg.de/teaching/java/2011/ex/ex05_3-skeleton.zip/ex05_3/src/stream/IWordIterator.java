package stream;

/**
 * A source of words, to be enumerated one by one. 
 * <p>
 * You can call {@link #hasNext()} anytime to find out if
 * the next call to {@link #next()} will return a word.
 * However, you can only call {@link #next()} once after
 * calling {@link #hasNext()}; otherwise its behaviour is
 * undefined.
 * 
 * @author anton
 *
 */
public interface IWordIterator {

	/**
	 * Enumerate the next word. Call only once after a
	 * call to {@link #hasNext()} has returned true.
	 * If you call this when no word is available, 
	 * undefined behaviour happens.
	 * @return a word, if available.
	 */
	String next();
	
	/**
	 * Is there a next word?
	 * @return true if there is a next word which {@link #next()} can 
	 *              produce.
	 */
	boolean hasNext();
}
