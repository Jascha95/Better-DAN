/**
 * 
 */
package stream;

/**
 * Splits a string into words and iterates over the words. 
 * 
 * @author anton
 *
 */
public class Words implements IWordIterator {

	/**
	 * The input string.
	 */
	private final String source;

	/**
	 * Has {@link #scan()} been called since the last call to {@link #next()}?
	 */
	private boolean scanResultValid = false;

	/**
	 * the next word to be produced.
	 */
	private String nextWord;

	/**
	 * Is {@link #nextWord} valid?
	 */
	private boolean nextWordAvailable;
	
	/**
	 * Index of next unread input char.
	 */
	private int scanPos = 0;
	
	
	/**
	 * Create a word-generator.
	 * @param source a string of words separated by blanks.
	 */
	public Words(String source) {
		this.source = source;
	}

	@Override
	public String next() {
		if(isAtEnd()){
			throw new IllegalStateException("next() on exhausted iterator");
		} 
		else if (!nextWordAvailable) {
			throw new IllegalStateException("hasNext() not called");
		}
		else {
			scanResultValid = false;
			return nextWord;
		}
	}

	/**
	 * Is the iterator in a state when it can certainly not produce
	 * another word?
	 * @return true if certainly no word can be produced.
	 */
	private boolean isAtEnd() {
		return !nextWordAvailable && scanPos >= source.length();
	}

	@Override
	public boolean hasNext() {
		if(!scanResultValid) {
			return scan();
		}
		else {
			return nextWordAvailable;
		}
	}

	/**
	 * Try to refill {@link #nextWord}.
	 * Precondition: !hasScannedSinceNextCall.
	 * @return true iff {@link #nextWord} has been filled, false if that wasn't possible.
	 */
	private boolean scan() {
		nextWordAvailable = false;
		scanResultValid = true;

		while(scanPos < source.length() && source.charAt(scanPos) == ' ') {
			scanPos = scanPos + 1;
		}
		// now scanPos points to the end or the beginning of a word.
		if(scanPos < source.length()) {
			int wordStart = scanPos;
			while(scanPos < source.length() && source.charAt(scanPos) != ' ') {
				scanPos = scanPos + 1;
			}
			nextWord = source.substring(wordStart, scanPos);
			nextWordAvailable = true;
		}
		return nextWordAvailable;
	}

	
}
