/**
 * 
 */
package stream;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * Unit test for class {@link Words}.
 * Many edge cases with trailing blanks etc.
 * 
 * @author anton
 *
 */
public class WordsTest {
	
	/**
	 * Input "" yields 0 words.
	 */
	@Test
	public void testEmptyString() {
		IWordIterator wi = new Words("");
		assertFalse(wi.hasNext());
	}

	/**
	 * Input "bla" yields 1 word "bla".
	 */
	@Test
	public void testSingleWordString() {
		IWordIterator words = new Words("bla");
		assertTrue(words.hasNext());
		String w1 = words.next();
		assertEquals("bla", w1);
		assertFalse(words.hasNext());
	}

	/**
	 * Input " bla" yields 1 word "bla".
	 */
	@Test
	public void testSingleWordStringLeadingBlanks() {
		IWordIterator words = new Words(" bla");
		assertTrue(words.hasNext());
		String w1 = words.next();
		assertEquals("bla", w1);
		assertFalse(words.hasNext());
	}

	/**
	 * Input "bla " yields 1 word "bla".
	 */
	@Test
	public void testSingleWordStringTrailingBlanks() {
		IWordIterator words = new Words("bla ");
		assertTrue(words.hasNext());
		String w1 = words.next();
		assertEquals("bla", w1);
		assertFalse(words.hasNext());
	}

	/**
	 * Input "bla blub" yields 2 words "bla" and "blub".
	 */
	@Test
	public void testTwoWordString() {
		IWordIterator words = new Words("bla blub");
		assertTrue(words.hasNext());
		String w1 = words.next();
		assertEquals("bla", w1);
		assertTrue(words.hasNext());
		String w2 = words.next();
		assertEquals("blub", w2);
		assertFalse(words.hasNext());
	}

	/**
	 * Input "b c" yields 2 words "b" and "c".
	 */
	@Test
	public void testTwoSingleCharWordStrings() {
		IWordIterator words = new Words("b c");
		assertTrue(words.hasNext());
		String w1 = words.next();
		assertEquals("b", w1);
		assertTrue(words.hasNext());
		String w2 = words.next();
		assertEquals("c", w2);
		assertFalse(words.hasNext());
	}

	/**
	 * Input "bla   blub" yields 2 words "bla" and "blub".
	 */
	@Test
	public void testTwoWordStringManyBlanks() {
		IWordIterator words = new Words("bla   blub");
		assertTrue(words.hasNext());
		String w1 = words.next();
		assertEquals("bla", w1);
		assertTrue(words.hasNext());
		String w2 = words.next();
		assertEquals("blub", w2);
		assertFalse(words.hasNext());
	}

	/**
	 * Input "bla" yields 1 word "bla" even if you call hasNext
	 * more than once.
	 */
	@Test
	public void testMultipleHasNextCalls() {
		IWordIterator words = new Words("bla ");
		assertTrue(words.hasNext());
		assertTrue(words.hasNext());
		String w1 = words.next();
		assertEquals("bla", w1);
		assertFalse(words.hasNext());
	}

	/**
	 * Input "bla blub" yields 2 words "bla" "blub" even if you call hasNext
	 * more than once.
	 */
	@Test
	public void testMultipleHasNextCallsBeforeSecondWord() {
		IWordIterator words = new Words("bla blub");
		assertTrue(words.hasNext());
		assertEquals("bla", words.next());
		assertTrue(words.hasNext());
		assertTrue(words.hasNext());
		assertEquals("blub", words.next());
		assertFalse(words.hasNext());
	}
}
