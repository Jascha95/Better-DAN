package equality;

import java.awt.Point;

/**
 * This class represents a racing car.
 */
public class RacingCar extends Car {

	/**
	 * The car's capacity of nitrous oxide.
	 */
	private final double nitrousOxideCapacity;

	/**
	 * Returns the nitrous oxide capacity.
	 * 
	 * @return the nitrousOxideCapacity
	 */
	public double getNitrousOxideCapacity() {
		return nitrousOxideCapacity;
	}

	/**
	 * Constructs a racing car with the given specs.
	 * 
	 * @param model the mode name
	 * @param numDoors the cars number of doors
	 * @param milesPerGallon the MPG
	 * @param engagedGear the currently choosen gear
	 * @param nitrousOxideCapacity this racing car's capacity of nitrous oxide 
	 */
	public RacingCar(String model, int numDoors,
			double milesPerGallon, int engagedGear, double nitrousOxideCapacity) {
		super(model, numDoors, milesPerGallon, engagedGear);
		this.nitrousOxideCapacity = nitrousOxideCapacity;
	}
}
