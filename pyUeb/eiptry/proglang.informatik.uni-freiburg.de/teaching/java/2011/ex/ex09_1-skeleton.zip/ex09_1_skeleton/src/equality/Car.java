package equality;

import java.awt.Point;

/**
 * A class representing cars.
 */
public class Car extends Vehicle {

	/**
	 * Constructs a car with the given specs.
	 * 
	 * @param model the mode name
	 * @param numDoors the cars number of doors
	 * @param milesPerGallon the MPG
	 * @param engagedGear the currently choosen gear
	 */
	public Car(String model, int numDoors,
			double milesPerGallon, int engagedGear) {
		super(model);
		this.numDoors = numDoors;
		this.milesPerGallon = milesPerGallon;
		this.engagedGear = engagedGear;
	}

	/**
	 * The number of doors.
	 */
	private final int numDoors;

	/**
	 * The mileage per galon.
	 */
	private final double milesPerGallon;

	/**
	 * Returns the engaged gear.
	 * 
	 * The currently active gear.
	 */
	private int engagedGear;

	/**
	 * Returns the number of doors.
	 * 
	 * @return the numDoors
	 */
	public int getNumDoors() {
		return numDoors;
	}

	/**
	 * Returns the miles per galon.
	 * 
	 * @return the milesPerGallon
	 */
	public double getMilesPerGallon() {
		return milesPerGallon;
	}

	/**
	 * Returns the currently engaged gear.
	 * 
	 * @return the engagedGear
	 */
	public int getEngagedGear() {
		return engagedGear;
	}

	/**
	 * Set the currently engaged gear.
	 * 
	 * @param engagedGear the engagedGear to set
	 */
	public void setEngagedGear(int engagedGear) {
		this.engagedGear = engagedGear;
	}
}
