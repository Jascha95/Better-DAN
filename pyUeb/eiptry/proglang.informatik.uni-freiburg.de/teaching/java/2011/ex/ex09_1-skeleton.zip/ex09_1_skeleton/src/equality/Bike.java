package equality;

import java.awt.Point;

/**
 * A class representing bikes.
 *
 */
public class Bike extends Vehicle {
	
	/**
	 * Indicated whether this bike has a bicycle stand.
	 */
	private final boolean hasStand;

	/**
	 * Creates a bike with the specified mode name, initial location,
	 * and a flag indicating whether the bike has a stand.
	 * 
	 * @param model the mode name
	 * @param hasStand true if the bike has a stand, false otherwise
	 */
	public Bike(String model, boolean hasStand) {
		super(model);
		this.hasStand = hasStand;
	}

}
