package equality;

import java.awt.Point;

/**
 * An abstract vehicle class.
 *
 */
public abstract class Vehicle {
	
	/**
	 * Constructs a vehicle with a default location of (0, 0).
	 * 
	 * @param model the model name
	 */
	public Vehicle(String model) {
		super();
		this.model = model;
	}

	/**
	 * The verhicle's model name. 
	 */
	private final String model;
	
	
	/**
	 * Returns the model of this vehicle.
	 * 
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * The vehicle's location. 
	 */
	private Point location = new Point();


	/**
	 * Returns the location of this vehicle.
	 * 
	 * @return the location
	 */
	public Point getLocation() {
		return location;
	}


	/**
	 * Sets the vehicle's location.
	 * 
	 * @param location the location to set
	 */
	public void setLocation(Point location) {
		this.location = location;
	}
}
