package bench;

import java.util.List;

/**
 * A scenario on {@link java.util.List} 
 * consisting of appending thousands of elements to the list.
 * 
 * @author anton
 *
 */
public class AppendScenario implements IScenario<List<Integer>> {

	/**
	 * Number of elements to add
	 */
	public static final int NUM_ELEMS = 100000;

	@Override
	public void run(List<Integer> target) {
		for(int i = 0; i < NUM_ELEMS; ++i) {
			target.add(NUM_ELEMS - i);
		}
	}

	@Override
	public String name() {
		return "Append";
	}

}
