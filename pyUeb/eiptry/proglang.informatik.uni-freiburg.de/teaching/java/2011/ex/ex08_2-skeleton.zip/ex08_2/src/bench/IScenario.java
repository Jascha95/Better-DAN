package bench;

/**
 * A sequence of operations on objects of type T
 * @author anton
 *
 * @param <T> objects I work on
 */
public interface IScenario<T> {

	
	/**
	 * Run on the target
	 * @param target will be changed
	 */
	void run(T target);
	
	/**
	 * @return Scenario name
	 */
	String name();
}
