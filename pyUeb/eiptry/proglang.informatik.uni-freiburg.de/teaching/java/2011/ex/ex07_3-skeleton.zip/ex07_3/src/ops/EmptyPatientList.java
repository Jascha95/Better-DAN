/**
 * 
 */
package ops;

/**
 * Empty patient list.
 */
public class EmptyPatientList implements IPatientList {

	@Override
	public boolean isEmpty() {
		return true;
	}

	@Override
	public Patient getEntry() {
		throw new UnsupportedOperationException();
	}

	@Override
	public IPatientList getRest() {
		throw new UnsupportedOperationException();
	}

}
