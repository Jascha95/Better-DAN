package ops;

/**
 *
 * A list of patients.
 *
 */
public interface IPatientList {

	/**
	 * @return is this list empty?
	 */
	boolean isEmpty();
	/**
	 * @return first patient
	 */
	Patient getEntry();
	/**
	 * @return remaining list
	 */
	IPatientList getRest();
	
}
