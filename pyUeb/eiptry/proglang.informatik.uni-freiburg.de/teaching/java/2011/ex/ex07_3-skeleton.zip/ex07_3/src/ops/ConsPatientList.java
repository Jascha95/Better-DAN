package ops;

/**
 * Nonempty patient list.
 * 
 * @author anton
 *
 */
public class ConsPatientList implements IPatientList {

	/**
	 * The first patient
	 */
	private Patient patient;
	/**
	 * The remaining patients.
	 */
	private IPatientList rest;

	/**
	 * Constructor.
	 * 
	 * @param patient a patient
	 * @param rest remaining list
	 */
	public ConsPatientList(Patient patient, IPatientList rest) {
		this.patient = patient;
		this.rest = rest;
	}

	@Override
	public boolean isEmpty() {
		return false;
	}

	@Override
	public Patient getEntry() {
		return this.patient;
	}

	@Override
	public IPatientList getRest() {
		return this.rest;
	}
	
}
