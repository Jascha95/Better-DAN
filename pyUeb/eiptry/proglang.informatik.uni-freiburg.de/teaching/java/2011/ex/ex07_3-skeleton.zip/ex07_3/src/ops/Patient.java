package ops;

/**
 * A patient has a name and a treatment duration. 
 * 
 */
public class Patient {

	/**
	 * Name.
	 */
	private String name;
	/**
	 * Duration of the treatment in minutes.
	 */
	private int duration;
	/**
	 * Ctor.
	 * @param name patient name
	 * @param duration duration in minutes of treatment.
	 */
	public Patient(String name, int duration) {		
		this.name = name;
		this.duration = duration;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @return the duration
	 */
	public int getDuration() {
		return duration;
	}
	
}
