package inventory;

/**
 * A vegetable (e.g. a head of cabbage) posing a current asset.
 */
public class Vegetable implements CurrentAsset {
	/**
	 * The ID of this antique product. 
	 */
	private String id;
	
	/**
	 * The gross price of this vegetable product in cents. 
	 */
	private int grossPrice;
	
	/**
	 * The value to divide the grossCashEquivalents
	 */
	private static final double TAX_DIVISOR = 1.19;
	
	/**
	 * The number of days this vegetable is old. 
	 */
	private int daysOld;

	
	/**
	 * Constructs a new vegetable product.
	 * @param id the product's ID
	 * @param grossPrice the gross consumer price of the product in cents
	 * @param daysOld the number of days this vegetable is old
	 */
	public Vegetable(String id, int grossPrice, int daysOld) {
		this.id = id;
		this.grossPrice = grossPrice;
		this.daysOld = daysOld;
	}

	@Override
	public int netCashEquivalents() {
		// calculate gross value, then divide by tax divisor
		double grossCashEquivalents;
		
		if (daysOld >= 7)
			grossCashEquivalents = 0;
		else
			grossCashEquivalents = (grossPrice - (daysOld / 7.0) * grossPrice);
		
		return (int)(grossCashEquivalents / TAX_DIVISOR);
	}
	
	/**
	 * Sets the price of this vegetable.
	 * 
	 * @param grossPrice the gross price to set
	 */
	public void setGrossPrice(int grossPrice) {
		this.grossPrice = grossPrice;
	}

	@Override
	public String toString() {
		return id;
	}
}
