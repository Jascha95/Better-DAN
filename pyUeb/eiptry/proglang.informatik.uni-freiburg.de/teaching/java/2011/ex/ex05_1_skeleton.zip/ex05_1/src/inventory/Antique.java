package inventory;

import java.util.Calendar;
import java.util.Random;

/**
 * An antique product (e.g. an old chair) posing a current asset.
 */
public class Antique implements CurrentAsset {

	/**
	 * The ID of this antique product. 
	 */
	private String id;
	
	/**
	 * The gross price of this antique product in cents. 
	 */
	private int grossPrice;
	
	/**
	 * The value to divide the grossCashEquivalents
	 */
	private static final double TAX_DIVISOR = 1.19;
	
	/**
	 * Constructs a new antique product.
	 * @param id the product's ID
	 * @param grossPrice the gross consumer price of the product in cents
	 */
	public Antique(String id, int grossPrice) {
		this.id = id;
		this.grossPrice = grossPrice;
	}

	/**
	 * This method represents the very special market for antiques.
	 * Speaking antiques the consumer price of the product hardly ever changes (though it can).
	 * Basically we usually just wait for the customer to buy.
	 * However, the demand for antiques is not constant and so isn't this product's actual value
	 * (e.g. due to the risk of not selling the antique product at all).
	 * This is reflected by this method.
	 * 
	 * It returns a factor reflecting the current price to value ratio.
	 * 
	 * @return the gross value of the good divided by the gross price of the product 
	 */
	private static double marketFactor() {
		return 1.0 - new Random(Calendar.getInstance().get(Calendar.YEAR)).nextDouble();
	}
	
	/**
	 * Sets the price of this antique product.
	 * 
	 * @param grossPrice the gross price to set
	 */
	public void setGrossPrice(int grossPrice) {
		this.grossPrice = grossPrice;
	}

	@Override
	public int netCashEquivalents() {
		// calculate gross value, then divide by tax divisor
		return (int)((grossPrice * Antique.marketFactor()) / TAX_DIVISOR);
	}
	
	@Override
	public String toString() {
		return id;
	}
}
