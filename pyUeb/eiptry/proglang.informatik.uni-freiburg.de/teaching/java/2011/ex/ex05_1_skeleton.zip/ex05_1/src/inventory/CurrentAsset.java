package inventory;

/**
 * Interface for items that have a current asset regarding the yearly balance sheet.
 */
public interface CurrentAsset {
	
	/**
	 * Returns the current net value of this item in cents. This takes into account
	 * all factors influencing the value of the product in terms of the
	 * yearly balance sheet.
	 * 
	 * The value excludes the tax (VAT) for this item. The net value can
	 * be calculated from the gross value by excluding the VAT.
	 * 
	 * @return the current net value (this is not the price) of this item.
	 */
	public int netCashEquivalents();
	
}