/**
 * 
 */
package deleteme;

/**
 * Delete this class; it is only a placeholder so that the
 * source folder is not optimized away just because it is empty.
 * 
 * @author anton
 *
 */
public class DeleteThisClass {

}
