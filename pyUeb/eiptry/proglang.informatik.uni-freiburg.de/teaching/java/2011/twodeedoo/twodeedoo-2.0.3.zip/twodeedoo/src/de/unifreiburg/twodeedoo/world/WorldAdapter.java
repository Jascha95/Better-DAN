package de.unifreiburg.twodeedoo.world;

import java.awt.Graphics;

import de.unifreiburg.twodeedoo.view.IActivity;
import de.unifreiburg.twodeedoo.view.IGameController;
import de.unifreiburg.twodeedoo.view.IPainter;

/**
 * Adapter from the world package's {@link IWorld} to twodeedoo's 
 * Activity+Painter.
 * <p>
 * This wraps a {@link IWorld} and translates twodeedoo method calls to
 * twodeedoo-world method calls. 
 * </p>
 * 
 * @author anton
 *
 */
public class WorldAdapter implements IActivity, IPainter {

	/**
	 * The wrapped world.
	 */
	private final IWorld world;
	

	/**
	 * Create an adapter
	 * @param world wrappee
	 */
	public WorldAdapter(IWorld world) {
		this.world = world;
	}

	@Override
	public boolean run(int elapsedTimeMillis, IGameController gameController) {
		world.onTick(new SimulationControllerAdapter(gameController));
		// we don't stop by returning false, ever.
		return true;
	}

	@Override
	public void keyPressed(int keyCode, IGameController controller) {
		world.onKeyPressed(keyCode, new SimulationControllerAdapter(controller));
	}

	@Override
	public void keyReleased(int keyCode, IGameController controller) {
		world.onKeyReleased(keyCode, new SimulationControllerAdapter(controller));
	}

	@Override
	public void paint(Graphics g) {
		AwtCanvas canvas = new AwtCanvas(g);
		world.paint(canvas);
	}

	@Override
	public int minimalTimeSlice() {
		return world.getCycleTimeMs();
	}

}
