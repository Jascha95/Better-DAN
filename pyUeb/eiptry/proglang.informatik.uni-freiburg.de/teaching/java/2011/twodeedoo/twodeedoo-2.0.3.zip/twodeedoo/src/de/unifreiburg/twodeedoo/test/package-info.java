/**
 * General test helpers.
 */
package de.unifreiburg.twodeedoo.test;

