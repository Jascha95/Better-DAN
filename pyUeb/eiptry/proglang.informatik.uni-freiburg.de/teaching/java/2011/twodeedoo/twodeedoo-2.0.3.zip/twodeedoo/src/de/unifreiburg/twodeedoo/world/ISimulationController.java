package de.unifreiburg.twodeedoo.world;

/**
 * A {@link IWorld}'s way of interacting with the simulator.
 *  
 * @author anton
 *
 */
public interface ISimulationController {

	/**
	 * Stop the world and quit intentionally.
	 */
	void quit();
}
