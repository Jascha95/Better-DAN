package de.unifreiburg.twodeedoo.model.test;

import de.unifreiburg.twodeedoo.model.ICompositeActor;
import de.unifreiburg.twodeedoo.test.UnimplementedStubCalledException;
import de.unifreiburg.twodeedoo.view.IActivity;
import de.unifreiburg.twodeedoo.view.IGameController;

/**
 * Implementation of {@link ICompositeActor} which raises {@link UnimplementedStubCalledException} 
 * for each method call.
 * 
 * @author anton
 *
 */
public class ErrorActivity implements IActivity {

	@Override
	public boolean run(int elapsedTimeMillis, IGameController controller) {
		throw new UnimplementedStubCalledException();
	}

	@Override
	public void keyPressed(int keyCode, IGameController controller) {
		throw new UnimplementedStubCalledException();
	}

	@Override
	public void keyReleased(int keyCode, IGameController controller) {
		throw new UnimplementedStubCalledException();
	}

	@Override
	public int minimalTimeSlice() {
		return 0;
	}

}
