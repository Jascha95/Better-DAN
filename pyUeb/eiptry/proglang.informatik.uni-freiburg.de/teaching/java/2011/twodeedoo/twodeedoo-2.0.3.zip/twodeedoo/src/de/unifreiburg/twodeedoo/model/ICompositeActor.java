package de.unifreiburg.twodeedoo.model;

import de.unifreiburg.twodeedoo.view.IKeyHandler;
import de.unifreiburg.twodeedoo.view.ISchedulable;

/**
 * A composite actor contains actors and runs them.
 * @author konrad
 *
 */
public interface ICompositeActor extends ISchedulable, IKeyHandler {
	/**
	 * Add an actor
	 * @param a an actor that isn't yet in this {@link ICompositeActor}.
	 */
	void addActor(IActor a);

	/**
	 * Remove that actor from the actors of this activity.
	 * <p>
	 * (But note that excessive use of this method is a design smell)
	 * This will also reset the container of the actor.
	 * 
	 * @param a an actor to remove. If not among my actors, I will do nothing.
	 */
	void removeActor(IActor a);
	
}
