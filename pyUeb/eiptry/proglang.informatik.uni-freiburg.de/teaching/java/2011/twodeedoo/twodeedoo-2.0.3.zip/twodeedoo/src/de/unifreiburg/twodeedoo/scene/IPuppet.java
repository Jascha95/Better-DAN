package de.unifreiburg.twodeedoo.scene;

import java.awt.Graphics;

import de.unifreiburg.twodeedoo.view.IPainter;

/**
 * I'm an {@link IPainter} which can be moved around.
 * 
 * 
 * @author anton
 *
 */
public interface IPuppet extends IPainter {
	/**
	 * Move the reference point to new coordinates.
	 * @param x x coordinate in the scene of my reference point
	 * @param y y coordinate in the scene of my reference point.
	 */
	void moveAbs(int x, int y);
	
	/**
	 * X coordinate
	 * @return x coordinate in scene units
	 */
	int getX();
	
	/**
	 * Y coordinate 
	 * @return y coordinate in scene units
	 */
	int getY();
	
	/**
	 * notify this puppet that it is now contained in a different scene.
	 * @param scene the new scene. Could be a non-displaying scene.
	 */
	void setContainingScene(IScene scene);
	
	/**
	 * Remove this puppet from its scene.
	 */
	void removeFromScene();
	
	/**
	 * A puppet which is always at 0,0 and never paints itself
	 */
	IPuppet NULL_OBJECT = new IPuppet() {
		@Override
		public void paint(Graphics g) {
		}
		@Override
		public void moveAbs(int x, int y) {
		}
		
		@Override
		public int getY() {
			return 0;
		}
		
		@Override
		public int getX() {
			return 0;
		}
		@Override
		public void removeFromScene() {}

		@Override
		public void setContainingScene(IScene scene) { }
		
	};
}
