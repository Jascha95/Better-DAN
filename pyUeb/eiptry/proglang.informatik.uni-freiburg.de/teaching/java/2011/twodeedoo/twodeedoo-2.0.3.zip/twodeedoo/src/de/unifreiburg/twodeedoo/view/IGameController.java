package de.unifreiburg.twodeedoo.view;


/**
 * Control the execution of the game from within an Activity:
 * switch to other activity, quit, restart.
 * 
 * @author anton
 *
 */
public interface IGameController {
	
	/**
	 * Tell the simulator to run a new activity instead of the current activity. 
	 * @param newActivity another activity.
	 */
	void switchToActivity(IActivity newActivity);
	
	/**
	 * Has {@link #switchToActivity(IActivity)} been called since the start
	 * of this event distribution cycle? 
	 * @return true if it has.
	 */
	boolean isActivitySwitched();
	
	/**
	 * Quit the game intentionally. This usually even exits the program.
	 */
	void quitGame();

	/**
	 * Restart the game from the beginning.
	 * If that isn't possible, quit.
	 */
	void restartGame();
}
