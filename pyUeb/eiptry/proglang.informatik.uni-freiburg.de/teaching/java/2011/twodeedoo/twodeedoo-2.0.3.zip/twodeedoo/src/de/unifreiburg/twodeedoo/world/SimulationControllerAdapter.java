package de.unifreiburg.twodeedoo.world;

import de.unifreiburg.twodeedoo.view.IGameController;

/**
 * Adapt {@link IGameController} (from complicated twodeedoo) to {@link ISimulationController}
 * from twodeedoo-world. 
 * 
 * @author anton
 *
 */
public class SimulationControllerAdapter implements ISimulationController {

	/**
	 * The wrapped game controller.
	 */
	private final IGameController gameController;

	/**
	 * Create adapter from {@link IGameController} to {@link ISimulationController}
	 * @param gameController Wrap this.
	 */
	public SimulationControllerAdapter(IGameController gameController) {
		this.gameController = gameController;
	}

	@Override
	public void quit() {
		gameController.quitGame();
	}

}
