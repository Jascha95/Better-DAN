package de.unifreiburg.twodeedoo.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import de.unifreiburg.twodeedoo.scene.IScene;
import de.unifreiburg.twodeedoo.view.IActivity;
import de.unifreiburg.twodeedoo.view.IGameController;

/**
 * Simple Composite of {@link IActor}s.
 * @author konrad
 *
 */
public class CompositeActor implements IActivity, ICompositeActor{
	/**
	 * The contained {@link IActor}s.
	 */
	private List<IActor> actors = new LinkedList<IActor>();
	/**
	 * Our scene
	 */
	private IScene scene;
	
	/**
	 * Create instance
	 * @param scene the scene for new puppets
	 */
	public CompositeActor(IScene scene){
		this.setScene(scene);
	}
	
	/**
	 * Let all the contained actors run. Follow their wishes for removal. 
	 * @param elapsedTimeMillis elapsed time since last run in ms
	 */
	@Override
	public boolean run(int elapsedTimeMillis, IGameController controller) {
		List<IActor> actorsCopy = copyActorsList();
		Iterator<IActor> iactors = actorsCopy.iterator();
		while(iactors.hasNext()){
			IActor a = iactors.next();
			boolean stillAlive = a.run(elapsedTimeMillis, controller);
			if(!stillAlive){
				removeActor(a);
			}
			if(controller.isActivitySwitched()){
				// stop processing events.
				break;
			}
		}
		return !actors.isEmpty();
	}

	/**
	 * Add an actor, becoming its container.
	 * <p>
	 * Actors which are already in this activity are not added again;
	 * this call becomes a noop then.
	 * 
	 * @param actor an actor 
	 */
	public void addActor(IActor actor){
		if(! this.actors.contains(actor)) {
			this.actors.add(actor);
			actor.setContainer(this);
		}
	}

	/**
	 * Remove this actor from the actor set. 
	 * 
	 * After that, I will no longer be its container.
	 * <p>
	 * (Think twice before using this method from the outside; 
	 * usually, an actor should decide itself when he stops acting.)
	 * 
	 * @param actor The actor to remove. Its container will be reset iff the actor was in this activity.
	 */
	public void removeActor(IActor actor){
		boolean couldRemove = this.actors.remove(actor);
		if(couldRemove) {
			actor.setContainer(null);
		}
	}
	
	/**
	 * Setter for scene.
	 * @param scene a scene, non-null.
	 */
	public void setScene(IScene scene) {
		this.scene = scene;
	}

	/**
	 * Getter for scene.
	 * @return the scene.
	 */
	public IScene getScene() {
		return scene;
	}

	/**
	 * Dispatch to the actor which likes that key
	 */
	@Override
	public void keyPressed(int keyCode, IGameController controller) {
		// copy the list so that key handlers can remove actors.
		ArrayList<IActor> actorsCopy = copyActorsList();
		for(IActor actor: actorsCopy){
			actor.keyPressed(keyCode, controller); 
			if(controller.isActivitySwitched()){
				// stop processing events.
				break;
			}
		}
	}

	/**
	 * @return
	 */
	private ArrayList<IActor> copyActorsList() {
		ArrayList<IActor> actorsCopy = new ArrayList<IActor>(actors.size());
		actorsCopy.addAll(actors);
		return actorsCopy;
	}

	/**
	 * Dispatch to the actor which likes that key
	 */
	@Override
	public void keyReleased(int keyCode, IGameController controller) {
		// copy the list so that key handlers can remove actors.
		ArrayList<IActor> actorsCopy = copyActorsList();
		for(IActor actor: actorsCopy){
			actor.keyReleased(keyCode, controller);
			if(controller.isActivitySwitched()){
				// stop processing events.
				break;
			}
		}
	}

	@Override
	public int minimalTimeSlice() {
		// more than 60fps, but not much more.
		return 15; // TODO make configurable
	}
	
	
}
