package de.unifreiburg.twodeedoo.model.test;

import de.unifreiburg.twodeedoo.view.IActivity;
import de.unifreiburg.twodeedoo.view.IGameController;
import de.unifreiburg.twodeedoo.view.IKeyHandler;
import de.unifreiburg.twodeedoo.view.ISchedulable;

/**
 * {@link IGameController} fake for testing.
 * 
 * @author anton
 *
 */
public class FakeGameController implements IGameController {

	private IKeyHandler keyHandler = null;
	private ISchedulable mainSchedulable = null;
	private boolean activitySwitched;
	/**
	 * @return the keyHandler
	 */
	public IKeyHandler getKeyHandler() {
		return keyHandler;
	}
	/**
	 * @return the mainSchedulable
	 */
	public ISchedulable getMainSchedulable() {
		return mainSchedulable;
	}
	
	@Override
	public void switchToActivity(IActivity newActivity) {
		this.keyHandler = newActivity;
		this.mainSchedulable = newActivity;
	}

	@Override
	public boolean isActivitySwitched() {
		return this.activitySwitched;
	}

	@Override
	public void quitGame() {
	}
	@Override
	public void restartGame() {
	}
	

}
