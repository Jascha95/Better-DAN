/**
 * Test helpers for the scene layer.
 */
package de.unifreiburg.twodeedoo.scene.test;

