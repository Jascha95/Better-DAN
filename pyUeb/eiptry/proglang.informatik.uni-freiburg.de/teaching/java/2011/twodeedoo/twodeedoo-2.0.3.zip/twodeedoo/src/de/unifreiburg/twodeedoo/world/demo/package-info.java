/**
 * Demo world for the twodeedoo world package.
 * <p>
 * The world is in {@link de.unifreiburg.twodeedoo.world.demo.DemoWorld},
 * and {@link de.unifreiburg.twodeedoo.world.demo.Main} is a runnable main class.
 * </p>
 */
package de.unifreiburg.twodeedoo.world.demo;