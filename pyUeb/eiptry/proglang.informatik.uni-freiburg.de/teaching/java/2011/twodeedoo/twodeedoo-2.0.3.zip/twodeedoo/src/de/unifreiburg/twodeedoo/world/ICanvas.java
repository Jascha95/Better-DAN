package de.unifreiburg.twodeedoo.world;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

/**
 * Simple drawing surface, wraps an AWT {@link Graphics}.
 * 
 * @author anton
 * 
 */
public interface ICanvas {

	/**
	 * Draw a filled circle.
	 * 
	 * @param centerX
	 *            X of center (in pixels)
	 * @param centerY
	 *            Y of center (in pixels)
	 * @param radius
	 *            radius in pixels
	 * @param color
	 *            color for the circle.
	 */
	void drawFilledCircle(int centerX, int centerY, int radius, Color color);

	/**
	 * Draw text in the standard font. The (x,y) point specifies where the
	 * baseline of the first character is drawn.
	 * 
	 * @param x
	 *            x coordinate of baseline of first character
	 * @param y
	 *            y coordinate of baseline of first character
	 * @param msg
	 *            a text
	 * @param color
	 *            text color
	 */
	void drawText(int x, int y, String msg, Color color);

	/**
	 * Draw a filled rectangle.
	 * 
	 * @param upperLeftX
	 *            X of upper left corner
	 * @param upperLeftY
	 *            Y of upper left corner
	 * @param width
	 *            width of rectangle
	 * @param height
	 *            height of rectangle
	 * @param color
	 *            fill color
	 */
	void drawFilledRect(int upperLeftX, int upperLeftY, int width, int height,
			Color color);

	/**
	 * Draw a line.
	 * 
	 * @param x0
	 *            first point
	 * @param y0
	 *            first point
	 * @param x1
	 *            second point
	 * @param y1
	 *            second point
	 * @param color
	 *            color
	 */
	void drawLine(int x0, int y0, int x1, int y1, Color color);

	/**
	 * Draws as much of the specified area of the specified image as is
	 * currently available. Transparent pixels do not affect whatever pixels are
	 * already there.
	 * 
	 * @param img
	 *            the specified image to be drawn. This method does nothing if
	 *            <code>img</code> is null.
	 * @param x
	 *            the <i>x</i> coordinate.
	 * @param y
	 *            the <i>y</i> coordinate.
	 * @see java.awt.Image
	 */
	public void drawImage(Image img, int x, int y);

	/**
	 * Draws as much of the specified area of the specified image as is
	 * currently available. Transparent pixels do not affect whatever pixels are
	 * already there.
	 * 
	 * @param x
	 *            the <i>x</i> coordinate.
	 * @param y
	 *            the <i>y</i> coordinate.
	 * @param sx1
	 *            the <i>x</i> coordinate of the first corner of the source
	 *            rectangle.
	 * @param sy1
	 *            the <i>y</i> coordinate of the first corner of the source
	 *            rectangle.
	 * @param sx2
	 *            the <i>x</i> coordinate of the second corner of the source
	 *            rectangle.
	 * @param sy2
	 *            the <i>y</i> coordinate of the second corner of the source
	 *            rectangle.
	 * @see java.awt.Image
	 */
	public void drawImage(Image img, int x, int y, int sx1, int sy1, int sx2,
			int sy2);

	/**
	 * Return the inner {@link Graphics}; you can use it to draw complicated
	 * shapes beyond what this interface offers.
	 * 
	 * @return the inner {@link Graphics}
	 */
	Graphics getAwtGraphics();
}
