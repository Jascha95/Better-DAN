package de.unifreiburg.twodeedoo.world.demo;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import de.unifreiburg.twodeedoo.world.ICanvas;
import de.unifreiburg.twodeedoo.world.ISimulationController;
import de.unifreiburg.twodeedoo.world.IWorld;

/**
 * Demonstration world for the world package. 
 * <p>
 * The user controls a red ball in a blue sky above a green ground.
 * Gravity pulls the ball downward. As long as the user presses UP,
 * An upward wind blows the ball upward. Pressing ESC quits the game.
 * </p>
 * <p>
 * The world demands a 640x480 simulation window and a simulation with
 * a timeslice of 20ms.
 * </p>
 * 
 * @author anton
 *
 */
public class DemoWorld implements IWorld {

	public DemoWorld() {
		try {
			background = ImageIO.read(new File("img/back.jpg"));
		} catch (IOException e) {
			e.printStackTrace();  // being lazy!
		}
	}

	/**
	 * Gravity acceleration, in pixels per timeslice squared
	 */
	private static final double GRAVITY_ACCEL = -0.5;
	/**
	 * Upwind acceleration, in pixels per timeslice squared
	 */
	private static final double WIND_ACCEL = 0.1;
	/**
	 * How much of the velocity will be left after a bounce?
	 */
	private static final double ELASTICITY = 0.5;
	/**
	 * Current altitude in pixels
	 */
	private double altitude = 400;
	/**
	 * Whether the wind is blowing (from keypress(UP) to keyrelease(UP) 
	 */
	private boolean blowing;
	/**
	 * Current velocity in pixels per timeslice
	 */
	private double velocity;
	
	/**
	 * Background image.
	 */
	private BufferedImage background;
	
	@Override
	public int getWidth() {
		return 640;
	}

	@Override
	public int getHeight() {
		return 480;
	}

	@Override
	public int getCycleTimeMs() {
		return 20;
	}
	
	@Override
	public String getTitle() {
		return "Wind blows. Gravity sucks.";
	}

	@Override
	public void onTick(ISimulationController controller) {
		// Very simple physics: altitude is the integral of velocity,
		// velocity is the integral of acceleration. We approximate that
		// naively.
		if(blowing) {
			velocity += WIND_ACCEL;
		} else {
			velocity += GRAVITY_ACCEL;
		}
		altitude += velocity;
		if(altitude < 0) {
			altitude = 0;
			// bounce!
			velocity = - ELASTICITY * velocity;
		}
	}

	@Override
	public void onKeyPressed(int keyCode, ISimulationController controller) {
		// If the up key is pressed, start upwards wind.
		if(keyCode == KeyEvent.VK_UP) {
			blowing = true;
		}
	}

	@Override
	public void onKeyReleased(int keyCode, ISimulationController controller) {
		if(keyCode == KeyEvent.VK_UP) {
			// If the up key is released, stop upwards wind.
			blowing = false;
		} 
		else if( keyCode == KeyEvent.VK_ESCAPE) {
			// If the Esc key is typed, quit. (We use the Release event
			// instead of the Press event so that it feels more
			// like typing).
			controller.quit();
		}
	}

	@Override
	public void paint(ICanvas canvas) {
		int y = 400 - (int)altitude;
		canvas.drawFilledRect(0, 0, 640, 410, Color.BLUE);
		canvas.drawImage(background, 0, 0, 0, 0, 640, 410);
		canvas.drawFilledRect(0, 410, 640, 70, Color.GREEN);
		canvas.drawFilledCircle(320, y, 10, Color.RED);
		canvas.drawText(0, 20, String.format(
				"Velocity: %+5.3f Press UP to blow upwards, or ESC to quit", 
				velocity),
				Color.WHITE);
		
		canvas.drawLine(320, y, 320, (int) (y + 5 * velocity), Color.DARK_GRAY);
	}

}
