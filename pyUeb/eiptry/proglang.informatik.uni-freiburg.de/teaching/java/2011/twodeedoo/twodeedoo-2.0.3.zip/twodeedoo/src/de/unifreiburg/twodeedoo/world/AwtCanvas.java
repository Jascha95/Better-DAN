package de.unifreiburg.twodeedoo.world;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

/**
 * Implementation of ICanvas using AWT Graphics.
 * 
 * @author anton
 * 
 */
public class AwtCanvas implements ICanvas {

	private Graphics g;

	public AwtCanvas(Graphics g) {
		this.g = g;
	}

	@Override
	public void drawFilledCircle(int x, int y, int radius, Color color) {
		g.setColor(color);
		g.fillOval(x - radius, y - radius, 2 * radius, 2 * radius);
	}

	@Override
	public void drawText(int x, int y, String msg, Color color) {
		g.setColor(color);
		g.drawString(msg, x, y);
	}

	@Override
	public void drawFilledRect(int upperLeftX, int upperLeftY, int width,
			int height, Color color) {
		g.setColor(color);
		g.fillRect(upperLeftX, upperLeftY, width, height);
	}

	@Override
	public void drawLine(int x0, int y0, int x1, int y1, Color color) {
		g.setColor(color);
		g.drawLine(x0, y0, x1, y1);
	}

	@Override
	public Graphics getAwtGraphics() {
		return g;
	}
	
	@Override
	public void drawImage(Image img, int x, int y) {
		g.drawImage(img, x, y, null);
	}

	@Override
	public void drawImage(Image img, int x, int y, int sx1, int sy1,
			int sx2, int sy2) {
		g.drawImage(img, x, y, x + Math.abs(sx2 - sx1),
				y + Math.abs(sy2 - sy1), sx1, sy1, sx2, sy2, null);

	}
}
