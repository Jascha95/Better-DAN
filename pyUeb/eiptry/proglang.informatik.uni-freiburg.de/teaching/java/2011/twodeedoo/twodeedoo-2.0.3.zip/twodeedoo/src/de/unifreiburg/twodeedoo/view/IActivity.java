package de.unifreiburg.twodeedoo.view;


/**
 * I'm a toplevel schedulable.
 * 
 * @author anton
 *
 */
public interface IActivity extends ISchedulable, IKeyHandler {

	
	/**
	 * Do not call me more often than with this many ms between two runs.
	 * @return millisecond delay
	 */
	int minimalTimeSlice();

}
