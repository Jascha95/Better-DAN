package de.unifreiburg.twodeedoo.world;

import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import de.unifreiburg.twodeedoo.view.GameControlAdapter;
import de.unifreiburg.twodeedoo.view.SceneView;

/**
 * Application which runs one {@link IWorld}. 
 * <p>
 * Simplest way of using this class: call static method {@link #runWorld(IWorld)}
 * with an instance of your world. That will open a window of the right size
 * and run the simulation until your world calls quit.
 * </p>
 * 
 * @author anton
 *
 */
public class WorldApplication implements Runnable {

	/**
	 * The world being simulated.
	 */
	private final IWorld world;

	/**
	 * Adapter from {@link #world} to the twodeedoo activity+painter concept.
	 */
	private final WorldAdapter worldAdapter;

	/**
	 * The main window. 
	 */
	private JFrame mainWindow;
	/**
	 * the UI component which displays the scene.
	 */
	private SceneView sceneView;



	/**
	 * Create an application to run one world.
	 * 
	 * @param world the world to be run.
	 */
	public WorldApplication(IWorld world) {
		this.world = world;
		this.worldAdapter = new WorldAdapter(world);
	}
	
	/**
	 * Init the user interface (do that once) 
	 */
	private void initUI() {
		int width = world.getWidth();
		int height = world.getHeight();
		sceneView = new SceneView(width,height);
		sceneView.addGameControlListener(new GameControlAdapter() {
			@Override
			public void quitRequested() {
				WorldApplication.this.quit();
			}			
		});
		
		mainWindow = new JFrame(world.getTitle());
		mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainWindow.add(sceneView);
		mainWindow.pack();
	}


	/**
	 * Init scene and activity from world adapter.
	 */
	private void restart() {
		sceneView.setScene(worldAdapter);
		sceneView.switchToActivity(worldAdapter);
	}



	/**
	 * Quit the execution.
	 */
	private void quit() {
		sceneView.stop();
		mainWindow.dispose();
	}

	/**
	 * Start interacting with the game. Requires full initialization.
	 */
	public void startPlaying() {
		mainWindow.setVisible(true);
		sceneView.initTimer();
		sceneView.initKey();
	}
	
	/**
	 * All one-time initializations, all begin-of-game initializations
	 * @throws IOException picture loading failure.
	 */
	public void init() throws IOException{
		initUI();
		restart();
	}

	/**
	 * This will be the first method to be run. Call this on the GUI thread, not 
	 * on the main thread!
	 */
	@Override
	public void run() {
		try {
			init();
			startPlaying();
		} catch (IOException e) {
			e.printStackTrace(); // being lazy!
		}
	}

	/**
	 * Friendly all-in-one service to run a world: create a window,
	 * simulate the world etc.
	 * 
	 * @param world some world.
	 */
	public static void runWorld(IWorld world) {
		SwingUtilities.invokeLater(new WorldApplication(world));
	}
	
}
