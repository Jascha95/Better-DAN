/**
 * Game model (actors)
 * <p>
 * This package deals with the world simulation model of the game.
 * {@link IActor}s simulate one part of the world, e.g. the position and speed
 * of the player. They are also notified of keyboard events.
 * </p>
 * <p>
 * {@link ICompositeActor}s group multiple related {@link IActor}s so that they can
 * be used as an {@link de.unifreiburg.twodeedoo.view.IActivity}.
 * </p>
 * 
 */
package de.unifreiburg.twodeedoo.model;


