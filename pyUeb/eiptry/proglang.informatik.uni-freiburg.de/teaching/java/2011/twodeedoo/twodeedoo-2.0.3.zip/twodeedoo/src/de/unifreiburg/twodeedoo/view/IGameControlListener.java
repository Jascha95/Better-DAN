package de.unifreiburg.twodeedoo.view;

/**
 * Someone who wants to know that a game in a {@link SceneView}
 * has requested the game to quit or to restart.
 * <p>
 * You may want to subclass {@link GameControlAdapter} if 
 * you don't intend to implement all methods.
 * </p>
 * @author anton
 *
 */
public interface IGameControlListener {

	/**
	 * The game wants the application to quit. 
	 */
	void quitRequested();

	/**
	 * The game wants the application to restart. 
	 */
	void restartRequested();
	
}
