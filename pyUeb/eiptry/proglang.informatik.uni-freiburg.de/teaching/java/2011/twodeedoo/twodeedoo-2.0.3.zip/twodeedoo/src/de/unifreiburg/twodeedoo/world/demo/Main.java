package de.unifreiburg.twodeedoo.world.demo;

import de.unifreiburg.twodeedoo.world.WorldApplication;

/**
 * Main class for the demo world.
 * @author anton
 *
 */
public class Main {

	/**
	 * Run the demo world.
	 * @param args ignored command line args.
	 */
	public static void main(String[] args) {
		WorldApplication.runWorld(new DemoWorld());
	}

}
