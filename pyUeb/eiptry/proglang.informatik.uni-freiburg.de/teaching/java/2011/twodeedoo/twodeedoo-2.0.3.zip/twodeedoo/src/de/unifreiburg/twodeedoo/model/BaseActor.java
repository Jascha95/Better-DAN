package de.unifreiburg.twodeedoo.model;

import de.unifreiburg.twodeedoo.scene.IScene;
import de.unifreiburg.twodeedoo.view.IGameController;

/**
 * Default base class for {@link IActor} implementations
 * @author anton
 *
 */
public abstract class BaseActor implements IActor {

	/**
	 * The containing actor group, or null.
	 */
	protected ICompositeActor container;
	
	/**
	 * The scene to which the actor can add puppets
	 */
	protected IScene scene;
	
	public BaseActor(IScene scene){
		this.container = null;
		this.scene = scene;
	}

	/**
	 * Get the container
	 * @return containing actor group or null
	 */
	public ICompositeActor getContainer() {
		return container;
	}

	/**
	 * Change the container
	 * @param container an actor group or null.
	 */
	public void setContainer(ICompositeActor container) {
		this.container = container;
	}

	/**
	 * Get the scene.
	 * @return the scene
	 */
	public IScene getScene() {
		return scene;
	}

	/**
	 * Set the scene
	 * @param scene scene where new puppets should go
	 */
	public void setScene(IScene scene) {
		this.scene = scene;
	}

	/**
	 * Default action: ignore all keys
	 */
	@Override
	public void keyPressed(int keyCode, IGameController controller) {
	}

	/**
	 * Default action: ignore all keys
	 */
	@Override
	public void keyReleased(int keyCode, IGameController controller) {
	}
	
	
}
