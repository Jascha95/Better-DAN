package de.unifreiburg.twodeedoo.world;

import java.awt.event.KeyEvent;

/**
 * A world contains state which updates over time and on keypress,
 * and it displays its state on a canvas.
 * <p>
 * Simpler than full twodeedoo.
 * </p>
 * 
 * @author anton
 *
 */
public interface IWorld {

	/**
	 * Title of the game. To be called once at setup.
	 * @return a title.
	 */
	String getTitle();

	/**
	 * Desired width in pixels of the inside of the simulation window 
	 * (call during setup).
	 * @return width in pixels
	 */
	int getWidth();

	/**
	 * Desired height in pixels of the inside of the simulation window 
	 * (call during setup).
	 * @return height in pixels
	 */
	int getHeight();

	/**
	 * Desired cycle time of the simulation, i.e. the time between two calls to
	 *  {@link #onTick(ISimulationController)}.
	 * The simulator should not call {@link #onTick(ISimulationController)} more
	 * frequently than that.
	 * <p>
	 * To be called during setup.
	 * 
	 * @return milliseconds. 
	 */
	int getCycleTimeMs();

	/**
	 * Time has passed. Simulate something.
	 * 
	 * @param controller to stop the simulation
	 */
	void onTick( ISimulationController controller );
	
	/**
	 * A key has been pressed.
	 * @param keyCode key code from {@link KeyEvent}, e.g. {@link KeyEvent#VK_LEFT}.
	 * @param controller to stop the simulation
	 */
	void onKeyPressed( int keyCode, ISimulationController controller);
	
	/**
	 * A key has been released
	 * @param keyCode key code from {@link KeyEvent}, e.g. {@link KeyEvent#VK_LEFT}.
	 * @param controller to stop the simulation
	 */
	void onKeyReleased( int keyCode, ISimulationController controller);
	
	/**
	 * Paint the current state of the world onto the canvas.
	 * @param canvas a canvas with simple drawing methods.
	 */
	void paint(ICanvas canvas);

}
