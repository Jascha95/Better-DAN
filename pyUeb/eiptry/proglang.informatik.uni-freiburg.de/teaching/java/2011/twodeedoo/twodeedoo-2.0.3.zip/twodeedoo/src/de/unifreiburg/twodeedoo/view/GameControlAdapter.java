package de.unifreiburg.twodeedoo.view;

/**
 * Default implementation of {@link IGameControlListener}
 * which ignores all events.
 * 
 * @author anton
 *
 */
public class GameControlAdapter implements IGameControlListener {

	@Override
	public void quitRequested() {
		// Ignore.
	}

	@Override
	public void restartRequested() {
		// Ignore.
	}

}
