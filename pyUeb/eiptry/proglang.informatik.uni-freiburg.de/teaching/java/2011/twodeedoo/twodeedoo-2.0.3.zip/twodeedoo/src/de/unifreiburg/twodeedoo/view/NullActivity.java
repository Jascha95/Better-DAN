package de.unifreiburg.twodeedoo.view;

/**
 * An activity which does nothing.
 * @author anton
 *
 */
public class NullActivity implements IActivity {

	@Override
	public boolean run(int elapsedTimeMillis, IGameController gameController) {
		return true;
	}

	@Override
	public void keyPressed(int keyCode, IGameController controller) {
	}

	@Override
	public void keyReleased(int keyCode, IGameController controller) {
	}

	@Override
	public int minimalTimeSlice() {
		return 0;
	}

}
