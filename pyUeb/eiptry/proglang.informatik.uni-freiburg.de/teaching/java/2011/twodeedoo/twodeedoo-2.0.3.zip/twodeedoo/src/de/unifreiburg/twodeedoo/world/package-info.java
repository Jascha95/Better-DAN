
/**
 * A world simulator (like DrScheme's world teachpack) for twodeedoo.
 * <p>
 * Users of this package are expected to implement an 
 * {@link de.unifreiburg.twodeedoo.world.IWorld}
 * and pass it to {@link de.unifreiburg.twodeedoo.world.WorldApplication#runWorld(IWorld)}.
 * As easy as that.
 * </p>
 */
package de.unifreiburg.twodeedoo.world;