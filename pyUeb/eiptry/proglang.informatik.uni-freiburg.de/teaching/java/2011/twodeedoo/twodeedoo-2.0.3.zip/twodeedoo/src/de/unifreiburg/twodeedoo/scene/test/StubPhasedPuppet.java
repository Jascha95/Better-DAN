package de.unifreiburg.twodeedoo.scene.test;

import java.awt.Graphics;

import de.unifreiburg.twodeedoo.scene.IPhasedPuppet;
import de.unifreiburg.twodeedoo.scene.IScene;
import de.unifreiburg.twodeedoo.test.UnimplementedStubCalledException;

/**
 * {@link IPhasedPuppet} impl with simple fields behind the setters.
 * @author anton
 *
 */
public class StubPhasedPuppet implements IPhasedPuppet {

	private int numberOfPhases;
	private int currentPhase;
	private int x;
	private int y;
	
	public StubPhasedPuppet(int numberOfPhases) {
		super();
		this.numberOfPhases = numberOfPhases;
		this.currentPhase = 0;
	}

	@Override
	public void setPhase(int phase) {
		this.currentPhase = phase;
	}

	@Override
	public int getX() {
		return this.x;
	}

	@Override
	public int getY() {
		return y;
	}

	@Override
	public void moveAbs(int x, int y) {
		this.x = x;
		this.y = y;
	}

	@Override
	public void paint(Graphics g) {
		throw new UnimplementedStubCalledException();
	}

	/**
	 * @return the currentPhase
	 */
	public int getCurrentPhase() {
		return currentPhase;
	}

	@Override
	public int getNumberOfPhases() {
		return this.numberOfPhases;
	}

	/** Not implemented.
	 * @see de.unifreiburg.twodeedoo.scene.IPuppet#removeFromScene()
	 */
	@Override
	public void removeFromScene() {
	}

	/** Not implemented.
	 * @see de.unifreiburg.twodeedoo.scene.IPuppet#setContainingScene(de.unifreiburg.twodeedoo.scene.IScene)
	 */
	@Override
	public void setContainingScene(IScene scene) {
	}
	
}
