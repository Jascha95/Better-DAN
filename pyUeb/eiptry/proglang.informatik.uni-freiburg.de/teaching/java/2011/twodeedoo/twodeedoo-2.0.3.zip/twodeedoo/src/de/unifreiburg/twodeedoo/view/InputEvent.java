package de.unifreiburg.twodeedoo.view;

/**
 * An input event which {@link SceneView} can queue. Not for use
 * outside {@link SceneView}.
 * 
 * Use {@link #makePressed(int)}, {@link #makeReleased(int)} instead
 * of constructors because internal representation may vary.
 * 
 * @author anton
 *
 */
public class InputEvent {

	private final boolean keyReleased;
	private final int keyCode;
	private InputEvent(int keyCode, boolean keyReleased){
		this.keyCode = keyCode;
		this.keyReleased = keyReleased;
		
	}
	
	void sendTo(IKeyHandler kh, IGameController controller){
		if(keyReleased) {
			kh.keyReleased(keyCode, controller);
		} else{
			kh.keyPressed(keyCode, controller);
		}
	}
	static InputEvent makePressed(int keyCode) {
		return new InputEvent(keyCode, false);	
	}
	static InputEvent makeReleased(int keyCode) {
		return new InputEvent(keyCode, true);
	}
}
