package androidlab.exercise5_1;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;

import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLUtils;

class CopyOfGLCube {
	private final IntBuffer mVertexBuffer;
	private final IntBuffer mTextureBuffer;

	public CopyOfGLCube() {

		int one = 65536;
		int half = one / 2;
		int vertices[] = {
				// FRONT
				-half, -half, half, half, -half, half, -half,
				half,
				half,
				half,
				half,
				half,
				// BACK
				-half, -half, -half, -half, half, -half, half, -half,
				-half,
				half,
				half,
				-half,
				// LEFT
				-half, -half, half, -half, half, half, -half, -half, -half,
				-half,
				half,
				-half,
				// RIGHT
				half, -half, -half, half, half, -half, half, -half, half, half,
				half,
				half,
				// TOP
				-half, half, half, half, half, half, -half, half, -half, half,
				half, -half,
				// BOTTOM
				-half, -half, half, -half, -half, -half, half, -half, half,
				half, -half, -half };

		int texCoords[] = {
				// FRONT
				0, one, one, one, 0, 0, one, 0,
				// BACK
				one, one, one, 0, 0, one, 0, 0,
				// LEFT
				one, one, one, 0, 0, one, 0, 0,
				// RIGHT
				one, one, one, 0, 0, one, 0, 0,
				// TOP
				one, 0, 0, 0, one, one, 0, one,
				// BOTTOM
				0, 0, 0, one, one, 0, one, one };

		ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
		vbb.order(ByteOrder.nativeOrder());
		mVertexBuffer = vbb.asIntBuffer();
		mVertexBuffer.put(vertices);
		mVertexBuffer.position(0);

		ByteBuffer tbb = ByteBuffer.allocateDirect(texCoords.length * 4);
		tbb.order(ByteOrder.nativeOrder());
		mTextureBuffer = tbb.asIntBuffer();
		mTextureBuffer.put(texCoords);
		mTextureBuffer.position(0);
	}

	public void draw(GL10 gl, Context context) {
		gl.glVertexPointer(3, GL10.GL_FIXED, 0, mVertexBuffer);

		gl.glEnable(GL10.GL_TEXTURE_2D); // workaround bug 3623
		gl.glTexCoordPointer(2, GL10.GL_FIXED, 0, mTextureBuffer);

		drawTexture(gl, context);
		// drawRandom(gl, context);
	}

	private Bitmap bmp1, bmp2, bmp3, bmp4, bmp5, bmp6;

	public void loadBitmap(GL10 gl, Context context) {
		bmp1 = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.wuerfel01_512);
		bmp2 = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.wuerfel02_512);
		bmp3 = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.wuerfel03_512);
		bmp4 = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.wuerfel04_512);
		bmp5 = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.wuerfel05_512);
		bmp6 = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.wuerfel06_512);
	}

	private void drawRandom(GL10 gl, Context context) {
		// switch (randomNr) {
		// case 1:
		// loadTexture(gl, context, bmp1);
		// break;
		// case 2:
		// loadTexture(gl, context, bmp2);
		// break;
		// case 3:
		// loadTexture(gl, context, bmp3);
		// break;
		// case 4:
		// loadTexture(gl, context, bmp4);
		// break;
		// case 5:
		// loadTexture(gl, context, bmp5);
		// break;
		// case 6:
		// loadTexture(gl, context, bmp6);
		// break;
		// }
	}

	private void drawTexture(GL10 gl, Context context) {
		gl.glTexEnvf(GL10.GL_TEXTURE_ENV, GL10.GL_TEXTURE_ENV_MODE,
				GL10.GL_MODULATE);

		gl.glColor4f(1, 1, 1, 1);
		gl.glNormal3f(0, 0, 1);
		gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 0, 4);
		GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bmp1, 0);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER,
				GL10.GL_LINEAR);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER,
				GL10.GL_LINEAR);

		gl.glColor4f(1, 1, 1, 1);
		gl.glNormal3f(0, 0, -1);
		gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 4, 4);
		GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bmp2, 0);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER,
				GL10.GL_LINEAR);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER,
				GL10.GL_LINEAR);

		gl.glColor4f(1, 1, 1, 1);
		gl.glNormal3f(-1, 0, 0);
		gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 8, 4);
		GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bmp3, 0);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER,
				GL10.GL_LINEAR);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER,
				GL10.GL_LINEAR);

		gl.glColor4f(1, 1, 1, 1);
		gl.glNormal3f(1, 0, 0);
		gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 12, 4);
		GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bmp4, 0);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER,
				GL10.GL_LINEAR);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER,
				GL10.GL_LINEAR);

		gl.glColor4f(1, 1, 1, 1);
		gl.glNormal3f(0, 1, 0);
		gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 16, 4);
		GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bmp5, 0);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER,
				GL10.GL_LINEAR);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER,
				GL10.GL_LINEAR);

		gl.glColor4f(1, 1, 1, 1);
		gl.glNormal3f(0, -1, 0);
		gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 20, 4);
		GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bmp6, 0);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER,
				GL10.GL_LINEAR);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER,
				GL10.GL_LINEAR);
	}

	private void loadTexture(GL10 gl, Context context, Bitmap bmp) {
		GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bmp, 0);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER,
				GL10.GL_LINEAR);
		gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER,
				GL10.GL_LINEAR);
	}
}