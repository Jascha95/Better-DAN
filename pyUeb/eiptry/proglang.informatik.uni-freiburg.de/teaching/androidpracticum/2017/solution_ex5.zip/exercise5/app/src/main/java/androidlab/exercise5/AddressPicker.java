package androidlab.exercise5;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.text.InputType;
import android.view.WindowManager;
import android.widget.EditText;
import androidlab.exercise5.sys.IntentManager;

/**
 * <h2>Address Picker Dialog</h2>
 * 
 * This {@link DialogFragment} provides to input an address string. Therefore
 * the displayed dialog shows an {@link EditText} in which the desired address
 * can be inputed. The entered address String will be broadcasted to the
 * invoking activity via an intent that contains also the information whether
 * the user has entered something.
 * 
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 * 
 * @see IntentManager#submitAddressFromAdressPicker(Context, String, boolean)
 **/
public class AddressPicker extends DialogFragment {

	/** The unique fragment tag for the {@link AddressPicker}. */
	public static final String ADDRESS_FRAGMENT_TAG = "androidlab.exercise5.AddressPicker";

	/**
	 * Method builds the custom {@link Dialog} container, which allows to enter
	 * an address String. The dialog is cancelable by clicking the 'cancel' as
	 * well as by clicking in the offset of the dialog. If the user enters a
	 * address and confirms by clicking the 'ok'-button, the entered address
	 * will be broadcasted via an intent.
	 * 
	 * @param savedInstanceState
	 *            The last saved instance state of the Fragment, or null if this
	 *            is a freshly created Fragment.
	 * 
	 * @return Returns a new Dialog instance to be displayed by the Fragment
	 *         which allows to enter an address String.
	 * @see DialogFragment#onCreateDialog(Bundle),
	 *      IntentManager#submitAddressFromAdressPicker(Context, String,
	 *      boolean)
	 **/
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		final EditText address = new EditText(getActivity());
		address.setInputType(InputType.TYPE_TEXT_VARIATION_POSTAL_ADDRESS);
		address.setLines(3);
		address.setHint(getString(R.string.fallback_address_0) + ", "
				+ getString(R.string.fallback_address_1));
		builder.setTitle(R.string.address_picker)
				.setNegativeButton(R.string.cancel,
						new DialogInterface.OnClickListener() {

							/**
							 * OnClickListener for the 'cancel' button of the
							 * dialog. This method will be invoked when the user
							 * clicks on this button. By clicking on the button
							 * the dialog will be canceled and the onscreen
							 * keyboard will be hidden.
							 * 
							 * @param dialog
							 *            The dialog that received the click.
							 * @param which
							 *            The button that was clicked or the
							 *            position of the item clicked.
							 * @see DialogInterface.OnClickListener#onClick(DialogInterface,
							 *      int)
							 **/
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								getActivity()
										.getWindow()
										.setSoftInputMode(
												WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
								dialog.cancel();
							}
						})
				.setPositiveButton(R.string.ok, new OnClickListener() {

					/**
					 * OnClickListener for the 'ok' button of the dialog. This
					 * method will be invoked when the user clicks on this
					 * button. By clicking on the button the dialog will be
					 * dismissed, the onscreen keyboard will be hidden and an
					 * intent with the entered address String is broadcasted.
					 * 
					 * @param dialog
					 *            The dialog that received the click.
					 * @param which
					 *            The button that was clicked or the position of
					 *            the item clicked.
					 * @see DialogInterface.OnClickListener#onClick(DialogInterface,
					 *      int),
					 *      IntentManager#submitAddressFromAdressPicker(Context,
					 *      String, boolean)
					 **/
					@Override
					public void onClick(DialogInterface dialog, int which) {
						String formattedAddress = address.getText().toString();
						boolean error = formattedAddress == null
								|| new String("").equals(formattedAddress);
						getActivity()
								.getWindow()
								.setSoftInputMode(
										WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
						IntentManager.submitAddressFromAdressPicker(
								getActivity(), formattedAddress, error);
						dialog.dismiss();
					}
				}).setView(address);
		return builder.create();
	}
}
