package androidlab.exercise5.sys;

import android.content.Context;
import android.support.annotation.NonNull;
import android.widget.Toast;
import androidlab.exercise5.R;

/**
 * <h2><Utils for the ToDo Manager Application/h2>
 * 
 * This class provides several static helper methods.
 * 
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 **/
public class Utils {

	/**
	 * Method which creates a human readable String that contains the specified
	 * latitude and longitude information.
	 * 
	 * @param latitude
	 *            The latitude information which should be converted to a human
	 *            readable format.
	 * @param longitude
	 *            The longitude information which should be converted to a human
	 *            readable format.
	 * @param context
	 *            Context in which the method is invoke
	 * @return A String which represents the specified latitude and longitude
	 *         information in a human readable format and which takes also the
	 *         translation into account.
	 */
	@NonNull
	public static String createLocationString(double latitude,
											  double longitude, Context context) {
		boolean latNeg = latitude < 0;
		boolean longNeg = longitude < 0;
		String latString = String.format(context.getResources()
				.getConfiguration().locale, "%.6f %s", (latNeg ? -latitude
				: latitude), (latNeg ? context.getString(R.string.south)
				: context.getString(R.string.north)));
		String longString = String.format(context.getResources()
				.getConfiguration().locale, "%.6f %s", (longNeg ? -longitude
				: longitude), (longNeg ? context.getString(R.string.west)
				: context.getString(R.string.east)));
		return context.getString(R.string.location_reminder_coordinates,
				latString, longString);
	}

	/**
	 * Method will show the specified text as Toast message.
	 * 
	 * @param context
	 *            Context in which the method is invoke
	 * @param msg
	 *            The text which should be displayed as a Toast message.
	 */
	public static void showToast(Context context, String msg) {
		Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
	}
}
