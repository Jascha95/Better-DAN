package androidlab.exercise5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.view.WindowManager;
import android.widget.SimpleAdapter;
import androidlab.exercise5.adapter.ContactAdapter;
import androidlab.exercise5.sys.IntentManager;

/**
 * <h2>Contact Picker Dialog</h2>
 * 
 * This {@link DialogFragment} provides the selection of a contact address.
 * Therefore the displayed dialog shows an list of all addresses in the phone
 * contacts. The chosen address String will be broadcasted to the activity which
 * invoked the dialog via an intent that contains also the information whether
 * the user has chosen a not empty contact.
 * 
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 * @see ContactAdapter, DialogFragment
 **/
public class ContactPicker extends DialogFragment implements OnClickListener {

	/** The unique fragment tag for the {@link ContactPicker}. */
	public static final String CONTACT_FRAGMENT_TAG = "androidlab.exercise5.ContactPicker";
    /** Identifier of the phone contact address String. */
    public static String CONTACT_ADDRESS = "contact_address";
    /** Identifier of the phone contact name. */
    public static String CONTACT_NAME = "contact_name";

	public String contactName;

    public String contactAddress;

	/**
	 * List which contains for every contact of the phone a {@link Map}. Each
	 * map contains the contact information which are accessible by the
	 * identifier {@link ContactAdapter#CONTACT_NAME} and
	 * {@link ContactAdapter#CONTACT_ADDRESS}.
	 */

	/**
	 * submit data for an intent
	 **/
	public void transfer(String contactName, String contactAddress) {
        this.contactName = contactName;
        this.contactAddress = contactAddress;
	}

    /**
     * OnClickListener function for the items of the displayed list in the
     * dialog. This method will lookup the address String for the clicked item,
     * will dismiss the dialog, will hide the onscreen keyboard and will
     * broadcast an intent with the selected address String.
     *
     * @param dialog
     *            The dialog that received the click.
     * @param pos
     *            The position of the item clicked.
     * @see DialogInterface.OnClickListener#onClick(DialogInterface, int)
     **/
    @Override
    public void onClick(DialogInterface dialog, int pos) {
        getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        boolean error = this.contactAddress == null
                || this.contactAddress.length() == 0;
        IntentManager.submitAddressFromContactPicker(getActivity(),
                this.contactAddress, error);
        dialog.dismiss();
    }

    /**
     * Method builds the custom {@link Dialog} container, which allows to chose
     * an address of a contact. The dialog is cancelable by clicking the
     * 'cancel' as well as by clicking in the offset of the dialog. If the user
     * chooses the address of a contact, the selected address will be
     * broadcasted via an intent.
     *
     * @param savedInstanceState
     *            The last saved instance state of the Fragment, or null if this
     *            is a freshly created Fragment.
     * @return Returns a new Dialog instance to be displayed by the Fragment
     *         which allows to chose an address of a phone contact.
     * @see DialogFragment#onCreateDialog(Bundle),
     *      IntentManager#submitAddressFromContactPicker(Context, String,
     *      boolean), ContactAdapter
     **/
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        List<Map<String, String>> contacts = new ArrayList<Map<String, String>>();
        Map<String, String> map = new HashMap<String, String>();
        map.put(CONTACT_NAME, contactName);
        map.put(CONTACT_ADDRESS, contactAddress);
        contacts.add(map);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        String[] from = new String[] { ContactAdapter.CONTACT_NAME,
                ContactAdapter.CONTACT_ADDRESS };
        int[] to = new int[] { R.id.contact_name, R.id.contact_address };
        builder.setTitle(R.string.contacts_picker)
                .setNegativeButton(R.string.cancel,
                        new DialogInterface.OnClickListener() {

                            /**
                             * OnClickListener for the 'cancel' button of the
                             * dialog. This method will be invoked when the user
                             * clicks on this button. By clicking on the button
                             * the dialog will be canceled and the onscreen
                             * keyboard will be hidden.
                             *
                             * @param dialog
                             *            The dialog that received the click.
                             * @param which
                             *            The button that was clicked or the
                             *            position of the item clicked.
                             * @see DialogInterface.OnClickListener#onClick(DialogInterface,
                             *      int)
                             **/
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                getActivity()
                                        .getWindow()
                                        .setSoftInputMode(
                                                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                                dialog.cancel();
                            }
                        })
                .setAdapter(
                        new SimpleAdapter(getActivity(), contacts,
                                R.layout.contact_picker_listview_item, from, to),
                        this);
        return builder.create();
    }
}
