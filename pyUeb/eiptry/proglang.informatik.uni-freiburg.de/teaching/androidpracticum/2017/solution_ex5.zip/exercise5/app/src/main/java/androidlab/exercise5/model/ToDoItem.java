package androidlab.exercise5.model;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import android.content.Context;

import androidlab.exercise5.R;
import androidlab.exercise5.sys.RemindService;

/**
 * <h2>Model of a ToDo item</h2>
 * 
 * An instance of this class represents a single ToDo item. Such an item
 * contains information about the title {@link ToDoItem#title} and the
 * description {@link ToDoItem#description} of the ToDo item, an unique
 * identifier {@link ToDoItem#id}, the information whether the item is done or
 * not {@link ToDoItem#done}, and also the information whether the remind
 * service {@link RemindService} should remind the user (
 * {@link ToDoItem#timeRemind} ) at a specific time. Therefore the item contains
 * the remind time {@link ToDoItem#date} in the {@link Calendar} format. Also an
 * item contains the information whether the remind service
 * {@link RemindService} should remind the user at a specific location (
 * {@link ToDoItem#locationRemind}). Thus, the information of the latitude
 * {@link ToDoItem#latitude} and the longitude {@link ToDoItem#longitude} can be
 * stored by the item.
 * <hr/>
 * The class also contains static identifier for all the properties of an ToDo
 * item. This is for example important for the creation of the database as well
 * as for the access to the database (see {@link ToDoItem#ID},
 * {@link ToDoItem#TITLE}, {@link ToDoItem#DESCRIPTION}, {@link ToDoItem#DONE},
 * {@link ToDoItem#TIME_REMIND}, {@link ToDoItem#DATE},
 * {@link ToDoItem#LOCATION_REMIND}, {@link ToDoItem#LOCATION_LATITUDE},
 * {@link ToDoItem#LOCATION_LONGITUDE} and {@link ToDoItem#LOCATION_ADDRESS}).
 * 
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 **/
public class ToDoItem {

	/** Identifier of the information when the reminding occurs. */
	public static final String DATE = "todo_remind_date";
	/** Identifier of the ToDo item description. */
	public static final String DESCRIPTION = "todo_description";
	/** Identifier of the information whether the ToDo item is done. */
	public static final String DONE = "todo_done";
	/** Identifier of the unique identifier of a ToDo item. */
	public static final String ID = "todo_id";
	/**
	 * Identifier of the address information at which the ToDo item should be
	 * fired. This identifier will be used only for the address which is
	 * generated from the latitude and longitude values.
	 */
	public static final String LOCATION_ADDRESS = "todo_location_address";
	/**
	 * Identifier of the latitude information at which the ToDo item should be
	 * fired.
	 */
	public static final String LOCATION_LATITUDE = "todo_location_latitude";
	/**
	 * Identifier of the longitude information at which the ToDo item should be
	 * fired.
	 */
	public static final String LOCATION_LONGITUDE = "todo_location_longitude";
	/**
	 * Identifier of the information whether for the ToDo item should be
	 * reminded at a specific location.
	 */
	public static final String LOCATION_REMIND = "todo_location_remind";
	/**
	 * Identifier of the information whether for the ToDo item should be
	 * reminded at a specific time.
	 */
	public static final String TIME_REMIND = "todo_time_remind";
	/** Identifier of the ToDo item title. */
	public static final String TITLE = "todo_title";
	/**
	 * The date format pattern, which will be used to store the
	 * {@link ToDoItem#date} in the database.
	 */
	private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

	/**
	 * Converts a {@link Calendar} object into a String which represents the
	 * time of the specified calendar.
	 * 
	 * @param cal
	 *            The calendar which should be converted into a time String.
	 * @return A String which contains the time of the specified
	 *         {@link Calendar} in the format which is defined by
	 *         {@link ToDoItem#DATE_FORMAT}.
	 * @see ToDoItem#DATE_FORMAT
	 */
	public static String getDateAsDBString(Calendar cal) {
		SimpleDateFormat dateFormatter = new SimpleDateFormat(DATE_FORMAT,
				Locale.getDefault());
		String res = "";
		try {
			res = dateFormatter.format(cal.getTime());
		} catch (Exception e) {
			res = "1970-01-01 00:00:00";
		}
		return res;
	}

	/**
	 * Converts String which contains a time in the format
	 * {@link ToDoItem#DATE_FORMAT} into a {@link Calendar} object which has the
	 * time that is represented by the specified String.
	 * 
	 * @param dateString
	 *            String which contains a time in the format
	 *            {@link ToDoItem#DATE_FORMAT}.
	 * @param context
	 *            Context in which the method is invoke
	 * @return A {@link Calendar} which has the time that is represented by the
	 *         specified time String.
	 * @see ToDoItem#DATE_FORMAT
	 */
	public static Calendar getDateFromDBString(String dateString,
			Context context) {
		SimpleDateFormat dateFormatter = new SimpleDateFormat(DATE_FORMAT,
				Locale.getDefault());
		Calendar cal = Calendar.getInstance(context.getResources()
				.getConfiguration().locale);
		try {
			cal.setTime(dateFormatter.parse(dateString));
		} catch (Exception e) {
			cal.setTimeInMillis(System.currentTimeMillis());
		}
		return cal;
	}

	/** Date at which the application should remind for this ToDo item. */
	private Calendar date;
	/** Description of a ToDo item. */
	private String description;
	/** Status of the ToDo item, whether it is done or not. */
	private boolean done;
	/** Identifier of a ToDo item. */
	private int id;
	/** Latitude at which the application should remind for this ToDo item. */
	private double latitude = 0;
	/**
	 * Flag, whether the application should remind for the ToDo item at a
	 * specific location.
	 */
	private boolean locationRemind = false;
	/** Longitude at which the application should remind for this ToDo item. */
	private double longitude = 0;
	/**
	 * Flag, whether the application should remind for the ToDo item at a
	 * specific time.
	 */
	private boolean timeRemind;
	/** Title of a ToDo item. */
	private String title;

	/**
	 * Constructor: This will create a new instance of a ToDo item including all
	 * required data, which is given to this instantiation.
	 * 
	 * @param id
	 *            Identifier of the ToDo item.
	 * @param title
	 *            Title of the ToDo item.
	 * @param description
	 *            Description of the ToDo item
	 * @param timeRemind
	 *            Should the application remind for this ToDo item at a specific
	 *            times?
	 * @param done
	 *            Is the ToDo item done?
	 * @param date
	 *            Date & time of the reminding
	 * @param locationRemind
	 *            Should the application remind for this ToDo item at a specific
	 *            location?
	 * @param latitude
	 *            Latitude of the reminding
	 * @param longitude
	 *            Longitude of the reminding
	 */
	public ToDoItem(int id, String title, String description,
			boolean timeRemind, boolean done, Calendar date,
			boolean locationRemind, double latitude, double longitude) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.timeRemind = timeRemind;
		this.done = done;
		this.date = date;
		this.locationRemind = locationRemind;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	/**
	 * Return the resource id of the background color for the list view. This
	 * depends on whether the item is done, whether the application should
	 * remind the user at a specific time and this time is in the past.
	 * 
	 * @param context
	 *            Context in which the method is invoke
	 * @return The resource id of the background color for this ToDo item in the
	 *         list view.
	 */
	public int getBgColorResourceId(Context context) {
		if (done) {
			return R.color.softgrey;
		} else if (!isAfterNow(context) && !done && timeRemind) {
			return R.color.white;
		} else {
			return R.color.white;
		}
	}

	/**
	 * Returns the remind date as Calendar instance.
	 * 
	 * @return The remind date of this ToDo item.
	 **/
	public Calendar getDate() {
		return date;
	}

	/**
	 * Returns the description of the ToDo item.
	 * 
	 * @return The description of this ToDo item.
	 **/
	public String getDescription() {
		return description;
	}

	/**
	 * Returns the identifier of the ToDo item.
	 * 
	 * @return The id of this ToDo item.
	 **/
	public int getId() {
		return id;
	}

	/**
	 * Returns the latitude at which the application should remind the user.
	 * 
	 * @return The latitude at which the application should remind.
	 */
	public double getLatitude() {
		return latitude;
	}

	/**
	 * Returns the resource id of the drawable which should be displayed in the
	 * list view and which indicates whether the item is done and whether the
	 * application should remind to this item at a specific location.
	 * 
	 * @return The resource id of the drawable which indicates the done and time
	 *         remind status of this ToDo item in the list view.
	 */
	public int getLocationAlertResourceId() {
		return (!done && locationRemind) ? R.drawable.location_en
				: R.drawable.location_dis;
	}

	/**
	 * Returns the longitude at which the application should remind the user.
	 * 
	 * @return The longitude at which the application should remind.
	 */
	public double getLongitude() {
		return longitude;
	}

	/**
	 * Returns the resource id of the drawable which should be displayed in the
	 * list view and which indicates whether the item is done and whether the
	 * application should remind to this item at a specific time.
	 * 
	 * @return The resource id of the drawable which indicates the done and
	 *         location remind status of this ToDo item in the list view.
	 */
	public int getTimeAlertResourceId() {
		return (!done && timeRemind) ? R.drawable.time_en : R.drawable.time_dis;
	}

	/**
	 * Returns the title of the ToDo item.
	 * 
	 * @return THe title of this ToDo item.
	 **/
	public String getTitle() {
		return title;
	}

	/**
	 * Checks whether the occurrence of the remind date is after the current
	 * date and time.
	 * 
	 * @param context
	 *            Context in which the method is invoke
	 * 
	 * @return Is the remind date of this ToDo item after now?
	 **/
	public boolean isAfterNow(Context context) {
		return Calendar.getInstance(
				context.getResources().getConfiguration().locale).before(date);
	}

	/**
	 * Return the information, whether the ToDo item is done or not.
	 * 
	 * @return Is the ToDo item done?
	 **/
	public boolean isDone() {
		return done;
	}

	/**
	 * Returns the information, whether for this ToDo item the application
	 * should remind the user at a specific location or not.
	 * 
	 * @return Should the application remind for this ToDo item at a specific
	 *         location?
	 **/
	public boolean shouldLocationRemind() {
		return locationRemind;
	}

	/**
	 * Returns the information, whether for this ToDo item the application
	 * should remind the user at a specific time or not.
	 * 
	 * @return Should the application remind for this ToDo item at a specific
	 *         time?
	 **/
	public boolean shouldTimeRemind() {
		return timeRemind;
	}
}
