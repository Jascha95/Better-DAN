package androidlab.exercise5.sys;

import java.text.DateFormat;
import java.util.ArrayList;

import android.app.AlarmManager;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;
import androidlab.exercise5.R;
import androidlab.exercise5.adapter.DatabaseAdapter;
import androidlab.exercise5.model.ToDoItem;

/**
 * <h2>Customized AppWigetProvider</h2>
 * 
 * This class implements the customized widget and handles all interactions
 * between the system and the widget(s). So it provides methods which are called
 * when a widget is instantiated, when the widget(s) should be updated and also
 * when all instances of this widget are deleted. Because the method
 * {@link Widget#onUpdate(Context, AppWidgetManager, int[])} is only called
 * minimal every 30 minutes automatically from the system, thus an
 * {@link AlarmManager} is used to update the widget more often. The widget
 * itself should show the next remind occurrence, means the ToDo item which
 * remind date occurs next. Also the widget shows the title of the application.
 * 
 * @see {@link ToDoItem}, {@link DatabaseAdapter}, {@link WidgetUpdate}
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 **/
public class Widget extends AppWidgetProvider {

	/**
	 * Called when the last widget instance was deleted. Because of this there
	 * is not further reason for updating the widgets, so the Alarm which sends
	 * periodical intents to the {@link WidgetUpdate} BroadcastReceiver will be
	 * canceled. This alarm is created in the method
	 * {@link Widget#onEnabled(Context)}.
	 * 
	 * @param context
	 *            The Context in which this receiver is running.
	 * 
	 * @see {@link AppWidgetProvider#onDisabled(Context)}, {@link AlarmManager}
	 **/
	@Override
	public void onDisabled(Context context) {
		AlarmManager alarmManager = (AlarmManager) context
				.getSystemService(Context.ALARM_SERVICE);
		alarmManager.cancel(IntentManager
				.getAlarmPendingIntentForWidget(context));
		super.onDisabled(context);
	}

	/**
	 * Called when the AppWidget for this provider is instantiated. It will
	 * create an alarm which sends periodical intents to the {@link Widget}
	 * BroadcastReceiver. This implementation allows to update the widget more
	 * often than only every half hour (
	 * {@link Widget#onUpdate(Context, AppWidgetManager, int[])} is only called
	 * every 30 minutes). The interval time of the alarm is stored in the
	 * resource {@code res/values/app_settings.xml} with the identifier
	 * {@code widget_updatetime}.
	 * 
	 * @param context
	 *            The Context in which this receiver is running.
	 * 
	 * @see {@link AppWidgetProvider#onEnabled(Context)}, {@link AlarmManager}
	 **/
	@Override
	public void onEnabled(Context context) {
		super.onEnabled(context);
		AlarmManager alarmManager = (AlarmManager) context
				.getSystemService(Context.ALARM_SERVICE);
		alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
				System.currentTimeMillis(),
				context.getResources().getInteger(R.integer.widget_updatetime),
				IntentManager.getAlarmPendingIntentForWidget(context));
	}

	/**
	 * Called when the AppWidgetProvider receives an intent from the system
	 * (enable, delete, update) or also from the {@link AlarmManager}. This
	 * {@link #onReceive(Context, Intent)} method extends the original method of
	 * the {@link AppWidgetProvider} by invoking the update function also when
	 * the customized intent with the action
	 * {@link IntentManager#ACTION_WIDGET_UPDATE} is received.
	 * 
	 * @param context
	 *            The Context in which this receiver is running.
	 * @param intent
	 *            The Intent being received.
	 * @see AppWidgetProvider#onReceive(Context, Intent)
	 */
	@Override
	public void onReceive(Context context, Intent intent) {
		super.onReceive(context, intent);
		if (intent.getAction().equals(IntentManager.ACTION_WIDGET_UPDATE)) {
			ComponentName thisWidget = new ComponentName(context, Widget.class);
			AppWidgetManager appWidgetManager = AppWidgetManager
					.getInstance(context);
			int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
			onUpdate(context, appWidgetManager, appWidgetIds);
		}
	}

	/**
	 * Called when this receives the intent which requests an update of the
	 * widget. Expected is that these intents are also send periodically from
	 * the AlarmManager in the {@link Widget} class. For each existing widget
	 * the shown information in this widget will be updated. More precisely, the
	 * three ToDo item which remind occurrences are next will be fetched from
	 * the database by calling
	 * {@link DatabaseAdapter#getUpcomingToDoItems(Context, int)}. If there
	 * exist such items the information are set to the widget fields otherwise
	 * the text field in the widget should show that there is no item.
	 * 
	 * @param context
	 *            The Context in which this receiver is running.
	 * @param appWidgetManager
	 *            A AppWidgetManager object you can call
	 *            updateAppWidget(ComponentName, RemoteViews) on.
	 * @param appWidgetIds
	 *            The appWidgetIds for which an update is needed. Note that this
	 *            may be all of the AppWidget instances for this provider, or
	 *            just a subset of them.
	 * 
	 * @see {@link AppWidgetProvider#onUpdate(Context, AppWidgetManager, int[])}
	 **/
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
			int[] appWidgetIds) {
		ComponentName thisWidget = new ComponentName(context, Widget.class);
		ArrayList<ToDoItem> toDoItems = DatabaseAdapter.getUpcomingToDoItems(
				context, 3);
		RemoteViews widget = new RemoteViews(context.getPackageName(),
				R.layout.widget);
		widget.setTextViewText(R.id.widget_app,
				context.getString(R.string.app_name));
		widget.setOnClickPendingIntent(R.id.widget_app,
				IntentManager.getAppLauncherPendingIntent(context));
		widget.removeAllViews(R.id.list);
		widget.setViewVisibility(R.id.widget_empty,
				(toDoItems.size() == 0) ? View.VISIBLE : View.GONE);
		for (ToDoItem toDoItem : toDoItems) {
			RemoteViews row = new RemoteViews(context.getPackageName(),
					R.layout.widget_listview_item);
			DateFormat timeFormatter = DateFormat.getTimeInstance(
					DateFormat.SHORT,
					context.getResources().getConfiguration().locale);
			DateFormat dateFormatter = DateFormat.getDateInstance(
					DateFormat.FULL,
					context.getResources().getConfiguration().locale);
			row.setTextViewText(R.id.widget_item_title, toDoItem.getTitle());
			row.setTextViewText(R.id.widget_item_datetime, context.getString(
					R.string.time_reminder_information,
					dateFormatter.format(toDoItem.getDate().getTime()),
					timeFormatter.format(toDoItem.getDate().getTime())));
			row.setImageViewResource(R.id.widget_time_alert_status,
					toDoItem.getTimeAlertResourceId());
			row.setImageViewResource(R.id.widget_location_alert_status,
					toDoItem.getLocationAlertResourceId());
			widget.addView(R.id.list, row);
		}
		for (int widgetId : appWidgetManager.getAppWidgetIds(thisWidget)) {
			appWidgetManager.updateAppWidget(widgetId, widget);
		}
		super.onUpdate(context, appWidgetManager, appWidgetIds);
	}

}
