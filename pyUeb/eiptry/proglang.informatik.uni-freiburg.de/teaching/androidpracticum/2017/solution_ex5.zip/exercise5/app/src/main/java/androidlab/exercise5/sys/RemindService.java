package androidlab.exercise5.sys;

import java.util.ArrayList;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import androidlab.exercise5.R;
import androidlab.exercise5.adapter.DatabaseAdapter;
import androidlab.exercise5.model.ToDoItem;

/**
 * <h2>Remind Service</h2>
 * 
 * The {@link RemindService} handles the reminding function of the
 * ToDoListManager. Firstly for every upcoming ToDo item an alarm (i.e. a
 * notification which will be fired at a specific time) will be created via the
 * {@link AlarmManager}. Secondly the service also triggers a notification for a
 * ToDo item if the remind location of this ToDo item is near the current
 * location. Therefore the {@link LocationManager} and a customized
 * {@link LocationListener} will be used. The service will be notified via a
 * BroadcastReceiver about changes in the database.
 * 
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 **/
public class RemindService extends Service {

	/**
	 * LocationListener which reacts on changes of a LocationManager and which
	 * initiates the check whether the database contains ToDo items which have a
	 * remind location near the current location of the device.
	 **/
	public class LocationUpdate implements LocationListener {

		/**
		 * Called when the location has changed. Via the AsyncTask
		 * {@link LocationChecker} the method checks whether the database
		 * contains ToDo items which have a remind location near the current
		 * location.
		 * 
		 * @param location
		 *            The new location, as a Location object.
		 * @see LocationListener#onLocationChanged(Location)
		 **/
		@Override
		public void onLocationChanged(Location location) {
			new LocationChecker(location).execute();
		}

		/**
		 * Called when the provider is disabled by the user. In this case, the
		 * {@link LocationUpdate} should do nothing.
		 * 
		 * @param provider
		 *            the name of the location provider associated with this
		 *            update.
		 * @see LocationListener#onProviderDisabled(String)
		 **/
		@Override
		public void onProviderDisabled(String provider) {
		}

		/**
		 * Called when the provider is enabled by the user. Via the AsyncTask
		 * {@link LocationChecker} the method tries to check whether the
		 * database contains ToDo items which have a remind location near the
		 * last known location of the LocationManager, if such an location
		 * exists, otherwise the task will be canceled.
		 * 
		 * @param provider
		 *            the name of the location provider associated with this
		 *            update.
		 * 
		 * @see LocationListener#onProviderEnabled(String)
		 **/
		@Override
		public void onProviderEnabled(String provider) {
			new LocationChecker().execute();
		}

		/**
		 * Called when the provider status changes. This method is called when a
		 * provider is unable to fetch a location or if the provider has
		 * recently become available after a period of unavailability. Via the
		 * AsyncTask {@link LocationChecker} the method tries to check whether
		 * the database contains ToDo items which have a remind location near
		 * the last known location of the LocationManager, if such an location
		 * exists, otherwise the task will be canceled.
		 * 
		 * @param provider
		 *            the name of the location provider associated with this
		 *            update.
		 * @param status
		 *            {@link LocationListener#OUT_OF_SERVICE} if the provider is
		 *            out of service, and this is not expected to change in the
		 *            near future;
		 *            {@link LocationListener#TEMPORARILY_UNAVAILABLE} if the
		 *            provider is temporarily unavailable but is expected to be
		 *            available shortly; and {@link LocationListener#AVAILABLE}
		 *            if the provider is currently available.
		 * @param extras
		 *            an optional Bundle which will contain provider specific
		 *            status variables.
		 * @see LocationListener#onStatusChanged(String, int, Bundle)
		 **/
		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			new LocationChecker().execute();
		}

	}

	/**
	 * BroadcastReceiver allows the interaction between the application and the
	 * service as well as between the system and the service. The receiver will
	 * react on the action that informs about the system reboot, the deletion of
	 * ToDo items as well as the update of ToDo items.
	 **/
	public class ServiceBroadcastReceiver extends BroadcastReceiver {

		/**
		 * This method is called when the BroadcastReceiver is receiving an
		 * Intent broadcast. This receiver should only receives Intents with the
		 * action that informs about the system reboot, the deletion of ToDo
		 * items as well as the update of ToDo items.
		 * 
		 * @param context
		 *            The Context in which the receiver is running.
		 * @param intent
		 *            The Intent being received.
		 * @see BroadcastReceiver#onReceive(Context, Intent)
		 **/
		@Override
		public void onReceive(Context context, Intent intent) {
			if (intent == null)
				return;
			if (intent.getAction() == null)
				return;
			if (intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
				initializeNotification();
			} else if (intent.getAction().equals(
					IntentManager.ACTION_ITEM_UPDATE)) {
				initializeNotification();
			} else if (intent.getAction().equals(
					IntentManager.ACTION_ITEM_DELETE)) {
				deleteAllAlarms();
			}
		}

	}

	/**
	 * This {@link AsyncTask} tries to fetch the ToDo items for which the
	 * application should remind at a specific location and which are not done.
	 * Finally it will be checked whether there are items with a remind location
	 * near the current or the last known location. For such an item, a
	 * notification will be displayed.
	 **/
	private class LocationChecker extends
			AsyncTask<Void, Void, ArrayList<ToDoItem>> {

		/** The last known location of the device. */
		private Location lastLocation;

		/**
		 * Constructor of a {@link LocationChecker} without a location. If the
		 * task will be executed, it will be canceled immediately, because the
		 * last known location is not available.
		 **/
		public LocationChecker() {
			lastLocation = null;
		}

		/**
		 * Constructor of a {@link LocationChecker} with the specified last
		 * known location. If the task will be executed, it will fetch all ToDo
		 * items from the database for which the application should remind at a
		 * specific location, and checks after that, whether any ToDo item has a
		 * remind location near the current last known location.
		 * 
		 * @param location
		 *            The last known location of the device.
		 **/
		public LocationChecker(Location location) {
			this.lastLocation = location;
		}

		/**
		 * During the execution of the task, all ToDo items were fetch from the
		 * database for which the application should remind at a specific
		 * location and which are not done. Those fetched ToDo items will be
		 * passed to the method {@link LocationChecker#onPostExecute(ArrayList)}
		 * .
		 * 
		 * @see AsyncTask#doInBackground(Params[]),
		 *      DatabaseAdapter#getLocationRemindToDoItems(Context)
		 **/
		@Override
		protected ArrayList<ToDoItem> doInBackground(Void... param) {
			ArrayList<ToDoItem> locationAlertItems = DatabaseAdapter
					.getLocationRemindToDoItems(RemindService.this);
			return locationAlertItems;
		}

		/**
		 * Checks for a location (which is the current location or the last
		 * known location of the device) whether one or many ToDo items exist in
		 * the database for which the application should trigger a notification
		 * because the remind location is near the location of the device. For
		 * each such an ToDo item a notification will be displayed by calling
		 * the method
		 * {@link RemindService#showLocationNotification(Context, int, String, String)}
		 * .
		 * 
		 * @param result
		 *            The list of ToDo items for which the application should
		 *            remind at a specific slocation and which are not done.
		 * @see AsyncTask#onPostExecute(Object)
		 **/
		@Override
		protected void onPostExecute(ArrayList<ToDoItem> result) {
			if (this.lastLocation == null)
				this.cancel(true);
			for (ToDoItem todo : result) {
				Location todoLocation = new Location("TEMPORARY_PROVIDER");
				todoLocation.setLatitude(todo.getLatitude());
				todoLocation.setLongitude(todo.getLongitude());
				if (todoLocation.distanceTo(this.lastLocation) <= Integer
						.valueOf(
								getResources().getInteger(
										R.integer.location_radius))
						.floatValue()) {
					showLocationNotification(RemindService.this, todo.getId(),
							todo.getTitle(), todo.getDescription());
				}
			}
		}

		/**
		 * Before executing the task, this method checks whether a current
		 * location is known, if not the method tries to fetch the last known
		 * location from the LocationManager. If one of those exists the
		 * execution continues with this location, otherwise the task will be
		 * canceled.
		 * 
		 * @see AsyncTask#onPreExecute(),
		 *      LocationManager#getLastKnownLocation(String)
		 **/
		@Override
		protected void onPreExecute() {
			if (this.lastLocation == null) {
				this.lastLocation = locationManager
						.getLastKnownLocation(LocationManager.GPS_PROVIDER);
			}
			if (this.lastLocation == null)
				this.cancel(true);
			super.onPreExecute();
		}

	}

	/** Indicates whether the service is running or not. */
	public static boolean IS_RUNNING = false;

	/**
	 * Method cancels the notification with the specified identifier.
	 * 
	 * @param context
	 *            The context in which the method is invoked.
	 * @param id
	 *            The id of the notification which should be canceled, i.e. the
	 *            identifier of the corresponding ToDo item.
	 **/
	public static void cancelNotification(Context context, int id) {
		NotificationManager notificationManager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);
		notificationManager.cancel(id);
	}

	/**
	 * Method triggers a notification in the StatusBar for the ToDo item which
	 * is represented by the specified id, title and description. The reason of
	 * showing the notification is that the remind location of the ToDo item is
	 * reached.
	 * 
	 * @param context
	 *            The context in which the method is invoked.
	 * @param id
	 *            The id of the ToDo item for which a notification should be
	 *            displayed.
	 * @param title
	 *            The title of the ToDo item for which a notification should be
	 *            displayed.
	 * @param description
	 *            The description of the ToDo item for which a notification
	 *            should be displayed.
	 **/
	public static void showLocationNotification(Context context, int id,
			String title, String description) {
		showNotification(context, id, title, description, false);
	}

	/**
	 * Method triggers a notification in the StatusBar for a ToDo item. The
	 * information about this ToDo item will be contained by the specified
	 * intent. The reason of showing the notification is that the remind date of
	 * the ToDo item is reached.
	 * 
	 * @param context
	 *            The context in which the method is invoked.
	 * @param intent
	 *            Intent which contains the information of the ToDo item for
	 *            which a notification should be displayed and which was fired
	 *            by the AlarmManager.
	 **/
	public static void showTimeNotification(Context context, Intent intent) {
		int id = intent.getIntExtra(ToDoItem.ID, -1);
		String title = intent.getStringExtra(ToDoItem.TITLE);
		String description = intent.getStringExtra(ToDoItem.DESCRIPTION);
		showNotification(context, id, title, description, true);
	}

	/**
	 * Method triggers a notification in the StatusBar for the ToDo item which
	 * is represented by the specified id, title and description. The reason of
	 * showing the notification is indicated by the specified flag.
	 * 
	 * @param context
	 *            The context in which the method is invoked.
	 * @param id
	 *            The id of the ToDo item for which a notification should be
	 *            displayed.
	 * @param title
	 *            The id of the ToDo item for which a notification should be
	 *            displayed.
	 * @param description
	 *            The title of the ToDo item for which a notification should be
	 *            displayed.
	 * @param time
	 *            Flag which indicates whether the notification reminds for a
	 *            reached deadline or a reached location.
	 **/
	private static void showNotification(Context context, int id, String title,
			String description, boolean time) {
		NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(
				context)
				.setContentTitle(title)
				.setLargeIcon(
						BitmapFactory.decodeResource(context.getResources(),
								R.drawable.app_icon))
				.setStyle(
						new NotificationCompat.BigTextStyle()
								.bigText(description))
				.setContentIntent(
						IntentManager.getAppLauncherPendingIntent(context))
				.addAction(R.drawable.check, context.getString(R.string.check),
						IntentManager.getItemCheckPendingIntent(context, id))
				.setAutoCancel(true);
		if (time) {
			notificationBuilder.setSmallIcon(R.drawable.time_alert).addAction(
					R.drawable.snooze, context.getString(R.string.snooze),
					IntentManager.getItemSnoozePendingIntent(context, id));
		} else {
			notificationBuilder.setSmallIcon(R.drawable.location_alert);
		}
		NotificationManager notificationManager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);
		notificationManager.notify(id, notificationBuilder.build());
	}

	/**
	 * The AlarmManager which allows to adjust alarms that are fired at a
	 * specific time.
	 */
	private AlarmManager alarmManager;
	/**
	 * The LoctionManager which allows to receive periodically the current
	 * location of the device.
	 */
	private LocationManager locationManager;
	/**
	 * The BroadcastReceiver which receives the Intents from the application
	 * that are related with the service.
	 */
	private ServiceBroadcastReceiver receiver;
	/**
	 * List of all PendingIntents which are passed to the AlarmManager, i.e. for
	 * which an alarm was set.
	 */
	private ArrayList<PendingIntent> timeAlarmIntents = new ArrayList<PendingIntent>();
	/**
	 * The LocationListener which listens for location changes in cooperation
	 * with the LocationManager.
	 */
	private LocationUpdate updateListener;

	/**
	 * Return the communication channel to the service. In this case the method
	 * return null because clients can not bind to the service. The returned
	 * IBinder is usually for a complex interface that has been described using
	 * aidl.
	 * 
	 * @param intent
	 *            The Intent that was used to bind to this service, as given to
	 *            {@link Context#bindService(Intent, ServiceConnection, int)}.
	 *            Note that any extras that were included with the Intent at
	 *            that point will not be seen here.
	 * @return Return an IBinder through which clients can call on to the
	 *         service. In this case the method returns always {@code null}.
	 * @see Service#onBind(Intent)
	 **/
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	/**
	 * When the service will be created, the BroadcastReceiver
	 * {@link ServiceBroadcastReceiver} will be created and registered for
	 * receiving informations from the application, the AlarmManager and the
	 * LocationManager will be fetched from the system. Also the LocationManger
	 * will be adjusted, i.e. the gps-provider and the LocationListener
	 * {@link LocationUpdate} will be register and the update times will be
	 * adjusted.
	 * 
	 * @see Service#onCreate(), AlarmManager, LocationManager
	 **/
	@Override
	public void onCreate() {
		this.receiver = new ServiceBroadcastReceiver();
		IntentFilter filter = new IntentFilter();
		filter.addAction(IntentManager.ACTION_ITEM_UPDATE);
		filter.addAction(IntentManager.ACTION_ITEM_DELETE);
		registerReceiver(receiver, filter);
		updateListener = new LocationUpdate();
		alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		locationManager.requestLocationUpdates(
				LocationManager.GPS_PROVIDER,
				Integer.valueOf(
						getResources()
								.getInteger(R.integer.location_updatetime))
						.longValue(),
				Integer.valueOf(
						getResources()
								.getInteger(R.integer.location_updatemindistance))
						.floatValue(), updateListener);
		IS_RUNNING = true;
		super.onCreate();
	}

	/**
	 * When the service will be destroyed, all set alarms will be deleted and
	 * the LocationListener {@link LocationUpdate} as well as the
	 * BroadcastReceiver {@link ServiceBroadcastReceiver} will be unregistered.
	 * 
	 * @see Service#onDestroy()
	 **/
	@Override
	public void onDestroy() {
		deleteAllAlarms();
		IS_RUNNING = false;
		locationManager.removeUpdates(updateListener);
		unregisterReceiver(receiver);
		super.onDestroy();
	}

	/**
	 * Called by the system every time a client explicitly starts the service by
	 * calling {@link #startService(Intent)}, providing the arguments it
	 * supplied and a unique integer token representing the start request.
	 * 
	 * @param intent
	 *            The Intent supplied to {@link #startService(Intent)}, as
	 *            given. This may be null if the service is being restarted
	 *            after its process has gone away, and it had previously
	 *            returned anything except {@link #START_STICKY_COMPATIBILITY}.
	 * @param flags
	 *            Additional data about this start request. Currently either 0,
	 *            {@link #START_FLAG_REDELIVERY}, or {@link #START_FLAG_RETRY}.
	 * @param startId
	 *            A unique integer representing this specific request to start.
	 *            Use with {@link #stopSelfResult(int)}.
	 * @return The return value indicates what semantics the system should use
	 *         for the service's current started state. It may be one of the
	 *         constants associated with the {@link #START_CONTINUATION_MASK}
	 *         bits.
	 * @see Service#onStartCommand(Intent, int, int)
	 **/
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		return super.onStartCommand(intent, flags, startId);
	}

	/**
	 * Creates the PendingIntent which has the operation to trigger a
	 * notification because the deadline of a specific ToDoItem is reached. The
	 * information of this ToDo item are specified by the id, the title, the
	 * description and the date. The generated PendingIntent is passed to the
	 * AlarmManager. I.e. the method stores an alarm for the ToDo item which is
	 * represented by the specified information.
	 * 
	 * @param id
	 *            Identifier of the ToDo item for which an alarm should be
	 *            stored.
	 * @param title
	 *            Title of the ToDo item for which an alarm should be stored.
	 * @param description
	 *            Description of the ToDo item for which an alarm should be
	 *            stored.
	 * @param date
	 *            Deadline of the ToDo item for which an alarm should be stored.
	 * @see IntentManager
	 **/
	private void createTimeAlarm(int id, String title, String description,
			long date) {
		PendingIntent pendingIntent = IntentManager
				.getTimeAlarmPendingIntentForNotification(this, id, title,
						description);
		timeAlarmIntents.add(pendingIntent);
		alarmManager.set(AlarmManager.RTC, date, pendingIntent);
	}

	/**
	 * Removes all set alarms from the AlarmManager.
	 **/
	private void deleteAllAlarms() {
		for (PendingIntent intent : timeAlarmIntents) {
			deleteTimeAlarm(intent);
		}
		timeAlarmIntents.clear();
	}

	/**
	 * Removes the specified PendingIntent from the AlarmManager, i.e. will
	 * remove the alarm for the ToDo item which is represented by the specified
	 * PendingIntent.
	 * 
	 * @param pendingIntent
	 *            The PendingIntent of the alarm for a ToDo item which should be
	 *            canceled.
	 **/
	private void deleteTimeAlarm(PendingIntent pendingIntent) {
		alarmManager.cancel(pendingIntent);
	}

	/**
	 * Method deletes all set alarms and re-fetches all upcoming ToDo items from
	 * the database (all undone items for which the application should remind at
	 * a specific time in the future). For all received items the method will
	 * create an alarm by calling
	 * {@link RemindService#createTimeAlarm(int, String, String, long)}.
	 * 
	 * @see DatabaseAdapter
	 **/
	private void initializeNotification() {
		deleteAllAlarms();
		ArrayList<ToDoItem> timeAlertItems = DatabaseAdapter
				.getUpcomingToDoItems(this);
		for (ToDoItem todo : timeAlertItems) {
			createTimeAlarm(todo.getId(), todo.getTitle(),
					todo.getDescription(), todo.getDate().getTimeInMillis());
		}
	}

}
