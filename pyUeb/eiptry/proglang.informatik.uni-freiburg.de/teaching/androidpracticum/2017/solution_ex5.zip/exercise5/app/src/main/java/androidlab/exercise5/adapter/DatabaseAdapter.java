package androidlab.exercise5.adapter;

import java.util.ArrayList;
import java.util.Calendar;

import samples.Samples;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidlab.exercise5.MainActivity;
import androidlab.exercise5.model.ToDoItem;
import androidlab.exercise5.sys.RemindService;
import androidlab.exercise5.sys.Widget;

/**
 * <h2>Class providing the database access</h2>
 * 
 * This class provides all the functionality for accessing the database. Because
 * there are multiple processes which will access at the same time to these
 * functions, the class provides only static methods so that the opening and
 * closing of the database itself is done within these methods (and so there
 * will no exceptions because of accessing to a closed database). To create a
 * customized database the class contains also the file name
 * {@link DatabaseAdapter#DB_FILENAME}, the version
 * {@link DatabaseAdapter#DB_VERSION} of this own database as well as the table
 * name {@link DatabaseAdapter#TABLE_NAME}. The creation, access, update and
 * deletion of this database is done by the nested class {@link DatabaseHelper}.
 * 
 * @see {@link SQLiteOpenHelper}, {@link DatabaseHelper}, {@link ToDoItem},
 *      {@link MainActivity}, {@link RemindService}, {@link Widget},
 *      {@link Widget}
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 **/
public class DatabaseAdapter {

	/**
	 * Nested class which extends from the {@link SQLiteOpenHelper} and which
	 * provides all basic functions to create, open, close and delete the
	 * database as well as it also provides functions to query for database
	 * entries.
	 **/
	public static class DatabaseHelper extends SQLiteOpenHelper {

		/**
		 * Constructor of the own database helper which will provide all the
		 * basic functions in a given context.
		 * 
		 * @param context
		 *            The Context in which the database helper is created.
		 */
		public DatabaseHelper(Context context) {
			super(context, DB_FILENAME, null, DB_VERSION);
		}

		/**
		 * Method will be called if the database does not exists and some
		 * process tries to access to the database for the first time. The
		 * method itself creates a table where the ToDo items can be stored.
		 * Therefore this table contains the same properties as a
		 * {@link ToDoItem} and the name of these columns are given by the
		 * property identifier (@link {@link ToDoItem#ID},
		 * {@link ToDoItem#TITLE}, {@link ToDoItem#DESCRIPTION},
		 * {@link ToDoItem#DONE}, {@link ToDoItem#TIME_REMIND},
		 * {@link ToDoItem#DATE} ), {@link ToDoItem#LOCATION_REMIND},
		 * {@link ToDoItem#LOCATION_LONGITUDE} and
		 * {@link ToDoItem#LOCATION_LATITUDE}. The used datatypes are straight
		 * forward excepted the flag remind for a specific time, the flag remind
		 * for a specific location and the done status (will be converted to 1
		 * if {@code true}, 0 otherwise) as well as the date. Because SQLite
		 * only can handle simple datatypes as {@code String} or {@code int},
		 * the {@code Calendar} must be converted to a {@code String}.
		 * 
		 * @param db
		 *            The database.
		 * @see {@link SQLiteOpenHelper#onCreate(SQLiteDatabase)}
		 **/
		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(String
					.format("CREATE TABLE %s (%s INTEGER PRIMARY KEY AUTOINCREMENT, "
							+ "%s TEXT, %s TEXT, %s INTEGER NOT NULL, "
							+ "%s INTEGER NOT NULL, %s TEXT, %s INTEGER NOT NULL, "
							+ "%s REAL , %s REAL );", TABLE_NAME, ToDoItem.ID,
							ToDoItem.TITLE, ToDoItem.DESCRIPTION,
							ToDoItem.TIME_REMIND, ToDoItem.DONE, ToDoItem.DATE,
							ToDoItem.LOCATION_REMIND,
							ToDoItem.LOCATION_LATITUDE,
							ToDoItem.LOCATION_LONGITUDE));
		}

		/**
		 * Called when the database needs to be upgraded. Because the database
		 * stays the same at the moment there is no need for a concrete
		 * implementation.
		 * 
		 * @param db
		 *            The database.
		 * @param oldVersion
		 *            The old database version.
		 * @param newVersion
		 *            The new database version.
		 * @see {@link SQLiteOpenHelper#onUpgrade(SQLiteDatabase, int, int)}
		 **/
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
			onCreate(db);
		}
	}

	/** Array which contains all used Identifier of a ToDo item. */
	private static final String[] ALL_TABLE_COLUMNS = new String[] {
			ToDoItem.ID, ToDoItem.TITLE, ToDoItem.DESCRIPTION, ToDoItem.DONE,
			ToDoItem.TIME_REMIND, ToDoItem.DATE, ToDoItem.LOCATION_REMIND,
			ToDoItem.LOCATION_LATITUDE, ToDoItem.LOCATION_LONGITUDE };
	/** Name of the database file (needed for the {@link DatabaseHelper}). */
	private static final String DB_FILENAME = "todoDB";
	/** Version of the database (needed for the {@link DatabaseHelper}) */
	private static final int DB_VERSION = 20;
	/** Name of the database table which contains the ToDo items */
	private static final String TABLE_NAME = "todos";

	/**
	 * Method will instantiate a {@link DatabaseHelper} and opens a writable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} the method will update the date of the
	 * ToDo item with the specified Id. The new remind date will be the
	 * specified minute amount after the current time. After this request the
	 * {@link DatabaseHelper} will be closed.
	 * 
	 * @param id
	 *            Identifier of the item which should be deleted.
	 * @param minutes
	 *            Number of minutes, by which the remind time should be shifted
	 *            from the current time.
	 * @param context
	 *            The Context in which this update of the database is invoked.
	 * @return {@code true} if the date of item with the given identifier in the
	 *         ToDo item table was updated, if not {@code false}.
	 */
	public synchronized static boolean addMinutesToToDoItemWith(int id,
			int minutes, Context context) {
		Calendar cal = Calendar.getInstance(context.getResources()
				.getConfiguration().locale);
		cal.add(Calendar.MINUTE, minutes);
		String date = ToDoItem.getDateAsDBString(cal);
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(ToDoItem.DATE, date);
		boolean result = db.update(TABLE_NAME, values, ToDoItem.ID + '=' + id,
				null) > 0;
		db.close();
		return result;
	}

	/**
	 * Method will instantiate a {@link DatabaseHelper} and opens a writable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} a new entry will be added which has
	 * the specified corresponding values. After this request the
	 * {@link DatabaseHelper} will be closed. If this query was successful the
	 * method will return the identifier of the new inserted item. (For the
	 * conversion of the {@code boolean} and the {@code long} value see
	 * {@link DatabaseHelper#onCreate(SQLiteDatabase)}.)
	 * 
	 * @param title
	 *            Title of the new ToDo item.
	 * @param description
	 *            Description of the new ToDo item.
	 * @param done
	 *            Done status of the new ToDo item.
	 * @param timeRemind
	 *            Time remind status of the new ToDo item.
	 * @param date
	 *            The remind date of the new ToDo item.
	 * @param locationRemind
	 *            Location remind status of the new ToDo item.
	 * @param latitude
	 *            Latitude information of the new ToDo item.
	 * @param longitude
	 *            Longitude information of the new ToDo item.
	 * @param context
	 *            The Context in which this access to the database is invoked.
	 * @return The identifier of the new inserted item if the request was
	 *         successful, otherwise -1.
	 * @see {@link ToDoItem}, {@link SQLiteDatabase},
	 *      {@link DatabaseHelper#getWritableDatabase()}
	 */
	public synchronized static int createToDoItem(String title,
			String description, boolean done, boolean timeRemind,
			Calendar date, boolean locationRemind, double latitude,
			double longitude, Context context) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(ToDoItem.TITLE, title);
		values.put(ToDoItem.DESCRIPTION, description);
		values.put(ToDoItem.DONE, done ? 1 : 0);
		values.put(ToDoItem.TIME_REMIND, timeRemind ? 1 : 0);
		values.put(ToDoItem.DATE, ToDoItem.getDateAsDBString(date));
		values.put(ToDoItem.LOCATION_REMIND, locationRemind ? 1 : 0);
		values.put(ToDoItem.LOCATION_LATITUDE, latitude);
		values.put(ToDoItem.LOCATION_LONGITUDE, longitude);
		int result = (int) db.insert(TABLE_NAME, null, values);
		db.close();
		return result;
	}

	/**
	 * Method will instantiates a {@link DatabaseHelper} and opens a writable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} will all entries be deleted which are
	 * marked as done. After this request the {@link DatabaseHelper} will be
	 * closed. If this query was successful the method will return {@code true},
	 * otherwise {@code false}.
	 * 
	 * @param context
	 *            The Context in which this deletion of all done ToDo items is
	 *            invoked.
	 * @return {@code true} if the request was successful and all done ToDo
	 *         items were deleted, otherwise {@code false}.
	 * @see {@link SQLiteDatabase}, {@link DatabaseHelper#getWritableDatabase()}
	 */
	public synchronized static boolean deleteAllDoneToDoItems(Context context) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getWritableDatabase();
		boolean result = db.delete(TABLE_NAME,
				String.format("%s=1", ToDoItem.DONE), null) >= 0;
		db.close();
		return result;
	}

	/**
	 * Method will instantiates a {@link DatabaseHelper} and opens a writable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} will all entries be deleted and after
	 * this request the {@link DatabaseHelper} will be closed. If this query was
	 * successful the method will return {@code true}, otherwise {@code false}.
	 * 
	 * @param context
	 *            The Context in which this access to the database is invoked.
	 * @return {@code true} if the items in the ToDo item table were deleted, if
	 *         not {@code false}. (The {@code boolean} result value does not
	 *         indicate that really all items where deleted, but the normal case
	 *         is that all items were deleted.)
	 * 
	 * @see {@link ToDoItem}, {@link SQLiteDatabase},
	 *      {@link DatabaseHelper#getWritableDatabase()}
	 */
	public synchronized static boolean deleteAllToDoItems(Context context) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getWritableDatabase();
		boolean result = db.delete(TABLE_NAME, "1", null) >= 0;
		db.close();
		return result;
	}

	/**
	 * Method will instantiate a {@link DatabaseHelper} and opens a writable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} the entry which has the given
	 * identifier will be deleted and after this request the
	 * {@link DatabaseHelper} will be closed. If this query was successful the
	 * method will return {@code true}, otherwise {@code false}.
	 * 
	 * @param id
	 *            Identifier of the item which should be deleted.
	 * @param context
	 *            The Context in which this access to the database is invoked.
	 * @return {@code true} if the item with the given identifier in the ToDo
	 *         item table was deleted, if not {@code false}.
	 * 
	 * @see {@link ToDoItem}, {@link SQLiteDatabase},
	 *      {@link DatabaseHelper#getWritableDatabase()}
	 */
	public synchronized static boolean deleteToDoItemWith(int id,
			Context context) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getWritableDatabase();
		boolean result = db.delete(TABLE_NAME, ToDoItem.ID + "=" + id, null) > 0;
		db.close();
		return result;
	}

	/**
	 * Method will instantiate a {@link DatabaseHelper} and opens a readable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} all entries will be fetched and
	 * through a {@link Cursor} the values of each row will be accessed. For
	 * such an row a new Instance of {@link ToDoItem} is created with the
	 * corresponding values. All created items will be added to a list which the
	 * method returns. Before returning the result object, the
	 * {@link DatabaseHelper} will be closed.
	 * 
	 * @param context
	 *            The Context in which this access to the database is invoked.
	 * @return List of all ToDo items which are stored in the database and for
	 *         which the location reminding is enabled.
	 * 
	 * @see {@link ToDoItem}, {@link SQLiteDatabase},
	 *      {@link DatabaseHelper#getReadableDatabase()}
	 */
	public synchronized static ArrayList<ToDoItem> fetchAllToDoItems(
			Context context) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getReadableDatabase();
		String sortBy = ToDoItem.DONE + " ASC, " + ToDoItem.TIME_REMIND
				+ " DESC, " + ToDoItem.DATE + " ASC";
		Cursor cursor = db.query(TABLE_NAME, ALL_TABLE_COLUMNS, null, null,
				null, null, sortBy);
		ArrayList<ToDoItem> todos = new ArrayList<ToDoItem>();
		if (cursor.getCount() > 0) {
			while (cursor.moveToNext()) {
				try {
					todos.add(createToDoItemFromCursor(cursor, context));
				} catch (Exception e) {
					cursor.close();
					db.close();
					return todos;
				}
			}
		}
		cursor.close();
		db.close();
		return todos;
	}

	/**
	 * Query the database.
	 */
	public synchronized static Cursor query(final String[] projection, final String selection,
							   final String[] selectionArgs, final String sortOrder, Context context) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getReadableDatabase();
		return db.query(TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder);
	}


	/**
	 * Method will instantiate a {@link DatabaseHelper} and opens a readable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} the entry which has the given
	 * identifier will be fetched. Through a {@link Cursor} the values of the
	 * entry will be accessed, if this contains more than one row. If there is
	 * no row the method will return {@code null}, otherwise with the received
	 * values a ToDo item will be instantiated and returned. Before returning
	 * the result object, the {@link DatabaseHelper} will be closed.
	 * 
	 * @param id
	 *            Identifier of the ToDo item which should be fetched.
	 * @param context
	 *            The Context in which this access to the database is invoked.
	 * @return The ToDo item which has the given identifier if such an entry
	 *         exists in the database, otherwise null.
	 * 
	 * @see {@link ToDoItem}, {@link SQLiteDatabase},
	 *      {@link DatabaseHelper#getReadableDatabase()}
	 */
	public synchronized static ToDoItem fetchToDoItemWith(int id,
			Context context) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getReadableDatabase();
		ToDoItem result = null;
		Cursor cursor = db.query(TABLE_NAME, ALL_TABLE_COLUMNS, ToDoItem.ID
				+ "=" + id, null, null, null, null);
		if (cursor.getCount() > 0) {
			cursor.moveToFirst();
			try {
				result = createToDoItemFromCursor(cursor, context);
			} catch (Exception e) {
				cursor.close();
				db.close();
				return result;
			}
		}
		cursor.close();
		db.close();
		return result;
	}

	/**
	 * Method will instantiate a {@link DatabaseHelper} and opens a readable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} all entries will be fetched for which
	 * the application should remind at a specific location and through a
	 * {@link Cursor} the values of each row will be accessed. For such an row a
	 * new Instance of {@link ToDoItem} is created with the corresponding
	 * values. All created items will be added to a list which the method
	 * returns. Before returning the result object, the {@link DatabaseHelper}
	 * will be closed.
	 * 
	 * @param context
	 *            The Context in which this access to the database is invoked.
	 * @return List of all ToDo items which are stored in the database and for
	 *         which the application should remind at a specific location.
	 */
	public static ArrayList<ToDoItem> getLocationRemindToDoItems(Context context) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getReadableDatabase();
		String where = ToDoItem.LOCATION_REMIND + " = 1 AND " + ToDoItem.DONE
				+ " = 0";
		String sortBy = ToDoItem.ID + " ASC";
		Cursor cursor = db.query(TABLE_NAME, ALL_TABLE_COLUMNS, where, null,
				null, null, sortBy);
		ArrayList<ToDoItem> todos = new ArrayList<ToDoItem>();
		if (cursor.getCount() > 0) {
			while (cursor.moveToNext()) {
				try {
					ToDoItem todo = createToDoItemFromCursor(cursor, context);
					todos.add(todo);
				} catch (Exception e) {
					cursor.close();
					db.close();
					return todos;
				}
			}
		}
		cursor.close();
		db.close();
		return todos;
	}

	/**
	 * Method will instantiate a {@link DatabaseHelper} and opens a readable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} all entries for which the application
	 * should remind at a specific time will be fetched and through a
	 * {@link Cursor} the values of each row will be accessed. For such an row a
	 * new Instance of {@link ToDoItem} is created with the corresponding
	 * values. All created items will be added to a list which the method
	 * returns. Before returning the result object, the {@link DatabaseHelper}
	 * will be closed.
	 * 
	 * @param context
	 *            The Context in which this access to the database is invoked.
	 * @return List of all ToDo items which are stored in the database and which
	 *         are enable for time reminding. This means that the ToDo items are
	 *         not done, the application should remind for these items and the
	 *         remind date is after the current date.
	 * 
	 * @see {@link ToDoItem}, {@link SQLiteDatabase},
	 *      {@link DatabaseHelper#getReadableDatabase()}
	 */
	public synchronized static ArrayList<ToDoItem> getUpcomingToDoItems(
			Context context) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getReadableDatabase();
		String now = ToDoItem.getDateAsDBString(Calendar.getInstance(context
				.getResources().getConfiguration().locale));
		String where = ToDoItem.TIME_REMIND + " = 1 AND " + ToDoItem.DONE
				+ " = 0 AND " + ToDoItem.DATE + " >= '" + now + "'";
		String sortBy = ToDoItem.DATE + " ASC";
		Cursor cursor = db.query(TABLE_NAME, ALL_TABLE_COLUMNS, where, null,
				null, null, sortBy);
		ArrayList<ToDoItem> todos = new ArrayList<ToDoItem>();
		if (cursor.getCount() > 0) {
			while (cursor.moveToNext()) {
				try {
					ToDoItem todo = createToDoItemFromCursor(cursor, context);
					if (todo.isAfterNow(context))
						todos.add(todo);
				} catch (Exception e) {
					cursor.close();
					db.close();
					return todos;
				}
			}
		}
		cursor.close();
		db.close();
		return todos;
	}

	/**
	 * Method will instantiate a {@link DatabaseHelper} and opens a readable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} all entries for which the application
	 * should remind at a specific time will be fetched and through a
	 * {@link Cursor} the values of each row will be accessed. The specified
	 * number is the amount for how many rows a new Instance of {@link ToDoItem}
	 * is created with the corresponding values. All created items will be added
	 * to a list which the method returns. Before returning the result object,
	 * the {@link DatabaseHelper} will be closed.
	 * 
	 * @param context
	 *            The Context in which this access to the database is invoked.
	 * @param count
	 *            The number of items which the resulting list should contain.
	 *            This means if the database has enough items to which the
	 *            characteristics apply the returned list will contains at most
	 *            the specified number of items.
	 * @return List of the ToDo items which are stored in the database and which
	 *         are enable for time reminding. The number of the items depends on
	 *         the specified integer. The returned ToDo items are not done, the
	 *         application should remind for these items and the remind date is
	 *         after the current date.
	 * @see {@link ToDoItem}, {@link SQLiteDatabase},
	 *      {@link DatabaseHelper#getReadableDatabase()}
	 */
	public static ArrayList<ToDoItem> getUpcomingToDoItems(Context context,
			int count) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getReadableDatabase();
		String now = ToDoItem.getDateAsDBString(Calendar.getInstance(context
				.getResources().getConfiguration().locale));
		String where = ToDoItem.TIME_REMIND + " = 1 AND " + ToDoItem.DONE
				+ " = 0 AND " + ToDoItem.DATE + " >= '" + now + "'";
		String sortBy = ToDoItem.DATE + " ASC";
		Cursor cursor = db.query(TABLE_NAME, ALL_TABLE_COLUMNS, where, null,
				null, null, sortBy);
		ArrayList<ToDoItem> todos = new ArrayList<ToDoItem>();
		if (cursor.getCount() > 0) {
			while (cursor.moveToNext() && cursor.getPosition() < count) {
				try {
					ToDoItem todo = createToDoItemFromCursor(cursor, context);
					if (todo.isAfterNow(context))
						todos.add(todo);
				} catch (Exception e) {
					cursor.close();
					db.close();
					return todos;
				}
			}
		}
		cursor.close();
		db.close();
		return todos;
	}

	/**
	 * Method will create a list of random sample ToDo items by calling the
	 * method {@link Samples#generateListOfToDoItems(Context)} and insert all
	 * these items into the database (
	 * {@link DatabaseAdapter#createToDoItem(String, String, boolean, boolean, long, Context)}
	 * ).
	 * 
	 * @param context
	 *            The Context in which this access to the database is invoked.
	 * @see {@link Samples}, {@link ToDoItem}
	 */
	public synchronized static void insertTestdata(Context context) {
		ArrayList<ToDoItem> todos = Samples.generateListOfToDoItems(context);
		for (ToDoItem todo : todos) {
			createToDoItem(todo.getTitle(), todo.getDescription(),
					todo.isDone(), todo.shouldTimeRemind(), todo.getDate(),
					todo.shouldLocationRemind(), todo.getLatitude(),
					todo.getLongitude(), context);
		}
	}

	/**
	 * Method will instantiate a {@link DatabaseHelper} and opens a writable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} the entry which has the given
	 * identifier will be updated. But only the done status of this entry will
	 * set to the given {@code boolean} value. After this request the
	 * {@link DatabaseHelper} will be closed. If this query was successful the
	 * method will return {@code true}, otherwise {@code false}. (For the
	 * conversion of the {@code boolean} and the {@code long} value see
	 * {@link DatabaseHelper#onCreate(SQLiteDatabase)}.)
	 * 
	 * @param id
	 *            Identifier of the item which should be updated.
	 * @param done
	 *            New done status of the ToDo item.
	 * @param context
	 *            The Context in which this access to the database is invoked.
	 * @return {@code true} if the done status of item with the given identifier
	 *         in the ToDo item table was updated, if not {@code false}.
	 * 
	 * @see {@link ToDoItem}, {@link SQLiteDatabase},
	 *      {@link DatabaseHelper#getWritableDatabase()}
	 */
	public synchronized static boolean updateToDoItemWith(int id, boolean done,
			Context context) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(ToDoItem.DONE, done ? 1 : 0);
		boolean result = db.update(TABLE_NAME, values, ToDoItem.ID + '=' + id,
				null) > 0;
		db.close();
		return result;
	}

	/**
	 * Method will instantiate a {@link DatabaseHelper} and opens a writable
	 * database. In the table of the ToDo items
	 * {@link DatabaseAdapter#TABLE_NAME} the entry which has the given
	 * identifier will be updated. All columns except the identifier column were
	 * set to the corresponding given value. After this request the
	 * {@link DatabaseHelper} will be closed. If this query was successful the
	 * method will return {@code true}, otherwise {@code false}. (For the
	 * conversion of the {@code boolean} and the {@code Calendar} values see
	 * {@link DatabaseHelper#onCreate(SQLiteDatabase)}.)
	 * 
	 * @param id
	 *            Identifier of the item which should be updated.
	 * @param title
	 *            New title of this ToDo item.
	 * @param description
	 *            New description of the ToDo item.
	 * @param done
	 *            New done status of the ToDo item.
	 * @param remind
	 *            New remind status of the ToDo item.
	 * @param date
	 *            New remind date of the ToDo item.
	 * @param locationRemind
	 *            New location remind status of the ToDo item.
	 * @param latitude
	 *            New latitude information of the ToDo item.
	 * @param longitude
	 *            New longitude information of the ToDo item.
	 * @param context
	 *            The Context in which this access to the database is invoked.
	 * @return {@code true} if the item with the given identifier in the ToDo
	 *         item table was updated, if not {@code false}.
	 * 
	 * @see {@link ToDoItem}, {@link SQLiteDatabase},
	 *      {@link DatabaseHelper#getWritableDatabase()}
	 */
	public synchronized static boolean updateToDoItemWith(int id, String title,
			String description, boolean done, boolean remind, Calendar date,
			boolean locationRemind, double latitude, double longitude,
			Context context) {
		DatabaseHelper helper = new DatabaseHelper(context);
		SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(ToDoItem.TITLE, title);
		values.put(ToDoItem.DESCRIPTION, description);
		values.put(ToDoItem.DONE, done ? 1 : 0);
		values.put(ToDoItem.TIME_REMIND, remind ? 1 : 0);
		values.put(ToDoItem.DATE, ToDoItem.getDateAsDBString(date));
		values.put(ToDoItem.LOCATION_REMIND, locationRemind ? 1 : 0);
		values.put(ToDoItem.LOCATION_LATITUDE, latitude);
		values.put(ToDoItem.LOCATION_LONGITUDE, longitude);
		boolean result = db.update(TABLE_NAME, values, ToDoItem.ID + '=' + id,
				null) > 0;
		db.close();
		return result;
	}

	/**
	 * Method creates a new ToDo item object, which contains the information of
	 * the specified cursor at the current position. This fetched ToDo item will
	 * be returned. (For the conversion of the {@code boolean} and the
	 * {@code Calendar} values see
	 * {@link DatabaseHelper#onCreate(SQLiteDatabase)}.)
	 * 
	 * @param cursor
	 *            A cursor which is at a valid position. With the information at
	 *            this cursor position a new ToDo item will be created and
	 *            returned.
	 * @param context
	 *            The Context in which conversion is invoked.
	 * @return The ToDo item which contains the information of the cursor at the
	 *         current position.
	 * @throws Exception
	 *             Throws an exception, if it is not possible the create a ToDo
	 *             item with the information of the cursor at the current
	 *             position.
	 */
	private static ToDoItem createToDoItemFromCursor(Cursor cursor,
			Context context) throws Exception {
		ToDoItem todo = new ToDoItem(cursor.getInt(cursor
				.getColumnIndexOrThrow(ToDoItem.ID)), cursor.getString(cursor
				.getColumnIndexOrThrow(ToDoItem.TITLE)),
				cursor.getString(cursor
						.getColumnIndexOrThrow(ToDoItem.DESCRIPTION)),
				cursor.getInt(cursor
						.getColumnIndexOrThrow(ToDoItem.TIME_REMIND)) > 0,
				cursor.getInt(cursor.getColumnIndexOrThrow(ToDoItem.DONE)) > 0,
				ToDoItem.getDateFromDBString(cursor.getString(cursor
						.getColumnIndexOrThrow(ToDoItem.DATE)), context),
				cursor.getInt(cursor
						.getColumnIndexOrThrow(ToDoItem.LOCATION_REMIND)) > 0,
				cursor.getDouble(cursor
						.getColumnIndexOrThrow(ToDoItem.LOCATION_LATITUDE)),
				cursor.getDouble(cursor
						.getColumnIndexOrThrow(ToDoItem.LOCATION_LONGITUDE)));
		return todo;
	}
}
