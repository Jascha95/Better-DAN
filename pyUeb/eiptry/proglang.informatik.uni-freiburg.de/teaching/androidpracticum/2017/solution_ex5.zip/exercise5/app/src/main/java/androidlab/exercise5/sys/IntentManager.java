package androidlab.exercise5.sys;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import androidlab.exercise5.AddressPicker;
import androidlab.exercise5.ContactPicker;
import androidlab.exercise5.CoordinatesPicker;
import androidlab.exercise5.EditActivity;
import androidlab.exercise5.LocationPicker;
import androidlab.exercise5.MainActivity;
import androidlab.exercise5.R;
import androidlab.exercise5.adapter.DatabaseAdapter;
import androidlab.exercise5.model.ToDoItem;

/**
 * <h2>Intent Manager</h2>
 * 
 * This class provides several methods for encapsulating as far as possible the
 * usage of {@link Intent}s. So the class lists all used actions of intents and
 * provides methods which create a specific intent and broadcast this as well
 * (e.g. request for updating the widget, starting the EditActivity for a
 * specified ToDo item). Additionally the {@link IntentManager} provides methods
 * which create {@link PendingIntent}s for different purposes (e.g.
 * PendingIntent for the {@link AlarmManager} which includes the intent that
 * defines the action when the alarm fires). Also the {@link IntentManager}
 * extends the {@link BroadcastReceiver} class and will receive multiple Intents
 * (e.g. if the system was rebooted) and executes the corresponding desired
 * operation.
 * 
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 **/
public class IntentManager extends BroadcastReceiver {

	/**
	 * Action of an Intent which indicates that the done flag of an item should
	 * be changed to done.
	 */
	public static final String ACTION_ITEM_CHECK = "androidlab.exercise5.action.ITEM_CHECK";
	/**
	 * Action of an Intent which indicates that the alarms for all ToDo items
	 * should be removed.
	 */
	public static final String ACTION_ITEM_DELETE = "androidlab.exercise5.action.ITEM_DELETE";
	/**
	 * Action of an Intent which indicates that remind time of an ToDo item
	 * should be shifted in the future.
	 */
	public static final String ACTION_ITEM_SNOOZE = "androidlab.exercise5.action.ITEM_SNOOZE";
	/**
	 * Action of an Intent which indicates that the alarms for all ToDo items
	 * should be updated.
	 */
	public static final String ACTION_ITEM_UPDATE = "androidlab.exercise5.action.ITEM_UPDATE";
	/**
	 * Action of an Intent which indicates that the Intent contains the result
	 * of a picker dialog.
	 */
	public static final String ACTION_PICKER_RESULT = "androidlab.exercise5.action.PICKER_RESULT";
	/** Action of an Intent which indicates that the service should be started. */
	public static final String ACTION_START_SERVICE = "androidlab.exercise5.action.START_SERVICE";
	/**
	 * Action of an Intent which indicates that the alarm has fired because of a
	 * reminder deadline.
	 */
	public static final String ACTION_TIME_NOTIFICATION = "androidlab.exercise5.action.TIME_NOTIFICATION";
	/** Action of an Intent which indicates that the widget should be updated. */
	public static final String ACTION_WIDGET_UPDATE = "androidlab.exercise5.action.WIDGET_UPDATE";

	/**
	 * The key for which the validity of the given location information is
	 * stored in the intent.
	 */
	public static final String KEY_PICKER_ERROR = "androidlab.exercise5.key.PICKER_ERROR";
	/** The key for which the picker type is stored in the intent. */
	public static final String KEY_PICKER_TYPE = "androidlab.exercise5.key.PICKER_TYPE";
	/** The key for which the type of editing is stored in the intent. */
	public static final String KEY_REQUEST_CODE = "androidlab.exercise5.key.REQUEST_CODE";

	/**
	 * The request code for creating a new ToDo item in the {@link EditActivity}
	 * .
	 */
	public static final int REQUEST_NEW_ITEM = 123;
	/**
	 * The request code for choosing a remind location from the
	 * {@link LocationPicker}.
	 */
	public static final int REQUEST_SET_LOCATION = 345;
	/**
	 * The request code for updating an existing ToDo item in the
	 * {@link EditActivity}.
	 */
	public static final int REQUEST_UPDATE_ITEM = 234;

	/**
	 * The result code which indicates that the result was canceled (see
	 * {@link Activity#RESULT_CANCELED}).
	 */
	public static final int RESULT_CANCELED = Activity.RESULT_CANCELED;
	/** The result code which indicates that the item was deleted. */
	public static final int RESULT_DELETE = 987;
	/**
	 * The result code which indicates that the result is ok (see
	 * {@link Activity#RESULT_OK}).
	 */
	public static final int RESULT_OK = Activity.RESULT_OK;

	/**
	 * Stores the specified id as an ToDo item id in the result intent of the
	 * specified {@link EditActivity}. This intent as well as the result code
	 * {@link IntentManager#RESULT_CANCELED} will be given to the method
	 * {@link Activity#onActivityResult(int, int, Intent)} of the activity which
	 * started the specified activity as soon as the activity will be finished.
	 * This indicates that the editing of the item was canceled.
	 * 
	 * @param activity
	 *            The activity for which the result intent should be updated
	 *            with the other specified information.
	 * @param id
	 *            The id of the ToDo item which was edited.
	 **/
	public static void cancelEditing(EditActivity activity, int id) {
		endEditing(activity, id, RESULT_CANCELED);
	}

	/**
	 * Cancels the selection of the remind location for the ToDo item with the
	 * specified id by including this id into the result intent of the specified
	 * {@link LocationPicker}. This intent as well as the result code
	 * {@link Activity#RESULT_CANCELED} will be given to the method
	 * {@link Activity#onActivityResult(int, int, Intent)} of the activity which
	 * started the LocationPicker as soon as the LocationPicker will be
	 * finished.
	 * 
	 * @param activity
	 *            The LocationPicker for which the result intent should be
	 *            stored.
	 * @param id
	 *            The id of the ToDo item for which the remind location was
	 *            changed.
	 **/
	public static void cancelLocationSelection(LocationPicker activity, int id) {
		Intent intent = new Intent();
		intent.putExtra(ToDoItem.ID, id);
		activity.setResult(RESULT_CANCELED, intent);
	}

	/**
	 * Stores the specified id as an ToDo item id in the result intent of the
	 * specified {@link EditActivity}. This intent as well as the result code
	 * {@link IntentManager#RESULT_DELETE} will be given to the method
	 * {@link Activity#onActivityResult(int, int, Intent)} of the activity which
	 * started the specified activity as soon as the activity will be finished.
	 * This indicates that the edited item should be deleted.
	 * 
	 * @param activity
	 *            The activity for which the result intent should be updated
	 *            with the other specified information.
	 * @param id
	 *            The id of the ToDo item which was edited.
	 **/
	public static void deleteEditing(EditActivity activity, int id) {
		endEditing(activity, id, RESULT_DELETE);
	}

	/**
	 * Generates and returns a PendingIntent which will broadcast the Intent
	 * that triggers the update of the {@link Widget}, when the PendingIntent is
	 * processed.
	 * 
	 * @param context
	 *            The Context in which the final Intent should be broadcasted.
	 * @return PendingIntent which will trigger a widget update by broadcasting
	 *         the corresponding Intent when it is processed.
	 **/
	public static PendingIntent getAlarmPendingIntentForWidget(Context context) {
		Intent intent = new Intent(ACTION_WIDGET_UPDATE);
		intent.setClass(context, Widget.class);
		return PendingIntent.getBroadcast(context, 0, intent, 0);
	}

	/**
	 * Generates and returns a PendingIntent which will open the
	 * {@link MainActivity}, when the PendingIntent is processed.
	 * 
	 * @param context
	 *            The Context in which the final Intent should be broadcasted.
	 * @return PendingIntent which will open the MainActivity when it is
	 *         processed.
	 **/
	public static PendingIntent getAppLauncherPendingIntent(Context context) {
		Intent intent = new Intent(context, MainActivity.class);
		return PendingIntent.getActivity(context, 0, intent,
				PendingIntent.FLAG_UPDATE_CURRENT);
	}

	/**
	 * Generates an IntentFilter which only listens for Intents with the action
	 * {@link IntentManager#ACTION_PICKER_RESULT}.
	 * 
	 * @return IntentFilter which only listens for the result of picker.
	 */
	public static IntentFilter getFilterForPickerResults() {
		return new IntentFilter(ACTION_PICKER_RESULT);
	}

	/**
	 * Generates and returns a PendingIntent which will broadcast the Intent
	 * that triggers to set the done flag of the ToDo item with the specified id
	 * to 'done' , when the PendingIntent is processed.
	 * 
	 * @param context
	 *            The Context in which the final Intent should be broadcasted.
	 * @param id
	 *            Id of the ToDo item for which the done status should be set to
	 *            'done' when the PendingIntent is processed.
	 * @return PendingIntent which will set the done status of the ToDo item
	 *         with the specified id to 'done' when it is processed.
	 **/
	public static PendingIntent getItemCheckPendingIntent(Context context,
			int id) {
		Intent checkIntent = new Intent(context, IntentManager.class);
		checkIntent.setAction(ACTION_ITEM_CHECK);
		checkIntent.putExtra(ToDoItem.ID, id);
		return PendingIntent.getBroadcast(context, 0, checkIntent,
				PendingIntent.FLAG_UPDATE_CURRENT);
	}

	/**
	 * Generates and returns a PendingIntent which will broadcast the Intent
	 * that triggers to shift the remind date of the ToDo item with the
	 * specified id to a later deadline, when the PendingIntent is processed.
	 * 
	 * @param context
	 *            The Context in which the final Intent should be broadcasted.
	 * @param id
	 *            Id of the ToDo item for which the remind date should be
	 *            shifted when the PendingIntent is processed.
	 * @return PendingIntent which will shift the remind date of the ToDo item
	 *         with the specified id when it is processed.
	 **/
	public static PendingIntent getItemSnoozePendingIntent(Context context,
			int id) {
		Intent snoozeIntent = new Intent(context, IntentManager.class);
		snoozeIntent.setAction(ACTION_ITEM_SNOOZE);
		snoozeIntent.putExtra(ToDoItem.ID, id);
		return PendingIntent.getBroadcast(context, 0, snoozeIntent,
				PendingIntent.FLAG_UPDATE_CURRENT);
	}

	/**
	 * Generates and returns a PendingIntent which will broadcast the Intent
	 * that triggers the notification because the remind date of the ToDo item
	 * with the specified id, the specified title and the specified description
	 * is is reached, when the PendingIntent is processed.
	 * 
	 * @param context
	 *            The Context in which the final Intent should be broadcasted.
	 * @param id
	 *            Id of the ToDo item for which the notification should be
	 *            displayed when the PendingIntent is processed.
	 * @param title
	 *            The title of the ToDo item for which the notification should
	 *            be displayed when the PendingIntent is processed.
	 * @param description
	 *            The description of the ToDo item for which the notification
	 *            should be displayed when the PendingIntent is processed.
	 * @return PendingIntent which will trigger a notification with the
	 *         specified information when it is processed.
	 **/
	public static PendingIntent getTimeAlarmPendingIntentForNotification(
			Context context, int id, String title, String description) {
		Intent intent = new Intent(context, IntentManager.class);
		intent.setAction(ACTION_TIME_NOTIFICATION);
		intent.putExtra(ToDoItem.ID, id);
		intent.putExtra(ToDoItem.TITLE, title);
		intent.putExtra(ToDoItem.DESCRIPTION, description);
		return PendingIntent.getBroadcast(context, id, intent,
				PendingIntent.FLAG_UPDATE_CURRENT);
	}

	/**
	 * Method which will start the service, update the widget and broadcasts an
	 * Intent which notifies the service that a ToDo item was deleted.
	 * 
	 * @param context
	 *            The Context in which the Intent should be broadcasted.
	 **/
	public static void informReceiverDeletion(Context context) {
		startServiceIfNotRunning(context);
		updateWidget(context);
		Intent intent = new Intent(ACTION_ITEM_DELETE);
		context.sendBroadcast(intent);
	}

	/**
	 * Method which will start the service, update the widget and broadcasts an
	 * Intent which notifies the service that a ToDo item was updated.
	 * 
	 * @param context
	 *            The Context in which the Intent should be broadcasted.
	 **/
	public static void informReceiverUpdating(Context context) {
		startServiceIfNotRunning(context);
		updateWidget(context);
		Intent intent = new Intent(ACTION_ITEM_UPDATE);
		context.sendBroadcast(intent);
	}

	/**
	 * Stores the specified id as an ToDo item id in the result intent of the
	 * specified {@link EditActivity}. This intent as well as the result code
	 * {@link IntentManager#RESULT_OK} will be given to the method
	 * {@link Activity#onActivityResult(int, int, Intent)} of the activity which
	 * started the specified activity as soon as the activity will be finished.
	 * This indicates that the edited item should be stored.
	 * 
	 * @param activity
	 *            The activity for which the result intent should be updated
	 *            with the other specified information.
	 * @param id
	 *            The id of the ToDo item which was edited.
	 **/
	public static void saveEditing(EditActivity activity, int id) {
		endEditing(activity, id, RESULT_OK);
	}

	/**
	 * Stores the specified coordinates of the remind location for the ToDo item
	 * with the specified id in the result intent of the specified
	 * {@link LocationPicker}. This intent including the specified values as
	 * well as the result code {@link Activity#RESULT_OK} will be given to the
	 * method {@link Activity#onActivityResult(int, int, Intent)} of the
	 * activity which started the LocationPicker as soon as the LocationPicker
	 * will be finished.
	 * 
	 * @param activity
	 *            The LocationPicker for which the result intent should be
	 *            stored.
	 * @param id
	 *            The id of the ToDo item for which the remind location was
	 *            changed.
	 * @param latitude
	 *            The latitude value of the chosen remind location.
	 * @param longitude
	 *            The longitude value of the chosen remind location.
	 **/
	public static void saveLocationSelection(LocationPicker activity, int id,
			double latitude, double longitude) {
		Intent intent = new Intent();
		intent.putExtra(ToDoItem.ID, id);
		intent.putExtra(ToDoItem.LOCATION_LATITUDE, latitude);
		intent.putExtra(ToDoItem.LOCATION_LONGITUDE, longitude);
		activity.setResult(RESULT_OK, intent);
	}

	/**
	 * Starts for the specified {@link MainActivity} the {@link EditActivity}
	 * for the ToDo item with the specified id. The method
	 * {@link MainActivity#onActivityResult(int, int, Intent)} will be invoked
	 * after finishing the EditActivity with the request code
	 * {@link IntentManager#REQUEST_UPDATE_ITEM}, if the specified id was
	 * greater than {@literal -1}, otherwise the request code will be
	 * {@link IntentManager#REQUEST_NEW_ITEM}.
	 * 
	 * @param activity
	 *            The MainActivity for which the EditActivity should be started.
	 * @param id
	 *            The id of the ToDo item which should be editable in the
	 *            EditActivity. For editing a new ToDo item the id has to be
	 *            {@literal -1}.
	 **/
	public static void startEditingItem(MainActivity activity, int id) {
		Intent intent = new Intent(activity, EditActivity.class);
		if (id > -1) {
			intent.putExtra(KEY_REQUEST_CODE, REQUEST_UPDATE_ITEM);
			intent.putExtra(ToDoItem.ID, id);
			activity.startActivityForResult(intent, REQUEST_UPDATE_ITEM);
		} else {
			intent.putExtra(KEY_REQUEST_CODE, REQUEST_NEW_ITEM);
			activity.startActivityForResult(intent, REQUEST_NEW_ITEM);
		}
	}

	/**
	 * Starts for the specified {@link MainActivity} the {@link EditActivity}
	 * for creating a new ToDo item. The method
	 * {@link MainActivity#onActivityResult(int, int, Intent)} will be invoked
	 * after finishing the EditActivity with the request code
	 * {@link IntentManager#REQUEST_NEW_ITEM}.
	 * 
	 * @param activity
	 *            The MainActivity for which the EditActivity should be started.
	 **/
	public static void startEditingNewItem(MainActivity activity) {
		startEditingItem(activity, -1);
	}

	/**
	 * Starts for the specified {@link EditActivity} the {@link LocationPicker}
	 * for the ToDo item with the specified id. Also the current coordinates
	 * will be send via the intent to the LocationPicker. The method
	 * {@link EditActivity#onActivityResult(int, int, Intent)} will be invoked
	 * after finishing the LocationPicker with the request code
	 * {@link IntentManager#REQUEST_SET_LOCATION}.
	 * 
	 * @param activity
	 *            The EditActivity for which the LocationPicker should be
	 *            started.
	 * @param id
	 *            The id of the ToDo item for which the remind location should
	 *            be updated.
	 * @param latitude
	 *            The current latitude value of the remind location.
	 * @param longitude
	 *            The current longitude value of the remind location.
	 **/
	public static void startPickingLocation(EditActivity activity, int id,
			double latitude, double longitude) {
		Intent intent = new Intent(activity, LocationPicker.class);
		intent.putExtra(ToDoItem.ID, id);
		intent.putExtra(ToDoItem.LOCATION_LATITUDE, latitude);
		intent.putExtra(ToDoItem.LOCATION_LONGITUDE, longitude);
		activity.startActivityForResult(intent, REQUEST_SET_LOCATION);
	}

	/**
	 * Generates an Intent which indicates that the picking of a location via
	 * the {@link AddressPicker} was successful. This intent will be broadcasted
	 * including the information of the picker type (
	 * {@link IntentManager#KEY_PICKER_TYPE}), whether the picking was valid and
	 * if it was valid also the formatted address.
	 * 
	 * @param context
	 *            The Context in which the Intent should be broadcasted.
	 * @param formattedAddress
	 *            String which contains the formatted address of the chosen
	 *            location.
	 * @param error
	 *            Flag that indicates whether the chosen location is valid.
	 **/
	public static void submitAddressFromAdressPicker(Context context,
			String formattedAddress, boolean error) {
		submitAddressFromPicker(context, formattedAddress, error,
				AddressPicker.ADDRESS_FRAGMENT_TAG);
	}

	/**
	 * Generates an Intent which indicates that the picking of a location via
	 * the {@link ContactPicker} was successful. This intent will be broadcasted
	 * including the information of the picker type (
	 * {@link IntentManager#KEY_PICKER_TYPE}), whether the picking was valid and
	 * if it was valid also the formatted address.
	 * 
	 * @param context
	 *            The Context in which the Intent should be broadcasted.
	 * @param formattedAddress
	 *            String which contains the formatted address of the chosen
	 *            location.
	 * @param error
	 *            Flag that indicates whether the chosen location is valid.
	 **/
	public static void submitAddressFromContactPicker(Context context,
			String formattedAddress, boolean error) {
		submitAddressFromPicker(context, formattedAddress, error,
				ContactPicker.CONTACT_FRAGMENT_TAG);

	}

	/**
	 * Generates an Intent which indicates that the picking of a location via
	 * the {@link CoordinatesPicker} was successful. This intent will be
	 * broadcasted including the information of the picker type (
	 * {@link IntentManager#KEY_PICKER_TYPE}), whether the picking was valid and
	 * if it was valid also the coordinates.
	 * 
	 * @param context
	 *            The Context in which the Intent should be broadcasted.
	 * @param latitude
	 *            The latitude of the chosen location.
	 * @param longitude
	 *            The longitude of the chosen location.
	 * @param error
	 *            Flag that indicates whether the chosen location is valid.
	 **/
	public static void submitCoodinatesFromCoordinatesPicker(Context context,
			double latitude, double longitude, boolean error) {
		Intent intent = new Intent(ACTION_PICKER_RESULT);
		intent.putExtra(KEY_PICKER_ERROR, error);
		intent.putExtra(KEY_PICKER_TYPE,
				CoordinatesPicker.COORDINATES_FRAGMENT_TAG);
		if (!error) {
			intent.putExtra(ToDoItem.LOCATION_LATITUDE, latitude);
			intent.putExtra(ToDoItem.LOCATION_LONGITUDE, longitude);
		}
		context.sendBroadcast(intent);
	}

	/**
	 * Stores the specified id as an ToDo item id in the result intent of the
	 * specified {@link Activity}. This intent as well as the specified result
	 * code will be given to the method
	 * {@link Activity#onActivityResult(int, int, Intent)} of the activity which
	 * started the specified activity as soon as the activity will be finished.
	 * 
	 * @param activity
	 *            The activity for which the result intent should be updated
	 *            with the other specified information.
	 * @param id
	 *            The id of the ToDo item which was edited.
	 * @param type
	 *            The result code which should be given to the activity that
	 *            invoked the specified activity.
	 **/
	private static void endEditing(Activity activity, int id, int type) {
		Intent intent = new Intent();
		intent.putExtra(ToDoItem.ID, id);
		activity.setResult(type, intent);
	}

	/**
	 * Checks whether the {@link RemindService} is running, if the service is
	 * not running, the method will start the service.
	 * 
	 * @param context
	 *            The Context in which the Service should be started.
	 **/
	private static void startServiceIfNotRunning(Context context) {
		if (!RemindService.IS_RUNNING) {
			Intent intent = new Intent(context, RemindService.class);
			intent.setAction(IntentManager.ACTION_START_SERVICE);
			context.startService(intent);
		}
	}

	/**
	 * Generates an Intent which indicates that the picking of a location via a
	 * picker was successful. This intent will be broadcasted including the
	 * information of the picker type ( {@link IntentManager#KEY_PICKER_TYPE}),
	 * whether the picking was valid and if it was valid also the formatted
	 * address.
	 * 
	 * @param context
	 *            The Context in which the Intent should be broadcasted.
	 * @param formattedAddress
	 *            String which contains the formatted address of the chosen
	 *            location.
	 * @param error
	 *            Flag that indicates whether the chosen location is valid.
	 * @param type
	 *            The type of the picker {@link IntentManager#KEY_PICKER_TYPE},
	 *            means one of the unique identifier of the customized dialog
	 *            fragments ({@link ContactPicker#CONTACT_FRAGMENT_TAG},
	 *            {@link AddressPicker#ADDRESS_FRAGMENT_TAG},
	 *            {@link CoordinatesPicker#COORDINATES_FRAGMENT_TAG}).
	 **/
	private static void submitAddressFromPicker(Context context,
			String formattedAddress, boolean error, String type) {
		Intent intent = new Intent(ACTION_PICKER_RESULT);
		intent.putExtra(KEY_PICKER_ERROR, error);
		intent.putExtra(KEY_PICKER_TYPE, type);
		if (!error) {
			intent.putExtra(ToDoItem.LOCATION_ADDRESS, formattedAddress);
		}
		context.sendBroadcast(intent);
	}

	/**
	 * Broadcasts the intent which triggers the update of the widget (
	 * {@link Widget}). Therefore the broadcasted intent has the action
	 * {@link IntentManager#ACTION_WIDGET_UPDATE}.
	 * 
	 * @param context
	 *            The Context in which the Intent should be broadcasted.
	 **/
	private static void updateWidget(Context context) {
		Intent intent = new Intent(ACTION_WIDGET_UPDATE);
		intent.setClass(context, Widget.class);
		context.sendBroadcast(intent);
	}

	/**
	 * The {@link IntentManager} receive multiple Intents and reacts depending
	 * on the action of the Intent. If it receives the "boot complete" intent,
	 * the service will be started and also the widget will be updated. If it
	 * receives the intent which notifies about to trigger a notification for a
	 * ToDo item, the method will update the widget and also displays the
	 * notification. Also the intents which will change the properties (shift
	 * the deadline and toggle the done status) of a specific ToDo item after a
	 * notification was shown for this item, will be handled by the
	 * {@link IntentManager}.
	 * 
	 * @param context
	 *            The Context in which the receiver is running.
	 * @param intent
	 *            The Intent being received.
	 * @see BroadcastReceiver#onReceive(Context, Intent)
	 **/
	@Override
	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction();
		if (action.equals(Intent.ACTION_BOOT_COMPLETED)) {
			startServiceIfNotRunning(context);
			updateWidget(context);
		} else if (action.equals(ACTION_TIME_NOTIFICATION)) {
			updateWidget(context);
			RemindService.showTimeNotification(context, intent);
		} else if (action.equals(ACTION_ITEM_CHECK)) {
			int id = intent.getIntExtra(ToDoItem.ID, -1);
			if (id > -1) {
				DatabaseAdapter.updateToDoItemWith(id, true, context);
				informReceiverUpdating(context);
				RemindService.cancelNotification(context, id);
			}
		} else if (action.equals(ACTION_ITEM_SNOOZE)) {
			int id = intent.getIntExtra(ToDoItem.ID, -1);
			if (id > -1) {
				DatabaseAdapter.addMinutesToToDoItemWith(id, context
						.getResources().getInteger(R.integer.snooze_time),
						context);
				informReceiverUpdating(context);
				RemindService.cancelNotification(context, id);
			}
		}
	}
}
