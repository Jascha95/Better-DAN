package androidlab.exercise5;

import static com.google.android.gms.maps.GoogleMap.MAP_TYPE_HYBRID;
import static com.google.android.gms.maps.GoogleMap.MAP_TYPE_NORMAL;
import static com.google.android.gms.maps.GoogleMap.MAP_TYPE_SATELLITE;
import static com.google.android.gms.maps.GoogleMap.MAP_TYPE_TERRAIN;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.provider.ContactsContract;
import androidlab.exercise5.adapter.LocationAdapter;
import androidlab.exercise5.model.ToDoItem;
import androidlab.exercise5.sys.IntentManager;
import androidlab.exercise5.sys.Utils;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.GoogleMap.OnMarkerDragListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * <h2>Location Picker</h2>
 * 
 * This {@link FragmentActivity} provides the possibility to select a remind
 * location. For this purpose various kinds can be chosen to select a location:
 * the user can drag and drop the marker on the map, the user can select a
 * location by long pressing on the map, the user can input an address or
 * coordinates via dialogs and the user can also select a contact address.
 * 
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 **/
public class LocationPicker extends FragmentActivity implements
		OnMapLongClickListener, OnMarkerClickListener, OnMarkerDragListener,
		OnItemSelectedListener, OnMapReadyCallback {

	/**
	 * BroadcastReceiver which receives the resulting intents from the picker
	 * dialogs. Depending on the picker, the onReceive method will process this
	 * intent.
	 **/
	private class LocationFragmentResultReceiver extends BroadcastReceiver {

		/**
		 * Receives the result of the picker dialogs and depending on the picker
		 * the method will process the result, if there was no error during the
		 * input, otherwise a error messages will be shown. If the result is an
		 * address String, the address will be converted via an
		 * {@link UpdateLocation} ASyncTask.
		 * 
		 * @param context
		 *            The Context in which the receiver is running.
		 * @param intent
		 *            The Intent being received.
		 * @see BroadcastReceiver#onReceive(Context, Intent)
		 **/
		@Override
		public void onReceive(Context context, Intent intent) {
			boolean err = intent.getBooleanExtra(
					IntentManager.KEY_PICKER_ERROR, true);
			if (intent.hasExtra(IntentManager.KEY_PICKER_TYPE)) {
				String type = intent
						.getStringExtra(IntentManager.KEY_PICKER_TYPE);
				if (type.equals(AddressPicker.ADDRESS_FRAGMENT_TAG)
						|| type.equals(ContactPicker.CONTACT_FRAGMENT_TAG)) {
					if (!err) {
						String address = intent
								.getStringExtra(ToDoItem.LOCATION_ADDRESS);
						new UpdateLocation().execute(address);
					} else {
						displayError(getString(R.string.error_geocoder_address));
					}
				} else if (type
						.equals(CoordinatesPicker.COORDINATES_FRAGMENT_TAG)) {
					LatLng temp = null;
					if (!err) {
						double lat = intent.getDoubleExtra(
								ToDoItem.LOCATION_LATITUDE, MAX_VALUE);
						double lng = intent.getDoubleExtra(
								ToDoItem.LOCATION_LONGITUDE, MAX_VALUE);
						err = err || lat == MAX_VALUE || lng == MAX_VALUE;
						temp = new LatLng(lat, lng);
					}
					if (!err) {
						hideError();
						storedCoordinates = temp;
						setupMarker();
						moveCamera(false);
						Utils.showToast(context,
								getString(R.string.location_new));
					} else {
						displayError(getString(R.string.error_geocoder_coordinates));
					}
				}
			}
		}
	}

	/**
	 * {@link AsyncTask} which tries to convert an address String into
	 * coordinates and if the conversion was successful it adds for these
	 * calculated coordinates a marker to the map and stores the location as
	 * remind location.
	 **/
	private class UpdateLocation extends AsyncTask<String, Void, LatLng> {

		/** List of all fetched coordinates. */
		private ArrayList<LatLng> data = new ArrayList<LatLng>();

		/**
		 * Tries to fetch via the {@link LocationAdapter} the coordinates of the
		 * given address Strings and returns if some coordinates were calculated
		 * the first one, otherwise the method will return {@code null}.
		 * 
		 * @param addresses
		 *            The address String for which the coordinates should be
		 *            calculated.
		 * @see android.os.AsyncTask#doInBackground(String[])
		 */
		@Override
		protected LatLng doInBackground(String... addresses) {
			LocationAdapter locationAdapter = new LocationAdapter(
					LocationPicker.this);
			for (String address : addresses) {
				data.add(locationAdapter
						.getCoordinatesFromAddressString(address));
				if (isCancelled())
					break;
			}
			for (LatLng coordinates : data) {
				if (coordinates != null)
					return coordinates;
			}
			return null;
		}

		/**
		 * After the execution of the task, the ProgressBar will be hidden and
		 * if valid coordinates were fetched, those were stored as the remind
		 * location, a marker will be set a this location and the focus will
		 * center the location, otherwise an error message will be displayed.
		 * 
		 * @param coordinates
		 * @see AsyncTask#onPostExecute(LatLng)
		 */
		@Override
		protected void onPostExecute(LatLng coordinates) {
			progress.setVisibility(View.GONE);
			if (coordinates != null) {
				hideError();
				storedCoordinates = coordinates;
				setupMarker();
				moveCamera(true);
				Utils.showToast(LocationPicker.this,
						getString(R.string.location_new));
			} else {
				displayError(getString(R.string.error_geocoder_address));
			}
		}

		/**
		 * Before the task will be executed , the ProgressBar will be shown.
		 * 
		 * @see AsyncTask#onPreExecute()
		 */
		@Override
		protected void onPreExecute() {
			progress.setVisibility(View.VISIBLE);
			super.onPreExecute();
		}

	}

	/**
	 * The max double value which will be used for invalid {@link LatLng}
	 * objects.
	 */
	private static final double MAX_VALUE = Double.MAX_VALUE;

	/** AddressPicker Dialog which provides inputing an address. */
	private AddressPicker addressPicker;
	/** ContactPicker Dialog which provides selecting a contact. */
	private ContactPicker contactPicker;
    private static final int RESULT_PICK_CONTACT = 1001;
	/** CoordinatesPicker Dialog which provides inputing coordinates. */
	private CoordinatesPicker coordinatesPicker;
	/** The IntentFilter for the {@link LocationFragmentResultReceiver}. */
	private IntentFilter filter = IntentManager.getFilterForPickerResults();
	/** Button which opens the dialog for inputing an address. */
	private Button fromAddress;
	/** Button which opens the dialog for selecting a contact. */
	private Button fromContacts;
	/** Button which opens the dialog for inputing coordinates. */
	private Button fromCoordinates;
	/**
	 * The identifier of the ToDo item for which the remind location will be
	 * chosen.
	 */
	private int id;
	/** The BroadcastReceiver which receives the result from the */
	private LocationFragmentResultReceiver locationFragmentReceiver;
	/** The Google map */
	private GoogleMap map;
	/** The TextView which should be shown for displaying error messages. */
	private TextView mapError;
	/** The ProgressBar which should be shown during calculations happen. */
	private ProgressBar progress;
	/** The current chosen remind location. */
	private LatLng storedCoordinates;

	/**
	 * Called if the back button is pressed. Stores the current coordinates of
	 * the remind location for the ToDo item with the id in the result intent of
	 * this activity and finishes the {@link LocationPicker}.
	 * 
	 * @see FragmentActivity#onBackPressed(), IntentManager
	 **/
	@Override
	public void onBackPressed() {
		IntentManager.saveLocationSelection(this, id,
				((storedCoordinates == null) ? MAX_VALUE
						: storedCoordinates.latitude),
				((storedCoordinates == null) ? MAX_VALUE
						: storedCoordinates.longitude));
		super.onBackPressed();
	}

	/**
	 * Creates the options menu through the menu resource
	 * {@code R.menu.location_picker_options}.
	 * 
	 * @param menu
	 *            The options menu in which you place your items.
	 * @result Return always {@code true} so that the menu will be displayed.
	 * @see Activity#onCreateOptionsMenu(Menu)
	 **/
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.location_picker_options, menu);
		return true;
	}

	/**
	 * Callback method to be invoked when an item in the spinner for choosing
	 * the map layout has been selected. This callback is invoked only when the
	 * newly selected position is different from the previously selected
	 * position or if there was no selected item. If the map exists the map will
	 * be adjusted, otherwise the method tries to setup the map.
	 * 
	 * @param parent
	 *            The AdapterView where the selection happened
	 * @param view
	 *            The view within the AdapterView that was clicked
	 * @param pos
	 *            The position of the view in the adapter
	 * @param id
	 *            The row id of the item that is selected
	 * @see OnItemSelectedListener#onItemSelected(AdapterView, View, int, long)
	 **/
	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int pos,
			long id) {
		if (map != null) {
			String chosenLayer = parent.getItemAtPosition(pos).toString();
			if (chosenLayer.equals(getString(R.string.normal))) {
				map.setMapType(MAP_TYPE_NORMAL);
			} else if (chosenLayer.equals(getString(R.string.hybrid))) {
				map.setMapType(MAP_TYPE_HYBRID);
			} else if (chosenLayer.equals(getString(R.string.satellite))) {
				map.setMapType(MAP_TYPE_SATELLITE);
			} else if (chosenLayer.equals(getString(R.string.terrain))) {
				map.setMapType(MAP_TYPE_TERRAIN);
			}
		} else {
			setupOfMap();
			displayError(getString(R.string.try_again)
					+ getString(R.string.blank)
					+ getString(R.string.error_google_maps));
		}
	}

	/**
	 * Called when the user makes a long-press gesture on the map, but only if
	 * none of the overlays of the map handled the gesture. This will store the
	 * click location as remind location, will set a marker to the location and
	 * the focus will center to the chosen location.
	 * 
	 * @param coordinates
	 *            The point on the ground (projected from the screen point) that
	 *            was pressed.
	 * @see OnMapLongClickListener#onMapLongClick(LatLng)
	 **/
	@Override
	public void onMapLongClick(LatLng coordinates) {
		storedCoordinates = coordinates;
		setupMarker();
		moveCamera(false);
		Utils.showToast(this, getString(R.string.location_new));
	}

	/**
	 * Called when a marker has been clicked or tapped. Toggles info window of
	 * the marker and returns always {@code false}.
	 * 
	 * @param marker
	 *            The marker that was clicked.
	 * @return Always {@code false}.
	 * @see OnMarkerClickListener#onMarkerClick(Marker)
	 **/
	@Override
	public boolean onMarkerClick(Marker marker) {
		if (marker.isInfoWindowShown()) {
			marker.hideInfoWindow();
		} else {
			marker.showInfoWindow();
		}
		return false;
	}

	/**
	 * Called repeatedly while a marker is being dragged. The position will be
	 * stored as the chosen remind location.
	 * 
	 * @param marker
	 *            The marker being dragged.
	 * 
	 * @see OnMarkerDragListener#onMarkerDrag(Marker)
	 **/
	@Override
	public void onMarkerDrag(Marker marker) {
		storedCoordinates = marker.getPosition();
	}

	/**
	 * Called when a marker has finished being dragged. The position will be
	 * stored as the chosen remind location. Also the focus will center the new
	 * location and a Toast will be shown.
	 * 
	 * @param marker
	 *            The marker that was dragged.
	 * 
	 * @see OnMarkerDragListener#onMarkerDragEnd(Marker)
	 **/
	@Override
	public void onMarkerDragEnd(Marker marker) {
		storedCoordinates = marker.getPosition();
		moveCamera(false);
		Utils.showToast(this, getString(R.string.location_new));
	}

	/**
	 * Called when a marker starts being dragged. The position will be stored as
	 * the chosen remind location.
	 * 
	 * @param marker
	 *            The marker being dragged.
	 * 
	 * @see OnMarkerDragListener#onMarkerDragStart(Marker)
	 **/
	@Override
	public void onMarkerDragStart(Marker marker) {
		storedCoordinates = marker.getPosition();
	}

	/**
	 * Callback method to be invoked when the selection disappears from this
	 * view. The selection can disappear for instance when touch is activated or
	 * when the adapter becomes empty. In this case nothing should be done.
	 * 
	 * @param view
	 *            The AdapterView that now contains no selected item.
	 * @see OnItemSelectedListener#onNothingSelected(AdapterView)
	 **/
	@Override
	public void onNothingSelected(AdapterView<?> view) {
	}

	/**
	 * Handles the selection in the options menu. In this activity two items are
	 * selectable. Firstly to cancel the selection of a remind location and
	 * secondly to save the chosen remind location.
	 * 
	 * @param item
	 *            The menu item that was selected.
	 * @return Return {@code false} to allow normal menu processing to proceed,
	 *         {@code true} to consume it here.
	 * @see Activity#onOptionsItemSelected(MenuItem)
	 **/
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.cancel:
			IntentManager.cancelLocationSelection(this, id);
			super.onBackPressed();
			break;
		case R.id.save:
			this.onBackPressed();
			break;
		}
		return true;
	}

	/**
	 * Sets the visibility of the View which shows the error messages to visible
	 * and fills the TextView with the specified String.
	 * 
	 * @param msg
	 *            Error message which should be shown in the TextView for
	 *            errors.
	 **/
	private void displayError(String msg) {
		mapError.setVisibility(View.VISIBLE);
		mapError.setText(msg);
	}

	/**
	 * Sets the visibility of the View which shows the error messages to
	 * invisible.
	 */
	private void hideError() {
		mapError.setVisibility(View.GONE);
		mapError.setText(getString(R.string.empty));
	}

	/**
	 * Initial setup of the map, i.e. sets all Listeners.
	 **/
	@SuppressLint("MissingPermission")
    private void initialConfiguration() {
		if (map != null) {
			hideError();
            map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
			map.getUiSettings().setCompassEnabled(false);
			map.getUiSettings().setTiltGesturesEnabled(false);
			map.getUiSettings().setRotateGesturesEnabled(false);
			map.setMyLocationEnabled(true);
			map.setOnMarkerDragListener(this);
			map.setOnMarkerClickListener(this);
			map.setOnMapLongClickListener(this);
		} else {
			displayError(getString(R.string.error_google_maps));
		}
	}

	/**
	 * Moves the focus of the map to the current stored remind location if the
	 * map is available, otherwise the method tries to setup the map. Depending
	 * on the specified flag also the camera zooms into the map.
	 * 
	 * @param zoom
	 *            Indicates whether the animation should also zoom into the map.
	 **/
	private void moveCamera(boolean zoom) {
		if (map != null) {
			if (zoom) {
				map.animateCamera(CameraUpdateFactory.newLatLngZoom(
						storedCoordinates, 13.0f));
			} else {
				map.animateCamera(CameraUpdateFactory
						.newLatLng(storedCoordinates));
			}
		} else {
			setupOfMap();
			displayError(getString(R.string.try_again)
					+ getString(R.string.blank)
					+ getString(R.string.error_google_maps));
		}
	}

	/**
	 * Registers the BroadcastReceiver {@link LocationFragmentResultReceiver} if
	 * it is not already registered.
	 **/
	private void registerReceiver() {
		if (locationFragmentReceiver == null) {
			locationFragmentReceiver = new LocationFragmentResultReceiver();
			registerReceiver(locationFragmentReceiver, filter);
		}
	}

	/**
	 * Adds a marker to the map at the stored remind location, if the map is
	 * available, otherwise the method tries to setup the map.
	 **/
	private void setupMarker() {
		if (map != null) {
			map.clear();
			if (storedCoordinates != null)
				map.addMarker(new MarkerOptions().position(storedCoordinates)
						.title(getString(R.string.marker_title))
						.draggable(true));
		} else {
			setupOfMap();
			displayError(getString(R.string.try_again)
					+ getString(R.string.blank)
					+ getString(R.string.error_google_maps));
		}
	}

	/**
	 * Method tries to fetch the reference to the map fragment and starts the
	 * initial setup of the map.
	 */
	private void setupOfMap() {
		if (map == null) {
			SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
					.findFragmentById(R.id.map);
			mapFragment.getMapAsync(this);
		}
	}

	@Override
	public void onMapReady(GoogleMap map) {
		this.map = map;
        if (this.map != null) {
            hideError();
            initialConfiguration();
        } else {
            displayError(getString(R.string.error_google_maps));
        }
		setupMarker();
	}

	/**
	 * Unregisters the BroadcastReceiver {@link LocationFragmentResultReceiver}
	 * if it is not already unregistered.
	 **/
	private void unregisterReceiver() {
		if (locationFragmentReceiver != null) {
			unregisterReceiver(locationFragmentReceiver);
			locationFragmentReceiver = null;
		}
	}

	/**
	 * Registers the BroadcastReceiver if it is not already registered, sets the
	 * OnClickListener for the Buttons, stores the references to the View
	 * elements in the instance variables and creates the Spinner for the map
	 * layout. Also the method tries to extract the latitude and longitude
	 * information from the specified bundle. Finally the map will be adjusted
	 * and if a location was passed through the bundle a marker will be added
	 * and the focus moves to this location.
	 * 
	 * @param savedInstanceState
	 *            {@code null} or the {@link Bundle} contains the data it most
	 *            recently supplied in
	 *            {@link Activity#onSaveInstanceState(Bundle)}.
	 * @see FragmentActivity#onCreate(Bundle), LocationPicker#setupOfMap(),
	 *      LocationPicker#setupMarker(), LocationPicker#moveCamera(boolean)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.location_picker);
		registerReceiver();
		fromCoordinates = (Button) findViewById(R.id.coordinates);
		fromContacts = (Button) findViewById(R.id.contacts);
		fromAddress = (Button) findViewById(R.id.address);
		mapError = (TextView) findViewById(R.id.mapError);
		progress = (ProgressBar) findViewById(R.id.progress);
		mapError.setVisibility(View.GONE);
		coordinatesPicker = new CoordinatesPicker();
		fromCoordinates.setOnClickListener(new OnClickListener() {

			/**
			 * If the user clicks the listened view, the dialog for inputing the
			 * coordinates will be opened.
			 * 
			 * @param v
			 *            The view that was clicked.
			 * @see OnClickListener#onClick(View)
			 **/
			@Override
			public void onClick(View v) {
				coordinatesPicker.show(getFragmentManager(),
						CoordinatesPicker.COORDINATES_FRAGMENT_TAG);
			}
		});
		addressPicker = new AddressPicker();
		fromAddress.setOnClickListener(new OnClickListener() {

			/**
			 * If the user clicks the listened view, the dialog for inputing the
			 * address will be opened.
			 * 
			 * @param v
			 *            The view that was clicked.
			 * @see OnClickListener#onClick(View)
			 **/
			@Override
			public void onClick(View v) {
				addressPicker.show(getFragmentManager(),
						AddressPicker.ADDRESS_FRAGMENT_TAG);

			}
		});
        contactPicker = new ContactPicker();
		fromContacts.setOnClickListener(new OnClickListener() {

			/**
			 * If the user clicks the listened view, the dialog for selecting a
			 * contact will be opened.
			 * 
			 * @param v
			 *            The view that was clicked.
			 * @see OnClickListener#onClick(View)
			 **/
			@Override
			public void onClick(View v) {
				pickContact(v);
			}
		});
		Spinner spinner = (Spinner) findViewById(R.id.layer);
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
				this, R.array.layers, R.layout.location_picker_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner.setAdapter(adapter);
		spinner.setOnItemSelectedListener(this);
		try {
			Intent intent = getIntent();
			id = intent.getIntExtra(ToDoItem.ID, -1);
			double tempLat = intent.getDoubleExtra(ToDoItem.LOCATION_LATITUDE,
					MAX_VALUE);
			double tempLng = intent.getDoubleExtra(ToDoItem.LOCATION_LONGITUDE,
					MAX_VALUE);
			if (tempLat != MAX_VALUE && tempLng != MAX_VALUE) {
				storedCoordinates = new LatLng(tempLat, tempLng);
				setupOfMap();
				moveCamera(true);
			} else {
				storedCoordinates = null;
				setupOfMap();
			}
		} catch (Exception e) {
			storedCoordinates = null;
			setupOfMap();
		}
	}

	/**
	 * Unregisters additionally the BroadcastReceiver if it is not already
	 * unregistered by calling {@link LocationPicker#unregisterReceiver()}.
	 * 
	 * @see FragmentActivity#onDestroy(), LocationPicker#unregisterReceiver()
	 **/
	@Override
	protected void onDestroy() {
		unregisterReceiver();
		super.onDestroy();
	}

    /**
     * Creating the intent to look for contacts with an address in the phone's contacts.
     **/
    public void pickContact(View v) {
        Intent contactPickerIntent = new Intent(Intent.ACTION_PICK,
                ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_URI);
        startActivityForResult(contactPickerIntent, RESULT_PICK_CONTACT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case RESULT_PICK_CONTACT:
                    Cursor cursor = null;
                    try {
                        String contactAddress;
                        String contactName;
                        Uri uri = data.getData();
                        cursor = getContentResolver().query(uri, null, null, null, null);
                        cursor.moveToFirst();
                        // column index of the phone number
                        int addressIndex = cursor.getColumnIndex(
                                ContactsContract.CommonDataKinds.StructuredPostal.FORMATTED_ADDRESS);
                        // column index of the contact name
                        int nameIndex = cursor.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                        contactAddress = cursor.getString(addressIndex);
                        contactName = cursor.getString(nameIndex);
                        cursor.close();
                        contactPicker.transfer(contactName, contactAddress);
                        contactPicker.show(getFragmentManager(),
                                ContactPicker.CONTACT_FRAGMENT_TAG);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    }

	/**
	 * Unregisters additionally the BroadcastReceiver if it is not already
	 * unregistered by calling {@link LocationPicker#unregisterReceiver()}.
	 * 
	 * @see FragmentActivity#onPause(), LocationPicker#unregisterReceiver()
	 **/
	@Override
	protected void onPause() {
		unregisterReceiver();
		super.onPause();
	}

	/**
	 * Registers additionally the BroadcastReceiver if it is not already
	 * registered by calling {@link LocationPicker#registerReceiver()}.
	 * 
	 * @see FragmentActivity#onResume(), LocationPicker#registerReceiver()
	 **/
	@Override
	protected void onResume() {
		registerReceiver();
		super.onResume();
	}

	/**
	 * Registers additionally the BroadcastReceiver if it is not already
	 * registered by calling {@link LocationPicker#registerReceiver()}.
	 * 
	 * @see FragmentActivity#onStart(), LocationPicker#registerReceiver()
	 **/
	@Override
	protected void onStart() {
		registerReceiver();
		super.onStart();
	}

	/**
	 * Unregisters additionally the BroadcastReceiver if it is not already
	 * unregistered by calling {@link LocationPicker#unregisterReceiver()}.
	 * 
	 * @see FragmentActivity#onStop(), LocationPicker#unregisterReceiver()
	 **/
	@Override
	protected void onStop() {
		unregisterReceiver();
		super.onStop();
	}

}
