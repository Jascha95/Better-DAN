package androidlab.exercise5;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

import samples.Samples;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.view.*;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnClickListener;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.*;
import androidlab.exercise5.model.ToDoItem;
import androidlab.exercise5.MainActivity.ListViewAdapter.ToDoItemViewHolder;
import androidlab.exercise5.adapter.DatabaseAdapter;
import androidlab.exercise5.sys.IntentManager;
import androidlab.exercise5.sys.Utils;

/**
 * <b>This application is design for the API level >= 17.</b>
 * <hr>
 * <h1>Example solution - ToDo list manager (exercise 4)</h1>
 * <h2>Main activity</h2>
 * This activity provides the main view of the ToDo list manager. Therefore it
 * contains a list view {@link MainActivity#listView} which shows all the ToDo
 * items. To customize the list view itself there exists an inner class
 * {@link ListViewAdapter}. This class extends from the {@link ArrayAdapter} and
 * handles the behavior and also the items of the list view. The storage of the
 * ToDo items is implemented by a SQLite database. The access to this database
 * is done through a separated class {@link DatabaseAdapter} which provides for
 * each purpose a static method. This is so because there a several process
 * which try to interact with the database at the same time. The add new items
 * this activity also provides a button {@link MainActivity#addButton} that will
 * allows by clicking it to insert the data of a new item.
 * 
 * <hr>
 * 
 * As said the activity contains a list view that shows all available ToDo
 * items. On the top of the screen the user has the possibility to add a new
 * item through a simple button. For editing or deleting of items the user can
 * either choose these actions in the context menu by long pressing on an item
 * or also by clicking the corresponding button on each item view. Beyond the
 * user can directly check or uncheck an item as done and he can delete all or
 * all 'done' items by selecting this action in the options menu.
 * 
 * @see {@link ListViewAdapter}, {@link DatabaseAdapter}, {@link EditActivity}
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 **/
public class MainActivity extends Activity {

		/**
	 * The {@link ListViewAdapter} extends from the {@link ArrayAdapter} and
	 * also implements the {@link View.OnCreateContextMenuListener} interface so that
	 * this class handles the usage of a ListView which shows a customized view
	 * of a complex data structure. The adapter uses for each single ToDo item
	 * view a ViewHolder (see {@link ToDoItemViewHolder}), because this
	 * ViewHolder is an efficient way to save resources.
	 **/
	public static class ListViewAdapter extends ArrayAdapter<ToDoItem>
			implements View.OnCreateContextMenuListener {

		/**
		 * The {@link ToDoItemViewHolder} provides for every element in the
		 * layout {@code res/layout/list_view_item.xml} an instance variable as
		 * well as an instance variable for the identifier of a ToDo item. Once
		 * the layout for a specific item is inflated, the tag of this view will
		 * be set to such an ViewHolder so that the layout do not have to be
		 * inflated for this item a second time, because the references to the
		 * view elements are given by the ViewHolder.
		 */
		public class ToDoItemViewHolder {
			/**
			 * The background LinearLayout of a single ToDo item in the
			 * ListView.
			 */
			LinearLayout background;
			/** The delete Button of a single ToDo item in the ListView. */
			Button delete;
			/** The done CheckBox of a single ToDo item in the ListView. */
			CheckBox done;
			/** The edit Button of a single ToDo item in the ListView. */
			Button edit;
			/** The identifier of a single ToDo item in the ListView. */
			int identifier;
			/**
			 * The location remind information TextView of a single ToDo item in
			 * the ListView.
			 */
			TextView location;
			/**
			 * The location remind status ImageView of a single ToDo item in the
			 * ListView.
			 */
			ImageView locationStat;
			/**
			 * The time remind information TextView of a single ToDo item in the
			 * ListView.
			 */
			TextView time;
			/**
			 * The time remind status ImageView of a single ToDo item in the
			 * ListView.
			 */
			ImageView timeStat;
			/** The title TextView of a single ToDo item in the ListView. */
			TextView title;
		}

		/** The id of the used layout for a single ToDo item. */
		private int viewResourceId;

		/**
		 * Constructor of the customized ArrayAdapter which allows displaying
		 * ToDo items in a ListView.
		 *
		 * @param context
		 *            The current context.
		 * @param viewResourceId
		 *            The resource ID for a layout file containing TextViews to
		 *            use when instantiating views.
		 * @param objects
		 *            The ToDo item objects to represent in the ListView.
		 */
		public ListViewAdapter(Context context, int viewResourceId,
							   List<ToDoItem> objects) {
			super(context, viewResourceId, objects);
			this.viewResourceId = viewResourceId;

		}

		/**
		 * Get a View that displays the single ToDo item at the specified
		 * position in the data set {@link ListViewAdapter#getItem(int)}. If the
		 * view is requested for the first time, then the layout
		 * {@code res/layout/list_view_item.xml} will be inflated and also a
		 * ViewHolder will be created where all elements of the inflated layout
		 * will be added to the ViewHolder. This ViewHolder will be set to the
		 * view as a tag, so that in further request the method does not need to
		 * inflate the layout. Also by the tag of the view, an other method can
		 * directly access the identifier of the ToDo item which is displayed by
		 * this view, especially the context menu knows for which ToDo item this
		 * is the context menu. All the fields of this layout are filled with
		 * corresponding data and the background is colored depending firstly by
		 * the done status and secondly by the remind date (grey if the ToDo
		 * item is done, red if the remind date is in the past, otherwise
		 * white). Anonymous {@link View.OnClickListener}s are set to the CheckBoxes
		 * which indicate the done status and also to the buttons for deleting
		 * and editing the ToDo item. All those {@link View.OnClickListener} will
		 * call the associated method in the {@link MainActivity}.
		 *
		 * @param position
		 *            The position of the ToDo item within the adapter's data
		 *            set of the item whose view should display.
		 * @param convertView
		 *            The old view to reuse, if possible.
		 * @param parent
		 *            The parent that this view will eventually be attached to.
		 *
		 * @return A View corresponding to the ToDo item at the specified
		 *         position in the data source {@link ListViewAdapter#data}.
		 *
		 * @see {@link Adapter#getView(int, View, ViewGroup)}, {@link ToDoItem},
		 *      {@link ListViewAdapter#data}
		 **/
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ToDoItemViewHolder holder = null;

			final ToDoItem todo = getItem(position);
			if (convertView == null) {
				LayoutInflater inflater = (LayoutInflater) getContext()
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = inflater.inflate(viewResourceId, parent, false);
				holder = new ToDoItemViewHolder();
				holder.background = (LinearLayout) convertView
						.findViewById(R.id.list_view_item);
				holder.done = (CheckBox) convertView
						.findViewById(R.id.item_checked);
				holder.timeStat = (ImageView) convertView
						.findViewById(R.id.time_alert_status);
				holder.locationStat = (ImageView) convertView
						.findViewById(R.id.location_alert_status);
				holder.title = (TextView) convertView
						.findViewById(R.id.item_title);
				holder.time = (TextView) convertView
						.findViewById(R.id.item_datetime);
				holder.location = (TextView) convertView
						.findViewById(R.id.item_location);
				holder.delete = (Button) convertView
						.findViewById(R.id.item_delete);
				holder.edit = (Button) convertView.findViewById(R.id.item_edit);
				convertView.setTag(holder);
			} else {
				holder = (ToDoItemViewHolder) convertView.getTag();
			}
			holder.background.setBackgroundResource(todo
					.getBgColorResourceId(getContext()));
			holder.timeStat.setImageResource(todo.getTimeAlertResourceId());
			holder.locationStat.setImageResource(todo
					.getLocationAlertResourceId());
			holder.done.setChecked(todo.isDone());
			holder.done.setOnClickListener(new View.OnClickListener() {

				/**
				 * If the user clicks the listened view and the context is a
				 * instance of {@link MainActivity}, then the done status of
				 * this ToDo item will be set to the value of the clicked
				 * checkbox by calling the method
				 * {@link MainActivity#checkToDoItemWith(int, boolean)}.
				 *
				 * @param v
				 *            The view that was clicked.
				 * @see View.OnClickListener#onClick(View)
				 */
				@Override
				public void onClick(View v) {
					int toCheckId = todo.getId();
					CheckBox checkbox = (CheckBox) v;
					if (getContext() instanceof MainActivity)
						((MainActivity) getContext()).checkToDoItemWith(
								toCheckId, checkbox.isChecked());
				}
			});
			holder.title.setText(todo.getTitle());
            if (todo.isDone()) {
                holder.time.setTextColor(ContextCompat.getColor(getContext(), R.color.grey));
            } else if (!todo.isAfterNow(getContext()) && !todo.isDone() && todo.shouldTimeRemind()) {
                holder.time.setTextColor(ContextCompat.getColor(getContext(), R.color.softred));
            } else {
                holder.time.setTextColor(ContextCompat.getColor(getContext(), R.color.grey));
            }
			if (todo.shouldTimeRemind()) {
				holder.time.setVisibility(View.VISIBLE);
				DateFormat timeFormatter = DateFormat.getTimeInstance(
						DateFormat.SHORT, getContext().getResources()
								.getConfiguration().locale);
				DateFormat dateFormatter = DateFormat.getDateInstance(
						DateFormat.FULL, getContext().getResources()
								.getConfiguration().locale);
				holder.time.setText(getContext().getString(
						R.string.time_reminder_information,
						dateFormatter.format(todo.getDate().getTime()),
						timeFormatter.format(todo.getDate().getTime())));
			} else {
				holder.time.setVisibility(View.GONE);
			}
			if (todo.shouldLocationRemind()) {
				holder.location.setVisibility(View.VISIBLE);
				holder.location.setText(Utils.createLocationString(
						todo.getLatitude(), todo.getLongitude(), getContext()));
			} else {
				holder.location.setVisibility(View.GONE);
			}
			holder.delete.setOnClickListener(new View.OnClickListener() {

				/**
				 * If the user clicks the listened view and the context is a
				 * instance of {@link MainActivity}, then this ToDo item will be
				 * in the database by calling the method
				 * {@link MainActivity#deleteToDoItemWith(int)}.
				 *
				 * @param v
				 *            The view that was clicked.
				 * @see View.OnClickListener#onClick(View)
				 */
				@Override
				public void onClick(View v) {
					int toDelId = todo.getId();
					if (getContext() instanceof MainActivity)
						((MainActivity) getContext())
								.deleteToDoItemWith(toDelId);
				}
			});
			holder.edit.setOnClickListener(new View.OnClickListener() {

				/**
				 * If the user clicks the listened view and the context is a
				 * instance of {@link MainActivity}, then the activity for
				 * editing a ToDo item will be started for this ToDo item by
				 * calling {@link MainActivity#editToDoItemWith(int)}.
				 *
				 * @param v
				 *            The view that was clicked.
				 * @see View.OnClickListener#onClick(View)
				 */
				@Override
				public void onClick(View v) {
					int toEditId = todo.getId();
					if (getContext() instanceof MainActivity)
						((MainActivity) getContext())
								.editToDoItemWith(toEditId);
				}
			});
			holder.identifier = todo.getId();
			convertView.setOnCreateContextMenuListener(this);
			return convertView;
		}

		/**
		 * Nothing should happen when a context menu should created in the list
		 * view. This will be done by the {@link MainActivity}. That is
		 * implemented in this way because it is a workaround so that it is
		 * possible to open a context menu for each item of a customized list
		 * view.
		 *
		 * @param menu
		 *            The context menu that is being built
		 * @param v
		 *            The view for which the context menu is being built
		 * @param menuInfo
		 *            Extra information about the item for which the context
		 *            menu should be shown. This information will vary depending
		 *            on the class of v.
		 *
		 * @see {@link View.OnCreateContextMenuListener#onCreateContextMenu(ContextMenu, View, ContextMenu.ContextMenuInfo)}
		 **/
		@Override
		public void onCreateContextMenu(ContextMenu menu, View view,
										ContextMenu.ContextMenuInfo menuInfo) {
			// Do nothing, because ContextMenu will be created by the
			// MainActivity.
		}
	}

	/** Button for adding new items */
	private Button addButton;
	/**
	 * ListView which is contained by this activity and which should be handled
	 * by the {@link MainActivity#listViewAdapter}.
	 */
	private ListView listView;
	/**
	 * Adapter of the list view which handles the behavior of the view and
	 * customizes the list view and its items.
	 */
	private ListViewAdapter listViewAdapter;

	/**
	 * Handles the returning from the edit activity {@link EditActivity}. For
	 * every combination of each possible request
	 * {@link MainActivity#REQUEST_CODE} (where the values can be
	 * {@link MainActivity#ITEM_NEW} and {@link MainActivity#ITEM_UPDATE}) as
	 * well as for each possible result (where the be
	 * {@link Activity#RESULT_CANCELED}, {@link Activity#RESULT_OK} and
	 * {@link MainActivity#RESULT_DELETE}) the method shows a toast message with
	 * the information what happens. If an existing item was deleted or updated,
	 * or if a new item was created than the remind service
	 * {@link IntentManager} will be informed about the changes.
	 * 
	 * @param requestCode
	 *            The integer request code originally supplied to
	 *            startActivityForResult(), allowing you to identify who this
	 *            result came from.
	 * @param resultCode
	 *            The integer result code returned by the child activity through
	 *            its setResult().
	 * @param data
	 *            An Intent, which can return result data to the caller (various
	 *            data can be attached to Intent "extras").
	 * 
	 * @see {@link Activity#onActivityResult(int, int, Intent)},
	 *      {@link MainActivity#newToDoItem()},
	 *      {@link MainActivity#editToDoItemWith(int)}, {@link IntentManager}
	 **/
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		int id = data.getIntExtra(ToDoItem.ID, -1);
		if (requestCode == IntentManager.REQUEST_NEW_ITEM
				&& resultCode == IntentManager.RESULT_OK) {
			Utils.showToast(this, getString(R.string.new_created));
			if (id != -1) {
				IntentManager.informReceiverUpdating(this);
			}
		} else if (requestCode == IntentManager.REQUEST_NEW_ITEM
				&& resultCode == IntentManager.RESULT_CANCELED) {
			Utils.showToast(this, getString(R.string.new_canceled));
		} else if (requestCode == IntentManager.REQUEST_NEW_ITEM
				&& resultCode == IntentManager.RESULT_DELETE) {
			Utils.showToast(this, getString(R.string.new_canceled));
		} else if (requestCode == IntentManager.REQUEST_UPDATE_ITEM
				&& resultCode == IntentManager.RESULT_OK) {
			Utils.showToast(this, getString(R.string.update_saved));
			if (id != -1) {
				IntentManager.informReceiverUpdating(this);
			}
		} else if (requestCode == IntentManager.REQUEST_UPDATE_ITEM
				&& resultCode == IntentManager.RESULT_CANCELED) {
			Utils.showToast(this, getString(R.string.update_canceled));
		} else if (requestCode == IntentManager.REQUEST_UPDATE_ITEM
				&& resultCode == IntentManager.RESULT_DELETE) {
			Utils.showToast(this, getString(R.string.update_deleted));
			if (id != -1) {
				IntentManager.informReceiverUpdating(this);
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	/**
	 * Set the instance variables, adds an OnClickListener to the
	 * {@link MainActivity#addButton} that calls the method
	 * {@link MainActivity#newToDoItem()} and also add the items which are
	 * stored in the database to the list view (includes the creation of the
	 * {@link MainActivity#listViewAdapter}). For the latter the method
	 * {@link MainActivity#updateListViewDatabase()} is invoked. Finally the
	 * context menu will be enable for the list items.
	 * 
	 * @param savedInstanceState
	 *            {@code null} or the {@link Bundle} contains the data it most
	 *            recently supplied in
	 *            {@link Activity#onSaveInstanceState(Bundle)}.
	 * 
	 * @see {@link Activity#onCreate(Bundle)}, {@link ListViewAdapter}
	 **/
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_activity);
		addButton = (Button) findViewById(R.id.add_item);
		addButton.setOnClickListener(new OnClickListener() {

			/**
			 * If the user clicks the listened view, the activity for editing a
			 * new ToDo item will be started by calling the method
			 * {@link MainActivity#newToDoItem()}.
			 * 
			 * @param v
			 *            The view that was clicked.
			 * @see OnClickListener#onClick(View)
			 */
			@Override
			public void onClick(View v) {
				newToDoItem();
			}
		});
		listView = (ListView) findViewById(R.id.list_todos);
		updateListViewDatabase();
		registerForContextMenu(listView);
	}

	/**
	 * Updates the list view when the activity was restarted (calls
	 * {@link MainActivity#updateListViewDatabase()}).
	 * 
	 * @see {@link Activity#onRestart()}, {@link ListViewAdapter}
	 **/
	@Override
	protected void onRestart() {
		updateListViewDatabase();
		super.onRestart();
	}

	/**
	 * Updates the list view when the activity was resumed (calls
	 * {@link MainActivity#updateListViewDatabase()}).
	 * 
	 * @see {@link Activity#onResume()}, {@link ListViewAdapter}
	 **/
	@Override
	protected void onResume() {
		updateListViewDatabase();
		super.onResume();
	}

	/**
	 * If the developer mode is activated (see
	 * {@code res/values/app_settings.xml}) the method will insert random sample
	 * data in the database {@link DatabaseAdapter#insertTestdata(Context)} and
	 * also refresh the list view, so that the new items will be shown. Finally
	 * the remind service {@link IntentManager} will be informed about the
	 * change via.
	 * 
	 * @see {@link DatabaseAdapter}, {@link Samples}, {@link RemindService}
	 **/
	private void insertTestData() {
		if (getResources().getBoolean(R.bool.dev_mode)) {
			DatabaseAdapter.insertTestdata(this);
			IntentManager.informReceiverUpdating(this);
			updateListViewDatabase();
		}
	}

	/**
	 * Will update the done status of the ToDo item in the database which has
	 * the given identifier. Therefore it calls the method
	 * {@link DatabaseAdapter#updateToDoItemWith(int, boolean, Context)},
	 * refreshes the list view and informs the {@link IntentManager} that
	 * changes happened.
	 * 
	 * @param id
	 *            The identifier of the ToDo item for which the done status
	 *            should be changed.
	 * @param checkStatus
	 *            Boolean value to which the done status of the ToDo item should
	 *            be changed.
	 * 
	 * @see {@link DatabaseAdapter}, {@link IntentManager}
	 **/
	public void checkToDoItemWith(int id, boolean checkStatus) {
		DatabaseAdapter.updateToDoItemWith(id, checkStatus, this);
		IntentManager.informReceiverUpdating(this);
		updateListViewDatabase();
	}

	/**
	 * Will delete all 'done' ToDo items from the database. Therefore it calls
	 * the method {@link DatabaseAdapter#deleteAllDoneToDoItems(Context)},
	 * refreshes the list view and informs the {@link IntentManager} that
	 * changes happened.
	 * 
	 * @see {@link DatabaseAdapter}, {@link IntentManager}
	 */
	public void deleteAllDoneToDoItems() {
		DatabaseAdapter.deleteAllDoneToDoItems(this);
		IntentManager.informReceiverUpdating(this);
		updateListViewDatabase();
	}

	/**
	 * Will delete all the ToDo items from the database. Therefore it calls the
	 * method {@link DatabaseAdapter#deleteAllToDoItems(Context)}, refreshes the
	 * list view and informs the {@link IntentManager} that all items were
	 * deleted.
	 * 
	 * @see {@link DatabaseAdapter}, {@link IntentManager}
	 **/
	public void deleteAllToDoItems() {
		DatabaseAdapter.deleteAllToDoItems(this);
		IntentManager.informReceiverDeletion(this);
		updateListViewDatabase();
	}

	/**
	 * Will delete the ToDo item from the database which has the given
	 * identifier. Therefore it calls the method
	 * {@link DatabaseAdapter#deleteToDoItemWith(int, Context)}, refreshes the
	 * list view and informs the {@link IntentManager} that changes happened.
	 * 
	 * @param id
	 *            The identifier of the ToDo item which should be deleted.
	 * 
	 * @see {@link DatabaseAdapter}, {@link IntentManager}
	 **/
	public void deleteToDoItemWith(int id) {
		DatabaseAdapter.deleteToDoItemWith(id, this);
		IntentManager.informReceiverUpdating(this);
		updateListViewDatabase();
	}

	/**
	 * Method will start the activity where an item can be edited (
	 * {@link EditActivity}). In this case the intent which will be passed to
	 * the activity does contain the information that a item should be edited
	 * which exists already. Also the intent contains the specified identifier
	 * of the ToDo item. The goal during the start of the edit activity is that
	 * the result will be passed back to this activity (see
	 * {@link Activity#startActivityForResult(Intent, int)}).
	 * 
	 * @param id
	 *            The identifier of the ToDo item which should be edited.
	 * 
	 * @see {@link EditActivity},
	 *      {@link MainActivity#onActivityResult(int, int, Intent)},
	 *      {@link IntentManager#startEditingItem(MainActivity, int)},
	 **/
	public void editToDoItemWith(int id) {
		IntentManager.startEditingItem(this, id);
	}

	/**
	 * Method will start the activity where an item can be edited (
	 * {@link EditActivity}). In this case the intent which will be passed to
	 * the activity does contain the information that a new item should be
	 * edited. The goal during the start of the edit activity is that the result
	 * will be passed back to this activity (see
	 * {@link Activity#startActivityForResult(Intent, int)}).
	 * 
	 * @see {@link EditActivity},
	 *      {@link IntentManager#startEditingNewItem(MainActivity)},
	 *      {@link MainActivity#onActivityResult(int, int, Intent)}
	 **/
	public void newToDoItem() {
		IntentManager.startEditingNewItem(this);
	}

	/**
	 * Handles the selection in the context menu which is enabled for each item
	 * of the list view {@link MainActivity#listView}. There are two possible
	 * selection in each context menu - firstly the editing of the item (
	 * {@link MainActivity#editToDoItemWith(int)}) and secondly the deletion of
	 * the item ({@link MainActivity#deleteToDoItemWith(int)}). Through the
	 * target view the identifier of the item can be received which is required
	 * for the editing or deletion of an item.
	 * 
	 * @param item
	 *            The context menu item that was selected.
	 * @result Return {@code false} to allow normal menu processing to proceed,
	 *         {@code true} to consume it here.
	 * 
	 * @see {@link Activity#onContextItemSelected(MenuItem)}
	 **/
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.menu_delete:
			AdapterContextMenuInfo menuInfoDel = (AdapterContextMenuInfo) item
					.getMenuInfo();
			int toDelId = ((ListViewAdapter.ToDoItemViewHolder) menuInfoDel.targetView
					.getTag()).identifier;
			this.deleteToDoItemWith(toDelId);
			break;
		case R.id.menu_edit:
			AdapterContextMenuInfo menuInfoEdit = (AdapterContextMenuInfo) item
					.getMenuInfo();
			int toEditId = ((ListViewAdapter.ToDoItemViewHolder) menuInfoEdit.targetView
					.getTag()).identifier;
			this.editToDoItemWith(toEditId);
			break;
		}
		return true;
	}

	/**
	 * Creates the context menu through the menu resource
	 * {@code R.menu.context_main_menu}. Also the method sets the title of the
	 * context menu which contains the title of the corresponding ToDo item.
	 * Therefore the method
	 * {@link DatabaseAdapter#fetchToDoItemWith(int, Context)} will be invoked
	 * to receive this ToDo item which is the context of this menu. The id of
	 * this ToDo item is received via the {@link ToDoItemViewHolder}.
	 * 
	 * @param menu
	 *            The context menu that is being built
	 * @param v
	 *            The view for which the context menu is being built
	 * @param menuInfo
	 *            Extra information about the item for which the context menu
	 *            should be shown. This information will vary depending on the
	 *            class of v.
	 * 
	 * @see {@link Activity#onCreateContextMenu(ContextMenu, View, ContextMenuInfo)}
	 *      , {@link DatabaseAdapter}
	 **/
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main_activity_listview_item_context, menu);
		int id = ((ListViewAdapter.ToDoItemViewHolder) ((AdapterContextMenuInfo) menuInfo).targetView
				.getTag()).identifier;
		ToDoItem todo = DatabaseAdapter.fetchToDoItemWith(id, this);
		String title = String.format("%s '%.8s %s'",
				getResources().getString(R.string.todo_item), todo.getTitle(),
				getResources().getString(R.string.dots));
		menu.setHeaderTitle(title);
	}

	/**
	 * Creates the options menu through the menu resource
	 * {@code R.menu.main_activity}. If the dev mode is not activated the item
	 * for inserting sample data will be removed.
	 * 
	 * @param menu
	 *            The options menu in which you place your items.
	 * @result Return always {@code true} so that the menu will be displayed.
	 * 
	 * @see {@link Activity#onCreateOptionsMenu(Menu)}
	 **/
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main_activity_options, menu);
		if (!getResources().getBoolean(R.bool.dev_mode))
			menu.removeItem(R.id.testdata);
		return true;
	}

	/**
	 * Handles the selection in the options menu. In this activity three items
	 * are selectable if the developer mode is activated (see
	 * {@code res/values/app_settings.xml}) otherwise the user can only select
	 * two items. The deletion of all items (
	 * {@link MainActivity#deleteAllToDoItems()}) and the deletion of all 'done'
	 * ToDo items are in both cases available. If the dev mode is activated also
	 * sample data can be inserted in the database (
	 * {@link MainActivity#insertTestData()}).
	 * 
	 * @param item
	 *            The menu item that was selected.
	 * @return Return {@code false} to allow normal menu processing to proceed,
	 *         {@code true} to consume it here.
	 * 
	 * @see {@link Activity#onOptionsItemSelected(MenuItem)}
	 **/
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.menu_delete_all:
			deleteAllToDoItems();
			break;
		case R.id.menu_delete_all_done:
			deleteAllDoneToDoItems();
			break;
		case R.id.testdata:
			insertTestData();
			break;
		}
		return true;
	}

	/**
	 * Method will fetch all ToDo items from the database by invoking the method
	 * {@link DatabaseAdapter#fetchAllToDoItems(Context)}. These items will be
	 * given to the {@link MainActivity#listViewAdapter}. This will inform all
	 * observers so that all those can refresh there view (see
	 * {@link ListViewAdapter#addAll(Collection)}).
	 * 
	 * @see {@link ListViewAdapter}, {@link DatabaseAdapter}
	 **/
	public void updateListViewDatabase() {
		ArrayList<ToDoItem> list = DatabaseAdapter.fetchAllToDoItems(this);
		if (listViewAdapter == null) {
			listViewAdapter = new ListViewAdapter(this,
					R.layout.main_activity_listview_item, list);
			listView.setAdapter(listViewAdapter);
		} else {
			listViewAdapter.clear();
			listViewAdapter.addAll(list);
		}
	}
}
