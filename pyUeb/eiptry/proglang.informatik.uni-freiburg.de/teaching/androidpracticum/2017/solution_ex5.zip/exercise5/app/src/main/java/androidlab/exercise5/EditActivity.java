package androidlab.exercise5;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import androidlab.exercise5.adapter.DatabaseAdapter;
import androidlab.exercise5.adapter.LocationAdapter;
import androidlab.exercise5.model.ToDoItem;
import androidlab.exercise5.sys.IntentManager;
import androidlab.exercise5.sys.Utils;

import com.google.android.gms.maps.model.LatLng;

/**
 * <h2>Activity which provides the possibility to edit a ToDo item</h2> This
 * activity allows the user to edit a new ToDo item or a ToDo item that already
 * exists. Therefore the layout contains several input elements
 * {@code res/layout/edit_activity.xml} which correspond to the properties of a
 * ToDo item and which are processed by this activity. Thus this class includes
 * the title {@link EditActivity#title}, the description
 * {@link EditActivity#description}, the done status {@link EditActivity#done},
 * the time remind status {@link EditActivity#timeRemind}, the remind date
 * {@link EditActivity#remindCal}, the location remind status
 * {@link EditActivity#locationRemind} and also the remind location
 * {@link EditActivity#remindLocation}. To change the remind date respectively
 * the remind time two {@link Dialog}s are used (
 * {@link EditActivity#datePickerFragment},
 * {@link EditActivity#timePickerFragment}). To receive the choosen date and
 * time the activity implements the {@link OnDateSetListener} and the
 * {@link OnTimeSetListener}. To change the remind location the
 * {@link LocationPicker} activity is used. The chosen location will be received
 * by the method {@link #onActivityResult(int, int, Intent)}. Further there
 * exists also a TextView {@link EditActivity#timeRemindInformation} which shows
 * the information about the time remind status. The same applies to the
 * TextView {@link EditActivity#locationRemindInformation} which shows the
 * information about the location remind status. In order to know which ToDo
 * item is processed also the identifier {@link EditActivity#id} of the item
 * exists (this will be -1 if a new item is processed). The inserted data should
 * be stored if the user presses the back button (
 * {@link EditActivity#onBackPressed()}) into the database through the
 * {@link DatabaseAdapter}. For showing not the coordinates of the remind
 * location, a nested {@link AsyncTask} tries to fetch the address of the
 * location.
 * 
 * @see {@link Activity}, {@link OnCheckListener}, {@link OnCheckListener},
 *      {@link DialogFragment}, {@link Calendar}, {@link OnDateSetListener},
 *      {@link OnTimeSetListener}, {@link DatabaseAdapter}, {@link MainActivity}
 *      , {@link MainActivity#onActivityResult(int, int, Intent)},
 *      {@link LocationPicker}, {@link IntentManager}, {@link AsyncTask}
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 **/
public class EditActivity extends Activity implements
		DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

	/**
	 * Nested class which implements the {@link OnCheckListener} interface. This
	 * will be set to the three CheckBoxes {@link EditActivity#timeRemind},
	 * {@link EditActivity#locationRemind} and {@link EditActivity#done} so that
	 * the activity can react to such changes.
	 **/
	private class OnCheckListener implements OnCheckedChangeListener {

		/**
		 * Called when the status of the CheckBox for which this is a Listener
		 * was changed. To show directly which impact the new setting has, the
		 * input elements are dis- or enabled depending an their value (see
		 * {@link EditActivity#setupDisabilityOfInputElements()}).
		 * 
		 * @see {@link OnCheckedChangeListener#onCheckedChanged(CompoundButton, boolean)}
		 **/
		@Override
		public void onCheckedChanged(CompoundButton buttonView,
				boolean isChecked) {
			setupDisabilityOfInputElements();
		}
	}

	/**
	 * Nested {@link AsyncTask} which will update the shown information of the
	 * location at which the application should remind the user from a
	 * coordinate format into a human readable address String.
	 */
	private class UpdateLocation extends AsyncTask<Void, Void, String> {

		/**
		 * Tries to fetch an Address for the current remind location with the
		 * {@link LocationAdapter}. If such an Address was received a human
		 * readable address String will be returned, otherwise {@code null}.
		 * 
		 * @result {@code null} if no address was fetched, otherwise the human
		 *         readable address String.
		 * @see android.os.AsyncTask#doInBackground(Params[]), LocationAdapter
		 */
		@Override
		protected String doInBackground(Void... nothing) {
			LocationAdapter locationAdapter = new LocationAdapter(
					EditActivity.this);
			Address address = locationAdapter
					.getAddressForCoordinates(remindLocation);
			if (address != null) {
				String addr = "";
				for (int i = 0; i <= address.getMaxAddressLineIndex(); i++) {
					if (i > 0) {
						addr += ", ";
					}
					addr += address.getAddressLine(i);
				}
				return addr;

			} else {
				return null;
			}
		}

		/**
		 * Updates the TextView which shows the remind location information to
		 * the fetched address String, if a valid address was fetched.
		 * 
		 * @param address
		 * @see AsyncTask#onPostExecute(java.lang.Object)
		 */
		protected void onPostExecute(String address) {
			if (address != null) {
				locationRemindInformation.setText(getString(
						R.string.location_reminder_address, address));
			}

		}

	}

	/**
	 * The max double value which will be used for invalid {@link LatLng}
	 * objects.
	 */
	private static final double MAX_VALUE = Double.MAX_VALUE;
	/**
	 * Instance of a {@link DialogFragment} which allows to show a Dialog to set
	 * the date of the remind occurrence.
	 */
	private DialogFragment datePickerFragment = new DialogFragment() {

		/**
		 * Method called when the Dialog should be created. It will set the
		 * showed date of the Dialog to the date when the remind occurrence is.
		 * With these information a new {@link DatePickerDialog} will be created
		 * and showed on the screen.
		 * 
		 * @param savedInstanceState
		 *            The last saved instance state of the Fragment, or null if
		 *            this is a freshly created Fragment.
		 * @result Return a new Dialog instance to be displayed by the Fragment.
		 * 
		 * @see {@link DialogFragment#onCreateDialog(Bundle)}
		 **/
		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			int year = remindCal.get(Calendar.YEAR);
			int month = remindCal.get(Calendar.MONTH);
			int day = remindCal.get(Calendar.DAY_OF_MONTH);
			return new DatePickerDialog(getActivity(), EditActivity.this, year,
					month, day);
		}

	};

	/**
	 * The {@link LinearLayout} which includes the buttons for setting up the
	 * remind date as well as the time remind information (do not include the
	 * {@link CheckBox} which indicates whether the application should remind at
	 * a specific time).
	 */
	private LinearLayout dateSection;
	/**
	 * {@link Button} which will by clicking open the
	 * {@link EditActivity#datePickerFragment}.
	 */
	private Button dateSetup;
	/**
	 * {@link EditText} where the user can input the description of the ToDo
	 * item.
	 */
	private EditText description;
	/**
	 * {@link CheckBox} where the user can state the done status of the ToDo
	 * item.
	 */
	private CheckBox done;
	/**
	 * Identifier of the processed ToDo item (if this is a new ToDo item the
	 * value of this variable is -1).
	 */
	private int id = -1;
	/**
	 * {@link CheckBox} where the user can state the location remind status of
	 * the ToDo item.
	 */
	private CheckBox locationRemind;
	/**
	 * {@link TextView} which shows the information about the remind location of
	 * the ToDo item.
	 */
	private TextView locationRemindInformation;
	/**
	 * The {@link LinearLayout} which includes the button for setting up the
	 * remind location as well as the location remind information (do not
	 * include the {@link CheckBox} which indicates whether the application
	 * should remind at a specific location).
	 */
	private LinearLayout locationSection;
	/**
	 * {@link Button} which will by clicking open the {@link LocationPicker} for
	 * setting up the remind location.
	 */
	private Button locationSetup;
	/**
	 * A {@link Calendar} instance which stores the date and the time when the
	 * application should remind for this ToDo item.
	 */
	private Calendar remindCal;
	/**
	 * The raw location coordinates at which the application should remind the
	 * user.
	 */
	private LatLng remindLocation = null;
	/**
	 * Instance of a {@link DialogFragment} which allows to show a Dialog to set
	 * the time of the remind occurrence.
	 */
	private DialogFragment timePickerFragment = new DialogFragment() {

		/**
		 * Method called when the Dialog should be created. It will set the
		 * showed time of the Dialog to the time when the remind occurrence is.
		 * With these information a new {@link TimePickerDialog} will be created
		 * and showed on the screen.
		 * 
		 * @param savedInstanceState
		 *            The last saved instance state of the Fragment, or null if
		 *            this is a freshly created Fragment.
		 * @result Return a new Dialog instance to be displayed by the Fragment.
		 * 
		 * @see {@link DialogFragment#onCreateDialog(Bundle)}
		 **/
		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			int hour = remindCal.get(Calendar.HOUR_OF_DAY);
			int minute = remindCal.get(Calendar.MINUTE);
			return new TimePickerDialog(getActivity(), EditActivity.this, hour,
					minute, DateFormat.is24HourFormat(getActivity()));
		}

	};

	/**
	 * {@link CheckBox} where the user can state the time remind status of the
	 * ToDo item.
	 */
	private CheckBox timeRemind;
	/**
	 * {@link TextView} which shows the information about the relation between
	 * done and remind status as well as the remind date.
	 */
	private TextView timeRemindInformation;
	/**
	 * {@link Button} which will by clicking open the
	 * {@link EditActivity#timePickerFragment}.
	 */
	private Button timeSetup;
	/** {@link EditText} where the user can input the title of the ToDo item. */
	private EditText title;

	/**
	 * Method called if the user presses the back button. The method will store
	 * the inputed values in the database. If the processed ToDo item is a new
	 * one ({@link EditActivity#id} = -1) the database is called to create a new
	 * entry (
	 * {@link DatabaseAdapter#createToDoItem(String, String, boolean, boolean, Calendar, boolean, double, double, Context)}
	 * ) otherwise the item will be updated in the database (
	 * {@link DatabaseAdapter#updateToDoItemWith(int, String, String, boolean, boolean, Calendar, boolean, double, double, Context)}
	 * ). Before the {@code super.onBackPressed()} is called the result value is
	 * set to {@link Activity#RESULT_OK} that this activity will return to its
	 * caller {@link MainActivity} including a intent which contains the
	 * identifier of the processed ToDo item.
	 * 
	 * @see {@link Activity#onBackPressed()}, {@link DatabaseAdapter},
	 *      {@link IntentManager}
	 **/
	@Override
	public void onBackPressed() {
		String title = this.title.getText().toString();
		String description = this.description.getText().toString();
		boolean done = this.done.isChecked();
		boolean timeRemindStat = this.timeRemind.isChecked();
		boolean locationRemindStat = this.locationRemind.isChecked();
		if (isLocationNull() && locationRemindStat) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle(R.string.warning)
					.setMessage(R.string.error_no_location)
					.setCancelable(false)
					.setPositiveButton(
							R.string.ok,
							new android.content.DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							}).create().show();
			return;
		}
		if (id == -1) {

			id = DatabaseAdapter.createToDoItem(title, description, done,
					timeRemindStat, remindCal, locationRemindStat,
					isLocationNull() ? MAX_VALUE : getLatitude(),
					isLocationNull() ? MAX_VALUE : getLongitude(), this);
			if (id == -1) {
				IntentManager.cancelEditing(this, id);
				super.onBackPressed();
			}
		} else {
			DatabaseAdapter.updateToDoItemWith(id, title, description, done,
					timeRemindStat, remindCal, locationRemindStat,
					isLocationNull() ? MAX_VALUE : getLatitude(),
					isLocationNull() ? MAX_VALUE : getLongitude(), this);
		}
		IntentManager.saveEditing(this, id);

		super.onBackPressed();
	}

	/**
	 * Creates the options menu through the menu resource
	 * {@code R.menu.edit_activity}. The menu will contains three items: firstly
	 * for canceling of the editing, secondly an item which initiates the
	 * deletion of the edited ToDo item and thirdly an item which initiates
	 * storing the item.
	 * 
	 * @param menu
	 *            The options menu in which you place your items.
	 * @result Return always {@code true} so that the menu will be displayed.
	 * 
	 * @see {@link Activity#onCreateOptionsMenu(Menu)}
	 **/
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.edit_activity_options, menu);
		return true;
	}

	/**
	 * Called when the {@link DatePickerDialog} is finished which was created by
	 * the {@link EditActivity#timePickerFragment}. So the method can store the
	 * inputed values (year, month and day) in the
	 * {@link EditActivity#remindCal} calendar.
	 * 
	 * @param view
	 *            The view associated with this listener.
	 * @param year
	 *            The year that was set.
	 * @param month
	 *            The month that was set (0-11) for compatibility with Calendar.
	 * @param dayOfMonth
	 *            The day of the month that was set.
	 * 
	 * @see {@link OnDateSetListener#onDateSet(DatePicker, int, int, int)}
	 **/
	@Override
	public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
		remindCal.set(year, month, dayOfMonth);
		setupDisabilityOfInputElements();
	}

	/**
	 * Handles the selection in the options menu. In this activity three items
	 * are selectable: firstly the possibility for canceling the editing so that
	 * the application returns without storing the changed data to the
	 * {@link MainActivity}. Therefore the {@link Activity#onBackPressed()} is
	 * called and the result value was set to {@link MainActivity#RESULT_DELETE}
	 * . Secondly the user can also select the option to delete this item from
	 * the database which is done by the method
	 * {@link DatabaseAdapter#deleteToDoItemWith(int, android.content.Context)}.
	 * And thirdly the possibility for storing the entered information int the
	 * database. Therefore simply the {@link Activity#onBackPressed()} is
	 * called.
	 * 
	 * @param item
	 *            The menu item that was selected.
	 * @return Return {@code false} to allow normal menu processing to proceed,
	 *         {@code true} to consume it here.
	 * 
	 * @see {@link Activity#onOptionsItemSelected(MenuItem)},
	 *      {@link IntentManager}
	 **/
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.delete:
			if (id != -1) {
				DatabaseAdapter.deleteToDoItemWith(id, this);
			}
			IntentManager.deleteEditing(this, id);
			super.onBackPressed();
			break;
		case R.id.cancel:
			IntentManager.cancelEditing(this, id);
			super.onBackPressed();
			break;
		case R.id.save:
			this.onBackPressed();
			break;
		}
		return true;
	}

	/**
	 * Called when the {@link TimePickerDialog} is finished which was created by
	 * the {@link EditActivity#timePickerFragment}. So the method can store the
	 * inputed values (hour, minute) in the {@link EditActivity#remindCal}
	 * calendar.
	 * 
	 * @param view
	 *            The view associated with this listener.
	 * @param hourOfDay
	 *            The hour that was set.
	 * @param minute
	 *            The minute that was set.
	 * 
	 * @see {@link OnTimeSetListener#onTimeSet(TimePicker, int, int)}
	 **/
	@Override
	public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
		remindCal.set(Calendar.HOUR_OF_DAY, hourOfDay);
		remindCal.set(Calendar.MINUTE, minute);
		remindCal.set(Calendar.SECOND, 0);
		setupDisabilityOfInputElements();
	}

	/**
	 * Method returns the latitude information of the remind location, if it
	 * exists, otherwise the max double value.
	 * 
	 * @return If it exists, the latitude value of the remind location,
	 *         otherwise the max double value.
	 */
	private double getLatitude() {
		return remindLocation != null ? remindLocation.latitude : MAX_VALUE;
	}

	/**
	 * Method returns the longitude information of the remind location, if it
	 * exists, otherwise the max double value.
	 * 
	 * @return If it exists, the longitude value of the remind location,
	 *         otherwise the max double value.
	 */
	private double getLongitude() {
		return remindLocation != null ? remindLocation.longitude : MAX_VALUE;
	}

	/**
	 * Checks whether the remind location is not set, i.e. is null.
	 * 
	 * @return {@code true} if the location is {@code null}, {@code false}
	 *         otherwise.
	 */
	private boolean isLocationNull() {
		return remindLocation == null;
	}

	/**
	 * Method fills the TextView which contains the information about the remind
	 * location with a String that contains the coordinates of the remind
	 * location.
	 */
	private void setCoordinatesToInformationView() {
		locationRemindInformation.setText(Utils.createLocationString(
				getLatitude(), getLongitude(), this));
	}

	/**
	 * Method will enable/disable the specified views in the array depending on
	 * the specified status.
	 * 
	 * @param status
	 *            Indicates whether the views should be enabled or disabled.
	 * @param views
	 *            The views which should be enable/disabled.
	 */
	private void setEnableOfViewsTo(boolean status, View[] views) {
		for (View view : views) {
			view.setEnabled(status);
		}
	}

	/**
	 * Enables or disables the input elements of the done, the time remind
	 * status and the location remind status as well as the buttons to change
	 * the date & time as well as the button for setup the remind location.
	 **/
	private void setupDisabilityOfInputElements() {
		boolean doneStatus = done.isChecked();
		boolean timeStatus = timeRemind.isChecked();
		boolean locationStatus = locationRemind.isChecked();
		if (doneStatus) {
			setEnableOfViewsTo(false, new View[] { locationRemind,
					locationRemindInformation, locationSetup });
			setEnableOfViewsTo(false, new View[] { timeRemind,
					timeRemindInformation, dateSetup, timeSetup });
			if (timeStatus)
				timeRemind.setText(getString(R.string.time_remind)
						+ getString(R.string.blank)
						+ getString(R.string.inactiv));
			if (locationStatus)
				locationRemind.setText(getString(R.string.location_remind)
						+ getString(R.string.blank)
						+ getString(R.string.inactiv));
		} else {
			timeRemind.setEnabled(true);
			locationRemind.setEnabled(true);
			timeRemind.setText(R.string.time_remind);
			locationRemind.setText(R.string.location_remind);
			setEnableOfViewsTo(timeStatus, new View[] { timeRemindInformation,
					dateSetup, timeSetup });
			setEnableOfViewsTo(locationStatus, new View[] {
					locationRemindInformation, locationSetup });
			java.text.DateFormat timeFormatter = java.text.DateFormat
					.getTimeInstance(java.text.DateFormat.SHORT, getResources()
							.getConfiguration().locale);
			java.text.DateFormat dateFormatter = java.text.DateFormat
					.getDateInstance(java.text.DateFormat.FULL, getResources()
							.getConfiguration().locale);
			if (timeStatus)
				timeRemindInformation.setText(getString(
						R.string.time_reminder_information,
						dateFormatter.format(remindCal.getTime()),
						timeFormatter.format(remindCal.getTime())));
		}
		locationSection
				.setVisibility(locationStatus ? View.VISIBLE : View.GONE);
		dateSection.setVisibility(timeStatus ? View.VISIBLE : View.GONE);
	}

	/**
	 * If a remind location exists the remind location TextView will be filled
	 * with a String that contains the coordinates. Also an AsyncTask
	 * {@link UpdateLocation} will be started for fetching an human readable
	 * address String. Otherwise the TextView will be filled with a message that
	 * no location was chosen.
	 */
	private void setupLocationInformation() {
		if (remindLocation != null) {
			setCoordinatesToInformationView();
			new UpdateLocation().execute();
		} else {
			locationRemindInformation
					.setText(getString(R.string.location_reminder_none));
		}
	}

	/**
	 * Handles the returning from the remind location selection activity
	 * {@link LocationPicker} (see {@link IntentManager#REQUEST_SET_LOCATION}).
	 * For each possible result (where the be
	 * {@link IntentManager#RESULT_CANCELED} and {@link IntentManager#RESULT_OK}
	 * the method shows a toast message with the information what happens. If an
	 * remind location was chosen, this will be set to the raw remind location
	 * {@link EditActivity#remindLocation}. In every case the method triggers to
	 * check the visibility and also the disability of the view elements. Also
	 * the method tries to convert the remind location coordinates into an human
	 * readable address String by calling the method
	 * {@link EditActivity#setupLocationInformation()}.
	 * 
	 * @param requestCode
	 *            The integer request code originally supplied to
	 *            startActivityForResult(), allowing you to identify who this
	 *            result came from.
	 * @param resultCode
	 *            The integer result code returned by the child activity through
	 *            its setResult().
	 * @param data
	 *            An Intent, which can return result data to the caller (various
	 *            data can be attached to Intent "extras").
	 * 
	 * @see Activity#onActivityResult(int, int, Intent)
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == IntentManager.REQUEST_SET_LOCATION) {
			if (resultCode == IntentManager.RESULT_OK) {
				int tempID = data.getIntExtra(ToDoItem.ID, -1);
				double tempLat = data.getDoubleExtra(
						ToDoItem.LOCATION_LATITUDE, MAX_VALUE);
				double tempLng = data.getDoubleExtra(
						ToDoItem.LOCATION_LONGITUDE, MAX_VALUE);
				boolean objError = tempID != id;
				boolean noLocation = tempLat == MAX_VALUE
						|| tempLng == MAX_VALUE;
				if (objError) {
					Utils.showToast(this, getString(R.string.error_assignment));
				} else if (noLocation) {
					remindLocation = null;
					Utils.showToast(this,
							getString(R.string.location_reminder_none));
				} else {
					remindLocation = new LatLng(tempLat, tempLng);
					Utils.showToast(this, getString(R.string.location_chosen));
				}
			} else if (resultCode == IntentManager.RESULT_CANCELED) {
				Utils.showToast(this,
						getString(R.string.location_selection_canceled));
			}
			setupLocationInformation();
			setupDisabilityOfInputElements();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	/**
	 * Set the Layout {@code res/layout/edit_activity.xml} as well as the
	 * instance variables. To the CheckBoxes {@link EditActivity#done},
	 * {@link EditActivity#timeRemind} and {@link EditActivity#locationRemind}
	 * the {@link OnCheckListener} is added as Listener as well as to the two
	 * buttons ({@link EditActivity#dateSetup}, {@link EditActivity#timeSetup})
	 * are two anonymous {@link OnClickListener} added which will show the
	 * corresponding dialog ( {@link EditActivity#timePickerFragment},
	 * {@link EditActivity#datePickerFragment}). To the button
	 * {@link EditActivity#locationSetup} also an anonymous
	 * {@link OnClickListener} is added which will open the
	 * {@link LocationPicker} activity for choosing a remind location. If the
	 * intent contains the extra {@link MainActivity#REQUEST_CODE} for updating
	 * a item ( {@link MainActivity#ITEM_UPDATE}), this item will be fetched
	 * from the database by calling the method
	 * {@link DatabaseAdapter#fetchToDoItemWith(int, Context)} and the received
	 * values of the ToDo item will be set to the corresponding fields.
	 * 
	 * @param savedInstanceState
	 *            {@code null} or the {@link Bundle} contains the data it most
	 *            recently supplied in
	 *            {@link Activity#onSaveInstanceState(Bundle)}.
	 * 
	 * @see {@link Activity#onCreate(Bundle)}, {@link DatabaseAdapter},
	 *      {@link MainActivity#REQUEST_CODE}
	 **/
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.edit_activity);
		remindCal = Calendar
				.getInstance(this.getResources().getConfiguration().locale);
		title = (EditText) findViewById(R.id.title);
		description = (EditText) findViewById(R.id.description);
		done = (CheckBox) findViewById(R.id.done);
		done.setOnCheckedChangeListener(new OnCheckListener());
		timeRemind = (CheckBox) findViewById(R.id.time_remind);
		timeRemind.setOnCheckedChangeListener(new OnCheckListener());
		locationRemind = (CheckBox) findViewById(R.id.location_remind);
		locationRemind.setOnCheckedChangeListener(new OnCheckListener());
		timeSetup = (Button) findViewById(R.id.timeSetup);
		timeSetup.setOnClickListener(new OnClickListener() {

			/**
			 * If the user clicks the listened view, the dialog for editing the
			 * time is displayed.
			 * 
			 * @param v
			 *            The view that was clicked.
			 * 
			 * @see {@link OnClickListener#onClick(View)}
			 **/
			@Override
			public void onClick(View v) {
				timePickerFragment.show(getFragmentManager(), "timePicker");
			}
		});
		dateSetup = (Button) findViewById(R.id.dateSetup);
		dateSetup.setOnClickListener(new OnClickListener() {

			/**
			 * If the user clicks the listened view, the dialog for editing the
			 * date is displayed.
			 * 
			 * @param v
			 *            The view that was clicked.
			 * 
			 * @see {@link OnClickListener#onClick(View)}
			 **/
			@Override
			public void onClick(View v) {
				datePickerFragment.show(getFragmentManager(), "datePicker");
			}
		});
		timeRemindInformation = (TextView) findViewById(R.id.dateTime_information);
		locationRemindInformation = (TextView) findViewById(R.id.location_information);
		locationSetup = (Button) findViewById(R.id.locationSetup);
		locationSetup.setOnClickListener(new OnClickListener() {

			/**
			 * If the user clicks the listened view, the activity
			 * {@link LocationPicker} will be started including the id of the
			 * edited ToDo item as well as the current coordinates of the remind
			 * location.
			 * 
			 * @param v
			 *            The view that was clicked
			 * @see OnClickListener#onClick(View), IntentManager
			 */
			@Override
			public void onClick(View v) {
				IntentManager.startPickingLocation(EditActivity.this, id,
						(isLocationNull() ? MAX_VALUE : getLatitude()),
						(isLocationNull() ? MAX_VALUE : getLongitude()));
			}
		});
		locationSection = (LinearLayout) findViewById(R.id.location_section);
		dateSection = (LinearLayout) findViewById(R.id.date_section);
		Intent intent = getIntent();
		if (intent.getIntExtra(IntentManager.KEY_REQUEST_CODE, 0) == IntentManager.REQUEST_UPDATE_ITEM) {
			id = intent.getIntExtra(ToDoItem.ID, -1);
			if (id != -1) {
				ToDoItem todo = DatabaseAdapter.fetchToDoItemWith(id, this);
				title.setText(todo.getTitle());
				description.setText(todo.getDescription());
				done.setChecked(todo.isDone());
				timeRemind.setChecked(todo.shouldTimeRemind());
				locationRemind.setChecked(todo.shouldLocationRemind());
				remindCal = todo.getDate();
				if (todo.getLatitude() != MAX_VALUE
						&& todo.getLongitude() != MAX_VALUE) {
					remindLocation = new LatLng(todo.getLatitude(),
							todo.getLongitude());
				}
			}
		}
		setupDisabilityOfInputElements();
		setupLocationInformation();
	}

}