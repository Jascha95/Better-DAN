package androidlab.exercise5;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import androidlab.exercise5.sys.IntentManager;

/**
 * <h2>Coordinates Picker Dialog</h2>
 * 
 * This {@link DialogFragment} allows to enter the latitude and longitude
 * information for selecting a location. Therefore the displayed dialog shows
 * two EditText elements as well as two {@link Spinner} for selecting whether
 * the latitude is north or south and whether the longitude is east or west.
 * Also the EditText elements uses an {@link InputFilter}, so that the user
 * can't enter invalid coordinates (Longitude: [-180, 180], Latitude: [-90,90]).
 * 
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 * @see InputFilter,
 **/
public class CoordinatesPicker extends DialogFragment {

	/**
	 * The {@link CoordinateType} in indicates whether the related information
	 * is a latitude value or a longitude value. Therefore those two constants
	 * exist.
	 **/
	private enum CoordinateType {
		/** The related information is a latitude value. */
		LATITUDE,
		/** The related information is a longitude value. */
		LONGITUDE
	}

	/**
	 * {@link InputFilter} for the EdiText elements that protects for invalid
	 * input of either a latitude or a longitude value (Longitude: [-180, 180],
	 * Latitude: [-90,90]). Because North/South and East/West will be entered by
	 * the Spinner there is no need to allow negative values. The filter will
	 * dismiss invalid added character.
	 * 
	 **/
	private class GPSInputFilter implements InputFilter {

		/**
		 * The maximal latitude/longitude value (will be set by the constructor
		 * depending on the specified CoordinateType).
		 */
		private double max = 0;

		/**
		 * Constructor of the {@link InputFilter} that only allows to input a
		 * valid latitude or longitude value. Whether the filter should check
		 * for latitude or longitude depends on the specified
		 * {@link CoordinateType}.
		 * 
		 * @param type
		 *            Indicates whether the filter should allow only valid
		 *            longitude or valid latitude values.
		 **/
		public GPSInputFilter(CoordinateType type) {
			switch (type) {
			case LONGITUDE:
				max = 180.0;
				break;
			case LATITUDE:
				max = 90.0;
				break;
			default:
				max = 0.0;
				break;
			}
		}

		/**
		 * Checks whether the complete input is in the specific range, i.e. for
		 * longitude in the range from 0 to 180 and for latitude in the range
		 * from 0 to 90. If the input is a number and also in the range the
		 * method will return {@code true}, otherwise {@code false}.
		 * 
		 * @param input
		 *            The complete input of the EditText element.
		 * @return {@code true} if the specified String is a number and also in
		 *         the defined range, otherwise {@code false}.
		 **/
		private boolean isInRange(String input) {
			double value = 0.0;
			try {
				value = Double.valueOf(input).doubleValue();
				return value <= max;
			} catch (Exception e) {
				return false;
			}
		}

		/**
		 * Method checks whether the entered character sequence is a valid
		 * longitude/latitude value. If the new added character makes the
		 * character sequence to an invalid latitude/longitude value, the method
		 * will dismiss the added character.
		 * 
		 * @param source
		 *            New text which will be add.
		 * @param start
		 *            Start index of the new text.
		 * @param end
		 *            End index of the new text.
		 * @param dest
		 *            The text which will be changed.
		 * @param dstart
		 *            Start index of the change text.
		 * @param dend
		 *            End index of the change text.
		 * @return The empty String if the new added character invalidates the
		 *         complete input text, otherwise {@code null}.
		 * @see InputFilter#filter(CharSequence, int, int, Spanned, int, int)
		 **/
		@Override
		public CharSequence filter(CharSequence source, int start, int end,
				Spanned dest, int dstart, int dend) {
			String input = dest.toString() + source.toString();
			if (isInRange(input)) {
				return null;
			}
			return "";
		}

	}

	/** The unique fragment tag for the {@link CoordinatesPicker}. */
	public static final String COORDINATES_FRAGMENT_TAG = "androidlab.exercise5.CoordinatesPicker";

	/**
	 * Method builds the custom {@link Dialog} container, which allows to enter
	 * coordinates. The dialog is cancelable by clicking the 'cancel' as well as
	 * by clicking in the offset of the dialog. If the user enters the
	 * coordinates and confirms by clicking the 'ok'-button, the entered coordinates
	 * will be broadcasted via an intent.
	 * 
	 * @param savedInstanceState
	 *            The last saved instance state of the Fragment, or null if this
	 *            is a freshly created Fragment.
	 * @return Returns a new Dialog instance to be displayed by the Fragment
	 *         which allows to enter coordinates.
	 * @see DialogFragment#onCreateDialog(Bundle)
	 **/
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		LayoutInflater inflater = getActivity().getLayoutInflater();
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		View view = inflater.inflate(R.layout.coordinates_picker, null);
		final EditText latitude = (EditText) view.findViewById(R.id.latitude);
		final Spinner latitudeType = (Spinner) view
				.findViewById(R.id.latitude_spinner);
		final EditText longitude = (EditText) view.findViewById(R.id.longitude);
		final Spinner longitudeType = (Spinner) view
				.findViewById(R.id.longitude_spinner);
		builder.setTitle(R.string.coordinates_picker)
				.setNegativeButton(R.string.cancel,
						new DialogInterface.OnClickListener() {

							/**
							 * OnClickListener for the 'cancel' button of the
							 * dialog. This method will be invoked when the user
							 * clicks on this button. By clicking on the button
							 * the dialog will be canceled and the onscreen
							 * keyboard will be hidden.
							 * 
							 * @param dialog
							 *            The dialog that received the click.
							 * @param which
							 *            The button that was clicked or the
							 *            position of the item clicked.
							 * @see DialogInterface.OnClickListener#onClick(DialogInterface,
							 *      int)
							 **/
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								getActivity()
										.getWindow()
										.setSoftInputMode(
												WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
								dialog.cancel();
							}
						})
				.setPositiveButton(R.string.ok,
						new DialogInterface.OnClickListener() {

							/**
							 * OnClickListener for the 'ok' button of the
							 * dialog. This method will be invoked when the user
							 * clicks on this button. By clicking on the button
							 * the dialog will be dismissed, the onscreen
							 * keyboard will be hidden and an intent with the
							 * entered coordinates is broadcasted.
							 * 
							 * @param dialog
							 *            The dialog that received the click.
							 * @param which
							 *            The button that was clicked or the
							 *            position of the item clicked.
							 * @see DialogInterface.OnClickListener#onClick(DialogInterface,
							 *      int), IntentManager#
							 *      submitCoodinatesFromCoordinatesPicker
							 *      (Context, double, double, boolean)
							 **/
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								getActivity()
										.getWindow()
										.setSoftInputMode(
												WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
								String latString = latitude.getText()
										.toString();
								String lngString = longitude.getText()
										.toString();
								double latValue = 0.0;
								double lngValue = 0.0;
								boolean error = latString == null
										|| new String("").equals(latString)
										|| lngString == null
										|| new String("").equals(lngString);
								try {
									latValue = Double.valueOf(latString)
											.doubleValue();
									latValue = (latitudeType.getSelectedItem()
											.toString().equals(getActivity()
											.getString(R.string.north))) ? latValue
											: 0 - latValue;
									lngValue = Double.valueOf(lngString)
											.doubleValue();
									lngValue = (latitudeType.getSelectedItem()
											.toString().equals(getActivity()
											.getString(R.string.north))) ? lngValue
											: 0 - lngValue;
								} catch (Exception e) {
									error = true;
								}
								IntentManager
										.submitCoodinatesFromCoordinatesPicker(
												getActivity(), latValue,
												lngValue, error);
								dialog.dismiss();
							}
						}).setView(view);
		latitude.setFilters(new InputFilter[] { new GPSInputFilter(
				CoordinateType.LATITUDE) });
		ArrayAdapter<CharSequence> latAdapter = ArrayAdapter
				.createFromResource(getActivity(), R.array.latitude_type,
						android.R.layout.simple_spinner_item);
		latAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		latitudeType.setAdapter(latAdapter);
		longitude.setFilters(new InputFilter[] { new GPSInputFilter(
				CoordinateType.LONGITUDE) });
		ArrayAdapter<CharSequence> lngAdapter = ArrayAdapter
				.createFromResource(getActivity(), R.array.longitude_type,
						android.R.layout.simple_spinner_item);
		lngAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		longitudeType.setAdapter(lngAdapter);
		return builder.create();
	}
}
