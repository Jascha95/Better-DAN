package androidlab.exercise5;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;

import androidlab.exercise5.adapter.DatabaseAdapter;


/**
 * This is a ContentProvider for the Todo database.
 * Anything else than reading is impossible.
 *
 */
public class TodoProvider extends ContentProvider {
    public static final String AUTHORITY = "androidlab.exercise5";
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY);

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Cursor query(final Uri uri, final String[] projection, final String selection,
                        final String[] selectionArgs, final String sortOrder) {
        return DatabaseAdapter.query(projection, selection, selectionArgs, sortOrder, getContext());
    }


    @Override
    public String getType(final Uri uri) {
        return null;
    }

    @Override
    public Uri insert(final Uri uri, final ContentValues values) {
        throw new UnsupportedOperationException("Inserting is unsupported on this content manager");
    }

    @Override
    public int update(final Uri uri, final ContentValues values, final String selection,
                      final String[] selectionArgs) {
        throw new UnsupportedOperationException("Editing is unsupported on this content manager");
    }

    @Override
    public int delete(final Uri uri, final String selection, final String[] selectionArgs) {
        throw new UnsupportedOperationException("Deleting is unsupported on this content manager");
    }
}