package androidlab.exercise5.adapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;

/**
 * <h2>Adapter for receiving the phone contacts</h2>
 * 
 * The {@link ContactAdapter} provides a method for fetching the address Strings
 * of the phone contacts. Therefore, the adapter uses the
 * {@link ContentResolver} and asks for the phone contacts.
 * 
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 * @see ContentResolver
 **/
public class ContactAdapter {

	/** Identifier of the phone contact address String. */
	public static String CONTACT_ADDRESS = "contact_address";
	/** Identifier of the phone contact name. */
	public static String CONTACT_NAME = "contact_name";

	/**
	 * Method returns a list which contains for every contact of the phone a
	 * {@link Map}. Each map contains the contact information. Those information
	 * are accessible by the identifier {@link ContactAdapter#CONTACT_NAME} and
	 * {@link ContactAdapter#CONTACT_ADDRESS}. The phone contacts are accessed
	 * via a content resolver. Consider that a single contact can have multiple
	 * addresses.
	 * 
	 * @param context
	 *            The Context in which the adapter is used.
	 * @return List of maps, which contain the name of the contact and the
	 *         address String of the contact.
	 */
	public static List<Map<String, String>> getContacts(Context context) {
		List<Map<String, String>> contacts = new ArrayList<Map<String, String>>();
		ContentResolver cr = context.getContentResolver();
		Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI, null,
				null, null, null);
		if (cur.getCount() > 0) {
			while (cur.moveToNext()) {
				String name = cur
						.getString(cur
								.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
				String id = cur.getString(cur
						.getColumnIndex(ContactsContract.Contacts._ID));
				String addrWhere = ContactsContract.Data.CONTACT_ID
						+ " = ? AND " + ContactsContract.Data.MIMETYPE + " = ?";
				String[] addrWhereParams = new String[] {
						id,
						ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE };
				Cursor addrCur = cr.query(ContactsContract.Data.CONTENT_URI,
						null, addrWhere, addrWhereParams, null);
				while (addrCur.moveToNext()) {
					String address = addrCur
							.getString(addrCur
									.getColumnIndex(ContactsContract.CommonDataKinds.StructuredPostal.FORMATTED_ADDRESS));
					if (name != null & address != null) {
						Map<String, String> map = new HashMap<String, String>();
						map.put(CONTACT_NAME, name);
						map.put(CONTACT_ADDRESS, address);
						contacts.add(map);
					}
				}
				addrCur.close();
			}
		}
		cur.close();
		return contacts;
	}

}
