package androidlab.exercise5.adapter;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import androidlab.exercise5.R;

import com.google.android.gms.maps.model.LatLng;

/**
 * <h2>Adapter for converting different location formats</h2>
 * 
 * The {@link LocationAdapter} provides multiple methods for converting a
 * specific location format into an other one, e.g from {@link LatLng} into an
 * {@link Address} object. Therefore, the adapter uses the Geocoder (
 * {@link LocationAdapter#geocoder}). If the adapter isn't able to convert an
 * input, a fallback {@link Address} and a fallback {@link LatLng} is available.
 * 
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 2.0
 **/
public class LocationAdapter {

	/** The context in which the {@link LocationAdapter} is used. */
	private Context context;
	/**
	 * The geocoder which allows to convert different location representations
	 * into an other one, e.g. from the latitude and longitude information into
	 * an address.
	 */
	private Geocoder geocoder;

	/**
	 * Constructor of the {@link LocationAdapter} which requires the context in
	 * which the adapter is used.
	 * 
	 * @param context
	 *            The context in which the {@link LocationAdapter} is used.
	 */
	public LocationAdapter(Context context) {
		this.context = context;
		this.geocoder = new Geocoder(context);
	}

	/**
	 * Method converts the specified latitude and longitude information into an
	 * {@link Address} instance. The address that represents the coordinates
	 * best is returned here. If there is no address for the given coordinates,
	 * the method will return {@code null}.
	 * 
	 * @param coordinates
	 *            The coordinates which should be converted into an address.
	 * @return The address which fits best the specified coordinates, if the
	 *         geocoder finds such an address, otherwise {@code null}.
	 */
	public Address getAddressForCoordinates(LatLng coordinates) {
		List<Address> result = null;
		try {
			result = geocoder.getFromLocation(coordinates.latitude,
					coordinates.longitude, 1);
			if (result.size() == 1) {
				return result.get(0);
			} else {
				return null;
			}
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Method converts the specified latitude and longitude information into a
	 * list of {@link Address} instance. The five addresses that represent the
	 * coordinates best are returned in the list here. If there is no address
	 * for the given coordinates, the method will return {@code null}.
	 * 
	 * @param coordinates
	 *            The coordinates which should be converted into a list of
	 *            suitable addresses.
	 * @return The five addresses which fits best the specified coordinates in a
	 *         list, if the geocoder finds such addresses, otherwise
	 *         {@code null}.
	 */
	public List<Address> getAllAddressForCoordinates(LatLng coordinates) {
		List<Address> result = null;
		try {
			result = geocoder.getFromLocation(coordinates.latitude,
					coordinates.longitude, 5);
			if (result.size() > 0) {
				return result;
			} else {
				return null;
			}
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Method converts the specified address information into an {@link LatLng}
	 * instance. The coordinates that represents the address best is returned
	 * here. If there is no latitude and longitude information for the given
	 * address, the method will return {@code null}.
	 * 
	 * @param address
	 *            The address which should be converted into coordinates.
	 * @return The coordinates which fits best the specified address, if the
	 *         geocoder finds such coordinates, otherwise {@code null}.
	 */
	public LatLng getCoordinatesFromAddressString(String address) {
		List<Address> result = null;
		try {
			result = geocoder.getFromLocationName(address, 1);
			if (result.size() > 0) {
				LatLng res = new LatLng(result.get(0).getLatitude(), result
						.get(0).getLongitude());
				return res;
			} else {
				return null;
			}
		} catch (IOException e) {
			return null;
		}
	}

	/**
	 * Method returns the fallback address which is provided by the
	 * {@code app_settings.xml}.
	 * 
	 * @return The fallback address from the {@code app_settings.xml}.
	 */
	public Address getFallbackAddress() {
		Address adr = new Address(Locale.GERMANY);
		adr.setAddressLine(0, context.getString(R.string.fallback_address_0));
		adr.setAddressLine(1, context.getString(R.string.fallback_address_1));
		adr.setFeatureName(context.getString(R.string.fallback_address_feature));
		adr.setCountryCode(context.getString(R.string.fallback_contry_code));
		adr.setCountryName(context.getString(R.string.fallback_contry_name));
		adr.setLatitude(getFallbackCoordinates().latitude);
		adr.setLongitude(getFallbackCoordinates().longitude);
		adr.setPhone(context.getString(R.string.fallback_phone));
		adr.setPostalCode(context.getString(R.string.fallback_postal_code));
		adr.setUrl(context.getString(R.string.fallback_url));
		return adr;
	}

	/**
	 * Method returns the fallback coordinates which are provided by the
	 * {@code app_settings.xml}. If those latitude and longitude are invalid,
	 * the method will return the origin coordinates (0,0).
	 * 
	 * @return The fallback coordinates from the {@code app_settings.xml}.
	 */
	public LatLng getFallbackCoordinates() {
		try {
			return new LatLng(Double.valueOf(
					context.getString(R.string.fallback_latitude))
					.doubleValue(), Double.valueOf(
					context.getString(R.string.fallback_longitude))
					.doubleValue());
		} catch (Exception e) {
			return new LatLng(0, 0);
		}

	}

	/**
	 * Checks whether the geocoder is present and can convert a location
	 * information.
	 * 
	 * @return {@code true} if the geocoder is available and ready to convert a
	 *         Location, otherwise {@code false}.
	 */
	public boolean isGeocoderPresent() {
		return Geocoder.isPresent();
	}
}
