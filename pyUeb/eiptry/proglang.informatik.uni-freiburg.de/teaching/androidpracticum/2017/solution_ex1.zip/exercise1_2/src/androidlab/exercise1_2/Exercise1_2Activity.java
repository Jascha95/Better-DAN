package androidlab.exercise1_2;

import android.os.Bundle;
import android.app.Activity;

import android.widget.TextView;


/**
 * <h1>Example solution - exercise sheet 1</h1>
 * <h2>Main activity (task 2)</h2>
 * This class is the starting point of the application and inherits of <i>Activity</i> (@see <a href="http://developer.android.com/reference/android/app/Activity.html">Activity</a>).
 * <hr>
 * <b>Tasks:</b>
 * <ol>
 * <li><b>Changing the graphical user interface programmatically:</b><br>
 * Import the <code>android.widget.TextView</code> class (<a href="http://developer.android.com/reference/android/widget/TextView.html">TextView</a>)
 * <br>and add the following lines inside the {@link Exercise1_2Activity#onCreate(Bundle)} implementation:<br>
 * <code>TextView tv = new TextView(this); <br>
 * tv.setText("Hello Android!");<br>
 * setContentView(tv);<br></code>
 * You might also comment the line <code>setContentView(R.layout.main);</code>. As a result, the layout resource <code>main.xml</code> is not loaded. 
 * </li>
 * <li><b>Changing the graphical user interface by declaration of UI elements in the layout resource (XML):</b><br>
 * Therefore, the {@link Exercise1_2Activity#onCreate(Bundle)} implementation should contain the fragment <code>setContentView(R.layout.main);</code>.<br>
 * This will load the layout from the resource file <code>main.xml</code> which is stored in the folder <code>res/layout</code>.<br>
 * As described you should change the implementation of this resource and add also a new string resource.
 * </li>
 * </ol>
 * For task 1 & 2 see <a href="http://developer.android.com/guide/topics/ui/declaring-layout.html">Layouts</a>.
 * @author Seminar 'Introduction to Android Smartphone Programming', University of Freiburg 
 * @version 1.0
 */
public class Exercise1_2Activity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        /**
         * Task 2.3 (toggle comment for enable/disable):
         * Changing the GUI by using the programmatical way. Therefore a new <i>TextView</i> object is created 
         * and the text of this view object is setted to 'Hello Android!'. Finally the the UI element is placed in the window
         * by calling {@link Exercise1_2Activity#setContentView(android.view.View)}.
         */
//        //setContentView(R.layout.main);
//        TextView tv = new TextView(this); 
//        tv.setText("Hello Android!");
//        setContentView(tv);
        
        /**
         * Task 2.4 (toggle comment for enable/disable):
         * Changing the GUI by using the XML-based layout resource <code>main.xml</code>.
         * This layout contains a <i>TextView</i> including a reference to the string resource 'hello' 
         * (which is added to the file <code>res/values/string.xml</code>). The value of this string is 'Hello Android!'.
         */
        setContentView(R.layout.main);
        
        
    }
}
