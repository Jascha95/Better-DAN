package androidlab.exercise2_1;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

/**
 * <b>This application is design for the API level >= 7.</b>
 * <hr>
 * <h1>Example solution - Simple Calculator (Exercise 2)</h1>
 * <h2>Main activity</h2>
 * 
 * This activity provides the interface of the calculator. Therefore the layout
 * resource {@code res/layout/main.xml} is used which includes the required
 * buttons ("0"-"9", "+", "-", "*", "/", ".", "=" and "Clear") as well as a
 * panel that shows the input of the calculator and also a panel which displays
 * the result of the calculation. These panels are referenced by the two
 * instance variables {@link Exercise2_1Activity#input} and
 * {@link Exercise2_1Activity#result} which are of the type {@link TextView}.
 * The first should show always the entered characters, the latter the result of
 * the entered equation or the error message which describes why there is no
 * solution for the equation. To each of the buttons a anonymous
 * {@link OnClickListener} will be added in the
 * {@link Exercise2_1Activity#onCreate(Bundle)} method. This broadcasts an
 * intent which contains the button identifier and the also the text of the
 * button. Such intents will be received by the anonymous
 * {@link BroadcastReceiver} that is stored in the instance variable
 * {@link Exercise2_1Activity#receiver}. The {@link BroadcastReceiver} decides
 * how the application responds to the press of a specific button. So that this
 * receiver does not respond to all sent intents, it will be registered with the
 * help of the intent filter {@link Exercise2_1Activity#filter}. The evaluation
 * of an expression will be done by the class {@link Calculator} which
 * calculates the result of such an expression using a stack variant.
 * 
 * @see {@link BroadcastReceiver}, {@link Intent}, {@link OnClickListener},
 *      {@link IntentFilter}, {@link Calculator}
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 1.0
 **/
public class Exercise2_1Activity extends Activity {

	/**
	 * Action name of the intent which will be sent when a button was pressed.
	 * So this constant is used for the creation of the intent that will be
	 * broadcasted and also for the intent filter of the
	 * {@link BroadcastReceiver} {@link Exercise2_1Activity#receiver} which
	 * should receive only this intent.
	 **/
	public static final String CUSTOM_INTENT = "androidlab.exercise2_1.BUTTON_PRESSED";
	/**
	 * Identifier of the button id, that is stored in the extra of the
	 * broadcasted intents.
	 */
	public static final String BTN_ID = "androidlab.exercise2_1.BUTTON_ID";
	/**
	 * Identifier of the button value, that is stored in the extra of the
	 * broadcasted intents.
	 */
	public static final String BTN_VAL = "androidlab.exercise2_1.BUTTON_VALUE";
	/** TextView that displays the entered characters of the calculator. */
	private TextView input;
	/**
	 * TextView that displays the result of the entered expression
	 * {@link Exercise2_1Activity#input} if there exists one solution. Otherwise
	 * this text field shows the reason why there exists no solution.
	 **/
	private TextView result;
	/**
	 * Instance variable which stores an instance of an anonymous
	 * {@link BroadcastReceiver} class. This receiver will receive the intents
	 * which are sent when a button was pressed (respectively has the action
	 * {@link Exercise2_1Activity#CUSTOM_INTENT}) and decide what action should
	 * be done.
	 **/
	private BroadcastReceiver receiver = new BroadcastReceiver() {

		/**
		 * This method is called when the BroadcastReceiver is receiving an
		 * {@link Intent} broadcast which has the action
		 * {@link Exercise2_1Activity#CUSTOM_INTENT}). The method will extract
		 * the button identifier which is stored as extra data inside the
		 * intent. Depending on this value the method will clear the input
		 * field, will delete the last character or add the value of the pressed
		 * button to the equation. Each time the method is called it will try to
		 * calculate the new result of the expression and displays this result
		 * in the {@link Exercise2_1Activity#result} {@link TextView} by calling
		 * the method {@link Exercise2_1Activity#calculateAndSetResult(String)}.
		 * 
		 * @param context
		 *            The Context in which the receiver is running.
		 * @param intent
		 *            The Intent being received.
		 * 
		 * @see {@link BroadcastReceiver#onReceive(Context, Intent)},
		 *      {@link Exercise2_1Activity#input},
		 *      {@link Exercise2_1Activity#calculateAndSetResult(String)}
		 **/
		@Override
		public void onReceive(Context context, Intent intent) {
			int v = intent.getIntExtra(BTN_ID, 0);
			switch (v) {
			case R.id.btn_func_clear:
				input.setText("");
				calculateAndSetResult("0.0");
				break;
			case R.id.btn_func_delete:
				String oldInput = input.getText().toString();
				if (oldInput.length() <= 1) {
					input.setText("");
					calculateAndSetResult("0.0");
				} else {
					String newInput = oldInput.substring(0,
							oldInput.length() - 1);
					input.setText(newInput);
					calculateAndSetResult(newInput);
				}
				break;
			case R.id.btn_func_equals:
				String curInput = input.getText().toString();
				calculateAndSetResult(curInput);
				break;
			default:
				String newInput = input.getText().toString()
						+ intent.getStringExtra(BTN_VAL);
				input.setText(newInput);
				calculateAndSetResult(newInput);
				break;
			}
		}
	};
	/**
	 * {@link IntentFilter} of the {@link BroadcastReceiver}
	 * {@link Exercise2_1Activity#receiver} which should receive the intents
	 * that are sent when the buttons are pressed.
	 **/
	private IntentFilter filter = new IntentFilter(CUSTOM_INTENT);

	/**
	 * Called when the activity is starting. Here the initialization takes
	 * place: the {@link Exercise2_1Activity#receiver} is registered, the
	 * {@link TextView}s of the layout were stored in the variables
	 * {@link Exercise2_1Activity#input} and {@link Exercise2_1Activity#result}
	 * as well as for each button an anonymous OnClickListener will be added. To
	 * set this listener only to all views which are of type {@link Button},
	 * the types of the children in the button table are checked. If such a
	 * button was pressed an intent that includes the view identifier and the
	 * value of the button as extra should be broadcasted.
	 * 
	 * @param savedInstanceState
	 *            If the activity is being re-initialized after previously being
	 *            shut down then this Bundle contains the data it most recently
	 *            supplied in onSaveInstanceState(Bundle). Note: Otherwise it is
	 *            null.
	 * @see {@link Activity#onCreate(Bundle)},
	 *      {@link Exercise2_1Activity#BTN_ID},
	 *      {@link Exercise2_1Activity#BTN_VAL},
	 *      {@link Exercise2_1Activity#CUSTOM_INTENT}, {@link OnClickListener}
	 **/
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		registerReceiver(receiver, filter);
		input = (TextView) findViewById(R.id.txt_input);
		input.setTextSize(30);
		result = (TextView) findViewById(R.id.txt_result);
		result.setTextSize(30);
		TableLayout buttonTable = (TableLayout) findViewById(R.id.table_buttons);
		for (int i = 0; i < buttonTable.getChildCount(); i++) {
			TableRow buttonRow = ((TableRow) findViewById(buttonTable
					.getChildAt(i).getId()));
			for (int j = 0; j < buttonRow.getChildCount(); j++) {
				if (buttonRow.getChildAt(j) instanceof Button) {
					((Button) buttonRow.getChildAt(j)).setTextSize(30);
					((Button) buttonRow.getChildAt(j))
							.setOnClickListener(new OnClickListener() {

								/**
								 * Called when a view has been clicked where
								 * this {@link OnClickListener} was added. The
								 * method will send a intent that contains the
								 * identifier of the view as well as the text
								 * value of the button as extra data. The
								 * created intent has the action
								 * {@link Exercise2_1Activity#CUSTOM_INTENT} and
								 * will be broadcasted to the
								 * {@link BroadcastReceiver}
								 * {@link Exercise2_1Activity#receiver}.
								 * 
								 * @param v
								 *            The view that was clicked.
								 * @see {@link OnClickListener#onClick(View)}
								 **/
								@Override
								public void onClick(View v) {
									Intent i = new Intent();
									i.putExtra(BTN_ID, v.getId());
									i.putExtra(BTN_VAL, ((Button) v).getText());
									i.setAction(CUSTOM_INTENT);
									sendBroadcast(i);
								}

							});
				}
			}
		}

	}

	/**
	 * Called as part of the activity lifecycle when an activity is going into
	 * the background. Because of that the receiver
	 * {@link Exercise2_1Activity#receiver} of the intents which are sent by
	 * pressing a button should be unregistered.
	 * 
	 * @see {@link Activity#onPause()}
	 **/
	@Override
	protected void onPause() {
		unregisterReceiver(receiver);
		super.onPause();
	}

	/**
	 * Called after {@link Activity#onRestoreInstanceState(Bundle)},
	 * {@link Activity#onRestart()}, or {@link Activity#onPause()}, for your
	 * activity to start interacting with the user. After the activity has been
	 * inactive, the {@link Exercise2_1Activity#receiver} should be registered,
	 * so that he can receive the intents which are sent when a button was
	 * pressed.
	 * 
	 * @see {@link Activity#onResume()}
	 **/
	@Override
	protected void onResume() {
		registerReceiver(receiver, filter);
		super.onResume();
	}

	/**
	 * Method which calculates the result of the given expression using the
	 * class {@link Calculator}. If there exists such a result it will be set to
	 * the text field {@link Exercise2_1Activity#result}, otherwise the
	 * exception will be caught and the message of this exception will be set to
	 * the result text field.
	 * 
	 * @param exp
	 *            Expression for which the result should be calculated and set
	 *            to the value of the result field.
	 * @see {@link Calculator}, {@link Exercise2_1Activity#result}
	 */
	private void calculateAndSetResult(String exp) {
		try {
			Calculator calc = new Calculator(Exercise2_1Activity.this);
			double res = calc.calculateResultFromString(exp);
			result.setText("= " + String.valueOf(res));
		} catch (Exception e) {
			result.setText(e.getMessage());
		}
	}

}
