package androidlab.exercise2_1;

import java.util.Collections;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.content.Context;

/**
 * <h2>Calculator class</h2>
 * 
 * This class provides the functionality to evaluate an arithmetic expression
 * which is given as a {@link String}. For that purpose you should create an
 * instance of the Calculator class and invoke the method
 * {@link Calculator#calculateResultFromString(String)}. The evaluation includes
 * the main operations addition {@link Calculator#PLUS}, subtraction
 * {@link Calculator#MINUS}, division {@link Calculator#DIV} and multiplication
 * {@link Calculator#TIMES} for real numbers. Also the evaluation can handle
 * parentheses ({@link Calculator#LEFT_PARENTHESIS},
 * {@link Calculator#RIGHT_PARENTHESIS}). The class uses the context
 * {@link Calculator#context} of the application to access to the exception
 * messages from the string resource ({@code res/values/string.xml}) which are
 * thrown when the calculator is not able to solve the expression (e.g. when a
 * number is not accurate formatted, when the parentheses are incorrect or when
 * the equation contains invalid operations).
 * <hr />
 * For the evaluation of an expression a stack variant is used (see
 * {@link Calculator#calculateResultFromString(String)}. Each subexpression
 * which is surrounded by parentheses will be evaluate recursively.
 * 
 * @see {@link Exercise2_1Activity}
 * @author Seminar 'Introduction to Android Smartphone Programming', University
 *         of Freiburg
 * @version 1.0
 **/
public class Calculator {

	/** Definition of the addition character. */
	private static char PLUS = "+".charAt(0);
	/** Definition of the subtraction character. */
	private static char MINUS = "-".charAt(0);
	/** Definition of the multiplication character. */
	private static char TIMES = "*".charAt(0);
	/** Definition of the division character. */
	private static char DIV = "/".charAt(0);
	/** Definition of the left parenthesis character. */
	private static char LEFT_PARENTHESIS = "(".charAt(0);
	/** Definition of the right parenthesis character. */
	private static char RIGHT_PARENTHESIS = ")".charAt(0);
	/** Definition of the decimal point character */
	private static char POINT = ".".charAt(0);
	/**
	 * The context {@link Context} of the application so that the calculator can
	 * access to the string resource ({@code res/values/string.xml}). This
	 * access is needed for the thrown exceptions so that the language of the
	 * messages depends on the system language.
	 **/
	private Context context;

	/**
	 * Constructor of the Calculator class which needs the given context for
	 * accessing to the string resource.
	 * 
	 * @param context
	 *            The Context in which this class should calculate an equation.
	 */
	public Calculator(Context context) {
		this.context = context;
	}

	/**
	 * Method calculates the result of an arithmetic expression that is given as
	 * {@link String}. The return value is of type {@link double} if the given
	 * expression is a valid arithmetic expression, otherwise the method will
	 * throw an exception. This exception contains as message the reason why the
	 * calculator can not solve the equation. The first step of the method to
	 * solve the given expression is checking whether the expression is valid or
	 * not (valid expression start ({@link Calculator#checkStart(String)})?,
	 * valid expression end ({@link Calculator#checkEnd(String)})?, is the
	 * bracketing correct ({@link Calculator#checkParenthesis(String)})? and are
	 * there invalid operations ({@link Calculator#checkOperators(String)})?).
	 * The second step is the real calculation of the expression which is done
	 * by using a stack variant. This means that each character of the given
	 * string is read from left to right and depending on the state of the
	 * method ("Did the method read a operator right before the current
	 * character?", "Did the method read a negativ sign right before the current
	 * character") and the current read character it will do following:
	 * <ul>
	 * <li>Current character is digit, a decimal point as well as the current
	 * character is a minus and the method read a operator right before: the
	 * character will be added to a temporary string which will parsed to a
	 * double value when the next operator character occurs or at the end when
	 * all characters are read.</li>
	 * <li>Current character is a left parenthesis: calculate the subexpression
	 * inside the parentheses recursively, store the result in the temporary
	 * string and jump with the reading to the character right after the closing
	 * right parenthesis.</li>
	 * <li>Current character is an operator: Parse the temporary string to a
	 * double value and do a division or a multiplication with this value and
	 * the value on the top of the number stack, when the top of the operator
	 * stack is such an operation and if the number stack contains values.
	 * Otherwise push the number value as well as the new operator on the top of
	 * the corresponding stack.</li>
	 * </ul>
	 * When the last character was read the method will also do a division or a
	 * multiplication if such an operator is on the top of the operator stack.
	 * Finally both stack will be reversed and the remaining operations (only
	 * addition and subtraction) will be done. The resulting value on the number
	 * stack is the result of the expression.
	 * 
	 * @param exp
	 *            Numeric expression as {@link String} for which the result
	 *            should be calculated.
	 * @return The result of the given equation as double value. If there exists
	 *         no equation for which the result should be calculated, e.g. the
	 *         given sting is equal to "", the method will return {@literal 0.0}
	 *         .
	 * @throws ArithmeticException
	 *             Throws this exception if the expression is invalid.
	 * @throws NumberFormatException
	 *             Throws this exception if an expected number can not be parsed
	 *             to a double value.
	 */
	public double calculateResultFromString(String exp)
			throws ArithmeticException, NumberFormatException {
		Stack<Double> numbers = new Stack<Double>();
		Stack<String> operators = new Stack<String>();
		StringBuilder temp = new StringBuilder();
		boolean lastSeqOP = true;
		boolean lastSeqSI = false;
		if (!checkStart(exp))
			throw new ArithmeticException(
					context.getString(R.string.exception_wrongstart));
		if (!checkEnd(exp))
			throw new ArithmeticException(
					context.getString(R.string.exception_wrongend));
		if (!checkParenthesis(exp))
			throw new ArithmeticException(
					context.getString(R.string.exception_wrongparenthesis));
		if (!checkOperators(exp))
			throw new ArithmeticException(
					context.getString(R.string.exception_wrongoperations));
		for (int i = 0; i < exp.length(); i++) {
			char current = exp.charAt(i);
			boolean shouldAddToTemp_digit = Character.isDigit(current);
			boolean shouldAddToTemp_point = current == POINT;
			boolean shouldAddToTemp_negativSign = current == MINUS && lastSeqOP
					&& !lastSeqSI;
			boolean shouldAddToTemp_resultOfParenthesis = current == LEFT_PARENTHESIS;
			if (shouldAddToTemp_digit || shouldAddToTemp_point
					|| shouldAddToTemp_negativSign
					|| shouldAddToTemp_resultOfParenthesis) {
				if (shouldAddToTemp_resultOfParenthesis) {
					int closingParenthesis = getIndexOfClosingRightParenthesis(
							exp, i);
					temp.append(calculateResultFromString(exp.substring(i + 1,
							closingParenthesis)));
					i = closingParenthesis;
				} else {
					temp.append(String.valueOf(current));
				}
				lastSeqOP = false;
				if (shouldAddToTemp_negativSign) {
					lastSeqSI = true;
				} else {
					lastSeqSI = false;
				}
			} else if (isOperator(current)) {
				if (temp.length() != 0) {
					Double newResult = parseStringToDouble(temp.toString());
					temp.delete(0, temp.length());
					if (!operators.isEmpty()) {
						String lastOp = operators.pop();
						if (numbers.size() > 0
								&& isLastOperatorTimesOrDiv(lastOp)) {
							Double lhs = numbers.pop();
							newResult = calculateBinaryOperation(lastOp, lhs,
									newResult);
						} else {
							operators.push(lastOp);
						}
					}
					operators.push(String.valueOf(current));
					numbers.push(newResult);
				}
				lastSeqOP = true;
				lastSeqSI = false;
			} else if (current == RIGHT_PARENTHESIS) {
				throw new ArithmeticException(
						context.getString(R.string.exception_noleftparenthesis));
			} else {
				throw new ArithmeticException(
						context.getString(R.string.exception_unexpectedsign));
			}
			if (i == exp.length() - 1) {
				Double newResult = parseStringToDouble(temp.toString());
				temp.delete(0, temp.length());
				if (!operators.isEmpty()) {
					String lastOp = operators.pop();
					if (numbers.size() > 0 && isLastOperatorTimesOrDiv(lastOp)) {
						Double lhs = numbers.pop();
						newResult = calculateBinaryOperation(lastOp, lhs,
								newResult);
					} else {
						operators.push(lastOp);
					}
				}
				numbers.push(newResult);
			}
		}
		Collections.reverse(operators);
		Collections.reverse(numbers);
		while (!operators.isEmpty()) {
			Double lhs = numbers.pop();
			Double rhs = numbers.pop();
			String op = operators.pop();
			numbers.push(calculateBinaryOperation(op, lhs, rhs));
		}
		try {
			return numbers.firstElement();
		} catch (Exception e) {
			return 0.0;
		}
	}

	/**
	 * Checks whether the given character is an arithmetic operator ("-", "+",
	 * "/" or "*").
	 * 
	 * @param character
	 *            Character which should be checked whether it is an operator.
	 * @return {@code true} if the given character is one of the following: "-",
	 *         "+", "/" or "*" otherwise {@code false}.
	 */
	private boolean isOperator(char character) {
		return character == PLUS || character == MINUS || character == DIV
				|| character == TIMES;
	}

	/**
	 * Calculates the result as {@link Double} value for the binary operation,
	 * which is given by the given operator and the two given operands. If the
	 * operator is not one of "+", "-", "/" or "*" the method throws an
	 * exception.
	 * 
	 * @param operator
	 *            The operator for the binary operation ("+", "-", "/" or "*").
	 * @param lhs
	 *            The operand on the left hand side of the binary operation.
	 * @param rhs
	 *            The operand on the right hand side of the binary operation.
	 * @return Returns the result of the binary operation.
	 * @throws ArithmeticException
	 *             Throws if the operator is "/" and the right hand side is
	 *             {@literal 0}, or if the operator is not one of "+", "-", "/"
	 *             or "*".
	 */
	private Double calculateBinaryOperation(String operator, Double lhs,
			Double rhs) throws ArithmeticException {
		if (operator.equals(String.valueOf(MINUS))) {
			return Double.valueOf(lhs.doubleValue() - rhs.doubleValue());
		} else if (operator.equals(String.valueOf(PLUS))) {
			return Double.valueOf(lhs.doubleValue() + rhs.doubleValue());
		} else if (operator.equals(String.valueOf(TIMES))) {
			return Double.valueOf(lhs.doubleValue() * rhs.doubleValue());
		} else if (operator.equals(String.valueOf(DIV))) {
			if (rhs.doubleValue() == 0.0)
				throw new ArithmeticException(
						context.getString(R.string.exception_divbyzero));
			return Double.valueOf(lhs.doubleValue() / rhs.doubleValue());
		} else {
			throw new ArithmeticException(
					context.getString(R.string.exception_unexpectedop));
		}
	}

	/**
	 * Checks whether the given {@link String} is one of "*" and "/".
	 * 
	 * @param str
	 *            String for which the method checks the equality to "/" and
	 *            "*".
	 * @return {@code true} if the given String is "*" or "/".
	 */
	private boolean isLastOperatorTimesOrDiv(String str) {
		return str.equals(String.valueOf(TIMES))
				|| str.equals(String.valueOf(DIV));
	}

	/**
	 * Method which returns the index of the closing right parenthesis which
	 * corresponds to the left parenthesis that is located at the given index in
	 * the given expression. E.g. the method will return {@literal 4} if the
	 * parameters are {@literal "(1+2)"} and {@literal 0}, or it will return
	 * {@literal 7} if the parameters are {@literal "(1+(1+1))"} and
	 * {@literal 3}.
	 * 
	 * @param exp
	 *            Expression in which a left parenthesis is located at the given
	 *            index and where also a right parenthesis exists which is the
	 *            closing parenthesis for the left one.
	 * @param indexLeftParenthesis
	 *            Index of the left parenthesis for which the index of the
	 *            corresponding right parenthesis should be returned.
	 * @return Returns the index of the right parenthesis which corresponds to
	 *         the left parenthesis at the given index in the given expression.
	 * @throws ArithmeticException
	 *             Will be thrown if the given expression does not contain the
	 *             corresponding right parenthesis.
	 */
	private int getIndexOfClosingRightParenthesis(String exp,
			int indexLeftParenthesis) throws ArithmeticException {
		int open = 0;
		for (int i = indexLeftParenthesis; i < exp.length(); i++) {
			char current = exp.charAt(i);
			if (current == LEFT_PARENTHESIS)
				open++;
			else if (current == RIGHT_PARENTHESIS) {
				open--;
				if (open == 0) {
					return i;
				}
			}
		}
		throw new ArithmeticException(
				context.getString(R.string.exception_norightparenthesis));
	}

	/**
	 * This method checks whether the given expression does not contain invalid
	 * operation combination. E.g. does not contain
	 * <ul>
	 * <li>{@literal ++} -> two or more operators right after each other
	 * (excepted {@literal +-}, {@literal /-}, {@literal *-})</li>
	 * </ul>
	 * 
	 * @param exp
	 *            Expression for which should be checked whether it contains
	 *            only valid operation combination.
	 * @return {@code true} if the expression only contains valid operation
	 *         combination, otherwise {@code false}.
	 */
	private boolean checkOperators(String exp) {
		String[] errorPatterns = new String[] { "(\\+|\\*|\\/){2}",
				"(\\+|\\*|\\/|\\-)(\\-){2}", "(\\-)(\\+|\\*|\\/)" };
		for (int i = 0; i < errorPatterns.length; i++) {
			Pattern pattern = Pattern.compile(errorPatterns[i]);
			Matcher matcher = pattern.matcher(exp);
			if (matcher.find())
				return false;
		}
		return true;
	}

	/**
	 * This method checks whether the start of the given expression is valid.
	 * E.g. does not start with
	 * <ul>
	 * <li>{@literal +} -> operator</li>
	 * <li>{@literal .} -> decimal point</li>
	 * <li>{@literal )} -> left parenthesis</li>
	 * </ul>
	 * 
	 * @param exp
	 *            Expression for which should be checked whether the start is
	 *            valid or not.
	 * @return {@code true} if the expression starts not with an operator, a
	 *         decimal point or a right parenthesis, otherwise {@code false}.
	 */
	private boolean checkStart(String exp) {
		String[] errorPatterns = new String[] { "^(\\+|\\*|\\/|\\.|\\))" };
		for (int i = 0; i < errorPatterns.length; i++) {
			Pattern pattern = Pattern.compile(errorPatterns[i]);
			Matcher matcher = pattern.matcher(exp);
			if (matcher.find())
				return false;
		}
		return true;
	}

	/**
	 * This method checks whether the end of the given expression is valid. E.g.
	 * does not end with
	 * <ul>
	 * <li>{@literal +} -> operator</li>
	 * <li>{@literal .} -> decimal point</li>
	 * <li>{@literal (} -> left parenthesis</li>
	 * </ul>
	 * 
	 * @param exp
	 *            Expression for which should be checked whether the end is
	 *            valid or not.
	 * @return {@code true} if the expression ends not with an operator, a
	 *         decimal point or a left parenthesis, otherwise {@code false}.
	 */
	private boolean checkEnd(String exp) {
		String[] errorPatterns = new String[] { "(\\+|\\-|\\*|\\/|\\.|\\()$" };
		for (int i = 0; i < errorPatterns.length; i++) {
			Pattern pattern = Pattern.compile(errorPatterns[i]);
			Matcher matcher = pattern.matcher(exp);
			if (matcher.find())
				return false;
		}
		return true;
	}

	/**
	 * Checks whether the given expression contains only allowed parentheses.
	 * This means that the following samples are not possible:
	 * <ul>
	 * <li>{@literal ()} -> empty</li>
	 * <li>{@literal .(} or {@literal 0(} -> point or a number right in front of
	 * the left parenthesis</li>
	 * <li>{@literal ).} or {@literal )0}-> point or a number right after the
	 * right parenthesis</li>
	 * <li>{@literal (+} -> left parenthesis which is followed by an operator
	 * (excepted minus)</li>
	 * <li>{@literal +)} -> an operator before a right parenthesis</li>
	 * </ul>
	 * The method also checks that the expression contains only correct
	 * bracketing:
	 * <ul>
	 * <li>number of left and right parenthesis is equal</li>
	 * <li>a right parenthesis is only allowed when there exists a left
	 * parenthesis before that right parenthesis and vice versa</li>
	 * </ul>
	 * 
	 * @param exp
	 *            Expression for which the parenthesis should be checked.
	 * @return {@code true} if the given expression is valid (with respect to
	 *         the rules above) otherwise {@code false}.
	 */
	private boolean checkParenthesis(String exp) {
		String[] errorPatterns = new String[] { "\\(\\)", "(\\d|\\.)\\(",
				"\\)(\\d|\\.)", "\\((\\+|\\*|\\/|\\.)",
				"(\\-,\\+|\\*|\\/|\\.)\\)" };
		for (int i = 0; i < errorPatterns.length; i++) {
			Pattern pattern = Pattern.compile(errorPatterns[i]);
			Matcher matcher = pattern.matcher(exp);
			if (matcher.find())
				return false;
		}
		int open = 0;
		for (int i = 0; i < exp.length(); i++) {
			if (open < 0)
				return false;
			char current = exp.charAt(i);
			if (current == LEFT_PARENTHESIS)
				open++;
			if (current == RIGHT_PARENTHESIS)
				open--;
		}
		return open == 0;
	}

	/**
	 * Parse a given string to a {@link Double} value. Therefore the following
	 * rules should be fulfilled:
	 * <ul>
	 * <li>The string can not contain more than one point -> not possible
	 * {@literal 1.1.1}</li>
	 * <li>The string can not contain one or more zero(s) in front of a digit
	 * before the decimal point -> not possible {@literal -01.1}</li>
	 * <li>The string can not contain no digit before the decimal point -> not
	 * possible {@literal -.1}</li>
	 * <li>The string can not contain no digit after the decimal point -> not
	 * possible {@literal -1.}</li>
	 * </ul>
	 * 
	 * @param exp
	 *            Numeric value as {@link String} which should be parsed to a
	 *            {@link Double} value.
	 * @return The {@link Double} value of the given string.
	 * @throws NumberFormatException
	 *             Throws if one of the rules above is not fulfilled or if the
	 *             the method {@link Double#valueOf(String)} can not parse the
	 *             string to a {@link Double} value.
	 */
	private Double parseStringToDouble(String exp) throws NumberFormatException {
		String[] errorPatterns = new String[] { "(\\.\\d*\\.)",
				"^(-)?0+\\d+\\.\\d*", "^(-)?(0)+\\d+", "^(-)?\\.", "\\.$" };
		String[] errorReasons = new String[] {
				context.getString(R.string.exception_multiplepoints),
				context.getString(R.string.exception_realleadingzero),
				context.getString(R.string.exception_intleadingzero),
				context.getString(R.string.exception_realdigitbefore),
				context.getString(R.string.exception_realdigitafter) };
		for (int i = 0; i < errorPatterns.length; i++) {
			Pattern pattern = Pattern.compile(errorPatterns[i]);
			Matcher matcher = pattern.matcher(exp);
			if (matcher.find())
				throw new NumberFormatException(errorReasons[i]);
		}
		return Double.valueOf(exp);
	}
}
