package androidlab.exercise1_2;

import android.os.Bundle;
import android.app.Activity;

import android.widget.TextView;


/**
 * <h1>Example solution - exercise sheet 1 (with multilanguage support)</h1>
 * <h2>Main activity (task 2)</h2>
 * This class is the starting point of the application and inherits of <i>Activity</i> (@see <a href="http://developer.android.com/reference/android/app/Activity.html">Activity</a>).<br>
 * This app should support multiple languages: Therefore you create in the <code>res</code> folder additional <code>values</code> folders <br>
 * which have the ISO country code as suffix separated by a '-' (e.g. <code>values-de</code> or <code>values-it</code>). <br>
 * Each of these folders contain the <code>string.xml</code> file with the corresponding translation (@see <a href="http://developer.android.com/training/basics/supporting-devices/languages.html">Supporting Different Languages</a>).
 * <hr>
 * <b>Tasks:</b>
 * <ol>
 * <li><b>Changing the graphical user interface programmatically:</b><br>
 * Import the <code>android.widget.TextView</code> class (<a href="http://developer.android.com/reference/android/widget/TextView.html">TextView</a>)
 * <br>and add the following lines inside the {@link Exercise1_2Activity#onCreate(Bundle)} implementation:<br>
 * <code>TextView tv = new TextView(this); <br>
 * tv.setText(...);<br>
 * setContentView(tv);<br></code>
 * You have to replace the dots by <code>R.string.hello_code</code> to accessing the value of this string resource or even you can create <br>
 * a new string variable <code>hello</code> which gets the value of the <code>R.string.hello_code</code> resource by the following line:<br>
 * <code>String hello = getResources().getString(R.string.hello_code);</code><br>
 * You might also comment the line <code>setContentView(R.layout.main);</code>. As a result, the layout resource <code>main.xml</code> is not loaded. 
 * </li>
 * <li><b>Changing the graphical user interface by declaration of UI elements in the layout resouce (XML):</b><br>
 * Therefore, the {@link Exercise1_2Activity#onCreate(Bundle)} implementation should contain the fragment <code>setContentView(R.layout.main);</code>.<br>
 * This will load the layout from the resource file <code>main.xml</code> which is stored in the folder <code>res/layout</code>.<br>
 * As described you should change the implementation of this resource and add also a new string resource.
 * </li>
 * </ol>
 * For task 1 & 2 see <a href="http://developer.android.com/guide/topics/ui/declaring-layout.html">Layouts</a>.
 * @author Seminar 'Introduction to Android Smartphone Programming', University of Freiburg 
 * @version 1.0
 */
public class Exercise1_2Activity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        /**
         * Task 2.3 (toggle comment for enable/disable):
         * Changing the GUI by using the programmatical way. Therefore a new <i>TextView</i> object is created 
         * and the text of this view object is setted to the value of the string resource 'hello_code'. Finally the the UI element is placed in the window
         * by calling {@link Exercise1_2Activity#setContentView(android.view.View)}.
         * For handling different languages see: <a href="http://developer.android.com/training/basics/supporting-devices/languages.html">Supporting Different Languages</a>
         */
//        //setContentView(R.layout.main);
//        TextView tv1 = new TextView(this); 
//        tv1.setText(R.string.hello_code);
//        setContentView(tv1);
        /**
         * OR
         */
//        //setContentView(R.layout.main);
//        TextView tv2 = new TextView(this);
//        String hello = getResources().getString(R.string.hello_code);
//        tv2.setText(hello);
//        setContentView(tv2);
        
        
        /**
         * Task 2.4 (toggle comment for enable/disable):
         * Changing the GUI by using the XML-based layout resource <code>main.xml</code>.
         * This layout contains a <i>TextView</i> including a reference to the string resource 'hello' 
         * (which is added to the file <code>res/values/string.xml</code>). The value of this string is 'Hello Android!'.
         */
        setContentView(R.layout.main);
        
        
    }
}
