######################################################################
## visible code

import math
import random
import string

######################################################################
## student code

def foo(x: int):
    pass

