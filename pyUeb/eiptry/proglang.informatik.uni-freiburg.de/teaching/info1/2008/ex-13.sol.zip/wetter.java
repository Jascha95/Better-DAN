class TemperatureRange{
  
  int high ;  // Maximaltemeratur
  int low;    // Minimaltemperatur
  
  TemperatureRange(int high, int low){
    this.high = high;
    this.low = low;
  }
}

class Date{
  
  int day;    // Tag (1-31)
  int month;  // Monat (1-12)
  int year;   // Jahr (vierstellig)
  
  Date(int day, int month, int year){
    this.day = day ;
    this.month = month ;
    this.year = year ;
  }
}

class WeatherRecord{
  
  Date d;                  // Datum
  TemperatureRange today;  // TemperaturRange heute
  TemperatureRange normal; // Durchschnittstemperatur dieses Tages (Range)
  TemperatureRange record; // Maximal gemessene TemperaturRange dieses Tages
  
  WeatherRecord(Date d, TemperatureRange today,
                TemperatureRange normal, TemperatureRange record){
    this.d = d;                 
    this.today = today;  
    this.normal = normal; 
    this.record = record; 
  }
  
}

/* Kopieren Sie diese Definitionen in das 
 * Interaktive Fenster (oder kapseln Sie sie in einer Methode) */

/*
WeatherRecord e = new WeatherRecord (new Date (5,6,2003), new TemperatureRange(1,2), new TemperatureRange(3,4), new TemperatureRange(5,6) );
Date d = new Date (5,6,2003) ;
WeatherRecord e1 = new WeatherRecord (d, new TemperatureRange(1,2), new TemperatureRange(3,4), new TemperatureRange(5,6) );
*/