class Apple {
  int x;
  int y;
  int RADIUS = 5;
  int G = 10;     // meters per second square

  Apple(int x, int y) {
    this.x = x;
    this.y = y;
  }
}

/* Kopieren Sie diese Definitionen in das 
 * Interaktive Fenster (oder kapseln Sie sie in einer Methode) */

/*
Apple a1 = new Apple(5,3);
Apple a2 = new Apple(0,-3);
Apple a3 = new Apple(-1,2341978);
*/