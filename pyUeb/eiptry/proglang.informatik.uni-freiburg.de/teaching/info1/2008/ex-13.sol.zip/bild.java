class Image {

  int height;     // pixels
  int width;      // pixels
  String source;  // file name 
  String quality; // informal

  Image(int heigth, int width, String source, String quality){
    this.height = height;
    this.width = width;
    this.source = source;
    this.quality = quality;
  }
  
}

