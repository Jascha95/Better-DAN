class Book{

  String title;    // Titel
  double price;    // Preis in Eur
  String author;   // Autor(en)
  String language; // Sprache(n)
  int year;        // Erscheinungsjahr
  
  Book(String title, double price, String author,
       String language, int year){
    this.title = title ;
    this.price = price ;
    this.author = author ;
    this.language = language ;
    this.year = year ;
  }
  
}

/* Kopieren Sie diese Definitionen in das 
 * Interaktive Fenster (oder kapseln Sie sie in einer Methode) */

/*
Book b1 = new Book("So Long and Thanks for all the Fisch",
                   8.45, "Douglas Adams", "English", 1984);
Book b2 = new Book("Die Leber wächst mit ihren Aufgaben. Kurioses aus der Medizin",
                   9.95, "Eckart von Hirschhausen", 2008);
Book b3 = new Book("Für jede Lösung ein Problem", 
                   7.95, "Kerstin Gier", "Deutsch", 2007);
Book b4 = new Book("De bello Gallico", 
                   12.80, "Caesar (Autor), Marieluise Deissmann(Hg./Übersetzung)", 
                   "Lateinisch/Deutsch", 1980);
Book b5 = new Book("Le voyage d'Hector. Ou la recherche du bonheur", 
                   11.95, "Francois Lelord", "Französisch", 2004);
Book b6 = new Book("Star Trek. The Klingon Dictionary: English/Klingon, Klingon/English", 
                   12.99, "Marc Okrand", "Englisch / Klingonisch", 1992);
*/