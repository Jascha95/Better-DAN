(*
 * Usage examples for OCaml coroutines.
 * You will need Oleg Kiselyov's caml-shift package.
*)

#use "ocoro.ml";;

  

(* simple coroutine yielding one value  *)
let example_return_once () =
  let rec return_once_f (k:int) :(int,string,string)cm =
    return (string_of_int k)
  in let return_once_coro = create return_once_f 
  in let x1 = resume return_once_coro 23
  in x1

(* averager coroutine, two instances *)
let example_averager () =
  let averager_f (k:int) : (int,string,string) cm =
    let rec avg n sumk : (int,string,string) cm  =
      yield (string_of_int (sumk/n)) 
      >>= (fun k -> avg (n+1) (sumk + k))
    in avg 1 k
  in let averager1_co = create averager_f 
  in let averager2_co = create averager_f 
  in let x1 = resume averager1_co 1 
  in let x2 = resume averager1_co 3
  in let y1 = resume averager2_co 10
  in let x3 = resume averager1_co 5
  in let y2 = resume averager2_co 30 
  in [x1; x2; x3; y1; y2]


(* tree in-order generator *)

type 'a bin_tree = Leaf | Node of ('a bin_tree * 'a * 'a bin_tree)
let example_tree_inorder_gen () =
  let inorder_f (t: 'a bin_tree) () : (unit,'a option,'a option) cm =
    let rec ino (t: 'a bin_tree) : (unit,'a option,'a option) cm =
      match t with
	| Leaf -> return None
	| Node (t1,x,t2) ->
	    (ino t1) 
	    >> (yield (Some x)) 
	    >> (ino t2) 
    in ino t
  in let tr = 
      Node(
	Node(Leaf,0,Leaf),
	1,
	Node(
	  Node(Leaf,
	       2,
	       Node(Leaf,3,Leaf)),
	  4,
	  Node(
	    Node(Leaf,5,Leaf),
	    6,
	    Node(Leaf,7,Leaf)))) 
  in let inorder_c : int gen = create (inorder_f tr) 
  in (list_of_gen inorder_c)
    
    
    


(* body of a coro which subtracts one and calls its opponent,
   or loses (terminates) if subtracting one results in zero. *)
let cookie_player_f (name:string) (roppo:(int,unit) coro ref) : 
      int -> (int,unit,unit) cm =
    let rec loop n = 
      if n > 1 then 
	(print_string (name^" takes one cookie and leaves "
		       ^(string_of_int (n-1))^" cookies\n") ;
	 (transfer !roppo (n-1)) >>= loop)
      else
	return (print_string (name^" takes the last cookie and loses\n"))
    in loop

(* ernie plays subtraction with bert, twice *)
let example_transfer() = 
  let dummy_c : (int, unit) coro = create (once ()) in    
  let co_bert = ref dummy_c in
  let co_ernie = ref (create (cookie_player_f "ernie" co_bert)) in
    co_bert := (create (cookie_player_f "bert" co_ernie)) ;
    print_string "one game\n";
    resume !co_bert 5 ;
    print_string "and now another game\n";
    resume !co_ernie 3 

(* bert playing subtraction with himself *)
let example_transfer_self() = 
  let dummy_c : (int, unit) coro = create (once ()) in    
  let co_bert = ref dummy_c in
    co_bert := (create (cookie_player_f "bert" co_bert)) ;
    print_string "one game\n";
    resume !co_bert 5 

(* use a generator-filter to delimit a stream of chars into a stream of lines *)
let lines_f (cgen: char gen)  : unit-> (unit, string option, string option) cm =
  let string_append_char s c =
    let n = String.length s in
    let s2 = String.make (1+n) c in
    let () = String.blit s 0 s2 0 n in
      s2
  in
  let rec loop (accu: string) () =
    match resume cgen () with
      | None -> return None
      | Some c -> 
	  if c='\n' then 
	    (yield (Some accu)) >>= (loop "")
	  else
	    loop (string_append_char accu c) ()
  in loop ""
      
let make_lines_gen (cgen: char gen) : string gen =
  create (lines_f cgen)

let example_print_lines () =
  let chars = ['e';'i';'n';'s';'\n';
	       'z';'w';'e';'i';'\n';'\n';
	       'd';'r';'e';'i';'\n'] in
  let cgen = make_list_gen chars in
  let linegen = make_lines_gen cgen in
    iter_gen linegen (fun s -> 
			print_string">>";
			print_string s; 
			print_string"<<\n")


(* repeatedly resuming a returned coroutine. Ouch!
*)
let example_resume_terminated () =
  let onetwo_f () :  (unit,int,int)cm =
    (yield 1) >> (return 2)
  in let onetwo = create onetwo_f
  in let x1 = resume onetwo ()
  in let x2 = resume onetwo ()
  in let x3 = resume onetwo ()
  in let x4 = resume onetwo ()
  in [x1;x2;x3;x4]



(* resume yourself. Ouch! *)

let example_resume_self () =
  let r_the_coro: (int,int)coro ref = ref (create(once 1)) in
  let body_f k : (int,int,int) cm =
    if k <= 1 
    then return 1
    else return ((resume !r_the_coro (k-1)) + (resume !r_the_coro (k-1)))
  in 
  let () = r_the_coro := create body_f in
  let x1 = resume !r_the_coro 4 in
    (* function computing the same *)
  let x2 = let rec f k = if k <= 1 then 1 else (f (k-1) ) + (f (k-1)) in f 4
  in  (x1, x2)

(* Mutual resume-recursion. Ouch! *)
let example_resume_self_indirectly() =
  let r_the_coro: (int,int)coro ref = ref (create(once 1)) in
  let two_f k : (int,int,int) cm =
    print_string "coro two got ";
    print_int k ;
    print_string " and will now resume the first coro\n" ;
    let x = resume !r_the_coro 2 
    in print_string "coro two is back with value " ;
      print_int x ; print_newline ();
      return 4
  in let two_c = create two_f in
  let one_f k : (int,int,int) cm = 
    print_string ("coro one at start. My param is "^(string_of_int k)^". Resuming two with 1.\n") ;
    let x = resume two_c 1 in
      print_string "coro one after resume two. Result is "; 
      print_int x;
      print_string "and now we return 3.\n";
      return 3
  in
  let ()= r_the_coro := create one_f in
    resume !r_the_coro 0 ;;
