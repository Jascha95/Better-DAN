module STMHelpers (safePutStrLn) where

import Control.Concurrent
import System.IO.Unsafe
import System.IO

-- neeeded as the output buffer is shared by all running threads in a non-synchronized way in ghc
safePutStrLn :: String -> IO ()
safePutStrLn s = do
  takeMVar outputLock
  putStrLn s
  hFlush stdout
  putMVar outputLock ()

{-# NOINLINE outputLock #-} 
outputLock :: MVar ()
outputLock = unsafePerformIO (newMVar ()) --(newMVar [0..])
