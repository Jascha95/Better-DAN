{-# LANGUAGE NoImplicitPrelude #-}

module Main where

import Prelude hiding ((>>=),(>>),return,fail)
--import Control.Concurrent.STM
import STM
import Control.Monad
import System.Random
import STMHelpers
import ThreadBarrier
import Control.Concurrent

incrListItems :: [TVar Int] -> Int -> STM s Atomic Atomic ()
incrListItems list tid = 
       let return :: a -> STM s p p a
           return = gret
           --(>>=) ::  STM p q a -> ( a -> STM q r b) -> STM p r b   
           (>>=) = gbind
           --(>>) ::  STM p q a -> STM q r b -> STM p r b
           (>>) ma mb = gbind ma ( \_ -> mb)
       in do
          r <- newRegion
          mapM (\var -> do (val,_) <- readTVar var r  
                           writeTVar var (val+1) ) 
                list 
          return ()
          
             


worker :: [TVar Int] -> Int -> IO ()
worker list tid = do
          sleeptime <- randomIO 
          threadDelay $ max 100 (sleeptime `div` 10000)   
          atomically $ incrListItems list tid
          safePutStrLn ("Worker "++ show tid++ " finished ")
                    
          
main :: IO ()
main = do list <- atomically $ mapM (\_ -> newTVar 0) [0..127] 
          mapM_ (\n -> forkChild $ do{ worker list n} ) [0..15]
          waitForChildren
          putStrLn "ListTwi finished."
          return ()



