module Main where

import Control.Concurrent
--import Control.Concurrent.STM
import STM
import Control.Monad
import System.Random
import STMHelpers

type Account = TVar Double
type Bank = [Account]
type Name = Int
type TransCounter = TVar Int

setBalance :: Account -> Double -> STM Atomic Atomic ()
setBalance acc value = writeTVar acc value

getBalance :: Account -> STM Atomic Atomic Double
getBalance acc = readTVar acc

transferMoney :: Bank -> Int -> Int -> Double -> TransCounter -> STM Twi Twi ()
transferMoney bank source sink amount =
  do v <- getBalance $ bank!!source
     setBalance (bank!!source) (v - amount)
     w <- getBalance $ bank!!sink
     setBalance (bank!!sink) (w + amount)
     
     

clerk :: Name -> Bank -> Int -> TransCounter -> IO ()
clerk n bank accs counter = do 
           s <- randomIO 
           let sink = s `mod` accs
           s <- randomIO 
           let source = s `mod` accs
           s <- randomIO
           let amount = fromInteger $ s `mod` 1000 
           atomically (transferMoney bank source sink amount counter)
           safePutStrLn $ "Mitarbeiter " ++ (show n) ++ " transferiert von " ++ (show source) ++ " nach " ++ (show sink)
           threadDelay 100000
           clerk n bank accs counter

           

checkSum :: Bank -> STM Atomic Atomic Double
checkSum bank = do s <- sequence $ map readTVar bank
                   return $ sum s

checkSumPeriodically :: Bank -> IO ()
checkSumPeriodically bank = do sum <- atomically (checkSum bank)
                               safePutStrLn $ "Gesamtsumme: " ++ (show sum)
                               threadDelay 10000
                               checkSumPeriodically bank

main :: IO ()
main = do let numberOfAccounts = 8
          bank <- sequence $ [newTVarIO 1000.0 | _ <- [0..(numberOfAccounts - 1) ]] 
          counter <- newTVarIO 0
          mapM_ (\n -> forkIO (clerk n bank numberOfAccounts counter)) [0..3]
          forkIO (checkSumPeriodically bank)
          threadDelay 10000000
          return ()

