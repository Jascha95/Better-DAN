#!/bin/sh

#bench what?
stm=base

if [ $stm = "twi" ]; then
  what=STM
else if [ $stm = "base" ]; then
  what=BaselineSTM
else if [ $stm = "serial" ]; then
  what=SerializedSTM
else
  echo "wrong choice!"
  what=FormatHarddisk
fi
fi
fi

rm -f Bench.o Bench.hi bench

# Serialized benchmark
sed "s/import STM$/import $what/" Bench.in | sed "s/xxxxx/$stm/" > Bench.hs
ghc -O2 -threaded --make Bench.hs -o bench
./bench +RTS -N2

