{-# LANGUAGE NoImplicitPrelude #-}

module Main where

import Prelude hiding ((>>=),(>>),return,fail)
import Control.Concurrent
--import Control.Concurrent.STM
import STM
import Control.Monad
import System.Random
import STMHelpers
import ThreadBarrier

incrListItems :: [TVar Int] -> [TVar Int] -> Int -> STM s Atomic Safe ()
incrListItems list1 list2 tid = 
       let return :: a -> STM s p p a
           return = gret
           --(>>=) ::  STM s p q a -> ( a -> STM s q r b) -> STM s p r b   
           (>>=) = gbind
           --(>>) ::  STM s p q a -> STM s q r b -> STM s p r b
           (>>) ma mb = gbind ma ( \_ -> mb)
       in do
          r1 <- newRegion
          mapM_ (\var -> do (val,_) <- readTVar var r1  
                            writeTVar var (val+1)) 
               list1 
          

          r2 <- newRegion
          mapM_ (\var -> do (val,_) <- readTVar var r2  
                            writeTVar var (val+1)) 
               list2 
          twilight 
          
          --unsafeTwiIO $ safePutStrLn $ "Worker "++ show tid ++ " reached twilight block!"
          check <- isInconsistent r1 
          --unsafeTwiIO $ safePutStrLn $ "Worker "++ show tid ++ " tested for inconsistencies!"
                   
          if (not check)
             then do unsafeTwiIO $ safePutStrLn $ "Worker "++ show tid ++ " might restart!"   
                     tryCommit
              
             else do
              --unsafeTwiIO $ safePutStrLn $ "Worker "++ show tid ++ " found inconsistencies!"             
              reload
              list' <- getInconsistencies r1
              --unsafeTwiIO $ safePutStrLn $ "Worker "++ show tid ++ " reloaded!"
           
              mapM (\(rvar,wvar) -> do val <- rereadTVar rvar 
                                       case wvar of
                                          Just var -> rewriteTVar var (val+1)
                                          Nothing -> error "This cannot happen!")
                   list'  
              safeTwiIO $ safePutStrLn ("Worker "++ show tid++ " had to reload, but will not restart ")
             


worker :: [TVar Int] -> [TVar Int] -> Int -> IO ()
worker list1 list2 tid = do
          sleeptime <- randomIO 
          threadDelay $ max 100 (sleeptime `div` 10000)   
          atomically $ incrListItems list1 list2 tid
                    
          
main :: IO ()
main = do list1 <- atomically $ mapM (\_ -> newTVar 0) [0..127] 
          list2 <- atomically $ mapM (\_ -> newTVar 0) [0..15] 
          mapM_ (\n -> forkChild $ do{ worker list1 list2 n} ) [0..7]
          waitForChildren          
          putStrLn "ListTwi finished."
          return ()



