{-# LANGUAGE NoImplicitPrelude #-}

module Main where

import Prelude hiding ((>>=),(>>),return,fail)
import Control.Concurrent
--import Control.Concurrent.STM
import BaselineSTM
import Control.Monad
import System.Random
import STMHelpers
import ThreadBarrier
import Criterion.Main
import Criterion.Config
import qualified Criterion.MultiMap as M
import Control.Concurrent.QSem

testname :: String
testname = "base"

jobs :: Int
jobs = 32

incrListItems :: [TVar Int] -> Int -> STM s Atomic Safe ()
incrListItems list1 tid = 
       let return :: a -> STM s p p a
           return = gret
           --(>>=) ::  STM s p q a -> ( a -> STM s q r b) -> STM s p r b   
           (>>=) = gbind
           --(>>) ::  STM s p q a -> STM s q r b -> STM s p r b
           (>>) ma mb = gbind ma ( \_ -> mb)
       in do
          r1 <- newRegion
          
          start <- unsafeTwiIO $ randomRIO (0,100)
          
          mapM_ (\var -> do (val,_) <- readTVar var r1
                            writeTVar var (val+1)) 
               (take 10 (drop start list1))
          
          -- unsafeTwiIO $ putStrLn (show tid)
          -- unsafeTwiIO $ threadDelay 100
          twilight 
          
          check <- isInconsistent r1
          if (not check)
             then tryCommit
             else do
              reload
              list' <- getInconsistencies r1
              mapM (\(rvar,wvar) -> do val <- rereadTVar rvar 
                                       case wvar of
                                          Just var -> rewriteTVar var (val+1)
                                          Nothing -> error "This cannot happen!")
                   list'
              return ()


worker :: Int -> [TVar Int] -> Int -> IO ()
worker reps list1 tid = do
          -- sleeptime <- randomIO
          -- threadDelay $ max 100 (sleeptime `div` 10000)
          sequence_ $ replicate reps $ atomically $ incrListItems list1 tid

onerun :: Int -> IO ()
onerun n
       = do s1 <- newQSem 0
            s2 <- newQSem 0
            list1 <- atomically $ mapM (\_ -> newTVar 0) [0..100]
            let jobsize = jobs `div` n
            mapM_ (\i -> forkChild s1 s2 $ do{ worker jobsize list1 i} ) [0..(n-1)]
            
            -- run the children
            sequence_ $ replicate n (signalQSem s2)
            
            -- wait for the children
            sequence_ $ replicate n (waitQSem s1)
  where
    forkChild s1 s2 action
      = forkIO (waitQSem s2 >> action >> signalQSem s1)


myConfig = defaultConfig {
              cfgPlot = M.singleton KernelDensity CSV
            }

main :: IO ()
main = defaultMainWith myConfig (return ())
  [ bgroup ("list-" ++ testname) $ map (\n -> bench ("t"++ show n) (onerun n)) [4,8,16]
  ]
