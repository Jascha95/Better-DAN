module Main where

import Control.Concurrent
--import Control.Concurrent.STM
import STM
import Control.Monad
import System.Random
import STMHelpers
import ThreadBarrier

worker :: TVar Int -> STM s Atomic Atomic Int
worker counter = 
          newRegion `gbind` \r ->
          readTVar counter r `gbind` \(pos,_) -> 
          writeTVar counter (pos+1) `gbind` \_ ->
          gret pos  
          
workerOut :: TVar Int -> Int -> IO ()
workerOut counter tid = do
          x <- atomically $ worker counter
          sleeptime <- randomIO 
          threadDelay $ sleeptime `mod` 1000
                    
          safePutStrLn $ "Worker " ++ show tid ++ ": " ++ show x          
          
main :: IO ()
main = do let numberOfAccounts = 8
          counter <- newTVarIO 0
          mapM_ (\n -> forkChild $ workerOut counter n ) [0..7]
          waitForChildren
          return ()

