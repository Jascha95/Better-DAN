
module Main where

import Control.Concurrent
--import Control.Concurrent.STM
import STM
import Control.Monad
import System.Random
import STMHelpers

type Gabel = TVar Bool
type Gabeln = [Gabel]

tisch :: Int -> STM Atomic Atomic Gabeln
tisch groesse =
  replicateM groesse (newTVar True)

essen :: Int -> Gabeln -> IO ()
essen n tisch = 
  do safePutStrLn $ "Philosoph " ++ (show n) ++ " hat Hunger"
     atomically (holeGabeln n tisch)
     safePutStrLn $ "Philosoph " ++ (show n) ++ " isst"
     randomIO >>= (\n -> threadDelay (n `mod` 1000))
     atomically (legeGabeln n tisch)

holeGabeln :: Int -> Gabeln -> STM Atomic Atomic ()
holeGabeln n tisch =
  do holeGabel n tisch
     holeGabel ((n + 1) `mod` (length tisch)) tisch

holeGabel :: Int -> Gabeln -> STM Atomic Atomic ()
holeGabel n tisch =
  do liegt <- readTVar (tisch !! n)
     if liegt then
       writeTVar (tisch !! n) False
      else retry

legeGabeln :: Int -> Gabeln -> STM Atomic Atomic ()
legeGabeln n tisch =
  do writeTVar (tisch !! n) True
     writeTVar (tisch !! ((n + 1) `mod` (length tisch))) True

denken :: Int -> IO () 
denken n =
  do safePutStrLn $ "Philosoph " ++ (show n) ++ " denkt"
     randomIO >>= (threadDelay . (`mod` 1000))

philosoph :: Int -> Gabeln -> IO ()
philosoph n tisch =
  do denken n
     essen n tisch
     philosoph n tisch
     yield



main :: IO ()
main =
  do t <- atomically (tisch 5)
     mapM_ (\n -> forkIO (philosoph n t)) [0..3] --mapM_ :: Monad m => (a -> m b) -> [a] -> m ()
     threadDelay 1000000
     return ()

