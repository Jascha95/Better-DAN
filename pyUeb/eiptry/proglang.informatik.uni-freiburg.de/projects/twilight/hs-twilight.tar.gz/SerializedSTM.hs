{-# LANGUAGE NoImplicitPrelude #-}
{-# OPTIONS -fglasgow-exts #-}
module SerializedSTM
           (STM, TVar, newTVar, newTVarIO, readTVar, writeTVar,
            atomically,retry, Atomic, Twi, Safe, gbind, gret,twilight,getInconsistencies, isInconsistent,
            reload,safeTwiIO, rewriteTVar, rereadTVar,unsafeTwiIO,newRegion,tryCommit) where

--
-- Single-global lock implementation of Twilight
--



-- for ghc
import Prelude hiding (mapM_)
import Counter
import Semaphore
import STMHelpers
import Control.Concurrent.MVar
import Data.IORef
import qualified Data.IntMap as Map 
import Data.Maybe
import Unsafe.Coerce
import Monad hiding (mapM_)
import Data.Foldable (mapM_)
import System.IO.Unsafe

import Control.VarStateM hiding (unlock)
-----------------------

-- The STM interface --
-----------------------

type Id = Int
data AccessFlag = W | WR | R deriving (Show,Eq)
data Twi = Twi 
data Atomic = Atomic 
data Safe = Safe
data Status = Ok [IO ()] | Bad [IO ()] | NotChecked
data Checked = Incons | Cons 

-- Mutex
type Mutex = MVar Int
{-# NOINLINE mutexRef #-} 
mutexRef :: Mutex
mutexRef = unsafePerformIO (newMVar 0)


-- The STM monad 

data STM r p q a = STM { internal :: IO a }

instance Monad (STM r p q) where
    return x = STM (return x)
    (STM m) >>= f = STM (m >>= internal . f)


-- parametrized/indexed monad we use to distinguish between atomic and twilight operations

instance Monadish (STM r) where
    gret = return
    gbind = unsafeCoerce orig_bind where
          orig_bind :: STM r p q a -> (a -> STM r p q b) -> STM r p q b 
          orig_bind = (>>=)

atomically :: (forall s . STM s p q a) -> IO a
atomically stm
  = case stm of
      STM action -> catch (serialized action) (const (atomically stm))

serialized :: IO a -> IO a
serialized action = withMVar mutexRef (const action)

retry :: STM r p q  a
retry = STM (ioError (userError "restart!"))


newTVar :: a -> STM r p p (IORef a)
newTVar x = STM (newIORef x)

writeTVar :: Show a => TVar a -> a -> STM r Atomic Atomic (WTwiVar a)
writeTVar tvar x = STM (writeIORef tvar x >> return tvar)

readTVar :: Show a => TVar a -> Region r a -> STM r Atomic Atomic (a, RTwiVar a)
readTVar tvar reg = STM (readIORef tvar >>= \x -> return (x, tvar))

is :: RTwiVar a -> TVar a -> Bool 
is _ _ = False


-- Twilight extra API
twilight :: STM r Atomic Twi Bool
twilight =  STM (return True)

rewriteTVar :: Show a => WTwiVar a -> a -> STM r p p ()
rewriteTVar tvar v = STM (writeIORef tvar v)

rereadTVar :: RTwiVar a -> STM r p p a
rereadTVar tvar = STM (readIORef tvar)

reload :: STM r Twi Safe ()
reload = STM (return ())

tryCommit :: STM r Twi Safe ()
tryCommit = STM (return ())


safeTwiIO :: IO a -> STM r Safe Safe a
safeTwiIO = unsafeTwiIO
      
unsafeTwiIO :: IO a -> STM r p p a
unsafeTwiIO = STM

getInconsistencies :: Region r a -> STM r Safe Safe [(RTwiVar a,Maybe (WTwiVar a))]
getInconsistencies _ = STM (return [])

isInconsistent :: Region r a -> STM r p p Bool
isInconsistent _ = STM (return False)

type TVar a = IORef a

type RTwiVar a = IORef a
type WTwiVar a = IORef a

newTVarIO :: a -> IO (TVar a)
newTVarIO = newIORef

data Region r a = Region

newRegion :: STM r Atomic Atomic (Region r a)
newRegion = STM (return Region)

--- Tests
main :: IO ()
main = do

  q <- atomically $ gret 3
  putStrLn "Empty transaction works\n"
  -- test read
  let val = 89

  y <- atomically $ newTVar val `gbind` \a -> gret a
  putStrLn "Creating new TVars works\n"
          
  x <- atomically $ newRegion `gbind` \r -> readTVar y r  `gbind` \(u,_) -> gret u
  putStrLn $ show x ++ " should be " ++ show val
  --- test write
 
  let new_val = 25
  z <- atomically $ writeTVar y new_val `gbind` \_ -> gret "done"
  putStrLn z
  
  let new_val = 34
  z <- atomically $ newRegion `gbind` \r -> writeTVar y new_val `gbind` \_ -> readTVar y r `gbind` \(u,_) -> gret u
  putStrLn $ show z ++ " should be " ++ show new_val

  --- test write
  let new_val = 78
  z <- atomically $ newRegion `gbind` \r -> writeTVar y new_val `gbind` \_ -> readTVar y r `gbind` \(u,_) -> twilight `gbind` \_ -> gret u
  putStrLn $ show z ++ " should be " ++ show new_val
{--
  --- test rewrite
  let v = 7
  w <- atomically $ newRegion `gbind` \r -> writeTVar y new_val `gbind` \y' -> readTVar y r `gbind` \u -> twilight `gbind` \_ -> rewriteTVar y' v `gbind` \_ -> gret v 
  putStrLn $ show w ++ " should be " ++ show v
  
  --}
 
 --  reg <- atomically $ newRegion

 -- a <- atomically $ readTVar y reg

 -- b <- atomically $ readTVar y reg


  return ()
