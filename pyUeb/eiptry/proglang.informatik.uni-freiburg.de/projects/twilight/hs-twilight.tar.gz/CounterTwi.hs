module Main where

import Control.Concurrent
--import Control.Concurrent.STM
import STM
import Control.Monad
import System.Random
import STMHelpers
import ThreadBarrier

worker :: TVar Int -> Int -> IO ()
worker counter tid = do
      sleeptime <- randomIO 
      threadDelay $ sleeptime `mod` 100
      atomically $
          newRegion `gbind` \r ->
          readTVar counter r `gbind` \(pos,rcounter) -> 
          writeTVar counter (pos+1) `gbind` \(wcounter) ->
          twilight `gbind` \_ ->
          reload `gbind` \_ -> 
          safeTwiIO (do {sleeptime <- randomIO; threadDelay $ sleeptime `mod` 100}) `gbind` \_ ->
          getInconsistencies r `gbind` \check -> 
          if (not $ null check) 
                     then    
                       rereadTVar rcounter `gbind` \pos ->
                       rewriteTVar wcounter (pos+1)  `gbind` \_ ->
                       safeTwiIO $ safePutStrLn ("Worker "++ show tid++ " finished after repair at "++ show pos)
                     else safeTwiIO $ safePutStrLn ("Worker "++ show tid++ " finished at position "++ show pos)                                    
      
                    
          
main :: IO ()
main = do counter <- newTVarIO 0
          mapM_ (\n -> forkChild $ do{ worker counter n} ) [0..31]
          waitForChildren
          putStrLn "CounterTwi finished."
          return ()

