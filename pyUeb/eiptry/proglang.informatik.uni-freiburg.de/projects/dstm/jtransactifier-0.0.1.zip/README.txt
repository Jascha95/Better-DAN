                  JTransactifier and Distributed STM
                  ==================================


Distributed STM is an object-based, fully decentralized STM algorithm.

It features:

    * object versioning eliminating read conflicts
    * a randomized consensus protocol
    * easy scalability 

Distributed STM is based on mostly immutable data structures, which
are well-suited for replication and migration. A randomized consensus
protocol guarantees the consistency of the mutable parts. Object
versioning allows transactions to proceed tentatively before the
consensus has been reached. Due to Distributed STM's architecture,
atomic code sections never block during execution. Although this leads
potentially to more rollbacks, a first evaluation shows that the
guaranteed success of reads more than compensates for this effect.

The jtransactifier inserts Java Bytecode instructions for the usage of
dstm in a project.  The projects source code needs to get annotated
with @Atomic on atomic methods and @Transactional on global objects.


Documentation: 
--------------

General information on Distributed STM can be found in the website

        http://proglang/projects/syncstm/

Usage:
------
This .zip archive contains 
     * jtransactifier.zip - the Java Byte code transactifier
  
For loading this into Eclipse use
    -> Import -> General -> Existing Projects into Workspace -> Select archieve file...

The jtransactifier.jar file contains both sources and the compiled binaries.
It includes:
   * dstm.jar - a dstm implementation
   * jtransactifier.jar - the transactifier 
   * asm-all-3.1.jar - a library for bytecode rewriting
   * build.xml - a ant script for automatic building, transactifying 
     and execussion of the project
   * a source folder with an example transcribed from the STAMP benchmark 
     (cf. http://stamp.stanford.edu/)     

Important: The dstm.jar which comes shipped with jtransactifier is at
the moment slightly different from the one that can be downloaded from
the project's webpage!


Further information:
--------------------

Author:      Annette Bieniusa <bieniusa@informatik.uni-freiburg.de>
License:     GPL (see LICENSE.txt)
Bug reports: Send them via email to bieniusa@informatik.uni-freiburg.de
Website:     http://proglang/projects/syncstm/

If you have any questions, feel free to contact me!
Have fun!