open ExtSSet
open ExtSSetImp
open ExtList

module type S = sig
  type 'a t
  type elt
  val create : unit -> 'a t
  val clean : 'a t -> unit
  val visit : ?cmp:(elt -> elt -> bool) -> 'a t -> elt -> (elt -> 'a) -> 'a option
  val visit_u : unit t -> elt -> (elt -> unit) -> unit
  val visit_id : elt t -> elt -> (elt -> elt) -> elt
end

module Make(Ord: OrderedType) : S with type elt = Ord.t = struct

  module Set = Make(Ord)
  type elt = Set.elt
  type 'a t = Set.t * (elt * 'a) list ref

  let create () = Set.create (), ref []
  let clean (set,cache) = 
    Set.clean set;
    cache := [];
    ()

  let visit ?(cmp=(=)) (set,cache) elt f =
    if (not (Set.mem elt set)) then begin
      Set.add elt set;
      let r = f elt in
        cache := (elt,r) :: !cache;
        Some r
    end else begin
      None
        (* List.assoc' ~equal:cmp elt !cache *)
    end

  let visit_u set elt (f : elt -> unit) =
    visit set elt f;
    ()

  let visit_id set elt (f : elt -> elt) =
    match visit set elt f with
      | Some e -> e
      | None -> elt

end

module Test = struct
  
end
