open ProglangUtils
open HiddenInts

include HiddenInts.Make(struct let prefix = "p" end)
