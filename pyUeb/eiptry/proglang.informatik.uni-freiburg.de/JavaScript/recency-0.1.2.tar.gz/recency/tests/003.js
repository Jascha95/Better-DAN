M_[l0] let x = new_l0 in let f = x.a := 42 in
M_[l0] let y = new_l0 in let f = y.a := undefined in
M_[l0] let z = new_l0 in let f = z.a := 20 in 
  x.a
