M_[l0] 
let x = new_l0 in 
let z = x.a := 42 in 
let f = \(u1,u2).x.a in 
  M_[l0] f(0)
