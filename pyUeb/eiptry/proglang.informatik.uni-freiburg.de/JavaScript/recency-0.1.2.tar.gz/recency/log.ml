module type LOGGER = sig
  val pstart : string -> unit
  val pdebug : string -> unit
  val pende : string -> unit
end

module type FULLLOGGER = sig
  include LOGGER
  val calls : string -> ('a -> 'b) -> ('a -> 'b)
end

module NoDebug = struct
  let pstart s = ()
  let pdebug s = ()
  let pende s = ()
end

module DEBUG = struct
  let i = ref 0

  let pstart s =
    if (!i > 15) then exit 1;
    print_endline ((String.make (2 * !i) ' ') ^ "S: " ^ s);
    i := !i + 1

  let pdebug s =
    print_endline ((String.make (2 * !i) ' ') ^ "D: " ^ s)

  let pende s = 
    i := !i - 1;
    print_endline ((String.make (2 * !i) ' ') ^ "E: " ^ s)

end

module Make(L: LOGGER) = struct
  include L
    
  let calls_with_ts s f x ts =
    pstart (s ^ (ts x));
    let r = f x in
      pende (s ^ (ts x));
      r

  let calls s f x =
    calls_with_ts s f x (fun _ -> "")
    
end
