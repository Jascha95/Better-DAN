let version = "0.1.2"

let get_version () = version
