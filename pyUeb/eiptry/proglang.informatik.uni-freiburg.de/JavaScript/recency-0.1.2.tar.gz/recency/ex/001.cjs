let x = new in
let y = x in
let z = y.a := 5 in 
  x.a
