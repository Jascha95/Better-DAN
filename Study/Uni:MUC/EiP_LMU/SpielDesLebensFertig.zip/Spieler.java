import java.util.ArrayList;

/**
 * Kümmert sich um die Vermittlung zwischen Modell und Ansicht,
 * legt fest wann und wie die Spielrunden aufeinander folgen.
 *
 * Hier könnte man auch Möglichkeiten zum Anhalten und Editieren
 * des Spielfeldes nach dem Start gewähren.
 *
 * Zugehörigkeit: Controller
 *
 * @author jost
 * Created Do, 30.November 2017
 */

public class Spieler {
  private Spielfeld spielfeld;
  private Ansicht ansicht;

  public Spieler() {
    this.spielfeld = new Spielfeld();
    this.ansicht = new Ansicht();
  }

  public void initalisieren() {
    // Alle Zellen einmal zeichnen
    for (Zelle zelle : spielfeld.alleZellen()) {
      ansicht.zeichneZelle(zelle);
    }
    // Startpositionen erfragen
    boolean okay = true;
    while (okay) {
      Position pos = ansicht.positionAbfragen();
      okay = spielfeld.positionOk(pos);
      if (okay) {
        spielfeld.zelleUmschalten(pos);
        ansicht.zeichneZelle(spielfeld.getZelle(pos));
      }
    }
  }

  public void starten() {
    for (int i = 0; i < Parameter.RUNDENZAHL; i++) {
      ArrayList<Zelle> änderungen = spielfeld.rundeBerechnen();
      for (Zelle zelle : änderungen) {
        ansicht.zeichneZelle(zelle);
      }
      ansicht.setStatus("Runde: " + i);
      ansicht.sleep(Parameter.VERZÖGERUNG);
    }
  }

}
