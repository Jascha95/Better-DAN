import java.awt.*;

/**
 * Konstanten die wir der Einfachheit nicht vom Benutzer
 * erfragen wollen.
 *
 * Normalerweise würde der Controller bei Spielstart mit Hilfe der View
 * den Benutzer nach der Wunschgröße des Spielfeldes fragen,
 * welche dann eine Instanvariable des Spielfeldes wird.
 *
 * Weiterhin könnte der Controller eine Instanzvariable für die Verzögerung
 * besitzen, welche über einen von der View bereitgestellten Schieberegler
 * vom Benutzer verändert werden kann.
 *
 * Zugehörigkeit: Vermischt.
 * (Da es nur wenige sind, fassen wir hier alle zusammen.)
 *
 * @author jost
 * Created Di, 28.November 2017
 */

public class Parameter {

  // Modell
  public static final int BREITE = 100;
  public static final int HÖHE   = 77;

  // Controller
  public static final int  RUNDENZAHL  = 1000;
  public static final long VERZÖGERUNG = 32;

  // View
  public static final int ZELLENGRÖßE = 9;
  public static final int GITTER      = 1;
  public static final Color FARBE_LEBENDIG = Color.RED;
  public static final Color FARBE_TOT = Color.LIGHT_GRAY;

}
