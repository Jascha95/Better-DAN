/**
 * Live in der Vorlesung
 *    "Einführung in die Programmierung mit Java"
 * programmiertes Beispiel zu Objektorientiertem Design.
 *
 * Wir implementieren Conway's Game of Life. *
 *
 * Zugehörigkeit: Controller
 *
 * @author jost
 * Created Di, 28.November 2017
 * LMU München
 */
public class Main {

  public static void main(String[] args) {
      // Vielleicht sollte die Klasse Spieler in Spiel umbenannt werden...
      Spieler spieler = new Spieler();
      spieler.initalisieren(); // Könnte man auch in den Konstruktor von Spieler verschieben.
      spieler.starten();
      System.exit(0);
  }
}
