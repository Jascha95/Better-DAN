/**
 * Eine unveränderliche Zelle an einer festen Position im Game of Life,
 * welche einen Zustand speichert.
 *
 * Zugehörigkeit: Modell
 *
 * @author jost
 * Created Di, 28.November 2017
 */

public class Zelle {

  public static final int TOT = 99;
  public static final int LEBENDIG = 42;

  private final Position position;
  private final int zustand;

  public Zelle(Position position, int zustand) {
    this.position = position;
    this.zustand  = zustand;
  }

  public Position getPosition() {
    return position;
  }

  public boolean istLebendig() {
    return this.zustand == LEBENDIG;
  }

  public boolean istTot() {
    return this.zustand == TOT;
  }

  // Man braucht eigentlich nicht alle drei, umschalten würde alleine auch reichen.
  public Zelle sterben() {
    return new Zelle(this.position, TOT);
  }

  public Zelle auferstehen() {
    return new Zelle(this.position, LEBENDIG);
  }

  public Zelle umschalten() {
    if (zustand == TOT) {
      return new Zelle(this.position, LEBENDIG);
    } else {
      return new Zelle(this.position, TOT);
    }
  }
}
