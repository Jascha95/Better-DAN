import java.util.ArrayList;

/** Spielfeld für Game of Life
 *
 * Zugehörigkeit: Modell
 *
 * @author jost
 * Created Di, 28.November 2017
 */

public class Spielfeld {

  private ArrayList<ArrayList<Zelle>> spielfeld;
  /* Anmerkung: Verschachtelte Array-Listen sind recht unhandlich.
      Zum Glück beschränkt sich das Problem hier nur auf den Konstruktor
      und die Methoden positionOK(), getZelle(), setZelle(), alleZellen(), da alle
      anderen das spielfeld nur über diese Methoden verwenden.

      Ein 2D Array "Zelle[][]" wäre einfacher in der Handhabung,
      aber arrays sind etwas problematisch, wie wir später sehen werden.

      Vermutlich am Besten wäre der Einsatz eine endlichen Abbildung,
      welche wir erst gegen Ende der Vorlesung noch kennenlernen werden.
   */

  public Spielfeld() {
    spielfeld = new ArrayList<>(Parameter.BREITE); // Erzeugt Array mit size==0
    for (int x = 0; x < Parameter.BREITE; x++){
      ArrayList<Zelle> spalte = new ArrayList<Zelle>(Parameter.HÖHE); // Erzeugt Array mit size==0
      for (int y = 0; y < Parameter.HÖHE; y++) {
        Position p = new Position(x, y);
        Zelle z = new Zelle(p,Zelle.TOT);
        spalte.add(z);  // Neue Element hinzufügen!
      }
      spielfeld.add(spalte); // Neue Spalte hinzufügen!
    }
  }

  public boolean positionOk(Position pos) {
    int x = pos.getX();
    int y = pos.getY();
    if (x < 0 || x >= spielfeld.size()) { return  false; };
    ArrayList<Zelle> spalte = spielfeld.get(x);
    // if (y < 0 || y >= spalte.size()) { return false; } else { return true };
    // Obige Zeile kann man vereinfach zu:
    return !(y < 0 || y >= spalte.size());
    // (Man könnte noch weiter zusammenfassen, so wie in setZelle .)
  }

  public Zelle getZelle(Position pos){
    if (positionOk(pos)) {
      ArrayList<Zelle> spalte = spielfeld.get(pos.getX());
      return spalte.get(pos.getY());
    } else {
      return new Zelle(pos,Zelle.TOT);
    }
  }

  public void setZelle(Zelle zelle){
    Position p = zelle.getPosition();
    // Hier sollte man einfach wieder positionOK(p) verwenden!
    int x = p.getX();
    int y = p.getY();
    if (   x >= 0 && x < spielfeld.size()
        && y >= 0 && y < spielfeld.get(x).size()) {
      ArrayList<Zelle> spalte = spielfeld.get(x);
      spalte.set(y, zelle);
    }
  }

  public ArrayList<Zelle> getNachbarn(Zelle zelle) {
    ArrayList<Zelle> nachbarn = new ArrayList<>(8);
    Position pos = zelle.getPosition();
    for (Position p : pos.getNachbarPositionen()) {
      nachbarn.add(this.getZelle(p));
    }
    return nachbarn;
  }

  public ArrayList<Zelle> rundeBerechnen() {
    ArrayList<Zelle> geänderte = new ArrayList<>();
    for (Zelle z : this.alleZellen()) {
      int lebendeNachbarn = 0;
      for (Zelle nachbar : getNachbarn(z)){
        if (nachbar.istLebendig()) { lebendeNachbarn++; }
      }
      if (z.istLebendig()) {
        if (lebendeNachbarn <= 1 || lebendeNachbarn >= 4 ) {
          geänderte.add(z.sterben());
        }
      } else { // z.istTot()
        if (lebendeNachbarn == 3) {
          geänderte.add(z.auferstehen());
        }
      }
    }
    // Wichtig: erst nachdem wir ALLE Änderungen berechnet haben,
    //    pflegen wir die Änderung in Array ein! Warum?!
    for (Zelle z : geänderte) {
      this.setZelle(z);
    }
    return geänderte;
  }

  public ArrayList<Zelle> alleZellen() {
    ArrayList<Zelle> ergebnis = new ArrayList<>(Parameter.BREITE * Parameter.HÖHE);
    for (ArrayList<Zelle> spalte : this.spielfeld) {
      for (Zelle z : spalte) {
        ergebnis.add(z);
      }
    }
    return ergebnis;
  }

  public void zelleUmschalten(Position pos) {
    Zelle z = this.getZelle(pos);
    this.setZelle(z.umschalten());
  }
}
