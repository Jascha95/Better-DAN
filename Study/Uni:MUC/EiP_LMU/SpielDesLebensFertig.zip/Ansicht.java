import java.awt.*;

/**
 * Kümmert sich um die Darstellung des Spielfeldes.
 * Diese Klasse `kennt' Zellen und kann diese verarbeiten/darstellen.
 * Wichtig: Die Ansicht hat keinen Zustand, der den Ablauf des Spiels beeinflusst.
 *
 * Zugehörigkeit: View
 *
 * @author jost
 * Created Do, 30.November 2017
 */

public class Ansicht {
  private GraphicsWindow fenster;
  private final int GRÖßE = Parameter.ZELLENGRÖßE + Parameter.GITTER;

  public Ansicht() {
    this.fenster = new GraphicsWindow(Parameter.BREITE * GRÖßE, Parameter.HÖHE * GRÖßE);
    this.fenster.setText("Starte...");
  }

  public void setStatus(String s) {
    this.fenster.setText(s);
  }

  public void zeichneZelle(Zelle zelle) {
    Position position = zelle.getPosition();
    int x = position.getX() * GRÖßE;
    int y = position.getY() * GRÖßE;
    Rectangle rechteck = new Rectangle(x,y,Parameter.ZELLENGRÖßE,Parameter.ZELLENGRÖßE);
    if (zelle.istLebendig()) {
      fenster.setColor(Parameter.FARBE_LEBENDIG);
    }
    if (zelle.istTot()) {
      fenster.setColor(Parameter.FARBE_TOT);
    }
    fenster.fill(rechteck);
  }

  public Position positionAbfragen() {
    Point p = fenster.mouseClick();
    int x = (int) p.getX() / GRÖßE;
    int y = (int) p.getY() / GRÖßE;
    return new Position(x,y);
  }

  public void sleep(long l) {
    fenster.sleep(l);
  }

}
